import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PanelModule } from 'primeng/panel';
import { ButtonModule } from 'primeng/button';
import { SplitButtonModule } from 'primeng/splitbutton';
import {
  AccordionModule,
  CalendarModule,
  CheckboxModule,
  DropdownModule,
  InputMaskModule,
  InputTextModule,
  MultiSelectModule,
  OverlayPanelModule,
  PaginatorModule,
  PanelMenuModule,
  PickListModule,
  ProgressSpinnerModule,
  RadioButtonModule,
  TabMenuModule,
  TabViewModule
} from 'primeng/primeng';
import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { ListboxModule } from 'primeng/listbox';
import { DialogModule } from 'primeng/dialog';
import { AppBreadcrumbModule } from './app-breadcrumb/app-breadcrumb.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VirtualScrollerModule } from 'primeng/virtualscroller';
import { AppTableModule } from './app-table/app-table.module';
import { SelectButtonModule } from 'primeng/selectbutton';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { SidebarModule } from 'primeng/sidebar';

const NgPrimeModules = [
  PanelModule,
  ButtonModule,
  SplitButtonModule,
  SelectButtonModule,
  RadioButtonModule,
  TabViewModule,
  TableModule,
  MenuModule,
  TabMenuModule,
  InputTextModule,
  ProgressSpinnerModule,
  CheckboxModule,
  DropdownModule,
  ListboxModule,
  MultiSelectModule,
  InputMaskModule,
  PanelMenuModule,
  OverlayPanelModule,
  AccordionModule,
  PaginatorModule,
  DialogModule,
  PickListModule,
  CalendarModule,
  VirtualScrollerModule,
  ConfirmDialogModule,
  SidebarModule
];

@NgModule({
  exports: [ CommonModule, NgPrimeModules, FormsModule, ReactiveFormsModule, HttpClientModule, AppBreadcrumbModule, AppTableModule ]
})
export class SharedModule {
}
