import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LsrOrderSearchService } from '../services/lsr-order-search.service';
import { RejectedOrderResponse, RejectedOrderGridColumns, GridColumnDetails } from '../order-lsr.constants'

@Component({
  selector: 'app-lsr-reject-order-details',
  templateUrl: './lsr-reject-order-details.component.html',
  styleUrls: ['./lsr-reject-order-details.component.css']
})
export class LsrRejectOrderDetailsComponent implements OnInit {

  public message: string;
  public extOrderId: string;
  // public RejectedOrderDetails: RejectedOrderResponse[] = [];
  public gridColumns: GridColumnDetails[] = RejectedOrderGridColumns;
  public errorResult: RejectedOrderResponse[] = [];


  constructor(private activatedRoute: ActivatedRoute, public lsrOrderSearchService: LsrOrderSearchService,
    private router: Router
  ) { }

  ngOnInit() {
    this.extOrderId = this.activatedRoute.snapshot.params['extOrderId']
    this.getRejectedOrderDetails();
  }
  // goBack() {
  //   this.router.navigate(['/lsr-order/search'])
  // }

  getRejectedOrderDetails() {
    this.lsrOrderSearchService.getRejectOrders(this.extOrderId).subscribe((response: RejectedOrderResponse[]) => {
      this.errorResult = response;
    }, error => this.message = error)
  }

}
