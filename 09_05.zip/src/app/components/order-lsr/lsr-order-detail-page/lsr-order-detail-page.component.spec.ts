import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SharedModule } from '../../../shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { RouterTestingModule } from '@angular/router/testing';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';
import { TnActivitySearchService } from '../../activation-service/services/tn-activity-search.service';
import { ApiService } from '../../../shared/services/api.service';
import { StorageService } from '../../../services/storage.service';
import { UtilityService } from '../../../shared/services/utility.service';
import { LsrOrderDetailPageComponent } from './lsr-order-detail-page.component';

describe('LsrOrderDetailPageComponent', () => {
  let component: LsrOrderDetailPageComponent;
  let fixture: ComponentFixture<LsrOrderDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LsrOrderDetailPageComponent],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        SearchPanelsModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        TnActivitySearchService,
        ApiService,
        StorageService,
        UtilityService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LsrOrderDetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
