import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateLsrDialogComponent } from './update-lsr-dialog.component';

describe('UpdateLsrDialogComponent', () => {
  let component: UpdateLsrDialogComponent;
  let fixture: ComponentFixture<UpdateLsrDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateLsrDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateLsrDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
