import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { UpdateLsrRequest } from '../activation-lsr.constants';
import { UtilityService } from '../../../shared/services/utility.service';

@Component({
  selector: 'app-update-lsr-dialog',
  templateUrl: './update-lsr-dialog.component.html',
  styleUrls: ['./update-lsr-dialog.component.scss']
})
export class UpdateLsrDialogComponent implements OnInit {

  showDialog: boolean = false;
  @Output('onSubmit') onSubmit: EventEmitter<any> = new EventEmitter();
  formTypes: any[] = [
    { name: 'Reject LSR', code: 'REJECT' },
    { name: 'Update FOC and CRD', code: 'UPDATE' }
  ]
  selectedType: any = { name: 'Reject LSR', code: 'REJECT' };
  reasonOptions: any = [
    { selected: 'selected', value: '', label: 'None' },
    { value: 'LOA expired', label: 'LOA expired' },
    { value: 'LOA illegible', label: 'LOA illegible' },
    { value: 'LOA not valid', label: 'LOA not valid' },
    { value: 'Modem lines require LOA', label: 'Modem lines require LOA' },
    { value: 'No Order found', label: 'No Order found' },
    { value: 'Other', label: 'Other' },
    { value: 'Pending order on account"', label: 'Pending order on account' },
    { value: 'TN not found"', label: 'TN not found' },
    { value: 'TN not portable"', label: 'TN not portable' },
    { value: 'Zip Code does not match"', label: 'Zip Code does not match' },
  ];
  public requestPayload: UpdateLsrRequest = new UpdateLsrRequest();

  constructor(private utilityService: UtilityService) { }

  ngOnInit() {
  }

  onSelectedTypeChange() {
    this.requestPayload = new UpdateLsrRequest();
    if (this.selectedType.code === 'REJECT') {
      this.requestPayload.rejectLsrFlag = true;
    } else {
      this.requestPayload.rejectLsrFlag = false;
    }
  }

  onClickSave() {
    const request = JSON.parse(JSON.stringify(this.requestPayload));
    if (this.selectedType.code === 'REJECT' && !this.requestPayload.reasonCode) {
      return;
    }
    if (this.selectedType.code === 'UPDATE' && !this.requestPayload.resellerName) {
      return;
    }

    if (this.requestPayload.reasonCode) {
      request.reasonCode = this.requestPayload.reasonCode['value'];
    }
    if (this.requestPayload.resellerName) {
      request.resellerName = this.requestPayload.resellerName['value'];
      if (this.requestPayload.resellerName['value'] === 'Other') {
        request.resellerName = this.requestPayload.otherResellerName;
      }
    }
    delete request.otherResellerName; // remove other reseleer key from request as it is for local use only.

    request.focDate = this.utilityService.getFormatedDate(this.requestPayload.focDate),
      request.systemId = this.utilityService.getSystemId();
    request.userId = this.utilityService.getUserId();
    this.onSubmit.emit(request);
  }

}
