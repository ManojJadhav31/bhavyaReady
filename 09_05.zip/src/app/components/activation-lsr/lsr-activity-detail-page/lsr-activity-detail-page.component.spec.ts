import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LsrActivityDetailPageComponent } from './lsr-activity-detail-page.component';
import { SharedModule } from '../../../shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { ActivationLsrRoutingModule } from '../activation-lsr-routing.module';
import { RouterTestingModule } from '@angular/router/testing';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';
import { TnActivitySearchService } from '../../activation-service/services/tn-activity-search.service';
import { ApiService } from '../../../shared/services/api.service';
import { StorageService } from '../../../services/storage.service';
import { LsrActivitySearchService } from '../services/lsr-activity-search.service';
import { UtilityService } from '../../../shared/services/utility.service';
import { LsrActivitySearchComponent } from '../lsr-activity-search/lsr-activity-search.component';
import { LsrActivityDeprovisionTnsPageComponent } from '../lsr-activity-deprovision-tns-page/lsr-activity-deprovision-tns-page.component';
import { LsrActivityAgentAssignDialogComponent } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.component';

describe('LsrActivityDetailPageComponent', () => {
  let component: LsrActivityDetailPageComponent;
  let fixture: ComponentFixture<LsrActivityDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LsrActivitySearchComponent, LsrActivityDetailPageComponent, LsrActivityDeprovisionTnsPageComponent, LsrActivityAgentAssignDialogComponent ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        SearchPanelsModule,
        ActivationLsrRoutingModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        TnActivitySearchService,
        ApiService,
        StorageService,
        LsrActivitySearchService,
        UtilityService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LsrActivityDetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
