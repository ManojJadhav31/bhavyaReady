import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LSRDetailsPageResponse, UpdateLsrRequest } from '../activation-lsr.constants';
import { LsrActivitySearchService } from '../services/lsr-activity-search.service';
import { UpdateLsrDialogComponent } from '../update-lsr-dialog/update-lsr-dialog.component';

@Component({
  selector: 'app-lsr-activity-detail-page',
  templateUrl: './lsr-activity-detail-page.component.html',
  styleUrls: ['./lsr-activity-detail-page.component.scss']
})
export class LsrActivityDetailPageComponent implements OnInit {

  extOrderId: any;
  carrierId: any;
  activityStatus: string;
  activityName: string;
  orderActivityIdPK: number;
  productId: number;
  validateLsrTask: boolean = false;
  updateLsrEls: boolean = false;
  orderDetail: LSRDetailsPageResponse;
  errorMessage: string;
  successMessage: string;
  parentOrderId: number;

  @ViewChild('updateLsrDialogComponent') updateLsrDialogComponent: UpdateLsrDialogComponent;

  constructor(private activatedRoute: ActivatedRoute, private lsrActivitySearchService: LsrActivitySearchService) {
  }

  ngOnInit() {
    this.carrierId = this.activatedRoute.snapshot.params['carrierId'];
    this.extOrderId = this.activatedRoute.snapshot.params['extOrderId'];
    this.activityName = this.activatedRoute.snapshot.params['activityName'];
    this.activityStatus = this.activatedRoute.snapshot.params['status'];
    this.orderActivityIdPK = this.activatedRoute.snapshot.params['orderActivityIdPK'];
    this.parentOrderId = this.activatedRoute.snapshot.params['parentOrderId'];

    console.log(this.activityName)
    if (this.activityStatus !== 'Processing' || this.activityName !== 'Validate Carrier LSR Data (Manual)') {
      this.validateLsrTask = true;
    }
    this.productId = this.activatedRoute.snapshot.params['productId'];
    this.productId = parseInt(this.productId.toString(), 0) || this.productId;
    if (this.productId === 2042 || this.productId === 2036) { 
      this.updateLsrEls = true;
    }
    this.getOrderDetails();
  }

  getOrderDetails() {
    this.errorMessage = '';
    this.lsrActivitySearchService.getLSRDetails(this.extOrderId).subscribe((response: LSRDetailsPageResponse) => {
      this.orderDetail = response;
    }, error => this.errorMessage = error);
  }

  onUpdateLsrClick() {
    this.updateLsrDialogComponent.onSelectedTypeChange();
    this.updateLsrDialogComponent.showDialog = true;
  }

  onUpdateLsrDialogSubmitClick(event: UpdateLsrRequest) {
    this.errorMessage = '';
    this.successMessage = '';
    this.updateLsrDialogComponent.showDialog = false;
    event.orderActivityPk = this.orderActivityIdPK;
    // event.parentTransId = this.parentOrderId;
    console.log(event)
    this.lsrActivitySearchService.updateLsr(event).subscribe((response: any) => {
      if (response && response.errorCode === 0) {
        this.successMessage = 'Successfully Updated';
      } else if (response && response.errorCode !== 0) {
        this.errorMessage = response.errorMessage
      }
    }, error => {
      this.errorMessage = error
      console.log(this.errorMessage);
    });
  }
}
