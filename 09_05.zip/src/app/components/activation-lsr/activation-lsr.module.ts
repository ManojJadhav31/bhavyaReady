import { NgModule } from '@angular/core';
import { ActivationLsrRoutingModule } from './activation-lsr-routing.module';
import { LsrActivitySearchComponent } from './lsr-activity-search/lsr-activity-search.component';
import { SharedModule } from '../../shared/shared.module';
import { SearchPanelsModule } from '../search-panels/search-panels.module';
import { ColumnPickListDialogModule } from '../dialog/column-pick-list-dialog/column-pick-list-dialog.module';
import { LsrActivitySearchService } from './services/lsr-activity-search.service';
import { LsrActivityDetailPageComponent } from './lsr-activity-detail-page/lsr-activity-detail-page.component';
import { LsrActivityDeprovisionTnsPageComponent } from './lsr-activity-deprovision-tns-page/lsr-activity-deprovision-tns-page.component';
import { UpdateOrderDateDialogModule } from '../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';
import { LsrActivityAgentAssignDialogModule } from '../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.module';
import { UpdateLsrDialogComponent } from './update-lsr-dialog/update-lsr-dialog.component';

@NgModule({
  declarations: [LsrActivitySearchComponent, LsrActivityDetailPageComponent, LsrActivityDeprovisionTnsPageComponent, UpdateLsrDialogComponent],
  exports: [UpdateLsrDialogComponent],
  imports: [
    ActivationLsrRoutingModule,
    SharedModule,
    SearchPanelsModule,
    ColumnPickListDialogModule,
    UpdateOrderDateDialogModule,
    TransactionViewDialogModule,
    UpdateReasonDialogModule,
    LsrActivityAgentAssignDialogModule
  ],
  providers: [LsrActivitySearchService]
})
export class ActivationLsrModule {
}
