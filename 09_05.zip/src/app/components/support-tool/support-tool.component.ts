import { Component, OnInit } from '@angular/core';
import { MsFlowUpdateRequest } from './support-tool-constants';
import { UtilityService } from '../../shared/services/utility.service';
import { SupportToolService } from './services/support-tool.service';

@Component({
  selector: 'app-support-tool',
  templateUrl: './support-tool.component.html',
  styleUrls: ['./support-tool.component.scss']
})
export class SupportToolComponent implements OnInit {

  msflowFlag: any = [];
  selectedMsFlag: any;
  public msFlowUpdateRequest: MsFlowUpdateRequest = new MsFlowUpdateRequest()
  public errorMsg: string;
  public successMsg: string;
  public totalCount: string;
  public isSearchingOrders = false;
  public message: string

  constructor(private utilService: UtilityService, private supportToolService: SupportToolService) {
    this.msflowFlag = [
      { value: 'N', label: 'No' },
      { value: 'Y', label: 'Yes' }
    ];
  }

  ngOnInit() {
    this.msFlowUpdateRequest.msFlag = 'N';
  }

  onSubmit() {
    this.message = null;
    this.errorMsg = null;
    this.successMsg = null;
    const patt = new RegExp("[^A-Za-z].[A-Za-z]+$");
    if (!this.msFlowUpdateRequest.orderIds || !this.msFlowUpdateRequest.msFlag || !this.msFlowUpdateRequest.userName || !this.msFlowUpdateRequest.comment) {
      this.message = 'Please enter required fields.'
      return;
    }else if(!patt.test(this.msFlowUpdateRequest.userName)){
      this.message = 'Please enter valid user name.'
      return;
    }
    if (this.msFlowUpdateRequest.orderIds) {
      this.msFlowUpdateRequest.orderActivityPks = this.utilService.createArrayFromTextArea(this.msFlowUpdateRequest.orderIds);
    }

    // calling api for every 30 orderActivityPksin recursive function
    const callRecursive = (ids, count) => {
      const requestPayload = new MsFlowUpdateRequest();
      requestPayload.orderActivityPks = ids;
      requestPayload.comment = this.msFlowUpdateRequest.comment;
      requestPayload.msFlag = this.msFlowUpdateRequest.msFlag;
      // requestPayload.userName = this.utilService.getUserId();
      requestPayload.userName = this.msFlowUpdateRequest.userName;
      this.isSearchingOrders = true
      this.supportToolService.msFlag(requestPayload).subscribe((response: any) => {
        this.successMsg = response.message;
        this.totalCount = response.totalCount;
        this.isSearchingOrders = false;
      }, (error) => {
        this.errorMsg = error
        this.isSearchingOrders = false;
      });
      if (this.msFlowUpdateRequest.orderActivityPks.length !== 0) {
        callRecursive(this.msFlowUpdateRequest.orderActivityPks.splice(0, 30), count++);
      }
    };
    callRecursive(this.msFlowUpdateRequest.orderActivityPks.splice(0, 30), 0);
  }
  onClearFields() {
    this.msFlowUpdateRequest.orderIds = '';
    this.isSearchingOrders = false;
    this.errorMsg = '';
    this.successMsg = '';
    this.message = '';
    this.totalCount = '';
    this.msFlowUpdateRequest.msFlag = 'N';
  }
}
