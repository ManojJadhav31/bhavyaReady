import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { SupportToolRoutingModule } from './support-tool-routing.module'
import { SupportToolComponent } from './support-tool.component';
import { UtilityService } from '../../shared/services/utility.service';
import { SupportToolService } from './services/support-tool.service';

@NgModule({
  declarations: [SupportToolComponent],
  imports: [
    SharedModule,
    SupportToolRoutingModule
  ],
  providers: [UtilityService, SupportToolService]
})
export class SupportToolModule {
}