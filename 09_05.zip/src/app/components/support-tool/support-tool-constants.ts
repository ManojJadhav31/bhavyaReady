export class MsFlowUpdateRequest {
    orderActivityPks: string[] = [];
    userName: string;
    comment: string;
    msFlag: string = 'Y';

    orderIds: string; // local use
};

