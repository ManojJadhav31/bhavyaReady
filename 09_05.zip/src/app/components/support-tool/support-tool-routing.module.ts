import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SupportToolComponent } from './support-tool.component';


const routes: Routes = [
    {
        path: '', component: SupportToolComponent,
    }
];

@NgModule({
  imports: [ RouterModule.forChild(routes) ],
  exports: [ RouterModule ]
})
export class  SupportToolRoutingModule {
}
