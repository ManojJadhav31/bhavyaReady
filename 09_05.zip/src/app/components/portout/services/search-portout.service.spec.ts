import { TestBed } from '@angular/core/testing';

import { SearchPortoutService } from './search-portout.service';
import { PortoutService } from './portout.service';
import { HttpClient } from '@angular/common/http';
import { UtilityService } from '../../../shared/services/utility.service';
import { StorageService } from '../../../services/storage.service';
import { ApiService } from '../../../shared/services/api.service';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { OrderDetails } from '../../../../tests/mockdata/portout/orderdetail/searchOrder';
import { of } from 'rxjs';

describe('SearchPortoutService', () => {

  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let apiService: ApiService;
  let searchPortoutService: SearchPortoutService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule, FormsModule, BrowserAnimationsModule ],
      providers: [ SearchPortoutService, PortoutService, UtilityService, StorageService, ApiService ],
    });

    httpClient = TestBed.get(HttpClient);
    httpTestingController = TestBed.get(HttpTestingController);
    searchPortoutService = TestBed.get(SearchPortoutService);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();

    spyOn(SearchPortoutService.prototype, 'searchOrders').and.returnValue(of(OrderDetails));
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  describe('searchOrders', () => {
    it('should search orders', () => {
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/search';
      searchPortoutService.searchOrders('8763782912', '1', '8763928374', '1', '1', '10', 'active').subscribe(
        data => expect(data).toEqual(OrderDetails),
        fail
      );
    });
    it('should cancel orders', () => {
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/cancel';
      searchPortoutService.cancelOrders('8763782912').subscribe(
        data => expect(data).toEqual(OrderDetails),
        fail
      );
      const req = httpTestingController.expectOne(url);
      expect(req.request.method).toEqual('PUT');
    });
  });
});
