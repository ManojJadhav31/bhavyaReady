import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { OrderDetailService } from './orderdetail-portout.service';
import { PortoutService } from './portout.service';
import { ApiService } from '../../../shared/services/api.service';
import { StorageService } from '../../../services/storage.service';


describe('OrderDetailPortoutService', () => {

  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let orderDetailService: OrderDetailService;
  let apiService: ApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [OrderDetailService, PortoutService, StorageService, ApiService]
    });

    httpClient = TestBed.get(HttpClient);
    httpTestingController = TestBed.get(HttpTestingController);
    orderDetailService = TestBed.get(OrderDetailService);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();

  });

  afterEach(() => {
    httpTestingController.verify();
  });

  describe('getOrderDetails', () => {
    const expectedResult: any = { type: 0 };
    it('should get order details', () => {
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/search?carrierRequesTypeId=1';
      orderDetailService.getOrderDetails(1).subscribe(
        data => expect(data).toEqual(expectedResult, 'should return data'),
        fail
      );

      const req = httpTestingController.expectOne(url);
      expect(req.request.method).toEqual('GET');
    });
  });
  describe('getTns', () => {
    const expectedResult: any = { type: 0 };
    it('should get tns', () => {
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/' + 1 + '/tns';
      orderDetailService.getTns(1).subscribe(
        data => expect(data).toEqual(expectedResult, 'should return data'),
        fail
      );

      const req = httpTestingController.expectOne(url);
      expect(req.request.method).toEqual('GET');
    });
  });

  describe('updateOrderDetail', () => {
    const expectedResult: any = { type: 0 };
    it('should update order details', () => {
      const params = {
        id: 1,
        focDate: '03/15/2018'
      };
      const body = {
        ban: 1234567890
      };
      // const url = this.apiService.getBaseUrl() + '/portOut' + '?id=' + params.id + '&focDate=' + params.focDate;
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut' + '?id=' + params.id + '&focDate=' + params.focDate;
      orderDetailService.updateOrderDetail(params, body).subscribe(
        data => expect(data).toEqual(expectedResult, 'should return data'),
        fail
      );

      const req = httpTestingController.expectOne(url);
      expect(req.request.method).toEqual('PUT');
    });
  });
  describe('Add/Remove tns', () => {
    const expectedResult: any = { type: 0 };
    it('should add tns', () => {
      const body = {
        carrierRequestId: '12356789',
        tn: '9346102357'
      };
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/' + body.carrierRequestId + '/add/tn';
      orderDetailService.addTns(body).subscribe(
        data => expect(data).toEqual(expectedResult, 'should return data'),
        fail
      );
      const req = httpTestingController.expectOne(url);
      expect(req.request.method).toEqual('PUT');

    });

    it('should remove tns', () => {
      const body = {
        carrierRequestId: '12356789',
        tn: '9346102357'
      };
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/' + body.carrierRequestId + '/remove/tn';
      orderDetailService.removeTns(body).subscribe(
        data => expect(data).toEqual(expectedResult, 'should return data'),
        fail
      );
      const req = httpTestingController.expectOne(url);
      expect(req.request.method).toEqual('PUT');
    });
  });
  describe('Able to Supp Orders', () => {
    const expectedResult: any = { type: 0 };
    it('Should be able to supp orders', () => {
      const params = {
        carrierRequestId: '82735656'
      };
      const body = {
        carrierRequestId: '8374868',
        addTnList: ['76786111'],
        removeTnList: ['65324756'],
        focDate: '05/23/2019',
        orderSourceId: 'Project portout tool'
      };
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/supp';
      orderDetailService.addRemoveUpdateDetails(body).subscribe(
        data => expect(data).toEqual(expectedResult, 'should return data'),
        fail
      );
      const req = httpTestingController.expectOne(url);
      expect(req.request.method).toBe('PUT');
    });
  });
  describe('Able to perform carrier approval action', () => {
    const expectedResult: any = { type: 0 };
    it('Should be able to provide carrier approval action', () => {
      const params = {
        carrierRequestId: '42839711'
      };
      const body = {
        action: 'Rejected',
        reason: 'test',
        user: 'nikethani.bhavya'
      };
      const url = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/customerApproval?carrierRequestId=' + params.carrierRequestId;
      orderDetailService.carrierApprovalAction(params.carrierRequestId, body.action).subscribe(
        data => expect(data).toEqual(expectedResult, 'should return data'),
        fail
      );
      const req = httpTestingController.expectOne(url);
      expect(req.request.method).toBe('POST');
    });
  });
});
