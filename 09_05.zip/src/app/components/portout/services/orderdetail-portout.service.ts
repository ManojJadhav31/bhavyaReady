import { Injectable } from '@angular/core';
import { PortoutService } from './portout.service';
import { ApiService } from '../../../shared/services/api.service';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { UtilityService } from '../../../shared/services/utility.service'

@Injectable()
export class OrderDetailService {
  private orderDetails: BehaviorSubject<any> = new BehaviorSubject<any>({});

  constructor(private service: PortoutService, private apiService: ApiService, private http: HttpClient,private utilityService: UtilityService ) {
  }

  getOrderDetailsData(): Observable<any> {
    return this.orderDetails;
  }

  setOrderDetailsData(data: any): void {
    this.orderDetails.next(data);
  }

  getOrderDetails(requestTypeId) {
    const url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/search?carrierRequesTypeId=' + requestTypeId;
    return this.service.getRequest(url).pipe(
      map(data => {
        return data;
      })
    );
  }

  getTns(requestTypeId) {
    const url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/' + requestTypeId + '/tns';
    return this.service.getRequest(url).pipe(
      map(data => {
        return data;
      })
    );
  }

  updateOrderDetail(params, body) {
    let url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut' + '?id=' + params.id;
    if ( params.focDate ) {
      url = url + '&focDate=' + params.focDate;
    }
    return this.service.putRequest(url, body).pipe(
      map(data => {
        return data;
      })
    );
  }

  carrierApprovalAction(carrierRequestId, action, errorMessage?: string) {
    const url = this.apiService.portoutToolApiUrl + `/ServiceDelivery/v1/Voice/portOut/customerApproval`;
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    let paramlist = new HttpParams();
    if ( carrierRequestId ) {
      paramlist = paramlist.append('carrierRequestId', carrierRequestId);
    }
    const body = {
      response: action,
      userName: this.utilityService.getUserId()
    };

    if ( action === 'Rejected' && errorMessage ) {
      body['errorMessage'] = errorMessage;
    }

    return this.http.post(url, body, { headers: headers, params: paramlist }).pipe(
      map(data => {
        return data;
      }),
      catchError(error => {
        return this.apiService.handleError(error);
      })
    );
  }

  addTns(body) {
    const url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/' + body.carrierRequestId + '/add/tn';
    return this.service.putRequest(url, body);
  }

  removeTns(body) {
    const url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/' + body.carrierRequestId + '/remove/tn';
    return this.service.putRequest(url, body).pipe(
      map(data => {
        return data;
      })
    );
  }

  addRemoveUpdateDetails(body) {
    const url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/supp';
    return this.http.put(url, body).pipe(
      map(data => {
        return data;
      }),
      catchError(error => {
        return this.apiService.handleError(error);
      })
    );
  }
}
