import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PortoutComponent } from './portout.component';
import { RouterTestingModule } from '@angular/router/testing';
import { SearchPortoutComponent } from './search-portout/search-portout.component';
import { VpDatePipe } from '../../shared/pipes/vpDate.pipe';
import { PortoutService } from './services/portout.service';
import { StorageService } from '../../services/storage.service';
import { UtilityService } from '../../shared/services/utility.service';
import { ApiService } from '../../shared/services/api.service';
import { SharedModule } from '../../shared/shared.module';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';
import { PortoutOrderStatusDetailsComponent } from './search-portout/portout-order-status-details/portout-order-status-details.component';
import { ColumnPickListDialogModule } from '../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

describe('PortoutComponent', () => {
  let component: PortoutComponent;
  let fixture: ComponentFixture<PortoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortoutComponent, SearchPortoutComponent, PortoutOrderStatusDetailsComponent, VpDatePipe ],
      imports: [ SharedModule, UpdateReasonDialogModule,ColumnPickListDialogModule,
        RouterTestingModule.withRoutes([
          {
            path: 'portout', component: PortoutComponent, children: [
              { path: '', redirectTo: 'search', pathMatch: 'full' },
              { path: 'search', component: SearchPortoutComponent },
            ]
          }
        ]) ],
      providers: [ PortoutService, StorageService, UtilityService, ApiService ]
    })
      .compileComponents().then(value => {
      fixture = TestBed.createComponent(PortoutComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  }));
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to other pages', () => {

    const app = fixture.debugElement.componentInstance;
    const event = {
      index: 0
    };
    spyOn(component, 'onTabChange').and.returnValue(true);
    const result = app.onTabChange(event); // trigger click on first inner
    expect(result).toBe(true);
  });
});
