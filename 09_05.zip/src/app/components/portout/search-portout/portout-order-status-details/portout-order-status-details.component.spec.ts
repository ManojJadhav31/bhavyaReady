import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PortoutOrderStatusDetailsComponent } from './portout-order-status-details.component';
import { SharedModule } from '../../../../shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UpdateReasonDialogModule } from '../../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ApiService } from '../../../../shared/services/api.service';
import { UtilityService } from '../../../../shared/services/utility.service';
import { StorageService } from '../../../../services/storage.service';
import { PortoutService } from '../../services/portout.service';
import { SearchPortoutComponent } from '../search-portout.component';
import { VpDatePipe } from '../../../../shared/pipes/vpDate.pipe';
import { RouterTestingModule } from '@angular/router/testing';
import { SearchPortoutService } from '../../services/search-portout.service';
import { OrderDetails } from '../../../../../tests/mockdata/portout/orderdetail/searchOrder';
import { ColumnPickListDialogModule } from '../../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';


describe('PortoutOrderStatusDetailsComponent', () => {
  let component: PortoutOrderStatusDetailsComponent;
  let fixture: ComponentFixture<PortoutOrderStatusDetailsComponent>;
  let searchPortoutService: SearchPortoutService;

  beforeEach(async(() => {
    const params = {
      requestTypeId: 1
    };
    TestBed.configureTestingModule({
      declarations: [ SearchPortoutComponent, VpDatePipe, PortoutOrderStatusDetailsComponent ],
      imports: [ BrowserAnimationsModule, SharedModule, RouterTestingModule,
        UpdateReasonDialogModule , ColumnPickListDialogModule],
      providers: [ ApiService, UtilityService, StorageService, PortoutService ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortoutOrderStatusDetailsComponent);
    searchPortoutService = fixture.debugElement.injector.get(SearchPortoutService);
    component = fixture.componentInstance;
    component.rowData = OrderDetails[0];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
