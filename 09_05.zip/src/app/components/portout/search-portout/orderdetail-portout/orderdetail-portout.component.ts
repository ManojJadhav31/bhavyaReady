import { Component, EventEmitter, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { OrderDetailService } from '../../services/orderdetail-portout.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { UtilityService } from '../../../../shared/services/utility.service';
import { DataTable } from 'primeng/primeng';
import * as XLSX from 'xlsx';
import { Subscription } from 'rxjs';
import { UpdateReasonDialogComponent } from '../../../dialog/update-reason-dialog/update-reason-dialog.component';
import { StorageService } from '../../../../services/storage.service';

@Component({
  selector: 'app-orderdetail-portout',
  templateUrl: './orderdetail-portout.component.html',
  styleUrls: ['./orderdetail-portout.component.scss']
})
export class OrderdetailPortoutComponent implements OnInit, OnDestroy {

  @Output() getOrderDetails = new EventEmitter<void>();
  @Output() updateOrderDetail = new EventEmitter<void>();
  @ViewChild('dt') tnGrid: DataTable;
  public newTn: string;
  public newBan: string;
  public orderDetail: OrderDetail;
  public orderDetailSubscribe: Subscription;
  public requestTypeId: string;
  public supActionDisabled: string;
  public suppDisabled: boolean;
  public tns: any[] = [];
  public filteredTns: any[] = [];
  public newTns: any[] = [];
  public addTnErrorMsg: string;
  public removeTnErrorMsg: string;
  public isAddingTn = false;
  public addTnUpdateSuccessMsg = '';
  public removeTnUpdateSuccessMsg = '';
  public orderDetailsCols: any;
  public isUpdate = true;
  public isLoadingTn = true;
  public isBanDisabled = false;
  selectAllCheckBox = false;
  suppActions: any = [];
  selectedSuppActions: any;
  public newRemoveTn: string;
  public newRemoveTns: any[] = [];
  public updateSuccessMsg: string;
  public UserName: string;

  items: any[];
  @ViewChild('updateReasonDialog') updateReasonDialog: UpdateReasonDialogComponent;

  constructor(private orderDetailService: OrderDetailService,
    private route: ActivatedRoute,
    public storageService: StorageService,
    private fb: FormBuilder,
    private router: Router,
    private utilityService: UtilityService) {

    this.route.params.subscribe(p => {
      if (p.requestTypeId) {
        this.requestTypeId = p.requestTypeId;
        this.getTns();
      }
      if (p.supActionDisabled) {
        this.supActionDisabled = p.supActionDisabled;
      }
    });

    this.suppActions = [
      { value: 'addTns', label: 'AddTns' },
      { value: 'removeTns', label: 'RemoveTns' },
      { value: 'update', label: 'Update' }
    ];
  }

  ngOnInit() {
    this.storageService.setModule('search-portout');
    this.UserName = localStorage.getItem('UserName') === 'undefined' ? undefined : localStorage.getItem('UserName');
    this.orderDetailSubscribe = this.orderDetailService.getOrderDetailsData().subscribe((result) => {
      this.orderDetail = result;
    });
    this.orderDetailsCols = [
      {
        'header': 'Carrier Request Id',
        'field': 'carrierRequestId'
      },
      {
        'header': 'TN',
        'field': 'wtn'
      },
      {
        'header': 'Carrier Name',
        'field': 'carrierName'
      },
      {
        'header': 'Product Name',
        'field': 'productName'
      },
      {
        'header': 'BAN',
        'field': 'billingAccountNumber'
      },

      {
        'header': ' LSR Order Status',
        'field': 'workFlowStatus'
      },

      {
        'header': 'Error Message',
        'field': 'errorMessage'
      }
    ];

    this.items = [
      {
        label: 'Approve', icon: 'pi pi-refresh', command: () => {
          this.carrierApprovalAction('Approved');
        }
      },
      {
        label: 'Reject', icon: 'pi pi-times', command: () => {
          this.updateReasonDialog.displaDialog = true;
        }
      },
      {
        label: 'Continue', icon: 'pi pi-info', command: () => {
          this.carrierApprovalAction('Continue');
        }
      }

    ];


  }


  onReasonSubmit(event) {
    this.carrierApprovalAction('Rejected', event.errorMessage);
    this.updateReasonDialog.displaDialog = false;
  }

  carrierApprovalAction(action: string, errorMessage?: string) {
    this.isLoadingTn = true;
    this.addTnUpdateSuccessMsg = '';
    this.orderDetailService.carrierApprovalAction(this.orderDetail.carrierRequestId, action, errorMessage).subscribe((response) => {
      this.isLoadingTn = false;
      const details = this.storageService.getSearchDetails();
      if (details) {
        if (details.formData) {
          details.formData.carrierRequestId = this.orderDetail.carrierRequestId.toString();
        }
        this.storageService.storeSearchDetails(details.formData, details.results);
      }
      this.addTnUpdateSuccessMsg = 'Request has been completed successfully';
      // this.getOrderDetails.emit();
      this.router.navigate(['/portout/search'], { queryParams: { search: true } });
      // this.getTns();
    }, (error) => {
      this.isLoadingTn = false;
      this.addTnUpdateSuccessMsg = error;

    });
  }

  ngOnDestroy(): void {
    if (this.orderDetailSubscribe) {
      this.orderDetailSubscribe.unsubscribe();
    }
  }

  getTns() {
    this.isLoadingTn = true;
    this.newBan = '';
    this.newTn = '';
    this.newRemoveTn = '';

    this.orderDetailService.getTns(this.requestTypeId).subscribe((data: any) => {
      this.tns = data;
      this.filteredTns = data;
      this.isLoadingTn = false;
      this.isBanDisabled = this.disableBan();
    }, error => {
      this.addTnErrorMsg = error;
      this.isLoadingTn = false;
    });
  }

  addRemoveUpdateTns() {
    if (!this.selectedSuppActions) {
      this.removeTnErrorMsg = 'Please select at least one action.';
      return;
    }
    this.updateSuccessMsg = null;
    this.addTnUpdateSuccessMsg = null;
    this.addTnErrorMsg = null;
    this.removeTnUpdateSuccessMsg = null;
    this.removeTnErrorMsg = null;

    let callApi = false;
    const requestPayload: SuppRequest = {
      carrierRequestId: this.orderDetail.carrierRequestId,
      orderSourceId: 'PROJECT PORTOUT TOOL'
    };
    if (this.selectedSuppActions.indexOf('addTns') > -1) {
      const tnDetail = this.addTn();
      if (tnDetail && tnDetail.tnList) {
        callApi = true;
        requestPayload.addTnList = tnDetail.tnList;
        if (!this.isBanDisabled && tnDetail.billingAccountNumber) {
          requestPayload.bansToAdd = tnDetail.billingAccountNumber;
        }
      } else {
        callApi = false;
        return;
      }
    }
    if (this.selectedSuppActions.indexOf('removeTns') > -1) {
      const tnDetails = this.removeTns();
      if (tnDetails && tnDetails.length > 0) {
        callApi = true;
        requestPayload.removeTnList = tnDetails;
      } else {
        callApi = false;
        return;
      }
    }
    if (this.selectedSuppActions.indexOf('update') > -1) {
      const focDate = this.getFOCDate();
      if (focDate) {
        callApi = true;
        requestPayload.focDate = focDate;
        requestPayload.lastUpdatedUser = this.UserName;
      } else {
        callApi = false;
        return;
      }
    }

    if (callApi && this.orderDetail) {
      this.isAddingTn = true;
      this.orderDetailService.addRemoveUpdateDetails(requestPayload).subscribe((response) => {
        if (this.selectedSuppActions.indexOf('addTns') > -1 || this.selectedSuppActions.indexOf('removeTns') > -1) {
          this.tns = [];
          this.filteredTns = [];
          setTimeout(() => {
            this.addTnUpdateSuccessMsg = 'Successfully Completed.';
            this.isAddingTn = false;
            this.isLoadingTn = true;
            this.getTns();
            setTimeout(() => {
              this.getOrderDetails.emit();
            }, );
          }, );
        } else if (this.selectedSuppActions.indexOf('update') > -1) {
          this.getOrderDetails.emit();
          this.isAddingTn = false;
          this.addTnUpdateSuccessMsg = 'Successfully Completed.';
        }
      }, (error) => {
        this.addTnErrorMsg = error;
        this.isAddingTn = false;
        this.isUpdate = false;
      });
    }
  }

  addTn() {
    this.addTnUpdateSuccessMsg = null;
    this.addTnErrorMsg = null;
    const tns = this.validateTns(this.newTn);
    const ban = this.validateBans(this.newBan);


    if (this.addTnErrorMsg) {
      return;
    }
    if (!tns) {
      this.addTnErrorMsg = 'Please enter atleast one TN to add.';
      return;
    }

    return {
      tnList: tns,
      billingAccountNumber: ban
    };
  }

  removeTns() {
    this.removeTnUpdateSuccessMsg = null;
    this.removeTnErrorMsg = null;
    let tnsForRemoval = [];
    const tns = this.validateTns(this.newRemoveTn) || [];
    if (this.addTnErrorMsg) {
      return;
    }
    const selectedTns = this.newRemoveTns.map(tn => {
      if (tn.wtn) {
        return tn.wtn;
      }
    });
    tnsForRemoval = [...tns, ...selectedTns];
    tnsForRemoval = tnsForRemoval.filter(function (item, pos, self) {
      return self.indexOf(item) === pos;
    });
    if (tnsForRemoval && tnsForRemoval.length === 0) {
      this.addTnErrorMsg = 'Please enter atleast one TN to remove.';
      return;
    }
    return tnsForRemoval;
  }

  getFOCDate() {
    if (this.orderDetail.focDate) {
      const date = this.utilityService.parseDate(this.orderDetail.focDate, 'mdy');
      return date;
    }
    return undefined;
  }


  filterTns(event) {
    const tn = event.target.value;
    this.filteredTns = this.tns.filter((value, index) => {
      const isExists = (value as any).wtn.toString().trim().includes(tn.trim());
      return isExists;
    });
  }

  validateTns(newTn) {
    if (newTn) {
      const tns = newTn.split(/[\n,]+/);
      tns.forEach(tn => {
        if (tn !== '') {
          if (isNaN(parseInt(tn, 0))) {
            this.addTnErrorMsg = 'Tn should be numeric - ' + tn;
            return;
          } else if (tn.length !== 10) {
            this.addTnErrorMsg = 'Tn should be 10-digits - ' + tn;
            return;
          }
        }
      });
      return tns.filter(tn => {
        return tn !== '';
      });
    }
  }

  validateBans(ban) {
    if (ban) {
      const bans = ban.split(/[\n,\s]+/);
      // bans.forEach(bn => {
      //   if (bn === "") {
      //     this.addRemoveTnErrorMsg = 'BAN should not be empty';
      //   }
      // });
      return bans.filter(bn => {
        return bn !== '';
      });
    }
    return undefined;
  }

  disableBan() {
    let flag = false;
    this.tns.forEach(tn => {
      if (tn && tn.carrierName) {
        if (tn.carrierName === 'LEVEL 3 COMMUNICATIONS') {
          flag = true;
        }
      }
    });
    return flag;
  }

  canExportTns() {

    let flag = true;
    if (this.tns) {
      const activeTns = this.tns.filter((tn, index) => {
        if (tn.workFlowStatus) {
          // return tn.workFlowStatus.toString().trim().toLowerCase() === 'active'
          return tn.workFlowStatus.toString().trim().toLowerCase() === 'created';
        } else {
          return false;
        }
      });
      if (activeTns.length > 0) {
        flag = true;
      } else {
        flag = false;
      }
    }
    return flag;
  }

  checkAllRows(event) {
    this.filteredTns.forEach(row => {
      row.checked = event.target.checked;
    });


    this.newTns = this.filteredTns.filter((object) => {
      return object.checked;
    });
  }

  selectTns(event, tn) {
    tn.checked = event.target.checked;
    const selectedResult = this.filteredTns.filter(item => {
      if (item.checked) {
        return true;
      } else {
        return false;
      }
    });
    this.newTns = selectedResult;
    if (this.filteredTns.length === selectedResult.length) {
      this.selectAllCheckBox = true;
    } else {
      this.selectAllCheckBox = false;
    }
  }

  exportTns() {
    if (this.canExportTns) {
      let exportData = [];
      const options = {
        showLabels: true,
        headers: this.orderDetailsCols.map(col => {
          return col.header;
        })
      };
      let selectedResult = this.filteredTns.filter(item => {
        if (item.checked) {
          return true;
        } else {
          return false;
        }
      });
      if (selectedResult.length === 0) {
        selectedResult = this.tns;
      }
      exportData = selectedResult.map(row => {
        const data = {};
        this.orderDetailsCols.forEach(col => {
          data[col.field] = row[col.field] || '';
        });
        return data;
      });
      this.exportExcelLocally(options, exportData);
      // this.tnGrid.exportCSV();
    }
  }

  exportExcelLocally(options, exportData) {
    if (exportData.length > 0) {
      const xlsData = [];
      xlsData.push(options.headers);
      exportData.forEach(f => {
        const arr = [];
        Object.keys(f).forEach(key => {
          arr.push(f[key]);
        });
        xlsData.push(arr);
      });
      const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(xlsData);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      XLSX.writeFile(wb, 'portout-report.xls');
    }
  }

  filterTnClick(event) {
    event.stopPropagation();
  }
}

interface Order {
  id: number;
  tn: string;
}

export interface OrderDetail {
  carrierRequestId: string;
  focDate: string;
  endUserName: string;
  streetNumber: string;
  streetName: string;
  city: string;
  state: string;
  zipCode: string;
  billingAccountName: string;
  purchaseOrderVersion: string;
  purchaseOrderNumber: string;
  errorMessage: string;
  errorCode: string;
  lsrStatus: string;
  authorizedBy: string;
  status: string;
}

interface SuppRequest {
  addTnList?: string | number[];
  bansToAdd?: string | number[];
  removeTnList?: string | number[];
  focDate?: string;
  lastUpdatedUser?: string;
  carrierRequestId: string;
  orderSourceId: string;
}
