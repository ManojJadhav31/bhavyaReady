import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchPortoutComponent } from './search-portout.component';
import { VpDatePipe } from '../../../shared/pipes/vpDate.pipe';
import { PortoutService } from '../services/portout.service';
import { RouterTestingModule } from '@angular/router/testing';
import { StorageService } from '../../../services/storage.service';
import { OrderDetails } from '../../../../tests/mockdata/portout/orderdetail/searchOrder';
import { of } from 'rxjs';
import { SearchPortoutService } from '../services/search-portout.service';
import { SharedModule } from '../../../shared/shared.module';
import { UtilityService } from '../../../shared/services/utility.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ApiService } from '../../../shared/services/api.service';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { PortoutOrderStatusDetailsComponent } from './portout-order-status-details/portout-order-status-details.component';
import { ConfirmationService } from 'primeng/api';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

describe('SearchPortoutComponent', () => {
  let component: SearchPortoutComponent;
  let fixture: ComponentFixture<SearchPortoutComponent>;
  let storageService: StorageService;
  let searchPortoutService: SearchPortoutService;
  let confirmationService: ConfirmationService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchPortoutComponent, VpDatePipe, PortoutOrderStatusDetailsComponent ],
      imports: [ BrowserAnimationsModule, SharedModule, RouterTestingModule,
        UpdateReasonDialogModule, ColumnPickListDialogModule ],
      providers: [ ApiService, UtilityService, StorageService, PortoutService ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPortoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    storageService = fixture.debugElement.injector.get(StorageService);
    searchPortoutService = fixture.debugElement.injector.get(SearchPortoutService);
    confirmationService = fixture.debugElement.injector.get(ConfirmationService);
    storageService.setModule('search-portout');
    spyOn(storageService, 'getSearchDetails').and.returnValue({
      formData: this.formData,
      results: undefined,
      totalRecords: undefined,
      pageConfig: undefined
    });
    spyOn(searchPortoutService, 'searchOrders').and.returnValue(of(OrderDetails));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fill order details form', () => {
    component.fillOrderDetails();
    // expect(component.searchOrderForm.controls.pon.value).toBe('2');
  });

  it('should be able to search orders', () => {
    component.results = null;
    const searchOrderFilter = OrderDetails[0];
    component.onSearchOrder(searchOrderFilter);
    expect(component.results.length).toBeGreaterThan(0);
  });

  it('should clear form', () => {
    component.searchOrderForm.controls.pon.setValue('2111');
    expect(component.searchOrderForm.controls.pon.value).toBe('2111');
    component.onClearFields();
    fixture.detectChanges();
    expect(component.searchOrderForm.controls.pon.value).toBe('');
  });

  it('should cancel order', () => {
    spyOn(confirmationService, 'confirm').and.callFake((params: any) => {
      params.accept();
    });
    spyOn(searchPortoutService, 'cancelOrders').and.returnValue(of(true));
    const searchOrderFilter = OrderDetails[0];
    fixture.detectChanges();
    component.onCancelButtonClick(searchOrderFilter);
    expect(component.successMsg).toBe('Order cancelled successfully');
  });

  it('should show hide column filter dialog', () => {
    component.showHideColumnFilterDialog();
    expect(component.columnPickListDialog.showDialog).toBe(true);
  });

  it('should show hide column filter dialog', () => {
    const list = [ {
      caption: 'LSR ID',
      value: 'carrierRequestId',
      visible: false,
      type: 'string',
      class: { 'r9': true }
    },
      {
        caption: '# Tn',
        value: 'tnCount',
        visible: false,
        type: 'string',
        class: { 'r6': true }
      } ];
    component.onPickListChange(list);
    expect(component.gridColumnList[0].value).toBe('carrierRequestId');
  });

});
