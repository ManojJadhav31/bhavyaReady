export interface SearchPortoutResult {
  carrierRequestId: string;
  focDate: Date;
  billingAccountName: string;
  endUserName: string;
  purchaseOrderVersion: string;
  streetNumber: string;
  streetName: string;
  city: string;
  state: string;
  ZipCode: string;
  purchaseOrderNumber: string;
  errorCode: string;
  errorMessage: string;
  tnCount: string;
  status: string;
  orderType: string;
  ponStatus: string;
}
export class CancelRequest {
  cancelOrderSource: string = 'PROJECT PORTOUT TOOL';
  carrierRequestId: string;
}