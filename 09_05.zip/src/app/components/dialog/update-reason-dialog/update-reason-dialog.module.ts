import { NgModule } from '@angular/core';
import { UpdateReasonDialogComponent } from './update-reason-dialog.component';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
  declarations: [ UpdateReasonDialogComponent ],
  exports: [ UpdateReasonDialogComponent ],
  imports: [
    SharedModule
  ]
})
export class UpdateReasonDialogModule {
}
