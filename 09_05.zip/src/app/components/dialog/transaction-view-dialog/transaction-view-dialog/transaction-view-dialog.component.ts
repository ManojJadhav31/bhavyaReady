import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { TransactionDialogService } from '../transaction-dialog.service';
import { StorageService } from '../../../../services/storage.service';
import { sortList } from '../../../../core/utills';

interface ErrorPanelDetails {
  mode: string;
  errors: ErrorDetails[];
  pageData: ErrorDetails[];
  startDate: number;
  endDate: number;
  totalId: number;
  pageSize: number;
  firstPage: number;
  success: boolean;
}

interface ErrorDetails {
  id: string;
  message: string;
}

@Component({
  selector: 'app-transaction-view-dialog',
  templateUrl: './transaction-view-dialog.component.html',
  styleUrls: ['./transaction-view-dialog.component.scss']
})
export class TransactionViewDialogComponent implements OnInit {
  @Output('onClose') onClose: EventEmitter<any> = new EventEmitter();

  displayDialog: boolean = false;
  pageSize = 100;
  firstPage = 0;
  columnList: any[] = [
    {
      caption: 'ID',
      value: 'id',
      visible: true,
      class: { 'r11': true }
    },
    {
      caption: 'Message',
      value: 'message',
      visible: true,
      class: { 'r11': true }
    }
  ];
  errorPanelList: ErrorPanelDetails[] = [];

  constructor(private storageService: StorageService, private transactionDialogService: TransactionDialogService) {
  }

  ngOnInit() {
    // console.log(new Date().valueOf())
    // console.log('ng on it trns')
  }

  diffDays(firstDate, secondDate): number {
    const oneDay = 24 * 60 * 60 * 1000;
    return Math.round(Math.abs((firstDate - secondDate.getTime()) / (oneDay)));
  }

  loadErrorList() {
    const trnsList = this.storageService.getTransactionActivityIds();


    this.errorPanelList = [];
    console.log(JSON.stringify(trnsList));
    const newTransactionList = [];
    trnsList.forEach((object, index) => {
      // console.log(this.diffDays(object.time, new Date()))
      if (typeof object.time === 'string') {
        object.time = new Date(object.time).getTime();
      }

      let mode = '';
      if (object.mode === 'restartActivity') {
        mode = 'Restart Activity';
      } else if (object.mode === 'forceCompleteActivity') {
        mode = 'Force Complete Activity';
      } else if (object.mode === 'orderDateUpdate') {
        mode = 'Order Date Update';
      } else if (object.mode === 'cancelLsrOrder') {
        mode = 'Cancel Order';
      } else if (object.mode === 'updateFOCandCRD') {
        mode = 'Update FOC and CRD';
      } else {
        mode = 'Activity';
      }

      const temp: ErrorPanelDetails = {
        endDate: new Date().getTime(),
        startDate: object.time,
        totalId: object.ids.length,
        mode: mode,
        errors: [],
        pageData: [],
        pageSize: 50,
        firstPage: 1,
        success: object.success
      };
      if (this.diffDays(object.time, new Date()) === 0 && object.ids.length > 0) {
        newTransactionList.push(JSON.parse(JSON.stringify(object)));
        if ((object.mode === 'orderDateUpdate' || object.mode === 'cancelLsrOrder') && !object.success) {
          object.ids.forEach((error: any) => {
            const temoError: ErrorDetails = {
              id: object.mode === error.ponId || error.lsrRequestId || error.parentOrderId,
              message: object.mode === error.error || error.errorMessage
            };
            temp.errors.push(temoError);
          });
          this.errorPanelList.push(temp);
          this.loadSearchResults({
            first: 0,
            page: 0,
            rows: 50
          }, temp)
        } else if (object.mode === 'updateFOCandCRD') {
          object.ids.forEach((error: any) => {
            const temoError: ErrorDetails = {
              id: error.parentOrderId,
              message: error.for + ' - ' + (error.errorCode === 0 ? 'Updated Successfully ' : error.errorMessage)
            };
            temp.errors.push(temoError);
          });
          temp.errors = sortList(temp.errors, 'id')
          this.errorPanelList.push(temp);
          this.loadSearchResults({
            first: 0,
            page: 0,
            rows: 50
          }, temp)
        } else if (object.mode !== 'orderDateUpdate' && object.mode !== 'cancelLsrOrder' && object.mode !== 'updateFOCandCRD') {
          let wait = false;
          const callRecursive = (ids, count) => {
            // if ( count === 10 ) {
            //   wait = true;
            // }
            this.transactionDialogService.getErrorMessage(ids).subscribe((response) => {
              const resKey = Object.keys(response);
              resKey.forEach((key) => {
                if (response[key] !== 'Activity Completed') {
                  const temoError: ErrorDetails = {
                    id: key,
                    message: response[key]
                  };
                  temp.errors.push(temoError);
                }
              });
              if (object.ids.length === 0) {
                this.loadSearchResults({
                  first: 0,
                  page: 0,
                  rows: 50
                }, temp)
              }
            });
            if (!wait && object.ids.length !== 0) {
              callRecursive(object.ids.splice(0, 100), count++);
            }
          };
          callRecursive(object.ids.splice(0, 100), 0);
          this.errorPanelList.push(temp);
        }
        this.errorPanelList = sortList(this.errorPanelList, 'startDate', 'DESC')
      }
    });
    this.storageService.setTransactionActivityIdsList(newTransactionList);
  }

  loadSearchResults(event, item: ErrorPanelDetails) {
    let list = item.errors;
    list = JSON.parse(JSON.stringify(list))
    item.pageData = list.splice(event.first, event.first + event.rows);
    console.log(event, item.pageData)
  }
}

