import { NgModule } from '@angular/core';
import { UpdateOrderDateDialogComponent } from './update-order-date-dialog.component';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
  declarations: [ UpdateOrderDateDialogComponent ],
  exports: [ UpdateOrderDateDialogComponent ],
  imports: [ SharedModule ]
})
export class UpdateOrderDateDialogModule {
}
