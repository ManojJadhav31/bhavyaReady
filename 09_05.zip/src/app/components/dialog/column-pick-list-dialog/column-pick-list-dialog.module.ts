import { NgModule } from '@angular/core';
import { ColumnPickListDialogComponent } from './column-pick-list-dialog/column-pick-list-dialog.component';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
  declarations: [ ColumnPickListDialogComponent ],
  exports: [ ColumnPickListDialogComponent ],
  imports: [ SharedModule ]
})
export class ColumnPickListDialogModule {
}
