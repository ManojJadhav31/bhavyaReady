import {getTestBed, inject, TestBed} from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {ApiService} from '../../../shared/services/api.service';
import {SearchPanelsService} from './search-panels.service';
import {HttpClient} from '@angular/common/http';
import { StorageService } from '../../../services/storage.service';

describe('SearchPanelService', () => {
  let searchPanelsService: SearchPanelsService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let apiService: ApiService;
  let httpClient: HttpClient;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SearchPanelsService, ApiService, StorageService]
    });
    injector = getTestBed();
    httpClient = TestBed.get(HttpClient);
    searchPanelsService = injector.get(SearchPanelsService);
    httpMock = injector.get(HttpTestingController);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();
  });

  afterEach(() => {
    httpMock.verify();
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', inject(
    [SearchPanelsService],
    (service: SearchPanelsService) => {
      expect(service).toBeTruthy();
    }
  ));

  it('should get Lnp order status using base url', () => {
    const url = apiService.baseUrl + 'order' + '-' + apiService.envName + '/ServiceDelivery/v1/Voice/tnActivitySearch/getAllLNPOrderStatus';
    searchPanelsService.getLnpOrderStatus().subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });

  it('should get activity names using base url', () => {
    const url = apiService.baseUrl + 'order' + '-' + apiService.envName + '/ServiceDelivery/v1/Voice/tnActivitySearch/getAllActivityRules';
    searchPanelsService.getActivityName().subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });

  it('should get reason code list using base url', () => {
    const url = apiService.baseUrl + 'order' + '-' + apiService.envName + '/ServiceDelivery/v1/Voice/tnActivitySearch/getAllReasonCodes';
    searchPanelsService.getReasonCodeList().subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });

  it('should get customer list using base url', () => {
    const url = apiService.baseUrl + 'order' + '-' + apiService.envName + '/ServiceDelivery/v1/Voice/tnActivitySearch/getCustomerInfo';
    searchPanelsService.getCustomerList().subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });
});
