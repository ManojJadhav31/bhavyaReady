import {Injectable} from '@angular/core';
import {ApiService} from '../../../shared/services/api.service';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {from} from 'rxjs';
import { StorageService } from '../../../services/storage.service';

@Injectable()
export class SearchPanelsService {

  constructor(private apiService: ApiService,
              private http: HttpClient) {
  }

  getProducts() {
    return from(products);
  }

  getLnpOrderStatus() {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/getAllLNPOrderStatus';
    return this.http.get(url).pipe(
      map(data => {
        return data;
      })
    );
  }

  getActivityName() {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/getAllActivityRules';
    return this.http.get(url).pipe(
      map(data => {
        return data;
      })
    );
  }

  getActivityStatus() {
    return from(activityStatus);
  }
getLSRActivityStatus(){
  return from(lsrActivityStatus)
}
  getReasonCodeList() {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/getAllReasonCodes';
    return this.http.get(url).pipe(
      map(data => {
        return data;
      })
    );
  }

  getCustomerList() {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/getCustomerInfo';
    return this.http.get(url).pipe(
      map(data => {
        return data;
      })
    );
  }
}

export const products = [
  // {label: 'All', selected: '', value: null},
  {label: '1111 - ICG Record', value: '1111'},
  {label: '2032 - Managed Modem', value: '2032'},
  {label: '2036 - (3)VoIP Local Inbound', value: '2036'},
  {label: '2037 - (3)VoIP Toll Free', value: '2037'},
  {label: '2042 - (3)VoIP Enhanced Local Service', value: '2042'},
  {label: '2043 - HomeTone', value: '2043'},
  {label: '2044 - (3)Tone', value: '2044'},
  {label: '2045 - Level(3) AOLTone', value: '2045'},
  {label: '2047 - 3VTwIP', value: '2047'},
  {label: '2051 - 3VT TDP', value: '2051'},
  {label: '8318 - Telcove Record', value: '8318'},
  {label: 'BM25 - Voice Complete', value: 'BM25'}
];
export const activityStatus = [
  // {value:  null, selected: 'selected', label: 'All'},
  {value: 'Cancelled', label: 'Cancelled'},
  {value: 'Completed', label: 'Completed'},
  {value: 'E911Rejected', label: 'E911Rejected'},
  {value: 'Error', label: 'Error'},
  {value: 'New', label: 'New'},
  {value: 'Parent Tx Wait', label: 'Parent Tx Wait'},
  {value: 'Processing', label: 'Processing'},
  {value: 'Response Pending', label: 'Response Pending'},
  {value: 'Scheduled', label: 'Scheduled'},
  {value: 'System Wait', label: 'System Wait'}
];
export const lsrActivityStatus = [
  // {value:'',selected:'selected',label:'All'},
	{value:'Cancelled',label:'Cancelled'},
	{value:'Completed',label:'Completed'},
	{value:'Error',label:'Error'},
	{value:'New',label:'New'},
	{value:'Parent Transaction Wait',label:'Parent Transaction Wait'},
	{value:'Processing',label:'Processing'},
	{value:'Scheduled',label:'Scheduled'},
	{value:'System Wait',label:'System Wait'}
];

