export class SearchRequestObject {
  /*default search fields*/
  id: string;
  tn: string;
  tnOrderId: string;
  countryCode: string;
  selectedDateType: string;
  selectedDateCategories = 'relative';
  selectedDateFromDate: string;
  selectedDateToDate: string;
  selectedDateRange: string;
  voiceCompleteServiceId: string;
  voiceOrderId: string;
  selectedDateTypeSecondary: string;
  selectedDateCategoriesSecondary = 'relative';
  selectedDateCategoriesSecondaryFromDate: string;
  selectedDateCategoriesSecondaryToDate: string;
  selectedDateRangeSecondary: string;
  internalPortOptions: string;
  parentOrderId: string;
  activityName: string[];
  reasonCodeList: string[];
  lnpProjectId: string;
  activityStatus: string;
  isDisplayable: string;
  masterBusOrgId: string;
  extOrderId: string;
  showTnTextArea: boolean;
  extOrderIdList: string[];
  tnList: string[];


  /*e911 search fields*/
  aliStatus: string;
  zip: string;
  preDirectional: string;
  city: string;
  streetName: string;
  contactLanguage: string;
  postDirectional: string;
  streetType: string;
  listingLanguage: string;
  businessName: string;
  streetNum: string;
  subscriberName: string;
  stateProv: string;
  esOption: string;

  /* emea search field*/
  country: string;
  cityEmea: string;
  tnAreaCode: string;

  /* inp oder search */
  lnpOrderError: string;
  adoptYn: string;
  lnpStatus: string;
  lnpVendorMessage: string;
  psid: string;
  btn: string;
  lnpOption: string;
  locationScid: string;
  lnpOldLrn: string;
  lnpWirelessYn: string;
  scid: string;
  lnpStateCode: string;
  activationHour: string;
  activationMin: string;
  activationTimeZone: string;
  newLrn: string;

  /* order search field */
  orderActiveYn: string;
  switchType: string;
  lnpOldOcn: string;
  routingLabel: string;
  usageBilling: string;
  lnpOrder: string;
  lnpFeatureCode: string;
  servicePackage: string;
  serviceTransferYn: string;
  market: string;
  newOcn: string;
  lata: string;
  lastInboundError: string;
  orderAction: string;
  orderStatus: string;
  requesterName: string;
  routePlanName: string;
  lastOutboundError: string;
  requesterEmail: string;
  jeopardyError: string;
  orderType: string;
  rcAbbr: string;
  reasonCode: string;
  orderSource: string;
  rcState: string;
  customerList: string[];
  product: string[];
  fipsCode: string;
  accomments: string;

  /*error fields*/
  requiredFieldsError: FieldsErrorDetail;
  dateTypeError: FieldsErrorDetail;
  noData: FieldsErrorDetail;
}

export class LsrSearchRequest {
  wtn: string;
  tns:string ;
  parentOrderId: string;
  purchaseOrderNumber:string;
  status:string;
  extOrderId:string;
  lsrOrderId: string;
  selectedDateType: string;
  selectedDateCategories: string = 'range';
  selectedDateFromDate: string;
  selectedDateToDate: string;
  selectedDateRange: string;
  selectedDateRangeSecondary: string;
  activityName: string;
  orderType: string;
  isDisplayable: string;
  activityStatus: string;
  carrierId:string;
  assignedAgent: string;
  carrierPon: string;
  orderStatus: string;
  companyName: string;
  orderActive: string;
  product: string;
  ban: string;
  lastName: string;
  ver: string;
  atn: string;
  portType: string;
  businessName: string;
  reseller: string;
  contactName: string;
  companyCode: string;
  firstName: string;
  lsrStatus: string;
  resellerName:string;
  billingAccountNumber:string;
  typeOfPort:string;
  ponStatus: string;
  showTnTextArea: boolean;
  

  /*error fields*/
  requiredFieldsError: FieldsErrorDetail;
  dateTypeError: FieldsErrorDetail;
  noData: FieldsErrorDetail;
}

class FieldsErrorDetail {
  error: boolean;
  msg?: string;
}
