import {NgModule} from '@angular/core';
import {DefaultSearchComponent} from './default-search/default-search.component';
import {LnpOrderSearchComponent} from './lnp-order-search/lnp-order-search.component';
import {E911SearchComponent} from './e911-search/e911-search.component';
import {EmeaSearchComponent} from './emea-search/emea-search.component';
import {OrderSearchComponent} from './order-search/order-search.component';
import {SearchPanelsService} from './services/search-panels.service';
import {SharedModule} from '../../shared/shared.module';
import { LsrSearchComponent } from './lsr-search/lsr-search.component';
import { LsrAdvancedSearchComponent } from './lsr-advanced-search/lsr-advanced-search.component';


@NgModule({
  imports: [SharedModule],
  declarations: [
    DefaultSearchComponent,
    E911SearchComponent,
    EmeaSearchComponent,
    LnpOrderSearchComponent,
    OrderSearchComponent,
    LsrSearchComponent,
    LsrAdvancedSearchComponent
  ],
  exports: [
    DefaultSearchComponent,
    E911SearchComponent,
    EmeaSearchComponent,
    LnpOrderSearchComponent,
    OrderSearchComponent,
    LsrSearchComponent,
    LsrAdvancedSearchComponent
  ],
  providers: [SearchPanelsService]
})
export class SearchPanelsModule {
}
