import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {of} from 'rxjs';
import {DefaultSearchComponent} from './default-search.component';
import {SearchPanelsService} from '../services/search-panels.service';
import {ApiService} from '../../../shared/services/api.service';
import {activityName, activityStatus} from '../../../../tests/mockdata/search-panels/default-search';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {SharedModule} from '../../../shared/shared.module';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { StorageService } from '../../../services/storage.service';


describe('DefaultSearchComponent', () => {
  let component: DefaultSearchComponent;
  let fixture: ComponentFixture<DefaultSearchComponent>;
  let searchPanelService: SearchPanelsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DefaultSearchComponent
      ],
      imports: [
        HttpClientTestingModule,
        SharedModule,
        BrowserAnimationsModule
      ],
      providers: [
        SearchPanelsService,
        ApiService,
        StorageService
      ]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    searchPanelService = fixture.debugElement.injector.get(SearchPanelsService);
    spyOn(searchPanelService, 'getActivityName').and.returnValue(of(activityName));
    spyOn(searchPanelService, 'getActivityStatus').and.returnValue(of(activityStatus));

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

it('should populate activity name', () => {
    component.getActivityName();
    expect(component.activityName[1].value).toEqual('432');
  });

  it('should populate activity status', () => {
    component.getActivityStatus();
    expect(component.activityStatus[0].value).toEqual('Cancelled');

  });

});
