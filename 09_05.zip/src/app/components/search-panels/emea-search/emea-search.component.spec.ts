import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {EmeaSearchComponent} from './emea-search.component';
import {DefaultSearchComponent} from '../default-search/default-search.component';
import {E911SearchComponent} from '../e911-search/e911-search.component';
import {LnpOrderSearchComponent} from '../lnp-order-search/lnp-order-search.component';
import {OrderSearchComponent} from '../order-search/order-search.component';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {SearchPanelsService} from '../services/search-panels.service';
import {SharedModule} from '../../../shared/shared.module';
import { ApiService } from '../../../shared/services/api.service';
import { StorageService } from '../../../services/storage.service';


describe('EmeaSearchComponent', () => {
  let component: EmeaSearchComponent;
  let fixture: ComponentFixture<EmeaSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DefaultSearchComponent,
        E911SearchComponent,
        EmeaSearchComponent,
        LnpOrderSearchComponent,
        OrderSearchComponent
      ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        SharedModule,
        BrowserAnimationsModule
      ],
      providers: [
        ApiService,
        SearchPanelsService,
        StorageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmeaSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set values', async(() => {
    expect(component.country[0].value).toEqual('');
    expect(component.featureCode[0].selected).toEqual('selected');
    expect(component.esOption[0].selected).toEqual('selected');
    expect(component.jeopardyErrors[0].selected).toEqual('selected');
  }));

});
