import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {OrderSearchComponent} from './order-search.component';
import {DefaultSearchComponent} from '../default-search/default-search.component';
import {E911SearchComponent} from '../e911-search/e911-search.component';
import {EmeaSearchComponent} from '../emea-search/emea-search.component';
import {LnpOrderSearchComponent} from '../lnp-order-search/lnp-order-search.component';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {SearchPanelsService} from '../services/search-panels.service';
import {SharedModule} from '../../../shared/shared.module';

import {PortoutService} from '../../portout/services/portout.service';
import {ApiService} from '../../../shared/services/api.service';
import { StorageService } from '../../../services/storage.service';


describe('OrderSearchComponent', () => {
  let component: OrderSearchComponent;
  let fixture: ComponentFixture<OrderSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DefaultSearchComponent,
        E911SearchComponent,
        EmeaSearchComponent,
        LnpOrderSearchComponent,
        OrderSearchComponent
      ],
      imports: [
        BrowserModule,
        FormsModule,
        SharedModule,
        ReactiveFormsModule,
        HttpClientModule,

        BrowserAnimationsModule
      ],
      providers: [
        SearchPanelsService,
        PortoutService,
        ApiService,
        StorageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderSearchComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
