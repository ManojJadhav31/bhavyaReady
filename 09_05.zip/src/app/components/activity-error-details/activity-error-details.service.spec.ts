import { TestBed } from '@angular/core/testing';

import { ActivityErrorDetailsService } from './activity-error-details.service';

describe('ActivityErrorDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ActivityErrorDetailsService = TestBed.get(ActivityErrorDetailsService);
    expect(service).toBeTruthy();
  });
});
