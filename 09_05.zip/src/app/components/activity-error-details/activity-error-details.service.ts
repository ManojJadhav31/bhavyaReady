import { Injectable } from '@angular/core';
import { ApiService } from '../../shared/services/api.service';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ActivityErrorDetailsService {

  constructor(private http: HttpClient, private apiService: ApiService) { }

  getOrderDetails(id: string) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsractivity/error?orderActivityIdPK=' + id;
    return this.http.get(url).pipe(catchError(error => this.apiService.handleException(error)));
  }
}
