import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PonSearchComponent } from './pon-search.component';
import { PonActivationComponents, PonActivationRoutingModule } from '../pon-activation-routing.module';
import { TnActivitySearchService } from '../../activation-service/services/tn-activity-search.service';
import { ApiService } from '../../../shared/services/api.service';
import { PortoutService } from '../../portout/services/portout.service';
import { RouterTestingModule } from '@angular/router/testing';
import { PonActivationService } from '../services/pon-activation.service';
import { SharedModule } from '../../../shared/shared.module';
import { UtilityService } from '../../../shared/services/utility.service';
import { of } from 'rxjs';


describe('PonSearchComponent', () => {
  let component: PonSearchComponent;
  let fixture: ComponentFixture<PonSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PonActivationComponents
      ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        PonActivationRoutingModule,
        RouterTestingModule
      ],
      providers: [
        TnActivitySearchService,
        PortoutService,
        UtilityService,
        ApiService,
        PonActivationService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PonSearchComponent);
    component = fixture.componentInstance;
    spyOn(component.ponService, 'getPONByVoid').and.returnValue(of([]));
    spyOn(component.ponService, 'searchPon').and.returnValue(of({}));
    spyOn(component.ponService, 'getTns').and.returnValue(of([]));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should search pon by PON', () => {
    component.ponSearch.pon = '123123123, 4564654';
    component.onPonSearch();
    expect(component.results.length).toBe(2);
  });
  it('should be able to clear pon form fields', () => {
    component.onClearFields();
    expect(component.isSearchingPon).toBe(false);
    expect(component.results.length).toBe(0);
    expect(component.ponSearch).toEqual({});
  });
   it('should be able to fetch Tns details', () => {
     const data = {
       tn: {
         pon:
           '537'
       },
       activity: {
         activityId: '1236548'
       }
     };
     component.getTns(data.tn, data.activity);
     expect(component).toBeTruthy();
   });

  it('should search pon by VOID', () => {
    component.ponSearch.void = '123123123';
    component.onPonSearch();
    expect(component.results.length).toBe(0);
  });
});
