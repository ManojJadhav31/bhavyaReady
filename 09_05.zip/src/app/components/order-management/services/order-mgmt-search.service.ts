import { Injectable } from '@angular/core';
import { ApiService } from '../../../shared/services/api.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { UtilityService } from '../../../shared/services/utility.service';


@Injectable()
export class OrderMgmtSearchService {

  constructor( private http: HttpClient,
               private apiService: ApiService,private utilityService: UtilityService ) {
  }

  searchActivities( data, pageSize, page ) {
    page = page - 1;
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/orderSearch/search/' + pageSize + '/' + page;
    const body = JSON.stringify(data);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.post(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }

  getOrderDetail( orderId ) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/slOrder/' + orderId;
    return this.http.get(url).pipe(catchError(error => this.apiService.handleException(error)));
  }

  getExportDetail( data ) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/search/export';
    const body = JSON.stringify(data);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.post(url, body, { responseType: 'blob', headers: headers }).pipe(
      map(( response ) => {
        return { fileName: 'tn-details.csv', data: response };
      }),
      catchError(error => this.apiService.handleException(error))
    );
  }

  getOrderPricingInfo( orderId, tn ): Observable<any> {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/pricing/' + orderId + '/' + tn;
    return this.http.get(url).pipe(catchError(error => this.apiService.handleException(error)));
  }

  updateActivitiesOrderDate( data: any, extraDetails, correlationId: string ): Observable<any> {
    console.log(extraDetails);
    // const url = this.apiService.saui3FlowURL;
    // let xhr: XMLHttpRequest;
    const userName = this.utilityService.getUserId()
    const requestPayload = {
      'correlationId': correlationId,
      'systemId': 'User',
      'userId': userName,
      'orderId': data,
      'orderComment': extraDetails.orderComments,
      'dateType': extraDetails.dateType,
      'newDate': extraDetails.newDate
    };
    const endpoint = '/ServiceDelivery/v1/Voice/tnActivitySearch/order/date';
    const url = this.apiService.orderApiUrl + endpoint;
    const body = JSON.stringify(requestPayload);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.put(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }

  updateActivitiesOrderComment( data: any, orderComments: string, correlationId: string ): Observable<any> {
    const userName = this.utilityService.getUserId;
    const requestPayload = {
      'correlationId': correlationId,
      'systemId': 'User',
      'userId': userName,
      'orderComments': orderComments,
      'slOrderId': data
    };
    const endpoint = '/ServiceDelivery/v1/Voice/tnActivitySearch/order/comments';
    const url = this.apiService.orderApiUrl + endpoint;
    const body = JSON.stringify(requestPayload);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.put(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }
}
