import { NgModule } from '@angular/core';
import { OrderManagementRoutingModule } from './order-management-routing.module';
import { OrderMgmtSearchService } from './services/order-mgmt-search.service';
import { SearchPanelsModule } from '../search-panels/search-panels.module';
import { OrderManagementOrderDetailPageComponent } from './order-management-order-detail-page/order-management-order-detail-page.component';
import { SharedModule } from '../../shared/shared.module';
import { OrderManagementComponent } from './order-management.component';
import { OrderMgmtSearchComponent } from './order-mgmt-search/order-mgmt-search.component';
import { PricingInformationComponent } from './pricing-information/pricing-information.component';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';
import { TransactionViewDialogModule } from '../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateOrderDateDialogModule } from '../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { ColumnPickListDialogModule } from '../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

@NgModule({
  imports: [ SharedModule,
    OrderManagementRoutingModule,
    SearchPanelsModule,
    UpdateOrderDateDialogModule,
    TransactionViewDialogModule,
    UpdateReasonDialogModule,
    ColumnPickListDialogModule ],
  declarations: [ OrderManagementComponent, OrderMgmtSearchComponent, OrderManagementOrderDetailPageComponent, PricingInformationComponent ],
  providers: [ OrderMgmtSearchService ],
})
export class OrderManagementModule {
}
