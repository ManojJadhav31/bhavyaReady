import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricingInformationComponent } from './pricing-information.component';
import { SharedModule } from '../../../shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OrderManagementRoutingModule } from '../order-management-routing.module';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { RouterTestingModule } from '@angular/router/testing';
import { OrderMgmtSearchService } from '../services/order-mgmt-search.service';
import { SearchPanelsService } from '../../search-panels/services/search-panels.service';
import { OrderManagementComponent } from '../order-management.component';
import { OrderMgmtSearchComponent } from '../order-mgmt-search/order-mgmt-search.component';
import { OrderManagementOrderDetailPageComponent } from '../order-management-order-detail-page/order-management-order-detail-page.component';
import { ApiService } from '../../../shared/services/api.service';
import { PortoutService } from '../../portout/services/portout.service';
import { StorageService } from '../../../services/storage.service';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

describe('PricingInformationComponent', () => {
  let component: PricingInformationComponent;
  let fixture: ComponentFixture<PricingInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderManagementComponent, OrderMgmtSearchComponent, OrderManagementOrderDetailPageComponent, PricingInformationComponent ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        OrderManagementRoutingModule,
        SearchPanelsModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        OrderMgmtSearchService,
        SearchPanelsService,
        ApiService,
        PortoutService,
        StorageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricingInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
