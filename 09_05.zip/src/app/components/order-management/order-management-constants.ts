export interface OrderPricingDTOResponse {
  amount: number;
  charge_level: string;
  currency: string;
  date_created: string;
  description: string;
  formatted_amount: string;
  formatted_gross: string;
  formatted_net: string;
  formatted_unit_price: string;
  frequency: string;
  gross: number;
  id: number;
  last_updated_user: string;
  lst_updated: string;
  net: number;
  quantity: number;
  slOrderID: number;
  tn: string;
  unit_of_measure: string;
  unit_price: number;
}
