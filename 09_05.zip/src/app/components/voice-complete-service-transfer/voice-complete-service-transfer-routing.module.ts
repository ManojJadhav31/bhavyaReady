import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VoiceCompleteServiceTransferViewComponent } from './voice-complete-service-transfer-view/voice-complete-service-transfer-view.component';

const routes: Routes = [
  {
    path: '',
    component: VoiceCompleteServiceTransferViewComponent
  }
];

@NgModule({
  imports: [ RouterModule.forChild(routes) ],
  exports: [ RouterModule ]
})
export class VoiceCompleteServiceTransferRoutingModule {
}
