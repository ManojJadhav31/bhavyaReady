import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TnActivitySearchComponent } from './tn-activity-search/tn-activity-search.component';
import { ActivationServiceComponent } from './activation-service.component';
import { TnActivityOrderDetailPageComponent } from './tn-activity-order-detail-page/tn-activity-order-detail-page.component';
import { TnActivityDetailPageComponent } from './tn-activity-detail-page/tn-activity-detail-page.component';

const routes: Routes = [
  {
    path: '', component: ActivationServiceComponent,
    data: {
      breadcrumb: 'Activation service'
    },
    children: [
      { path: '', redirectTo: 'tn-activity-search', pathMatch: 'full' },
      {
        path: 'tn-activity-search', component: TnActivitySearchComponent,
        data: {
          breadcrumb: 'TN activity search'
        }
      },
      {
        path: 'tn-activity-order-detail/:slOrderId', component: TnActivityOrderDetailPageComponent,
        data: {
          breadcrumb: 'TN activity order detail'
        }
      },
      {
        path: 'tn-activity-detail/:activityId', component: TnActivityDetailPageComponent,
        data: {
          breadcrumb: 'TN activity detail'
        }
      },
      {
        path: 'tn-activity-errors/:id', loadChildren: 'src/app/components/activity-error-details/activity-error-details.module#ActivityErrorDetailsModule',
        data: {
          breadcrumb: 'TN activity error detail'
        }
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],

})
export class ActivationServiceRoutingModule {
}
