import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { TnActivitySearchService } from '../services/tn-activity-search.service';
import { TnSearchResultsGridColumns } from './tn-activity-search-results-grid-columns';
import * as dateFn from 'date-fns';
import { DataTable } from 'primeng/primeng';
import { Router } from '@angular/router';
import { SearchRequestObject } from '../../search-panels/search-panel-constants';
import { StorageService } from '../../../services/storage.service';
import { forkJoin, Observable, Subscription } from 'rxjs';
import * as XLSX from 'xlsx';
import { UpdateOrderDateDialogComponent } from '../../dialog/update-order-date-dialog/update-order-date-dialog.component';
import { TransactionViewDialogComponent } from '../../dialog/transaction-view-dialog/transaction-view-dialog/transaction-view-dialog.component';
import { UpdateReasonDialogComponent } from '../../dialog/update-reason-dialog/update-reason-dialog.component';
import { ColumnPickListDialogComponent } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog/column-pick-list-dialog.component';
import { UtilityService } from '../../../shared/services/utility.service';


@Component({
  selector: 'app-tn-activity-search',
  templateUrl: './tn-activity-search.component.html',
  styleUrls: ['./tn-activity-search.component.scss']
})
export class TnActivitySearchComponent implements OnInit, OnDestroy {

  @ViewChild('searchResultGrid') searchResultGrid: DataTable;
  slOrderId: any;
  activityName: any = [];
  activityStatus: any = [];
  customerList: any = [];
  dateType: any = [];
  selectedDateType: any = 'All';
  dateCategories: any = [];
  selectedDateCategories: any = 'range';
  dateRange: any = [];
  selectedDateRange: any;
  frozenCols: any[];
  filteredParentOrderId: number;
  selectedDateTypeSecondary: any = 'All';
  selectedDateCategoriesSecondary: any = 'range';
  selectedDateRangeSecondary: any;
  items: MenuItem[];

  defaultDate: Date = new Date();
  panelFilter: PanelFilter;
  filteredResults: any[] = [];
  selectedActivityIds: any[] = [];
  activitySearch: SearchRequestObject = new SearchRequestObject();

  gridColumnList: any = [];
  hiddenColumns: any = [];
  showColumnFilterDialog = false;
  isSearching = false;
  searchResults: any = [];
  pageNumber = 1;
  totalRecords = 0;
  pageSize = 100;
  firstPage = 0;
  skip = 0;
  actionToPerform = { code: 'export' };

  exportType: any = { name: 'Selected Result', code: 'selected' };
  actionDropdownOptions: any[] = [
    {
      name: 'export', code: 'export'
    }
  ];

  @ViewChild('updateOrderDateDialog') updateOrderDateDialog: UpdateOrderDateDialogComponent;
  @ViewChild('transactionDetailsDialog') transactionDetailsDialog: TransactionViewDialogComponent;
  @ViewChild('updateReasonOnlyDialog') updateReasonOnlyDialog: UpdateReasonDialogComponent;
  updateOptions: any = [
    { name: 'All Result', code: 'all' },
    { name: 'Selected Activities', code: 'selected' },
    { name: 'Selected Order', code: 'selectedOrder' }
  ];
  updateOptionsOperations: any = [
    { name: 'Restart Activity', code: 'restartActivity' },
    { name: 'Complete Activity', code: 'forceCompleteActivity' }
  ];
  selectedOrderOperations: any = [
    { name: 'Select One', code: '' },
    { name: 'Update Order Date', code: 'orderDateUpdate' },
    { name: 'Update Order Comment', code: 'orderCommentUpdate' }
  ];
  exportOptions: any = [
    { name: 'All Result', code: 'all' },
    { name: 'Selected Result', code: 'selected' }
  ];
  resultType: any = {
    code: 'all'
  };
  resultOptions: any = [
    { name: 'Export Results', code: 'all' },
    { name: 'Export All', code: 'exportAll' },
    { name: 'Export TNS', code: 'tns' }

  ];
  updateAction = {
    type: { name: 'Selected Activities', code: 'selected' },
    operation: { name: 'Restart Activity', code: 'restartActivity' }
  };
  updateActionReason = { name: 'Choose', code: '' };
  completedActionReason = '';
  reasonCommentOptions: any = [
    { name: 'Choose', code: '' },
    { name: 'Completing Manual Task', code: 'Completing Manual Task' },
    { name: 'Completing Re-opened Task', code: 'Completing Re-opened Task' },
    {
      name: 'Completing task-Completed task didnt not create next task',
      code: 'Completing task-Completed task didnt not create next task'
    },
    { name: 'Completing task - Duplicate Task Created', code: 'Completing task - Duplicate Task Created' },
    { name: 'Completing task - Task did not auto-complete', code: 'Completing task - Task did not auto-complete' },
    { name: 'Completing task to move order forward', code: 'Completing task to move order forward' },
    { name: 'Other', code: 'Other' },
    { name: 'Provising complete', code: 'Provising complete' },
  ];

  updateError = '';
  updateErrorShowTrunk = {
    length: 500,
    showMore: false
  };
  updateErrorMesg = '';
  successMessage = '';
  message: string;
  selectAllCheckBox = [];
  panelFilterList: string[] = [];
  searchPanelCollapsed = {
    mainSearch: false,
    OrderSearch: false,
    LnpSearch: false,
    E911Search: false,
    EmeaSearch: false
  };
  filerPanelsCheckBox = {
    OrderSearch: [],
    LnpSearch: [],
    E911Search: [],
    EmeaSearch: []
  };
  isExporting = false;
  isUpdating = false;
  displayCompletedActivitydialog = false;
  public tnSearchResultsGridColumns = TnSearchResultsGridColumns;
  public defaultGridColumns: string[] = ['voiceOrderId', 'parentTransId', 'tn', 'lnpFocDate', 'customerRequestDate', 'lnpStatus', 'customerBizOrgName',
    'activityName', 'activityStatus', 'activityCreateDate', 'activityCompleteDate', 'activationDate'];

  @ViewChild('columnPickListDialog') columnPickListDialog: ColumnPickListDialogComponent;
  UserName: string;
  private searchSubscription: Subscription;

  constructor(private tnActSearchService: TnActivitySearchService,
    public storageService: StorageService,
    private utilService: UtilityService,
    private router: Router) {
    this.storageService.setModule('tn-activity');
  }

  ngOnDestroy(): void {
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
  }

  ngOnInit() {
    this.UserName = localStorage.getItem('UserName') !== 'undefined' ? localStorage.getItem('UserName') : undefined;
    if (this.UserName) {
      this.actionDropdownOptions.push({
        name: 'Update', code: 'update'
      });
    }
    this.panelFilter = {
      OrderSearch: false,
      LnpSearch: false,
      E911Search: false,
      EmeaSearch: false
    };
    this.activitySearch.selectedDateTypeSecondary = 'All';
    this.activitySearch.selectedDateType = 'All';
    this.searchResults = [];
    this.filteredResults = [];
    this.setPresetData();
  }

  setPresetData() {
    const columnList = JSON.parse(JSON.stringify(this.tnSearchResultsGridColumns));
    columnList.forEach((item) => {
      if (this.defaultGridColumns.indexOf(item.value) !== -1) {
        item.visible = true;
      }
    });
    this.gridColumnList = columnList.filter(item => item.visible);
    this.hiddenColumns = columnList.filter(item => !item.visible);

    const searchDetails = this.storageService.getSearchDetails();
    if (searchDetails) {
      if (searchDetails.formData) {
        Object.assign(this.activitySearch, searchDetails.formData);
      }
      if (searchDetails.results && searchDetails.totalRecords) {
        Object.assign(this.searchResults, searchDetails.results);
        this.totalRecords = searchDetails.totalRecords;
        Object.assign(this.filteredResults, searchDetails.results);
        this.skip = 0;
        this.searchPanelCollapsed['mainSearch'] = true;
      }
      if (searchDetails.panelList) {
        searchDetails.panelList.forEach((key) => {
          if (searchDetails.results && searchDetails.totalRecords) {
            this.searchPanelCollapsed[key] = true;
          }
          this.filerPanelsCheckBox[key] = ['true'];
          this.filterPanels(key, true);
        });
      }
      if (searchDetails.pageConfig) {
        this.firstPage = searchDetails.pageConfig.firstPage;
        this.pageNumber = searchDetails.pageConfig.pageNumber;
        this.pageSize = searchDetails.pageConfig.pageSize;
      }
      const pickListDetails = this.storageService.getPickList();
      if (pickListDetails) {
        this.hiddenColumns = pickListDetails.hiddenColumns;
        this.gridColumnList = pickListDetails.gridColumnList;
      }
    }
  }

  filterPanels(key, event) {
    if (key === 'OrderSearch') {
      this.panelFilter.OrderSearch = event;
    } else if (key === 'LnpSearch') {
      this.panelFilter.LnpSearch = event;
    } else if (key === 'E911Search') {
      this.panelFilter.E911Search = event;
    } else if (key === 'EmeaSearch') {
      this.panelFilter.EmeaSearch = event;
    }
    if (event) {
      const index = this.panelFilterList.indexOf(key);
      if (index === -1) {
        this.panelFilterList.push(key);
      }
    } else {
      const index = this.panelFilterList.indexOf(key);
      if (index !== -1) {
        this.panelFilterList.splice(index, 1);
      }
    }
    this.storageService.storePanelSearchList(this.panelFilterList);
  }

  search(activitySearch) {
    this.updateError = '';
    this.updateErrorMesg = '';
    this.message = '';
    this.successMessage = '';
    this.pageNumber = 1;
    this.firstPage = 0;
    this.selectedActivityIds = [];
    this.selectAllCheckBox = [];
    this.storageService.storeSelectedActivityIds([], true);
    this.searchActivities(activitySearch);
  }

  checkNonRequiredField(activitySearch) {
    if (activitySearch.activityName || activitySearch.activityStatus || activitySearch.countryCode || activitySearch.selectedDateCategoriesSecondaryToDate || activitySearch.selectedDateCategoriesSecondaryFromDate) {
      return true;
    }
    if (this.filerPanelsCheckBox.LnpSearch[0] && this.filerPanelsCheckBox.LnpSearch[0] == 'true') {
      if (activitySearch.lnpStatus || activitySearch.lnpOrderState || activitySearch.psid || activitySearch.lnpOption || activitySearch.lnpStateCode || activitySearch.scid || activitySearch.lnpOldLrn
        || activitySearch.newLrn || activitySearch.lnpOrderError || activitySearch.lnpWirelessYn || activitySearch.locationScid || activitySearch.lnpWirelessYn
        || activitySearch.btn || activitySearch.adoptYn || activitySearch.activationHour || activitySearch.activationMin || activitySearch.activationTimeZone) {
        return true;
      }
    }
    if (this.filerPanelsCheckBox.E911Search[0] && this.filerPanelsCheckBox.E911Search[0] == 'true') {
      if (activitySearch.businessName || activitySearch.preDirectional || activitySearch.aliStatus || activitySearch.subscriberName || activitySearch.streetNum
        || activitySearch.fipsCode || activitySearch.city || activitySearch.streetName || activitySearch.stateProv || activitySearch.streetType
        || activitySearch.zip || activitySearch.postDirectional || activitySearch.esOption) {
        return true;
      }
    }
    if (this.filerPanelsCheckBox.EmeaSearch[0] && this.filerPanelsCheckBox.EmeaSearch[0] == 'true') {
      if (activitySearch.country || activitySearch.cityEmea || activitySearch.tnAreaCode || activitySearch.contactLanguage || activitySearch.listingLanguage) {
        return true;
      }
    }
    if (this.filerPanelsCheckBox.OrderSearch[0] && this.filerPanelsCheckBox.OrderSearch[0] == 'true') {
      if (activitySearch.orderType || activitySearch.customerList || activitySearch.product || activitySearch.switchType
        || activitySearch.lnpOrder || activitySearch.orderStatus || activitySearch.orderAction || activitySearch.servicePackage || activitySearch.orderSource
        || activitySearch.switchType || activitySearch.serviceTransferYn || activitySearch.routePlanName || activitySearch.requesterName || activitySearch.requesterEmail
        || activitySearch.accomments || activitySearch.jeopardyError || activitySearch.lastInboundError || activitySearch.lnpFeatureCode || activitySearch.rcAbbr
        || activitySearch.rcState || activitySearch.reasonCodeList || activitySearch.lastOutboundError || activitySearch.lnpOldOcn || activitySearch.newOcn
        || activitySearch.lata || activitySearch.market || activitySearch.extOrderIdList || activitySearch.usageBilling) {//activitySearch.orderActiveYn ||
        return true;
      }

    }
    return false;
  }

  searchActivities(activitySearch, checkCheckbox = false) {
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
    this.activitySearch.noData = {
      error: false
    };
    if (activitySearch.tnOrderId || activitySearch.lnpProjectId || activitySearch.id || activitySearch.voiceOrderId || activitySearch.extOrderId || activitySearch.parentOrderId || activitySearch.tn || (activitySearch.tn === null && activitySearch.tnList) || activitySearch.voiceCompleteServiceId || activitySearch.selectedDateType !== 'All' || activitySearch.selectedDateTypeSecondary !== 'All') {
      activitySearch.requiredFieldsError = {
        error: false
      };
    } else {
      activitySearch.requiredFieldsError = {
        error: true,
        msg: 'Please enter at least one of the required fields'
        // : Tn Order ID, LNP ProjectID , Activity ID, Voice Order Id ,Parent Order Id,Voice Complete ServiceID, External Order Id, or TN
      };
      return;
    }
    if (activitySearch.requiredFieldsError.error === false) {
      if (activitySearch.selectedDateType !== 'All') {
        this.utilService.fillDateTypePayload(activitySearch, activitySearch);
        let error = false;
        if (activitySearch.tnOrderId || activitySearch.lnpProjectId || activitySearch.id || activitySearch.voiceOrderId || activitySearch.extOrderId || activitySearch.parentOrderId || activitySearch.tn || activitySearch.voiceCompleteServiceId) {
          error = false;
        } else if (activitySearch.selectedDateCategories === 'range') {
          if (dateFn.differenceInCalendarDays(activitySearch.selectedDateToDate, activitySearch.selectedDateFromDate) >= 90) {
            error = true;
          }
        } else if (activitySearch.selectedDateCategories === 'relative' && activitySearch.selectedDateRange === 'past90Days' && this.checkNonRequiredField(activitySearch)) {
          error = true;
        }
        if (error) {
          activitySearch.requiredFieldsError = {
            error: true,
            msg: 'You can not select date type past 90 days date'
          };
          this.isSearching = false;
          return;
        }
      }
      if (activitySearch.selectedDateTypeSecondary !== 'All') {
        this.utilService.fillDateTypeSecondaryPayload(activitySearch, activitySearch);
        let error = false;
        if (activitySearch.tnOrderId || activitySearch.lnpProjectId || activitySearch.id || activitySearch.voiceOrderId || activitySearch.extOrderId || activitySearch.parentOrderId || activitySearch.tn || activitySearch.voiceCompleteServiceId) {
          error = false;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'range' && this.checkNonRequiredField(activitySearch)) {
          if (dateFn.differenceInCalendarDays(activitySearch.selectedDateCategoriesSecondaryToDate, activitySearch.selectedDateCategoriesSecondaryFromDate) >= 90) {
            error = true;
          }
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative' && activitySearch.selectedDateRangeSecondary === 'past90Days' && this.checkNonRequiredField(activitySearch)) {
          error = true;
        }
        if (error) {
          activitySearch.requiredFieldsError = {
            error: true,
            msg: 'You can not select date type secondary past 90 days date'
          };
          this.isSearching = false;
          return;
        }
      }
    }

    if (activitySearch.selectedDateType !== 'All' && activitySearch.selectedDateType === activitySearch.selectedDateTypeSecondary) {
      activitySearch.dateTypeError = {
        error: true,
        msg: 'Date Type & Date Type Secondary cannot be same. Please choose different values.'
      };
      return;
    } else {
      activitySearch.dateTypeError = {
        error: false
      };
    }
    this.createBodyForService(activitySearch).subscribe((returnBody) => {
      const body = returnBody;
      this.searchResults = [];
      this.filteredResults = [];
      this.totalRecords = 0;
      // this.skip = 0;
      this.isSearching = true;
      this.message = '';
      this.searchSubscription = this.tnActSearchService.searchActivities(body, this.pageSize, this.pageNumber).subscribe(res => {
        this.isSearching = false;
        const data = (res as any);
        if (data.orderTNActivitySummaryDTOList && data.orderTNActivitySummaryDTOList.length > 0) {
          this.searchPanelCollapsed = {
            mainSearch: true,
            OrderSearch: true,
            LnpSearch: true,
            E911Search: true,
            EmeaSearch: true
          };
          // make activity as select to update
          const activitySerchResult = JSON.parse(JSON.stringify(data.orderTNActivitySummaryDTOList));
          if (checkCheckbox) {
            // if (this.selectAllCheckBox[0] === 'true') {
            //   const activityIds = activitySerchResult.filter(object => {
            //     return !this.selectedActivityIds.find(obj => obj.id === object.id)
            //   });
            //   this.selectedActivityIds = this.selectedActivityIds.concat(activityIds)
            // }
            activitySerchResult.forEach(activity => {
              const findObject = this.selectedActivityIds.find(obj => obj.id === activity.id);
              if (findObject) {
                activity.checked = 'true';
              }
            });
          } else {
            this.selectedActivityIds = [];
          }
          this.searchResults = activitySerchResult;//JSON.parse(JSON.stringify(data.orderTNActivitySummaryDTOList));
          this.filteredResults = activitySerchResult;//JSON.parse(JSON.stringify(data.orderTNActivitySummaryDTOList));
          this.totalRecords = data.totalElementsCount;
          this.skip = 0;
          /*used to store current search details*/
          this.storageService.storeSearchDetails(activitySearch, this.searchResults, this.totalRecords);
        } else {
          this.activitySearch.noData = {
            error: true
          };
        }
      }, error => {
        this.message = error;
        this.isSearching = false;
      });
    });
  }

  createBodyForService(activitySearch): Observable<any> {
    return new Observable((observer) => {
      const body: any = {};

      // ----------- Default Search Params -----------
      body.slOrderId = activitySearch.tnOrderId || undefined;
      body.serviceId = activitySearch.voiceCompleteServiceId || undefined;
      body.internalPortYn = activitySearch.internalPortOptions || undefined;
      body.lnpProjectId = activitySearch.lnpProjectId || undefined;
      body.extOrderIdList = activitySearch.extOrderId || undefined;
      body.voiceOrderId = activitySearch.voiceOrderId || undefined;
      if (activitySearch.activityName && activitySearch.activityName.length > 0) {
        body.activityNameList = activitySearch.activityName.map(item => {
          return item.activityDisplayLabel;
        });
      }

      if (activitySearch.activityStatus && activitySearch.activityStatus.length > 0) {
        body.activityStatusList = activitySearch.activityStatus;
      }

      // body.activityStatusList = activitySearch.activityStatus || undefined;
      body.parentTransIdList = activitySearch.parentOrderId || undefined;
      body.isDisplayable = activitySearch.isDisplayable || undefined;

      if (activitySearch.showTnTextArea) {
        body.tnList = this.utilService.createArrayFromTextArea(activitySearch.tnList);
        // const tns = activitySearch.tnList.split(',');
        // if (tns.length > 0) {
        //   body.tnList = tns;
        // } else {
        //   body.tnList = [activitySearch.tnList];
        // }
      } else {
        if (activitySearch.tn) {
          body.tnList = this.utilService.createArrayFromTextArea(activitySearch.tn);
        }
      }
      if (body.tnList) {
        if (body.tnList.length === 0) {
          delete body.tnList;
        }
      }
      if (activitySearch.parentOrderId) {
        body.parentTransIdList = this.utilService.createArrayFromTextArea(activitySearch.parentOrderId);

      }
      if (activitySearch.extOrderId) {
        body.extOrderIdList = this.utilService.createArrayFromTextArea(activitySearch.extOrderId);

        // const newValue = activitySearch.extOrderId.replace(new RegExp('\r?\n', 'g'), ',')

      }
      if (activitySearch.selectedDateType !== 'All') {
        this.utilService.fillDateTypePayload(activitySearch, body);
      }
      if (activitySearch.selectedDateTypeSecondary !== 'All') {
        this.utilService.fillDateTypeSecondaryPayload(activitySearch, body);
      }


      // ----------- Order Search Params -----------
      body.orderActiveYn = activitySearch.orderActiveYn || undefined;
      body.switchType = activitySearch.switchType || undefined;
      body.rcAbbr = activitySearch.rcAbbr || undefined;
      body.lnpOldOcn = activitySearch.lnpOldOcn || undefined;
      body.routeLabel = activitySearch.routingLabel || undefined;

      if (activitySearch.servicePackage && activitySearch.servicePackage.length > 0) {
        body.servicePackageList = activitySearch.servicePackage;
      }
      // body.servicePackageList = activitySearch.servicePackage || undefined;
      body.serviceTransferYn = activitySearch.serviceTransferYn || undefined;
      body.market = activitySearch.market || undefined;
      body.newOcn = activitySearch.newOcn || undefined;
      body.lata = activitySearch.lata || undefined;

      if (activitySearch.reasonCodeList && activitySearch.reasonCodeList.length > 0) {
        body.reasonCodeList = activitySearch.reasonCodeList;
      }
      // body.reasonCodeList = activitySearch.reasonCodeList || undefined;
      body.id = activitySearch.id || undefined;
      // body.customerServiceRequestId = activitySearch.
      // body.lastInboundError = activitySearch.lastInboundError;
      body.orderAction = activitySearch.orderAction || undefined;

      if (activitySearch.orderStatus && activitySearch.orderStatus.length > 0) {
        body.orderStatusList = activitySearch.orderStatus;
      }
      // body.orderStatusList = activitySearch.orderStatus || undefined;
      body.requesterName = activitySearch.requesterName || undefined;
      body.routePlanName = activitySearch.routePlanName || undefined;
      // body.lastOutboundError = activitySearch.lastOutboundError;
      body.requesterEmail = activitySearch.requesterEmail || undefined;
      body.orderType = activitySearch.orderType || undefined;
      body.orderSource = activitySearch.orderSource || undefined;
      body.lnpYn = activitySearch.lnpOrder || undefined;
      body.fipsCode = activitySearch.fipsCode || undefined;
      body.customerList = activitySearch.customerList || undefined;

      body.product = activitySearch.product || undefined;
      body.accomments = activitySearch.accomments || undefined;
      body.rcState = activitySearch.rcState || undefined;


      //  ----------- LNP Order Search -----------
      body.lnpOrderError = activitySearch.lnpOrderError || undefined;
      body.adoptYn = activitySearch.adoptYn || undefined;

      if (activitySearch.lnpStatus && activitySearch.lnpStatus.length > 0) {
        body.lnpStatusList = activitySearch.lnpStatus;
      }
      // body.lnpStatusList = activitySearch.lnpStatus || undefined;
      body.lnpVendorMesg = activitySearch.lnpVendorMessage || undefined;
      body.btn = activitySearch.btn || undefined;
      body.lnpOption = activitySearch.lnpOption || undefined;
      body.locationScid = activitySearch.locationScid || undefined;
      body.lnpOldLrn = activitySearch.lnpOldLrn || undefined;
      body.lnpWirelessYn = activitySearch.lnpWirelessYn || undefined;
      body.scid = activitySearch.scid || undefined;

      if (activitySearch.lnpOrderState && activitySearch.lnpOrderState.length > 0) {
        body.lnpOrderStateList = activitySearch.lnpOrderState;
      }
      // body.lnpOrderStateList = activitySearch.lnpOrderState || undefined;
      if (activitySearch.activationHour && activitySearch.activationMin && activitySearch.activationTimeZone) {
        body.activationDate = activitySearch.activationHour + ':' + activitySearch.activationMin + ' ' + activitySearch.activationTimeZone;
      }
      body.newLrn = activitySearch.newLrn || undefined;

      //  ----------- E911 Search -----------
      // body.owner = activitySearch.owner;
      body.aliStatus = activitySearch.aliStatus || undefined;
      body.zip = activitySearch.zip || undefined;
      body.preDirectional = activitySearch.preDirectional || undefined;
      body.city = activitySearch.city || undefined;
      body.streetName = activitySearch.streetName || undefined;
      body.postDirectional = activitySearch.postDirectional || undefined;
      body.streetType = activitySearch.streetType || undefined;
      body.businessName = activitySearch.businessName || undefined;
      body.streetNum = activitySearch.streetNum || undefined;
      body.subscriberName = activitySearch.subscriberName || undefined;
      body.stateProv = activitySearch.stateProv || undefined;
      body.contactLanguage = activitySearch.contactLanguage || undefined;
      body.listingLanguage = activitySearch.listingLanguage || undefined;
      body.lnpStateCode = activitySearch.lnpStateCode || undefined;

      //  ----------- EMEA Search -----------
      body.country = activitySearch.country || undefined;
      body.cityEmea = activitySearch.cityEmea || undefined;
      body.tnAreaCode = activitySearch.tnAreaCode || undefined;
      observer.next(body);
    });
  }

  gotoDetail(item) {
    this.router.navigate(['./activation-service/tn-activity-order-detail/' + item.slOrderId]);
  }

  gotoActivityErrors(item) {
    this.router.navigate(['./activation-service/tn-activity-errors/', item.id]);
  }

  gotoActivityDetail(item) {
    // window.location.href = "?page=activation-service/tn-activity-detail/" + item.id;
    // this.router.navigateByUrl('/activation-service/tn-activity-detail/' + item.id)
    this.router.navigate(['./activation-service/tn-activity-detail/' + item.id]);
  }

  loadSearchResults(event, filteredResults) {
    this.updateError = '';
    this.updateErrorMesg = '';
    let selectedActivityids: string[] = [];
    this.firstPage = event.first;
    this.pageNumber = (event.first / event.rows) + 1;
    this.pageSize = event.rows;
    filteredResults.forEach(item => {
      if (item.checked && item.checked[0] === 'true') {
        selectedActivityids.push(item.id);
      }
    });
    this.storageService.storeSelectedActivityIds(selectedActivityids, false);
    this.storageService.storeSearchDetailsGridPage(this.pageNumber, this.pageSize, this.firstPage);
    if (this.totalRecords > 0) {
      this.searchActivities(this.activitySearch, true);
    }
    // this.onRowCheckboxChnage(event);
  }


  clearForm() {
    /*to clear stored search details*/
    this.storageService.resetDetails();
    this.setPresetData();
    this.isSearching = false;
    this.isUpdating = false;
    this.message = '';
    this.selectAllCheckBox = [];
    // change to make clear button work
    this.activitySearch = new SearchRequestObject();
    this.activitySearch.selectedDateTypeSecondary = 'All';
    this.activitySearch.selectedDateType = 'All';
    this.searchResults = [];
    this.filteredResults = [];
    this.firstPage = 0;
    this.totalRecords = 0;
    this.activitySearch.isDisplayable = 'Y';
    this.activitySearch.orderActiveYn = 'Y';
    this.successMessage = '';
    this.updateError = '';
    this.updateErrorMesg = '';

  }

  exportExcelLocally(options, exportData) {
    if (exportData.length > 0) {
      const xlsData = [];
      xlsData.push(options.headers);
      exportData.forEach(f => {
        const arr = [];
        Object.keys(f).forEach(key => {
          arr.push(f[key]);
        });
        xlsData.push(arr);
      });
      const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(xlsData);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      XLSX.writeFile(wb, 'ActivityResults.csv');
    }
    this.isExporting = false;
  }

  exportExcelFromService(exportColumns?: string[]) {
    this.createBodyForService(this.activitySearch).subscribe((returnBody) => {
      if (exportColumns) {
        returnBody['exportColumns'] = exportColumns;
      }
      this.tnActSearchService.getExportDetail(returnBody).subscribe((response) => {
        const url = window.URL.createObjectURL(response.data);
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.setAttribute('style', 'display:none');
        a.href = url;
        a.download = response.fileName;
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        this.isExporting = false;
      }, error => {
        this.message = error;
        this.isExporting = false;
      });
    });
  }

  exportActivitySearch() {
    let exportData = [];
    if (this.filteredResults.length > 0) {
      this.isExporting = true;
      const options = {
        showLabels: true,
        headers: this.gridColumnList.map(col => {
          return col.caption;
        })
      };
      let selectedResult = this.filteredResults.filter(item => {
        if (item.checked && item.checked[0] === 'true') {
          return true;
        } else {
          return false;
        }
      });
      if (this.exportType.code === 'selected') {
        if (this.resultType.code === 'tns') {
          options.headers = ['TN'];
          exportData = selectedResult.map(row => {
            const data = {};
            data['tn'] = row['tn'];
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else if (this.resultType.code === 'all') {
          exportData = selectedResult.map(row => {
            const data = {};
            this.gridColumnList.forEach(col => {
              data[col.value] = row[col.value] || '';
            });
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else {
          this.isExporting = false;
        }
      } else if (this.exportType.code === 'all') {
        if (this.resultType.code === 'tns') {
          this.exportExcelFromService(['tn']);
        } else if (this.resultType.code === 'all') {
          selectedResult = this.filteredResults;
          exportData = selectedResult.map(row => {
            const data = {};
            this.gridColumnList.forEach(col => {
              data[col.value] = row[col.value] || '';
            });
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else if (this.resultType.code === 'exportAll') {
          const exportColumns = this.gridColumnList.map(col => {
            return col.value;
          });
          this.exportExcelFromService(exportColumns);
        } else {
          this.isExporting = false;
        }
      } else {
        this.isExporting = false;
      }
    }
  }

  showHideColumnFilterDialog() {
    this.columnPickListDialog.showDialog = true;
  }

  onPickListChange(list: any[]) {
    this.gridColumnList = JSON.parse(JSON.stringify(list));
  }

  onChangeAction(event, action) {
    this.filteredResults.forEach(row => {
      if (action.code === 'update' && row.activityStatus === 'Completed') {
        row.checked = [];
      }
    });
  }

  checkAllRows(event) {
    this.filteredResults.forEach(row => {
      if (this.actionToPerform.code === 'export') {
        row.checked = event ? ['true'] : [];
        if (event) {
          this.selectedActivityIds.push(row);
        }
      } else if (event) {
        if (!(row.activityStatus == 'Completed' && this.actionToPerform.code === 'update' && (this.updateAction.type.code == 'selected' || this.updateAction.type.code === 'all'))) {
          row.checked = event ? ['true'] : [];
          if (event) {
            this.selectedActivityIds.push(row);
          }
        }
      } else {
        row.checked = event ? ['true'] : [];
        if (event) {
          this.selectedActivityIds.push(row);
        }
      }
    });
    if (!event) {
      this.selectedActivityIds = [];
    }
  }

  onRowCheckboxChnage(event, row) {
    const selectedResult = this.filteredResults.filter(item => {
      if (item.checked && item.checked[0] === 'true') {
        return true;
      } else {
        return false;
      }
    });
    if (selectedResult.length > 0 && (this.filteredResults.length === selectedResult.length)) {
      this.selectAllCheckBox = ['true'];
    } else {
      this.selectAllCheckBox = [];
    }

    if (event) {
      this.selectedActivityIds.push(row);
    } else {
      const index = this.selectedActivityIds.findIndex((obj) => {
        return obj.id === row.id;
      });
      if (index !== -1) {
        this.selectedActivityIds.splice(index, 1);
      }
    }
  }


  pickListClick() {
    this.gridColumnList = JSON.parse(JSON.stringify(this.gridColumnList));
    const pickList = {
      hiddenColumns: this.hiddenColumns,
      gridColumnList: this.gridColumnList
    };
    this.storageService.storePickList(pickList);
  }


  filterGridResults(value, filter) {
    const results = [];
    if (value) {
      this.gridColumnList.forEach(col => {
        // this.searchResultGrid.filter(value, row.value, filter);
        this.searchResults.forEach(item => {
          if (item[col.value]) {
            if (item[col.value].toString().toLowerCase().indexOf(value.toLowerCase()) !== -1) {
              if (results.indexOf(item) === -1) {
                results.push(item);
              }
            }
          }
        });
      });
      this.filteredResults = results;
    } else {
      this.filteredResults = this.searchResults;
    }
  }

  openCompletedActivitydialog() {
    this.updateActionReason = { name: 'Choose', code: '' };
    this.completedActionReason = '';
    this.displayCompletedActivitydialog = true;
  }

  onSelectedOrderActionClick() {
    if (this.updateAction.operation.code === 'orderDateUpdate') {
      this.openUpdateOrderDateDialog();
    } else if (this.updateAction.operation.code === 'orderCommentUpdate') {
      let exportData = this.selectedActivityIds;
      if (this.updateAction.type.code === 'all') {
        exportData = this.filteredResults.filter(item => {
          if (item.activityStatus !== 'Completed') {
            return true;
          } else {
            return false;
          }
        });
      }
      if (exportData.length > 1) {
        this.updateError = 'Only one order can be selected for Update Order Comments.';
        return;
      } else if (exportData.length === 1) {
        this.updateReasonOnlyDialog.reset();
        this.updateReasonOnlyDialog.displaDialog = true;
      }
    }
  }

  updateReasonOnlyDialogSubmit(event) {
    this.updateReasonOnlyDialog.displaDialog = false;
    this.updateActivitySearch();
  }

  openUpdateOrderDateDialog() {
    this.updateOrderDateDialog.onReset();
    this.updateOrderDateDialog.displayDialog = true;
  }

  setCommentAndPerformAction() {
    this.displayCompletedActivitydialog = false;
    if (this.updateActionReason.code === 'Other') {
    } else {
      this.completedActionReason = this.updateActionReason.code;
    }

    this.updateActivitySearch();
  }

  onUpdateOrderDate(event) {
    console.log('onUpdateOrderDate');
    this.updateOrderDateDialog.displayDialog = false;
    this.updateActivitySearch(event);
  }

  setcomment() {
    this.displayCompletedActivitydialog = false;
    if (this.updateActionReason.code === 'Other') {
      this.completedActionReason = this.completedActionReason;
    } else {
      this.completedActionReason = this.updateActionReason.code;
    }
    this.updateActivitySearch();
  }

  updateActivitySearch(extraDetails?) {
    this.updateError = '';
    this.updateErrorMesg = '';
    this.successMessage = '';
    let exportData = [];
    if (this.filteredResults.length > 0) {
      this.isUpdating = true;
      exportData = this.selectedActivityIds;
      if (this.updateAction.type.code === 'all') {
        exportData = this.filteredResults.filter(item => {
          if (item.activityStatus !== 'Completed') {
            return true;
          } else {
            return false;
          }
        });
        if (exportData.length === 0) {
          this.isUpdating = false;
          this.updateError = 'Trying to Perform ' + this.updateAction.operation.name + ' Action on Completed Activities';
          return;
        }
      } else if (exportData.length === 0) {
        this.isUpdating = false;
        this.updateError = 'Please select atleast one record to perform action';
        return;
      }
      let count = 0;
      let hitApi = false;
      let activityIds = [];

      const dateTime = new Date();
      const dateTimeStr = 'SLDB-' + dateTime.getTime();


      const codeForAcvtivity = ['restartActivity', 'forceCompleteActivity'];
      const codeForPON = ['orderDateUpdate'];
      const codeForSLOrderId = ['orderCommentUpdate'];

      if (codeForAcvtivity.indexOf(this.updateAction.operation.code) !== -1) {

        if (exportData.length > 0) {
          const list = exportData.map(b => b.id);
        }

        let errorResponse = false;
        let successfulResponse = false;
        const listOfResultIds = [];
        const listOfSuccessIds = [];
        for (let i = 0; i < exportData.length; i++) {
          if (activityIds.indexOf(exportData[i].id) === -1) {
            activityIds.push(exportData[i].id);
          }
          count++;
          if (i === exportData.length - 1) {
            hitApi = true;
          }
          if (count === 30 || hitApi) {
            const idList = activityIds;
            switch (this.updateAction.operation.code) {
              case 'restartActivity':
                this.tnActSearchService.updateActivities(activityIds, this.updateAction.operation.code, dateTimeStr).subscribe((response) => {
                  response.forEach((obj, index) => {
                    if (obj.successful === true && !errorResponse) {
                      successfulResponse = true;
                      listOfResultIds.push(idList[index]);
                    } else if (obj.errorCode === 0) {
                      errorResponse = true;
                      listOfResultIds.push(idList[index]);
                    }
                  });

                  if (successfulResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.successMessage = 'Update Successful';
                    } else {
                      this.successMessage = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.updateAction.operation.code, dateTime, true);
                    }
                  } else if (errorResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.updateError = response[0].errorMessage;
                    } else {
                      this.updateError = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.updateAction.operation.code, dateTime);
                    }
                  }
                  this.searchActivities(this.activitySearch);
                }, (error) => {
                  console.log(error);
                });
                activityIds = [];
                count = 0;
                break;
              case 'forceCompleteActivity':
                // update comment in filtered list
                this.filteredResults.forEach(item => {
                  if (item.checked && item.checked[0] === 'true') {
                    item.accomments = this.completedActionReason;
                  }
                });
                // this.searchActivities(this.activitySearch);
                this.tnActSearchService.updateActivities(activityIds, this.updateAction.operation.code, dateTimeStr, this.completedActionReason).subscribe((response) => {
                  response.forEach((obj, index) => {
                    if (obj.successful === true && !errorResponse) {
                      successfulResponse = true;
                      listOfResultIds.push(idList[index]);
                    } else if (obj.errorCode === 0) {
                      errorResponse = true;
                      listOfResultIds.push(idList[index]);
                    }
                  });

                  if (successfulResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.successMessage = 'Update Successful';
                    } else {
                      this.successMessage = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.updateAction.operation.code, dateTime, true);
                    }
                  } else if (errorResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.updateError = response.errorMessage;
                    } else {
                      this.updateError = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.updateAction.operation.code, dateTime);
                    }
                  }
                  this.searchActivities(this.activitySearch);

                }, (error) => {
                  // console.log(error);
                  this.updateError = error;
                  this.isUpdating =false;
                });
                activityIds = [];
                count = 0;
                break;
            }
          }
        }
      } else if (codeForPON.indexOf(this.updateAction.operation.code) !== -1) {
        let filterParentId = exportData.map(
          object => object.parentTransId
        );
        filterParentId = filterParentId.filter(function (item, pos) {
          return filterParentId.indexOf(item) == pos;
        });
        const responseArray: any[] = [];
        switch (this.updateAction.operation.code) {
          case 'orderDateUpdate':
            const requestArray = [];
            for (let index = 0; index < filterParentId.length; index++) {
              requestArray.push(this.tnActSearchService.updateActivitiesOrderDate(filterParentId[index], extraDetails, dateTimeStr));
            }
            forkJoin(requestArray).subscribe((result) => {
              console.log(result);
              result.forEach((response, index) => {
                if (response.successful === false) {
                  responseArray.push({
                    ponId: filterParentId[index],
                    error: response.errorMessage
                  });
                }
                ;
                if (filterParentId.length - 1 === index) {
                  this.isUpdating = false;
                  if (responseArray.length > 0) {
                    this.successMessage = '';
                    if (filterParentId.length === 1) {
                      this.updateError = response.errorMessage;
                    } else {
                      this.updateError = 'multiple';
                    }
                    this.storageService.setTransactionActivityIds(responseArray, this.updateAction.operation.code, dateTime);
                  } else {
                    this.updateError = '';
                    if (filterParentId.length === 1) {
                      this.successMessage = 'Update Successful';
                    } else {
                      this.successMessage = 'multiple';
                      this.storageService.setTransactionActivityIds(result, this.updateAction.operation.code, dateTime, true);
                    }
                  }
                  this.searchActivities(this.activitySearch);
                }
              });
            }, () => {
              this.isUpdating = false;
            });
        }
      } else if (codeForSLOrderId.indexOf(this.updateAction.operation.code) !== -1) {
        let filterSLOrderId = exportData.map(
          object => object.slOrderId
        );
        filterSLOrderId = filterSLOrderId.filter(function (item, pos) {
          return filterSLOrderId.indexOf(item) == pos;
        });
        if (filterSLOrderId.length > 1) {
          this.updateError = 'Only one order can be selected for Update Order Comments.';
          return;
        } else {
          const responseArray: any[] = [];
          switch (this.updateAction.operation.code) {
            case 'orderCommentUpdate':
              const requestArray = [];
              for (let index = 0; index < filterSLOrderId.length; index++) {
                requestArray.push(this.tnActSearchService.updateActivitiesOrderComment(filterSLOrderId[index], this.updateReasonOnlyDialog.actionReason, dateTimeStr));
              }
              ;
              forkJoin(requestArray).subscribe((result) => {
                console.log(result);
                result.forEach((response, index) => {
                  if (response.successful === false) {
                    responseArray.push({
                      ponId: filterSLOrderId[index],
                      error: response.errorMessage
                    });
                  }
                  ;
                  if (filterSLOrderId.length - 1 === index) {
                    this.isUpdating = false;
                    if (responseArray.length > 0) {
                      this.successMessage = '';
                      if (filterSLOrderId.length === 1) {
                        this.updateError = response.errorMessage;
                      } else {
                        this.updateError = 'multiple';
                      }
                      this.storageService.setTransactionActivityIds(responseArray, this.updateAction.operation.code, dateTime);
                    } else {
                      this.updateError = '';
                      if (filterSLOrderId.length === 1) {
                        this.successMessage = 'Update Successful';
                      } else {
                        this.successMessage = 'multiple';
                        this.storageService.setTransactionActivityIds(result, this.updateAction.operation.code, dateTime, true);
                      }
                    }
                    this.searchActivities(this.activitySearch);
                  }
                });
              }, () => {
                this.isUpdating = false;
              });
          }
        }
      } else {
        this.isUpdating = false;
      }
    }
  }

  openTransactionDialog() {
    console.log('open');
    this.transactionDetailsDialog.loadErrorList();
    this.transactionDetailsDialog.displayDialog = true;
  }

  onCloseTransactionDialog() {
    this.transactionDetailsDialog.displayDialog = false;
  }

}


interface PanelFilter {
  OrderSearch: boolean;
  LnpSearch: boolean;
  E911Search: boolean;
  EmeaSearch: boolean;
}
