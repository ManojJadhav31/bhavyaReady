import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ]
})
export class AppComponent implements OnInit {

  public navHide: boolean = false;
  selectedTab: string;

  public showSidenav: boolean = false;

  constructor(private route: ActivatedRoute, private router: Router) {
    this.route.queryParams.subscribe(param => {
      if ( param.page ) {
        if ( param.UserName != '' ) {
          localStorage.setItem('UserName', param.UserName);
        }
        if ( param.navHide === 'true' ) {
          this.router.navigate([ param.page ], { queryParams: { navHide: param.navHide } });
        } else {
          this.router.navigate([ param.page ]);
        }
      } else {
        if ( param.navHide === 'true' ) {
          this.navHide = true;
        }

      }
    });
  }

  ngOnInit(): void {
    this.router.events.subscribe((e) => {
      if ( e instanceof NavigationEnd ) {
        // console.log(e.url);
        if ( e.url.search('portout') > 0 ) {
          this.selectedTab = 'portout';
        } else if ( e.url.search('activation-service') > 0 ) {
          this.selectedTab = 'actservice';
        } else if ( e.url.search('order-management') > 0 ) {
          this.selectedTab = 'orderMgmt';
        }
      }
    });
  }

  toggleSidenav() {
    this.showSidenav = !this.showSidenav;
  }

  changeTab(tab) {
    this.selectedTab = tab;
  }
}
