import {StorageService} from './storage.service';


describe('StorageService', () => {
  let storageService: StorageService;
  let formData: any;
  let result: any;
  beforeEach(() => {
    storageService = new StorageService();
    storageService.setModule('module-name');
    formData = {
      id: 1
    };
    result = {
      orderId: 1,
      ban: 2
    };
  });
  it('should store search details', () => {
    storageService.storeSearchDetails(formData, result);
    const results = storageService.getSearchDetails();
    expect(results.formData).toBe(formData);
    expect(results.results).toBe(result);
  });

  it('should get search details', () => {
    storageService.storeSearchDetails(formData, result);
    const results = storageService.getSearchDetails();
    expect(results.formData).toBe(formData);
    expect(results.results).toBe(result);
  });
});
