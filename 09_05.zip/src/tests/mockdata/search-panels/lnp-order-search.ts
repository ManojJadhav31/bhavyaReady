

export const lnpOrderState = [
    '',
    'Cancel',
    'Cancel Completed',
    'Completed',
    'FOC Received',
    'Init-Activate-Temp',
    'Init-Cancel',
    'Init-DisconnectLDS-Temp',
    'Init-New',
    'Init-Supp',
    'Installed'
  ]; 