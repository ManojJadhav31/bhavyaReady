export const activityStatus = [
  {value: null, label: '', selected: 'selected'},
  {value: '', label: 'All'},
  {value: '4', label: 'Cancelled'},
  {value: '3', label: 'Completed'},
  {value: '5', label: 'E911Rejected'},
  {value: '2', label: 'Error'},
  {value: '0', label: 'New'},
  {value: '6', label: 'Parent Tx Wait'},
  {value: '1', label: 'Processing'},
  {value: '9', label: 'Response Pending'},
  {value: '8', label: 'Scheduled'},
  {value: '7', label: 'System Wait'},
];

export const activityName = [
  {value: '', selected: 'selected', label: 'All'},
  {value: '432', label: '911 - Activate Routing for FIPS Exception subscriber'},
  {value: '205', label: '911 ALI Provisioning - Change'},
  {value: '522', label: '911 ALI Provisioning - Delete'},
  {value: '521', label: '911 ALI Provisioning - Insert'}
];
