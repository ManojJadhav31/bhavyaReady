import { Observable, of } from 'rxjs';

export const OrderDetail = {
  focDate: '03/14/2018',
  zipCode: '',
  billingAccountName: '',
  purchaseOrderVersion: '2',
  city: 'Denver',
  endUserName: 'John',
  state: '',
  streetName: '',
  streetNumber: '',
  carrierRequestId: '12344555',
  purchaseOrderNumber: '1236',
  authorizedBy: 'user'
};


export const OrderDetailTns = [
  { wtn: '8541236584' },
  { wtn: '8541236584' },
  { wtn: '8541236584' },
  { wtn: '8541236584' }
];

export const tns = [
  {
    carrierName: 'LEVEL 3 COMMUNICATIONS',
    carrierRequestId: 8046618222,
    workFlowStatus: 'ACTIVE',
    wtn: '2564473218'
  }, {
    carrierName: 'LEVEL 3 COMMUNICATIONS',
    carrierRequestId: 8046618222,
    workFlowStatus: 'CREATED',
    wtn: '2564473218'
  }
];

export class OrderDetailServiceStub {
  public getOrderDetailsData(): Observable<any> {
    return of([ OrderDetail ]);
    // return of([]);
  }

  public getOrderDetails(requestTypeId: string): Observable<any> {
    return of([ OrderDetail ]);
    // return of([]);
  }

  public setOrderDetailsData(details: any): void {
  }

  public getTns(requestTypeId: string): Observable<any[]> {
    return of(tns);
  }

  public removeTns(body): Observable<any[]> {
    return of([]);
  }

  public addTns(body): Observable<any> {
    return of(true);
  }

  public updateOrderDetail(params, body): Observable<any> {
    return of(true);
  }

  public carrierApprovalAction(params, body): Observable<any> {
    return of(true);
  }

  public addRemoveUpdateDetails(params, body): Observable<any> {
    return of(true);
  }
}
