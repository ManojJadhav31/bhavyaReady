export const PONSearchResponse = [
  {
    'pon': '220740538',
    'tnCount': 100,
    'mileStoneActivityVOList': [ {
      'activityId': '581',
      'activityName': 'Wait to Trigger Provisioning',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '2'
    }, {
      'activityId': '319',
      'activityName': 'Wait to Update Voice Inventory',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '1'
    }, {
      'activityId': '427',
      'activityName': 'Receive: NPAC Load Completion',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '11'
    }, {
      'activityId': '573',
      'activityName': 'Activate TN on ENASS Network',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '6'
    } ],
    "status": "Ports cancelled in NPAC",
    "focDate": "2019-01-29T12:30:00.000+0000",
    "voiceOrderId": "10256249",
    "state": "Cancel Completed"

  },
  {
    'pon': '220740539',
    'tnCount': 100,
    'mileStoneActivityVOList': [ {
      'activityId': '581',
      'activityName': 'Wait to Trigger Provisioning',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '2'
    }, {
      'activityId': '319',
      'activityName': 'Wait to Update Voice Inventory',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '1'
    }, {
      'activityId': '427',
      'activityName': 'Receive: NPAC Load Completion',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '11'
    }, {
      'activityId': '573',
      'activityName': 'Activate TN on ENASS Network',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '6'
    } ],
    "status": "Ports cancelled in NPAC",
    "focDate": "2019-01-29T12:30:00.000+0000",
    "voiceOrderId": "10256249",
    "state": "Cancel Completed"

  },
  {
    'pon': '220740540',
    'tnCount': 100,
    'mileStoneActivityVOList': [ {
      'activityId': '581',
      'activityName': 'Wait to Trigger Provisioning',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '2'
    }, {
      'activityId': '319',
      'activityName': 'Wait to Update Voice Inventory',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '1'
    }, {
      'activityId': '427',
      'activityName': 'Receive: NPAC Load Completion',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '11'
    }, {
      'activityId': '573',
      'activityName': 'Activate TN on ENASS Network',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '6'
    } ],
    "status": "Ports cancelled in NPAC",
    "focDate": "2019-01-29T12:30:00.000+0000",
    "voiceOrderId": "10256249",
    "state": "Cancel Completed"

  },
  {
    'pon': '220740541',
    'tnCount': 100,
    'mileStoneActivityVOList': [ {
      'activityId': '581',
      'activityName': 'Wait to Trigger Provisioning',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '2'
    }, {
      'activityId': '319',
      'activityName': 'Wait to Update Voice Inventory',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '1'
    }, {
      'activityId': '427',
      'activityName': 'Receive: NPAC Load Completion',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '11'
    }, {
      'activityId': '573',
      'activityName': 'Activate TN on ENASS Network',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '6'
    } ],
    "status": "Ports cancelled in NPAC",
    "focDate": "2019-01-29T12:30:00.000+0000",
    "voiceOrderId": "10256249",
    "state": "Cancel Completed"

  },
  {
    'pon': '220740542',
    'tnCount': 820,
    'mileStoneActivityVOList': [ {
      'activityId': '581',
      'activityName': 'Wait to Trigger Provisioning',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '2'
    }, {
      'activityId': '319',
      'activityName': 'Wait to Update Voice Inventory',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '1'
    }, {
      'activityId': '427',
      'activityName': 'Receive: NPAC Load Completion',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '11'
    }, {
      'activityId': '573',
      'activityName': 'Activate TN on ENASS Network',
      'tnCount': 100,
      'status': 'Completed',
      'crd': '2019-05-06T12:00:00.000+0000',
      'actionType': 'Install',
      'internalPortYN': 'N',
      'seq': '6'
    } ],
    "status": "Ports cancelled in NPAC",
    "focDate": "2019-01-29T12:30:00.000+0000",
    "voiceOrderId": "10256249",
    "state": "Cancel Completed"

  }
];

/**
 * const result = <any>PONSearchResponse;
 result.forEach((res, index) => {
        if ( res ) {
          const data = res;
          data.expanded = false;
          data.mileStoneExpanded = false;
          data.tnExpanded = false;
          // this.totalTnCount = this.totalTnCount + data.tnCount;
          if ( data.mileStoneActivityVOList && data.mileStoneActivityVOList.length > 0 ) {

            this.incompletedStatus = [];
            const milestoneList = [];
            data.mileStoneActivityVOList.forEach(activity => {
              if ( ( activity.actionType === 'Install' || activity.actionType === 'Supp' ) && activity.internalPortYN === 'Y' ) {
                data.status = 'Pending Activation';
              }

              if ( this.utilityService.parseDate(data.focDate, 'mdy') !== ( this.utilityService.parseDate(activity.crd, 'mdy') ) ) {
                data.focDateError = 'FOC Date != CRD.';
              }

              const findObject = milestoneList.find((object) => {
                return object.activityId === activity.activityId;
              });
              if
              ( !findObject ) {
                activity.statusArray = [];
                activity.statusArray = [ {
                  status: activity.status,
                  count: activity.tnCount
                } ];
                milestoneList.push(activity);
              } else {
                findObject.statusArray.push({
                  status: activity.status,
                  count: activity.tnCount
                });
              }
              activity.statusExpanded = false;
            });
            this.incompletedStatus = milestoneList.filter((v, k) => {
              // console.log(v.statusArray)
              const d = v.statusArray.find((obj) => {
                return obj.status !== 'Completed';
              });
              return d ? true : false;
            });
            // console.log(this.incompletedStatus)
            data.mileStoneActivityVOList = milestoneList.sort((a: any, b: any) => {
              if ( parseInt(a.seq, 0) < parseInt(b.seq, 0) ) {
                return -1;
              } else if ( parseInt(a.seq, 0) > parseInt(b.seq, 0) ) {
                return 1;
              } else {
                return 0;
              }
            });
            data.activityNameWithStatus = this.setActivityNameWithStatus(data.mileStoneActivityVOList, data.tnCount);
          }
          this.results.push(data);
          this.onCancelledCheckboxChange();
        }
      });
 */

