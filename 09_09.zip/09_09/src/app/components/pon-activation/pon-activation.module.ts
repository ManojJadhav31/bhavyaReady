import {NgModule} from '@angular/core';
import {PonActivationComponents, PonActivationRoutingModule} from './pon-activation-routing.module';
import {PonActivationService} from './services/pon-activation.service';
import {SharedModule} from '../../shared/shared.module';
import { PonSearchComponent } from './pon-search/pon-search.component';

@NgModule({
  imports: [SharedModule, PonActivationRoutingModule],
  declarations: [PonActivationComponents, PonSearchComponent],
  providers: [PonActivationService],
})
export class PonActivationModule {
}
