import { Component, OnInit, ViewChild } from '@angular/core';
import { TreeNode } from 'primeng/api';
import { PonActivationService } from '../services/pon-activation.service';
import * as XLSX from 'xlsx';
import { UtilityService } from '../../../shared/services/utility.service';
import { DatePipe } from '@angular/common';
import { PONSearchResponse } from '../../../../tests/mockdata/pon/pon-search';
import { activityStatus } from '../../../../tests/mockdata/search-panels/default-search';


@Component({
  selector: 'app-pon-search',
  templateUrl: './pon-search.component.html',
  styleUrls: ['./pon-search.component.scss'],
  providers: [DatePipe]
})
export class PonSearchComponent implements OnInit {
  files: TreeNode[];
  ponSearch: any = {};
  errorMsg = '';
  isSearchingPon = false;
  results: any[] = [];
  filterByLIst: any[] = [
    { label: 'LNP Status', value: 'status' },
    { label: 'LNP State', value: 'state' },
    { label: 'MileStone Activity', value: 'mileStoneActivity' },
    { label: 'MileStone Activity Status', value: 'mileStoneActivityStatus' },
    { label: 'FOC Date', value: 'facDate' }
  ]
  selectedFilterBy: any = 'status';
  filteredResult: any[] = [];
  filterMileStoneActivityList: any[] = [];
  filterMileStoneActivityStatusList: any[] = [];
  selectedMileStoneActivityStatus: string;
  selectedFilterMileStoneActivityList: string;
  selectedFocDate: string;
  selectedSortColumn: any = {
    column: 'pon',
    order: 1
  }
  selectedStatus: string;
  statusList: any[] = [];
  stateList: any[] = [];
  selectedState: string;
  focDateList: any[] = [];
  cancelledData = [];
  isStatusExpanded = false;
  isExporting = false;
  tNDetailVOList: any = [];
  message: string;
  columns = [
    { field: 'tn', header: 'TN' },
    { field: 'activityState', header: 'Activity State' },
  ];
  ponFilter = false;
  voidFilter = false;
  totalPonCount = 0;
  totalTnCount = 0;
  incompletedStatus: any;
  @ViewChild('dataTable') dataTable: any;
  public columnList: any[] = [
    { field: 'voiceOrderId', header: 'Void' },
    { field: 'pon', header: 'PON' },
    { field: 'tnCount', header: 'TN Count' },
    { field: 'status', header: 'LNP Order Status' },
    { field: 'state', header: 'LNP Order state' }
  ];

  constructor(public ponService: PonActivationService, private utilityService: UtilityService,
    private datePipe: DatePipe) {

  }

  ngOnInit() {

  }

  onRefresh() {
    this.isSearchingPon = true;
    this.results = [];

    if (this.ponFilter) {
      const newValue = this.ponSearch.pon.replace(new RegExp('\r?\n', 'g'), ',');
      let ponNumberArray = newValue.split(',');
      ponNumberArray = ponNumberArray.map(value => value.trim());
      ponNumberArray = ponNumberArray.filter(value => value)
      this.getPONDetails(ponNumberArray);
    } else {
      // here we need to make request to get PONs based on VOID
      const voiceOrderId = this.ponSearch.void.replace(new RegExp('\r?\n', 'g'), ',');
      const ponNumberArray = voiceOrderId.split(',');
      if (ponNumberArray.length > 1) {
        this.errorMsg = 'Only one VOID should be entered at a time.';
        this.isSearchingPon = false;
        return;
      }
      this.ponService.getPONByVoid(voiceOrderId).subscribe((res: any) => {
        this.getPONDetails(res);
      }, error => {
        this.message = error;
        this.isSearchingPon = false;
      }
      );
    }
  }

  onPonSearch() {
    this.ponFilter = false;
    this.voidFilter = false;
    this.isStatusExpanded = false;
    this.totalPonCount = 0;
    this.totalTnCount = 0;
    this.errorMsg = '';
    this.message = '';
    if (!this.ponSearch.pon && !this.ponSearch.void) {
      this.errorMsg = 'PON or VOID Required';
      return;
    }
    if (this.ponSearch.pon && this.ponSearch.void) {
      this.errorMsg = 'Only one PON or VOID should be entered.';
      return;
    }
    if (this.ponSearch.pon) {
      this.ponFilter = true;
    } else {
      this.voidFilter = true;
    }
    this.isSearchingPon = true;
    this.results = [];
    this.cancelledData = [];
    this.filteredResult = [];
    this.statusList = [];
    this.stateList = [];
    this.selectedFilterMileStoneActivityList = null;
    this.selectedStatus = null;
    this.selectedState = null;
    this.filterMileStoneActivityList = [];
    this.filterMileStoneActivityStatusList = [];
    this.selectedMileStoneActivityStatus = null;
    this.selectedSortColumn = {
      column: 'pon',
      order: 1
    };
    if (this.ponFilter) {
      const newValue = this.ponSearch.pon.replace(new RegExp('\r?\n', 'g'), ',');
      let ponNumberArray = newValue.split(',');
      ponNumberArray = ponNumberArray.map(value => value.trim());
      ponNumberArray = ponNumberArray.filter(value => value)
      this.getPONDetails(ponNumberArray);
    } else {
      // here we need to make request to get PONs based on VOID
      const voiceOrderId = this.ponSearch.void.replace(new RegExp('\r?\n', 'g'), ',');
      const ponNumberArray = voiceOrderId.split(',');
      if (ponNumberArray.length > 1) {
        this.errorMsg = 'Only one VOID should be entered at a time.';
        this.isSearchingPon = false;
        return;
      }
      this.ponService.getPONByVoid(voiceOrderId).subscribe((res: any) => {
        this.getPONDetails(res);
      }, error => {
        this.message = error;
        this.isSearchingPon = false;
      }
      );
    }

  }

  getPONDetails(ponNumberArray: string[]) {
    // this.totalPonCount = ponNumberArray.length;
    this.message = null;
    ponNumberArray.forEach((ponNumber, index) => {
      /*ponNumber = ponNumber.trim();
      if ( ponNumber ) {
        requestArray.push(this.ponService.searchPon(ponNumber));
      }*/
      this.ponService.searchPon(ponNumber).subscribe((result) => {
        if (index === ponNumberArray.length - 1) {
          this.isSearchingPon = false;
        }
        this.setResult(result);
      }, error => {
        // this.setResult(PONSearchResponse[index]);
        if (!this.message) {
          this.message = 'An unexpected error occured, due to the services being down or technical error' + ' : ' + ponNumber;
        } else {
          this.message += ' , ' + ponNumber;
        }
        this.isSearchingPon = false;
      });
    });
    /*forkJoin(requestArray).subscribe((result) => {
      result.forEach((res) => {
        this.isSearchingPon = false;
        if ( res ) {
          const data = res;
          data.expanded = false;
          data.mileStoneExpanded = false;
          data.tnExpanded = false;
          // this.totalTnCount = this.totalTnCount + data.tnCount;
          if ( data.mileStoneActivityVOList && data.mileStoneActivityVOList.length > 0 ) {

            this.incompletedStatus = [];
            const milestoneList = [];
            data.mileStoneActivityVOList.forEach(activity => {
              if ( ( activity.actionType === 'Install' || activity.actionType === 'Supp' ) && activity.internalPortYN === 'Y' ) {
                data.status = 'Pending Activation';
              }

              if ( this.utilityService.parseDate(data.focDate, 'mdy') !== ( this.utilityService.parseDate(activity.crd, 'mdy') ) ) {
                data.focDateError = 'FOC Date != CRD.';
              }

              const findObject = milestoneList.find((object) => {
                return object.activityId === activity.activityId;
              });
              if
              ( !findObject ) {
                activity.statusArray = [];
                activity.statusArray = [ {
                  status: activity.status,
                  count: activity.tnCount
                } ];
                milestoneList.push(activity);
              } else {
                findObject.statusArray.push({
                  status: activity.status,
                  count: activity.tnCount
                });
              }
              activity.statusExpanded = false;
            });
            this.incompletedStatus = milestoneList.filter((v, k) => {
              // console.log(v.statusArray)
              const d = v.statusArray.find((obj) => {
                return obj.status !== 'Completed';
              });
              return d ? true : false;
            });
            // console.log(this.incompletedStatus)
            data.mileStoneActivityVOList = milestoneList.sort((a: any, b: any) => {
              if ( parseInt(a.seq, 0) < parseInt(b.seq, 0) ) {
                return -1;
              } else if ( parseInt(a.seq, 0) > parseInt(b.seq, 0) ) {
                return 1;
              } else {
                return 0;
              }
            });
            data.activityNameWithStatus = this.setActivityNameWithStatus(data.mileStoneActivityVOList, data.tnCount);
          }
          this.results.push(data);
          this.onCancelledCheckboxChange();
        }
      });
    }, error => {
      this.message = error;
      this.isSearchingPon = false;
    });*/
  }

  setResult(res) {
    if (res) {
      const data = res;
      data.expanded = false;
      data.mileStoneExpanded = false;
      data.tnExpanded = false;
      this.totalTnCount = this.totalTnCount + data.tnCount;
      // data.mileStoneActivityVOList.push({
      //   "activityId": "581",
      //   "activityName": "Wait to Trigger Provisioning",
      //   "tnCount": 1,
      //   "status": "System Wait Demo",
      //   "crd": "2019-06-07T18:00:00.000+0000",
      //   "actionType": "Install",
      //   "internalPortYN": "N",
      //   "seq": "2"
      // });
      // data.mileStoneActivityVOList.push({
      //   "activityId": "581",
      //   "activityName": "Wait to Trigger Provisioning",
      //   "tnCount": 0,
      //   "status": "Completed",
      //   "crd": "2019-06-07T18:00:00.000+0000",
      //   "actionType": "Install",
      //   "internalPortYN": "N",
      //   "seq": "2"
      // });
      // data.tnCount = 2;
      if (data.mileStoneActivityVOList && data.mileStoneActivityVOList.length > 0) {
        this.incompletedStatus = [];
        const milestoneList = [];
        data.mileStoneActivityVOList.forEach(activity => {
          if ((activity.actionType === 'Install' || activity.actionType === 'Supp') && activity.internalPortYN === 'Y') {
            data.status = 'Pending Activation';
          }

          if (this.utilityService.parseDate(data.focDate, 'mdy') !== (this.utilityService.parseDate(activity.crd, 'mdy'))) {
            data.focDateError = 'FOC Date != CRD.';
          }

          const findObject = milestoneList.find((object) => {
            return object.activityId === activity.activityId;
          });
          if
          (!findObject) {
            activity.statusArray = [];
            activity.statusArray = [{
              status: activity.status,
              count: activity.tnCount
            }];
            milestoneList.push(activity);
          } else {
            findObject.statusArray.push({
              status: activity.status,
              count: activity.tnCount
            });
          }
          activity.statusExpanded = false;
        });
        this.incompletedStatus = milestoneList.filter((v, k) => {
          // console.log(v.statusArray)
          const d = v.statusArray.find((obj) => {
            return obj.status !== 'Completed';
          });
          return d ? true : false;
        });
        // console.log(this.incompletedStatus)
        data.mileStoneActivityVOList = milestoneList.sort((a: any, b: any) => {
          if (parseInt(a.seq, 0) < parseInt(b.seq, 0)) {
            return -1;
          } else if (parseInt(a.seq, 0) > parseInt(b.seq, 0)) {
            return 1;
          } else {
            return 0;
          }
        });
        data.activityNameWithStatus = this.setActivityNameWithStatus(data.mileStoneActivityVOList, data.tnCount);
      }
      this.results.push(data);
      this.onCancelledCheckboxChange();
    }
  }

  setActivityNameWithStatus(mileStoneActivityVOList: any[], tnCount: number): string {

    const totalActivity = mileStoneActivityVOList.length;

    const sameStatusWithMisMatchCount = mileStoneActivityVOList.every((object) => {
      let flag = object.status === mileStoneActivityVOList[0].status;
      let count = 0;
      object.statusArray.forEach(status => count += status.count);
      if (flag && count === tnCount) {
        flag = false;
      }
      return flag;
    });
    const differentActivityDiffStatusWithMisMatchCount = mileStoneActivityVOList.some((object) => {
      let count = 0;
      object.statusArray.forEach(status => count += status.count);
      return count !== tnCount;
    });
    if (sameStatusWithMisMatchCount || differentActivityDiffStatusWithMisMatchCount) {
      return `Not all TNs in the same milestone activty.`
    }

    const oneActivityDifferentStatusWithSameCount = mileStoneActivityVOList.every((object) => {
      let flag = object.status !== mileStoneActivityVOList[0].status;
      let count = 0;
      object.statusArray.forEach(status => count += status.count);
      if (flag && count === tnCount) {
        flag = true;
      }
      return flag;
    });
    if (oneActivityDifferentStatusWithSameCount && totalActivity === 1) {
      return `${mileStoneActivityVOList[totalActivity - 1].activityName} in ${mileStoneActivityVOList[totalActivity - 1].statusArray.filter(object => object.status !== 'Completed').map(object => object.status).join(', ')} status.`;
    }

    // When all the activities are in completed status and the TNCount(of the particular activity) is equal to total Tncount(grid main level).
    return `${mileStoneActivityVOList[totalActivity - 1].activityName} in ${mileStoneActivityVOList[totalActivity - 1].statusArray.map(object => object.status).join(', ')} status.`;
  }

  // setActivityNameWithStatus(mileStoneActivityVOList: any, tnCount: number): string {
  //   const activityNameFirst = mileStoneActivityVOList[0].activityName;
  //   const statusFirst = mileStoneActivityVOList[0].status
  //   let allSameActivity = true;
  //   let atLeastOneNotCompleted = false;
  //   let sameTNCountWithSingleStatus = true;
  //   let milestoneCountNotSame = false;

  //   /*if ( mileStoneActivityVOList.length === 1 && mileStoneActivityVOList[0].status !== 'Completed' ) {
  //     return mileStoneActivityVOList[0].activityName + ' in ' + mileStoneActivityVOList[0].status + ' Status ';
  //   } else*/
  //   // if ( mileStoneActivityVOList.length > 1 ) {
  //   mileStoneActivityVOList.forEach(activity => {
  //     console.log(activity)
  //     if ((activity.tnCount !== tnCount && activity.statusArray.length > 1) || this.incompletedStatus.length > 0) {
  //       sameTNCountWithSingleStatus = false;
  //     }
  //     if (activity.status !== 'Completed' || this.incompletedStatus.length > 0) {
  //       atLeastOneNotCompleted = true;
  //     }
  //     if (activityNameFirst !== activity.activityName || statusFirst !== activity.status) {
  //       allSameActivity = false;
  //     }
  //     if (!milestoneCountNotSame) {
  //       if (activity.tnCount !== tnCount) {
  //         milestoneCountNotSame = true;
  //       }
  //     }
  //   });
  //   // }
  //   if (milestoneCountNotSame) {
  //     return 'Not all TNs at same milestone activity ';
  //   }
  //   if (sameTNCountWithSingleStatus) {
  //     return ' All TNs at same milestone activity ';

  //   }else if (this.incompletedStatus.length === 1 && !allSameActivity && atLeastOneNotCompleted) {
  //     let status = '';
  //     this.incompletedStatus[0].statusArray.forEach((v, k) => {
  //       status = status + (status ? ', ' : '') + v.status;
  //     });
  //     return this.incompletedStatus[0].activityName + ' is in ' + status + ' status';
  //   } 
  //   else if (atLeastOneNotCompleted && !allSameActivity) {
  //     return ' Not all TNs at same milestone activity ';
  //   } else if (!atLeastOneNotCompleted && !allSameActivity) {
  //     return 'Activation Completed';
  //   } else {
  //     return '';
  //   }
  // }

  onClearFields() {
    this.errorMsg = '';
    this.message = '';
    this.totalPonCount = 0;
    this.totalTnCount = 0;
    this.isSearchingPon = false;
    this.results = [];
    this.filteredResult = [];
    this.ponSearch = {};
    this.dataTable.reset();
    this.totalTnCount = 0;
    this.statusList = [];
    this.stateList = [];
    this.selectedFilterMileStoneActivityList = null;
    this.selectedStatus = null;
    this.filterMileStoneActivityList = [];
    this.filterMileStoneActivityStatusList = [];
    this.selectedMileStoneActivityStatus = null;
    this.selectedSortColumn = {
      column: 'pon',
      order: 1
    }
  }

  getTns(tn, activity) {
    this.isStatusExpanded = false;
    tn.tNDetailVOList = [];
    this.ponService.getTns(tn.pon, activity.activityId, tn.tnCount).subscribe(res => {
      tn.tNDetailVOList = (res as any);
      tn.tNDetailVOList = tn.tNDetailVOList.sort((value1, value2) => {
        return (value1.activityState < value2.activityState) ? -1 : (value1.activityState > value2.activityState) ? 1 : 0;
      });
      tn.isStatusExpanded = true;
      this.isStatusExpanded = true;
    });
  }

  hideTNListExpanded(tn) {
    tn.tNDetailVOList = [];
    tn.isStatusExpanded = false;
    this.isStatusExpanded = false;
  }

  exportTNList(tn) {
    if (tn.tNDetailVOList && tn.tNDetailVOList.length > 0) {
      const options = {
        showLabels: true,
        headers: ['TN Number', 'Activity State']
      };

      const xlsData = [];
      xlsData.push(options.headers);
      tn.tNDetailVOList.forEach(f => {
        const arr = [];
        Object.keys(f).forEach(key => {
          arr.push(f[key]);
        });
        xlsData.push(arr);
      });

      const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(xlsData);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      XLSX.writeFile(wb, 'pon-search.xls');
    }
  }

  exportPonList() {
    let exportData = [];
    if (this.filteredResult.length > 0) {
      this.isExporting = true;
      const options = {
        showLabels: true,
        headers: ['VOID', 'PON', 'Tn Count', 'Milestone Status', 'LNP Status', 'LNP State', 'FOC Date']
      };
      exportData = this.filteredResult.map(row => {
        const data = {};
        data['voiceOrderId'] = row['voiceOrderId'];
        data['pon'] = row['pon'];
        data['tnCount'] = row['tnCount'];
        if (row.mileStoneActivityVOList.length === 0) {
          data['activityNameWithStatus'] = 'TN(s) not at expected milestone activity';
        } else {
          data['activityNameWithStatus'] = row.activityNameWithStatus;
        }
        data['status'] = row.status;
        data['state'] = row.state;
        if (row.focDateError) {
          data['focDate'] = row.focDateError;
        } else {
          data['focDate'] = this.datePipe.transform(row.focDate, 'MM/dd/yyyy');
        }
        console.log(data);
        return data;
      });
      if (exportData.length > 0) {
        const xlsData = [];
        xlsData.push(options.headers);
        exportData.forEach(f => {
          const arr = [];
          Object.keys(f).forEach(key => {
            arr.push(f[key]);
          });
          xlsData.push(arr);
        });
        const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(xlsData);
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
        XLSX.writeFile(wb, 'pon-list.csv');
        this.isExporting = false;
      } else {
        this.isExporting = false;
      }
    }

  }

  onCancelledCheckboxChange() {
    this.dataTable.reset();
    this.totalTnCount = 0;
    this.statusList = [];
    this.stateList = [];
    if (!this.cancelledData[0]) {
      this.filteredResult = this.results.filter(object => object.state !== 'Cancel' && object.state !== 'Cancel Completed');
    } else {
      this.filteredResult = this.results.filter(object => object.state === 'Cancel' || object.state === 'Cancel Completed');
    }
    this.totalPonCount = this.filteredResult.length;
    this.filteredResult.forEach((object) => this.totalTnCount = this.totalTnCount + object.tnCount);

    /**filter status list start*/
    const list = this.filteredResult.map((obj) => obj.status).filter(function (a) {
      if (!this.has(a)) {
        this.set(a, true);
        return true;
      }
    }, new Map);
    this.statusList = list.map((data) => {
      return { label: data, value: data };
    });
    this.statusList = this.sortFunc(this.statusList, 'label');
    if (this.statusList.length > 0) {
      this.statusList.splice(0, 0, { label: 'All', value: null });
    }
    /**filter status list end*/

    /** filter state List  start*/
    const lists = this.filteredResult.map((obj) => obj.state).filter(function (a) {
      if (!this.has(a)) {
        this.set(a, true);
        return true;
      }
    }, new Map);
    this.stateList = lists.map((data) => {
      return { label: data, value: data };
    });
    this.stateList = this.sortFunc(this.stateList, 'label');
    if (this.stateList.length > 0) {
      this.stateList.splice(0, 0, { label: 'All', value: null });
    }
    /**filter status list end*/

    /**foc date list start*/
    const focDateList = this.filteredResult.map((obj) => obj.focDate).filter(function (a) {
      if (!this.has(a)) {
        this.set(a, true);
        return true;
      }
    }, new Map);
    this.focDateList = focDateList.map((data) => {
      return { label: data, value: data };
    });
    this.focDateList = this.sortFunc(this.focDateList, 'label');
    if (this.focDateList.length > 0) {
      this.focDateList.splice(0, 0, { label: 'All', value: null });
    }
    /**filter status list end*/

    /**milestone activity filter list start*/
    let mileStoneActivityList = [];
    this.filteredResult.forEach((object) => {
      mileStoneActivityList = mileStoneActivityList.concat(object.mileStoneActivityVOList);
    });
    const result = [];
    mileStoneActivityList.reduce((previous, current) => {
      if (!result.find(object => object.activityName === current.activityName)) {
        result.push(current);
      }
    }, []);
    this.filterMileStoneActivityList = result.map(object => {
      return { label: object.activityName, value: object.activityName };
    });
    this.filterMileStoneActivityList = this.sortFunc(this.filterMileStoneActivityList, 'label');
    if (this.filterMileStoneActivityList.length > 0) {
      this.filterMileStoneActivityList.splice(0, 0, { label: 'All', value: null });
    }
    /**milestone activity filter list start*/


    /** filter state List  start*/
    const mileStoneActivityStatusList = this.filteredResult.map((obj) => {
      console.log(obj)
      if (obj.mileStoneActivityVOList && obj.mileStoneActivityVOList.length === 0) {
        return 'TN(s) not at expected milestone activity';
      }
      return obj.activityNameWithStatus;
    }).filter(function (a) {
      if (!this.has(a)) {
        this.set(a, true);
        return true;
      }
    }, new Map);
    this.filterMileStoneActivityStatusList = mileStoneActivityStatusList.map((data) => {
      return { label: data, value: data };
    });
    this.filterMileStoneActivityStatusList = this.sortFunc(this.filterMileStoneActivityStatusList, 'label');
    if (this.filterMileStoneActivityStatusList.length > 0) {
      this.filterMileStoneActivityStatusList.splice(0, 0, { label: 'All', value: null });
    }
    /**filter status list end*/

    this.filteredResult = this.sortFunc(this.filteredResult, this.selectedSortColumn.column, this.selectedSortColumn.order)
    if (this.selectedStatus) {
      this.dataTable.filter(this.selectedStatus, 'status', 'equals');
    }
    if (this.selectedFocDate) {
      this.dataTable.filter(this.selectedFocDate, 'focDate', 'equals');
    }

    setTimeout(() => {
      if (this.selectedFilterMileStoneActivityList) {
        this.onFilterMileStoneActivityListChange();
      }
      if (this.selectedMileStoneActivityStatus) {
        this.onFilterMileStoneActivityStatusListChange();
      }
    });
  }

  sortFunc(list: any[], attr: string, order = 1): any[] {
    return list.sort((a, b) => {
      let value1 = a[attr];
      let value2 = b[attr];
      let result = null;

      if (value1 == null && value2 != null)
        result = -1;
      else if (value1 != null && value2 == null)
        result = 1;
      else if (value1 == null && value2 == null)
        result = 0;
      else if (typeof value1 === 'string' && typeof value2 === 'string')
        result = value1.localeCompare(value2);
      else
        result = (value1 < value2) ? -1 : (value1 > value2) ? 1 : 0;

      return (order * result);
    });
  }

  onFilterMileStoneActivityListChange() {
    if (this.selectedFilterMileStoneActivityList) {
      this.dataTable.value = this.filteredResult.filter((object) => {
        return object.mileStoneActivityVOList.find(milestone => milestone.activityName === this.selectedFilterMileStoneActivityList);
      });
    } else {
      this.dataTable.value = this.filteredResult;
    }
  }

  onFilterMileStoneActivityStatusListChange() {
    if (this.selectedMileStoneActivityStatus) {
      this.dataTable.value = this.filteredResult.filter((object) => {
        if (this.selectedMileStoneActivityStatus === 'TN(s) not at expected milestone activity' && (object.mileStoneActivityVOList && object.mileStoneActivityVOList.length === 0)) {
          return true;
        }
        return object.activityNameWithStatus === this.selectedMileStoneActivityStatus;
      });
    } else {
      this.dataTable.value = this.filteredResult;
    }
  }

  onChangeFilterBy() {
    this.selectedFilterMileStoneActivityList = null;
    this.selectedFocDate = null;
    this.selectedStatus = null;
    this.selectedState = null;
    this.selectedMileStoneActivityStatus = null;
    this.dataTable.value = this.filteredResult;
    this.dataTable.filter(this.selectedStatus, 'status', 'equals');
    this.dataTable.filter(this.selectedState, 'state', 'equal');
    this.onFilterMileStoneActivityListChange();
    this.onFilterMileStoneActivityStatusListChange();
    this.dataTable.filter(this.selectedFocDate, 'focDate', 'equals');
  }

  customSort(event) {
    this.selectedSortColumn = {
      column: event.field,
      order: event.order
    };
    event.data = this.sortFunc(event.data, event.field, event.order);
  }
}
