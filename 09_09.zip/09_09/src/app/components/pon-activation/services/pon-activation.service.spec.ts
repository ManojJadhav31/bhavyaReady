import { HttpClient } from '@angular/common/http';
import { getTestBed, inject, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { PortoutService } from '../../portout/services/portout.service';
import { ApiService } from '../../../shared/services/api.service';
import { PonActivationService } from './pon-activation.service';

describe('PonActivationService', () => {
  let ponActivationService: PonActivationService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let apiService: ApiService;
  let httpClient: HttpClient;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ PonActivationService, PortoutService, ApiService ]
    });
    injector = getTestBed();
    httpClient = TestBed.get(HttpClient);
    ponActivationService = injector.get(PonActivationService);
    httpMock = injector.get(HttpTestingController);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', inject(
    [ PonActivationService ],
    (service: PonActivationService) => {
      expect(service).toBeTruthy();
    }
  ));

  it('should get Pon details using base url', () => {
    const url = apiService.baseUrl + 'order' + '-' + apiService.envName + '/ServiceDelivery/v1/Voice/pon/search/activation/1';
    ponActivationService.searchPon('1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });
  it('should get tns activity detail using base url', () => {
    const url = apiService.baseUrl + 'order' + '-' + apiService.envName + '/ServiceDelivery/v1/Voice/pon/search/activation/tn-details/1/1/1';
    ponActivationService.getTns('1', '1', '1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });
  it('should search void using base url', () => {
    const url = apiService.baseUrl + 'order' + '-' + apiService.envName + '/ServiceDelivery/v1/Voice/pon/search/void/1';
    ponActivationService.getPONByVoid('1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });
});
