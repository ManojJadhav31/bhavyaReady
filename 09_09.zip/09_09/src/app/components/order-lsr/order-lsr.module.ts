import { NgModule } from '@angular/core';
import { OrderLsrRoutingModule } from './order-lsr-routing.module';
import { LsrOrderSearchComponent } from './lsr-order-search/lsr-order-search.component';
import { SharedModule } from '../../shared/shared.module';
import { SearchPanelsModule } from '../search-panels/search-panels.module';
import { ColumnPickListDialogModule } from '../dialog/column-pick-list-dialog/column-pick-list-dialog.module';
import { UpdateOrderDateDialogModule } from '../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';
import { LsrOrderSearchService } from './services/lsr-order-search.service';
import { LsrActivityAgentAssignDialogModule } from '../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.module';
import { LsrRejectOrderDetailsComponent } from './lsr-reject-order-details/lsr-reject-order-details.component';
import { ActivationLsrModule } from '../activation-lsr/activation-lsr.module';
import { LsrOrderDetailPageComponent } from './lsr-order-detail-page/lsr-order-detail-page.component';
import { UpdateFocAndCrdDialogModule } from '../dialog/update-foc-and-crd-dialog/update-foc-and-crd-dialog.module';

@NgModule({
  declarations: [LsrOrderSearchComponent, LsrRejectOrderDetailsComponent, LsrOrderDetailPageComponent],
  imports: [
    OrderLsrRoutingModule,
    SharedModule,
    SearchPanelsModule,
    ColumnPickListDialogModule,
    UpdateOrderDateDialogModule,
    UpdateReasonDialogModule,
    TransactionViewDialogModule,
    LsrActivityAgentAssignDialogModule,
    ActivationLsrModule,
    UpdateFocAndCrdDialogModule
  ],
  providers: [LsrOrderSearchService]
})
export class OrderLsrModule {

}
