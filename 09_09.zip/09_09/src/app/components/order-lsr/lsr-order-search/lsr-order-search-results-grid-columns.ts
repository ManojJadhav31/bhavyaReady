export const ColumnType: any = {
    string: 'string',
    number: 'number',
    date: 'date'
  };
  
  export const LsrOrderSearchResultsGridColumns: any = [
    {
      caption: 'Carrier Id',
      value: 'extOrderId',
      visible: 'false',
      type: ColumnType.string,
      class: { 'r12': true }
    },
    {
      caption: 'PON Status',
      value: 'ponStatus',
      visible: 'false',
      type: ColumnType.string,
      class: { 'r10': true }
    },
    {
      caption: 'LSR Status',
      value: 'lsrStatus',
      visible: 'false',
      type: ColumnType.string,
      class: { 'r10': true }
    },
    {
      caption: 'FOC Date',
      value: 'focDateFormatted',
      format: 'MM/dd/yyyy hh:mm:a',
      visible: false,
      type: ColumnType.date,
      class: { 'r10': true }
    },
    // {
    //   caption: 'orderDate',
    //   value: 'orderDate',
    //   visible: 'false',
    //   type: ColumnType.date,
    //   class: { 'r10': true }
    // },
    {
      caption: 'CRD',
      value: 'customerRequestedDateFormatted',
      visible: false,
      type: ColumnType.date,
      format: 'MM/dd/yyyy hh:mm:a',
      class: { 'r10': true }
    },
    {
      caption: 'Carrier PON',
      value: 'purchaseOrderNumber',
      visible: false,
      type: ColumnType.number,
      class: { 'r10': true }
    },
    {
      caption: 'VER',
      value: 'purchaseOrderVersion',
      visible: false,
      type: ColumnType.number,
      class: { 'r7': true }
    },
    {
      caption: 'Legacy Company Name',
      value: 'companyName',
      visible: false,
      type: ColumnType.string,
      class: { 'r21': true }
    },
    {
      caption: 'Order Status',
      value: 'orderStatus',
      visible: false,
      type: ColumnType.string,
      class: { 'r14': true }
    },
    {
      caption: 'Order Type',
      value: 'orderType',
      visible: false,
      type: ColumnType.string,
      class: { 'r12': true }
    }, 
    {
      caption:'Order Source',
      value:'orderSource',
      visible:false,
      type: ColumnType.string,
      class:{'r13': true}
    },
    {
      caption: 'Activity',
      value: 'activity',
      visible: false,
      type: ColumnType.string,
      class: { 'r10': true }
    },
    {
      caption: 'Carrier Additional Notes',
      value: 'carrierAdditionalNotes',
      visible: false,
      type: ColumnType.string,
      class: { 'r17': true }
    },
    {
      caption: 'Biz Org',
      value: 'bizOrg',
      visible: false,
      type: ColumnType.string,
      class: { 'r11': true }
    },
    {
      caption: 'BAN',
      value: 'billingAccountNumber',
      visible: false,
      type: ColumnType.number,
      class: { 'r10': true }
    },
    {
      caption: 'Reseller',
      value: 'resellerName',
      visible: false,
      type: ColumnType.string,
      class: { 'r10': true }
    },
    {
      caption: 'Type of Port',
      value: 'TypeOfPort',
      visible: false,
      type: ColumnType.string,
      class: { 'r10': true }
    },
    // {
    //   caption: 'Business Name',
    //   value: 'businessName',
    //   visible: false,
    //   type: ColumnType.string,
    //   class: { 'r16': true }
    // },
    {
      caption: 'Parent Order Id',
      value: 'parentOrderId',
      visible: false,
      type: ColumnType.string,
      class: { 'r14': true }
    },
    {
      caption: 'Product',
      value: 'productId',
      visible: false,
      type: ColumnType.number,
      class: { 'r11': true }
    },
    // {
    //   caption: 'Sl Order Id',
    //   value: 'slOrderId',
    //   visible: false,
    //   type: ColumnType.number,
    //   class: { 'r11': true }
    // },
    {
      caption: 'Carrier Spid',
      value: 'carrierSpid',
      visible: false,
      type: ColumnType.string,
      class: { 'r9': true }
    },
    {
      caption: 'Assigned Agent',
      value: 'assignedAgent',
      visible: false,
      type: ColumnType.string,
      class: { 'r13': true }
    },
    {
      caption: 'Trunk Number',
      value: 'trunkNumber',
      visible: false,
      type: ColumnType.number,
      class: { 'r11': true }
    },
    {
      caption: 'Switch Number',
      value: 'switchNumber',
      visible: false,
      type: ColumnType.number,
      class: { 'r12': true }
    },
    {
      caption:'LOA Filename',
      value:'loaFileName',
      visible:false,
      type: ColumnType.string,
      class:{'r12': true}
    },
    {
      caption: 'Contact Name',
      value: 'contactName',
      visible: false,
      type: ColumnType.string,
      class: { 'r14': true }
    },
    // {
    //   caption: 'First Name',
    //   value: 'firstName',
    //   visible: false,
    //   type: ColumnType.string,
    //   class: { 'r11': true }
    // },
    // {
    //   caption: 'Middle Initial',
    //   value: 'middleInitial',
    //   visible: false,
    //   type: ColumnType.string,
    //   class: { 'r11': true }
    // },
    // {
    //   caption: 'Last Name',
    //   value: 'lastName',
    //   visible: false,
    //   type: ColumnType.string,
    //   class: { 'r11': true }
    // },
    {
      caption: 'Order  Active',
      value: 'orderActive',
      visible: false,
      type: ColumnType.string,
      class: { 'r12': true }
    },
    {
      caption: 'Carrier Eid',
      value: 'carrierId',
      visible: false,
      type: ColumnType.string,
      class: { 'r11': true }
    }
  ];
  