import { Injectable } from '@angular/core';
import { ApiService } from '../../../shared/services/api.service';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { UtilityService } from '../../../shared/services/utility.service';

@Injectable({
  providedIn: 'root'
})
export class LsrOrderSearchService {

  constructor(private apiService: ApiService, private http: HttpClient,
    private utilityService: UtilityService) { }

  searchOrderActivities(data, pageSize, page): Observable<any> {
    page = page - 1;
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsrorder/search';
    let params = new HttpParams();
    params = params.append('pageSize', pageSize);
    params = params.append('page', page);
    const body = JSON.stringify(data);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');

    return this.http.post(url, body, {
      params: params,
      headers: headers
    }).pipe(catchError(error => this.apiService.handleException(error)));
  }

  getLSRDetails(extOrderId) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsractivity/LSRDetails';
    let params = new HttpParams();
    params = params.append('extOrderId', extOrderId);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.get(url, { params: params, headers: headers }).pipe(
      catchError(error => this.apiService.handleException(error))
    );
  }

  getRejectOrders(extOrderId) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsrorder/rejectedLSROrderDetail';
    let params = new HttpParams();
    params = params.append('extOrderId', extOrderId);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.get(url, { params: params, headers: headers }).pipe(
      catchError(error => this.apiService.handleException(error))
    );
  }

  getExportDetail(data) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/LSROrderSearch/export';
    const body = JSON.stringify(data);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.post(url, body, { responseType: 'blob', headers: headers }).pipe(
      map((response) => {
        return { fileName: 'lsr-details.csv', data: response };
      }),
      catchError(error => this.apiService.handleException(error))
    );
  }

  cancelLsrOrder(data: any, operation: string, correlationId: string, actionReason?: string): Observable<any> {
    const userName = localStorage.getItem('UserName');
    const requestPayload = {
      'correlationId': correlationId,
      'systemId': 'MOAB',
      'userId': userName,
      'lsrRequestId': data.extOrderId,
      'spid': data.carrierSpid,
      'reasonComments': actionReason
    };
    let endPoint = '/ServiceDelivery/v1/Voice/lsrorder/cancelLSROrder';

    const url = this.apiService.orderApiUrl + endPoint;
    const body = JSON.stringify(requestPayload);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.post(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }

  updateLsr(requestPayload) {
    let endPoint = '/ServiceDelivery/v1/Voice/lsrorder/updateLsrRequest';
    const url = this.apiService.orderApiUrl + endPoint;
    const body = JSON.stringify(requestPayload);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.post(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }

  updateLsrOrderRequest(data: any, extraDetails, correlationId: string): Observable<any> {
    const requestPayload = {
      "rejectLsrFlag": false,
      "comments": extraDetails.comments,
      "correlationId": correlationId,
      "focDate": extraDetails.date,
      "orderActivityPk": null,
      "parentTransId": data,
      "systemId": this.utilityService.getSystemId(),
      "userId": this.utilityService.getUserId(),
      "billingAccountNumber": null,
      "reasonCode": null,
      "reasonDesc": null,
      "resellerName": null,
      "switchNumber": null,
      "trunkNumber": null
    };
    const endPoint = '/ServiceDelivery/v1/Voice/lsrorder/updateLsrRequest';
    const url = this.apiService.orderApiUrl + endPoint;
    const body = JSON.stringify(requestPayload);
    console.log(body)
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.post(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }
  updateActivitiesOrderDate(data: any, extraDetails, correlationId: string): Observable<any> {
    const userName = this.utilityService.getUserId()
    const requestPayload = {
      'correlationId': correlationId,
      'systemId': 'User',
      'userId': userName,
      'orderId': data,
      'orderComment': extraDetails.orderComments,
      'dateType': extraDetails.dateType,
      'newDate': extraDetails.newDate
    };
    const endPoint = '/ServiceDelivery/v1/Voice/tnActivitySearch/order/date';
    const url = this.apiService.orderApiUrl + endPoint;
    const body = JSON.stringify(requestPayload);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.put(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }
}
