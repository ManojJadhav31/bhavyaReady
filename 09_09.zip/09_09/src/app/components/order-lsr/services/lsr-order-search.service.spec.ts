import { TestBed } from '@angular/core/testing';

import { LsrOrderSearchService } from './lsr-order-search.service';

describe('OrderLsrService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LsrOrderSearchService = TestBed.get(LsrOrderSearchService);
    expect(service).toBeTruthy();
  });
});
