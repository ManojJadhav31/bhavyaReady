import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {LnpOrderSearchComponent} from './lnp-order-search.component';
import {DefaultSearchComponent} from '../default-search/default-search.component';
import {E911SearchComponent} from '../e911-search/e911-search.component';
import {EmeaSearchComponent} from '../emea-search/emea-search.component';
import {OrderSearchComponent} from '../order-search/order-search.component';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {SearchPanelsService} from '../services/search-panels.service';
import {PortoutService} from '../../portout/services/portout.service';
import {ApiService} from '../../../shared/services/api.service';
import {lnpOrderState} from '../../../../tests/mockdata/search-panels/lnp-order-search';
import {SharedModule} from '../../../shared/shared.module';
import {of} from 'rxjs';
import {StorageService} from '../../../services/storage.service';


describe('LnpOrderSearchComponent', () => {
  let component: LnpOrderSearchComponent;
  let fixture: ComponentFixture<LnpOrderSearchComponent>;
  let searchPanelService: SearchPanelsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DefaultSearchComponent,
        E911SearchComponent,
        EmeaSearchComponent,
        LnpOrderSearchComponent,
        OrderSearchComponent
      ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        SharedModule,
        BrowserAnimationsModule
      ],
      providers: [
        SearchPanelsService,
        PortoutService,
        ApiService,
        StorageService

      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LnpOrderSearchComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();

    searchPanelService = fixture.debugElement.injector.get(SearchPanelsService);
    spyOn(searchPanelService, 'getLnpOrderStatus').and.returnValue(of(lnpOrderState));

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should populate lnpOrderStatus', () => {
    component.getLnpOrderStatus();
    expect(component.lnpOrderStatus.length).toBeGreaterThan(0);
  });

});
