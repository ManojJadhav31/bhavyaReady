import {Component, Input, OnInit} from '@angular/core';
import {SearchPanelsService} from '../services/search-panels.service';
import {SearchRequestObject} from '../search-panel-constants';
import {sortList} from 'src/app/core/utills';


@Component({
  selector: 'app-default-search',
  templateUrl: './default-search.component.html',
  styleUrls: ['./default-search.component.scss']
})
export class DefaultSearchComponent implements OnInit {

  @Input() parentPanel: string;
  @Input() activitySearch: SearchRequestObject = new SearchRequestObject();

  activityName: any = [];
  activityStatus: any = [];
  dateType: any = [];
  selectedDateType: any = 'All';
  dateCategories: any = [];
  selectedDateCategories: any = 'range';
  dateRange: any = [];
  selectedDateRange: any;
  selectedDateCategoriesSecondary: any = 'range';
  selectedDateRangeSecondary: any;
  displayableActivity: any = [];
  selectedActivity: any;
  internalPortOptions: any = [];
  selectedInternalPort: any;
  selectedActivityNames: any;
orderSearchDateType:any = [];

  defaultDate: Date = new Date();


  constructor(private searchPanelsService: SearchPanelsService) {

    this.internalPortOptions = [
      {value: null, selected: 'selected', label: 'All'},
      {value: 'Y', label: 'Yes'},
      {value: 'N', label: 'No'}
    ];
    this.orderSearchDateType = [
      {label: 'All', selected: 'selected', value: 'All'},
      {label: 'Bill Start Date', value: 'BillStartDate'},
      {label: 'Customer Commit Date', value: 'CustomerCommitDate'},
      {label: 'Customer Request Date', value: 'CustomerRequestDate'},
      {value: 'CustomerAcceptanceDate', label: 'Customer Acceptance Date'},
      {value: 'FocDate', label: 'LNP FOC Date'},
      {value: 'InstallDate', label: 'Install Date'},
      {value: 'LastUpdatedDate', label: 'Last Update Date'},
      {value: 'OrderCompletionDate', label: 'Order Completion Date'},
      {value: 'OrderDate', label: 'Order Date'},
      {value: 'PortRequestDate', label: 'Port Request Date'},
      {value: 'RevisedCommitDate', label: 'Revised Commit Date'},
      {value: 'DesiredDueDate', label: 'Desired Due Date'},
      {value: 'PortTriggerDate', label: 'Port Trigger Date'},
      {value: 'lnpGwFocDate', label: 'LNP GW Foc Date'},
    ]
    this.dateType = [
      {label: 'All', selected: 'selected', value: 'All'},
      {label: 'Bill Start Date', value: 'BillStartDate'},
      {label: 'Customer Commit Date', value: 'CustomerCommitDate'},
      {label: 'Customer Request Date', value: 'CustomerRequestDate'},
      {value: 'CustomerAcceptanceDate', label: 'Customer Acceptance Date'},
      {value: 'FocDate', label: 'LNP FOC Date'},
      {value: 'InstallDate', label: 'Install Date'},
      {value: 'LastUpdatedDate', label: 'Last Update Date'},
      {value: 'OrderCompletionDate', label: 'Order Completion Date'},
      {value: 'OrderDate', label: 'Order Date'},
      {value: 'PortRequestDate', label: 'Port Request Date'},
      {value: 'RevisedCommitDate', label: 'Revised Commit Date'},
      {value: 'DesiredDueDate', label: 'Desired Due Date'},
      {value: 'ActivityCreateDate', label: 'Activity Create Date'},
      {value: 'ActivityCompleteDate', label: 'Activity Complete Date'},
    ];

    this.dateCategories = [
      {label: 'Date Range', value: 'range'},
      {label: 'Relative Date', value: 'relative'},
      // {label: 'Null', value: null}
    ];

    this.dateRange = [
      {label:'All', value: null},
      {label: 'Today', value: 'today'},
      {label: 'Tomorrow', value: 'tomorrow'},
      {label: 'Yesterday', value: 'yesterday'},
      {label: 'Next Business Day', value: 'nextBusinessDay'},
      {label: 'Previous Business Day', value: 'previousBusinessDay'},
      {label: 'Next 2 Days', value: 'next2Days'},
      {label: 'Past 2 Days', value: 'past2Days'},
      {label: 'Next 3 Days', value: 'next3Days'},
      {label: 'Past 3 Days', value: 'past3Days'},
      {label: 'Next 5 Days', value: 'next5Days'},
      {label: 'Past 5 Days', value: 'past5Days'},
      {label: 'Next 5 Business Days', value: 'next5BusinessDays'},
      {label: 'Past 5 Business Days', value: 'past5BusinessDays'},
      {label: 'Next 10 Business Days', value: 'next10BusinessDays'},
      {label:'Past 10 Business Days',value:'past10BusinessDays'},
      {label:'Past 30 Days', value:'past30Days'},
      {label:'Next 30 Days',value:'next30Days'},
      {label:'Previous 30 to Next 60 Days',value:'previous30DaysToNext60Days'}
    ];


    this.displayableActivity = [
      {value: null, label: 'All'},
      {value: 'Y', selected: 'selected', label: 'Yes'},
      {value: 'N', label: 'No'}
    ];
  }

  ngOnInit() {
    this.dateType = sortList(this.dateType, 'label');
    this.dateCategories = sortList(this.dateCategories, 'label');
    // this.dateRange = sortList(this.dateRange, 'label');
    this.getActivityName();
    this.getActivityStatus();
    this.activitySearch.showTnTextArea = false;

    // this.activitySearch.internalPortOptions = "Y";
    this.activitySearch.isDisplayable = 'Y';
  };

  getActivityName() {
    this.searchPanelsService.getActivityName().subscribe(data => {
      this.activityName = data;
      this.activityName = sortList(this.activityName, 'activityDisplayLabel');
    });
  };

  getActivityStatus() {
    this.searchPanelsService.getActivityStatus().subscribe(data => {
      this.activityStatus.push(data);
      this.activityStatus = sortList(this.activityStatus, 'label');
    });
  };

  // onDateTypeSecondaryChange() {
  //   if (this.dateCategories[0]) {
  //     this.activitySearch.selectedDateCategoriesSecondary = this.dateCategories[0].value;
  //   }
  // }

  // onDateTypeChange() {
  //   if (this.dateCategories[0]) {
  //     this.activitySearch.selectedDateCategories = this.dateCategories[0].value;
  //   }
  // }


  setDateRangeValue(category, dropdown) {
    if (category === 'relative') {
      if (dropdown === 'first') {
        this.activitySearch.selectedDateRange = this.dateRange[0].value;
      } else {
        this.activitySearch.selectedDateRangeSecondary = this.dateRange[0].value;
      }
    }
  }
}
