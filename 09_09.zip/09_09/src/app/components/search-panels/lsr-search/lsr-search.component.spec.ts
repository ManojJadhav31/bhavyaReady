import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LsrSearchComponent } from './lsr-search.component';
import { SharedModule } from '../../../shared/shared.module';
import { SearchPanelsService } from '../services/search-panels.service';
import { ApiService } from '../../../shared/services/api.service';
import { of } from 'rxjs';
import { activityStatus } from '../../../../tests/mockdata/search-panels/default-search';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StorageService } from '../../../services/storage.service';

describe('LsrSearchComponent', () => {
  let component: LsrSearchComponent;
  let fixture: ComponentFixture<LsrSearchComponent>;
  let searchPanelService: SearchPanelsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LsrSearchComponent ],
      imports: [
        HttpClientTestingModule,
        SharedModule,
        BrowserAnimationsModule
      ],
      providers: [
        SearchPanelsService,
        ApiService,
        StorageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LsrSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    searchPanelService = fixture.debugElement.injector.get(SearchPanelsService);
    spyOn(searchPanelService, 'getActivityStatus').and.returnValue(of(activityStatus));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should populate activity status', () => {
    component.getLsrActivityStatus();
    expect(component.lsrActivityStatus[0].value).toEqual('Cancelled');
  });
});
