import { Component, Input, OnInit } from '@angular/core';
import { LsrSearchRequest } from '../search-panel-constants';
import { sortList } from '../../../core/utills';
import { SearchPanelsService } from '../services/search-panels.service';

@Component({
  selector: 'app-lsr-search',
  templateUrl: './lsr-search.component.html',
  styleUrls: [ './lsr-search.component.scss' ]
})
export class LsrSearchComponent implements OnInit {

  @Input() parentPanel: string;
  @Input() activitySearch: LsrSearchRequest = new LsrSearchRequest();
  public defaultDate: Date = new Date();

  public dateType: any[] = [
    { label: 'All', value: 'All' },
    { label: 'OrderDate', value: 'OrderDate' },
    { label: 'Order Completion Date', value: 'orderCompleteDate' }
  ];
  public companyNameOptions: any[] = [
    { value: '', selected: 'selected', label: 'All' },
    { value: 'BROADWING', label: 'BROADWING' },
    { value: 'ICG', label: 'ICG' },
    { value: 'LEVEL 3', label: 'LEVEL 3' },
    { value: 'TELCOVE', label: 'TELCOVE' }
  ];
  public orderType: any[] = [
    { value: '', selected: 'selected', label: 'All' },
    { value: 'Cancel', label: 'Cancel' },
    { value: 'New', label: 'New' },
    { value: 'Supplemental', label: 'Supplemental' },
  ];
  public orderActive: any = [
    {value: null, selected: 'selected', label: 'All'},
    {value: 'Y', label: 'Yes'},
    {value: 'N', label: 'No'}
  ]
  public dateCategories = [
    { label: 'Date Range', value: 'range' },
    { label: 'Relative Date', value: 'relative' },
  ];
  public dateRange = [
      {label:'All', value: null},
      {label: 'Today', value: 'today'},
      {label: 'Tomorrow', value: 'tomorrow'},
      {label: 'Yesterday', value: 'yesterday'},
      {label: 'Next Business Day', value: 'nextBusinessDay'},
      {label: 'Previous Business Day', value: 'previousBusinessDay'},
      {label: 'Next 2 Days', value: 'next2Days'},
      {label: 'Past 2 Days', value: 'past2Days'},
      {label: 'Next 3 Days', value: 'next3Days'},
      {label: 'Past 3 Days', value: 'past3Days'},
      {label: 'Next 5 Days', value: 'next5Days'},
      {label: 'Past 5 Days', value: 'past5Days'},
      {label: 'Next 5 Business Days', value: 'next5BusinessDays'},
      {label: 'Past 5 Business Days', value: 'past5BusinessDays'},
      {label: 'Next 10 Business Days', value: 'next10BusinessDays'},
      {label:'Past 10 Business Days',value:'past10BusinessDays'},
      {label:'Past 30 Days', value:'past30Days'},
      {label:'Next 30 Days',value:'next30Days'},
      {label:'Previous 30 to Next 60 Days',value:'previous30ToNext60Days'}
    ];

  public displayableActivity = [
    { value: null, label: 'All' },
    { value: 'Y', selected: 'selected', label: 'Yes' },
    { value: 'N', label: 'No' }
  ];
  public orderStatus: any[] = [
    // { value: null, label: 'All' },
    { value: 'Completed', label: 'Completed' },
    { value: 'Created', label: 'Created' },
    { value: 'Foc Received', label: 'Foc Received' },
    { value: 'Processing', label: 'Processing' }
  ];
  public lsrStatus: any[] = [
    // {value:null,label:'All'},
    {value:'Created',label:'Created'},
    {value:'Completed',label:'Completed'},
    {value:'Approved',label:'Approved'},
    {value:'Rejected',label:'Rejected'},
    {value:'Submitted',label:'Submitted'},
    {value:'Cancelled',label:'Cancelled'},
    {value:'Cancelling',label:'Cancelling'},
    {value:'Carrier Rejected',label:'Carrier Rejected'},
    {value:'Errored',label:'Errored'},
    {value:'Pending Customer Validation',label:'Pending Customer Validation'},
  ];
  public ponStatus: any [] = [
    // {value:null, label:'All'},
    {value:'Foc Received',label:'Foc Received'},
    {value:'Created',label:'Created'},
    {value:'Completed',label:'Completed'},
    {value:'Submitted',label:'Submitted'},
    {value:'Rejected',label:'Rejected'},
    {value:'Cancelled',label:'Cancelled'},
    {value:'Pending Disconnect',label:'Pending Disconnect'},
    {value:'Cancelling',label:'Cancelling'},
  ];
  public activityName: any[] = [
    // { value: '', selected: 'selected', label: 'All' },
    { value: 'Cancel Pending Activities in Install Order', label: 'Cancel Pending Activities in Install Order' },
    { value: 'Cancel Port Out Disconnect (Manual)', label: 'Cancel Port Out Disconnect (Manual)' },
    { value: 'De-Provision Port Out TN (Manual)', label: 'De-Provision Port Out TN (Manual)' },
    { value: 'DL Complete (Manual)', label: 'DL Complete (Manual)' },
    { value: 'ES ALI Provisioning - Unlock', label: 'ES ALI Provisioning - Unlock' },
    { value: 'ES Route Provisioning - Delete', label: 'ES Route Provisioning - Delete' },
    { value: 'Get DL Carrier Info and L3 OCN', label: 'Get DL Carrier Info and L3 OCN' },
    { value: 'Has First Usage Billing Occurred?', label: 'Has First Usage Billing Occurred?' },
    { value: 'Send Carrier Billing Complete Notification', label: 'Send Carrier Billing Complete Notification' },
    { value: 'Send Carrier Cancel Complete Notification', label: 'Send Carrier Cancel Complete Notification' },
    { value: 'Send Carrier FOC Notification', label: 'Send Carrier FOC Notification' },
    { value: 'Send Carrier Order Submit Notification', label: 'Send Carrier Order Submit Notification' },
    { value: 'Send Carrier Reject Notification', label: 'Send Carrier Reject Notification' },
    { value: 'Set LSR FOC', label: 'Set LSR FOC' },
    { value: 'Set LSR Status = Accepted', label: 'Set LSR Status = Accepted' },
    { value: 'Set LSR Status = Completed', label: 'Set LSR Status = Completed' },
    { value: 'Set LSR Status = Rejected', label: 'Set LSR Status = Rejected' },
    { value: 'Set Supp Allowed Flag = \'None\'', label: 'Set Supp Allowed Flag = \'None\'' },
    { value: 'Submit DL (Manual)', label: 'Submit DL (Manual)' },
    { value: 'Trigger Billing', label: 'Trigger Billing' },
    { value: 'Trigger Check for Cancel LRN', label: 'Trigger Check for Cancel LRN' },
    { value: 'Trigger Check for LRN Update', label: 'Trigger Check for LRN Update' },
    { value: 'Trigger Mediation', label: 'Trigger Mediation' },
    { value: 'Validate Carrier LSR Data (Manual)', label: 'Validate Carrier LSR Data (Manual)' },
    { value: 'Voice De-Provisioning (Disconnect)', label: 'Voice De-Provisioning (Disconnect)' },
    { value: 'Wait for CRD', label: 'Wait for CRD' },
    { value: 'Wait for SONUS Deprovisioning', label: 'Wait for SONUS Deprovisioning' },
    { value: 'Wait for Trigger LRN Update Check', label: 'Wait for Trigger LRN Update Check' },
    { value: '911 Manager ALI Provisioning - Delete',label:'911 Manager ALI Provisioning - Delete'},
    { value: '911 Route Provisioning - Delete',label:'911 Route Provisioning - Delete'},
    {value:  '911 ALI Provisioning - Unlock', label:'911 ALI Provisioning - Unlock'}
  ];
  public lsrActivityStatus: any[] = [];

  constructor(private searchPanelsService: SearchPanelsService) {
  }

  ngOnInit() {
    this.activitySearch.showTnTextArea = false;
    // this.activitySearch.isDisplayable = 'Y';
    this.activitySearch.orderActive = 'Y';
    this.activitySearch.isDisplayable = 'Y';
    this.dateType = sortList(this.dateType, 'label');
    this.dateCategories = sortList(this.dateCategories, 'label');
    this.dateRange = sortList(this.dateRange, 'label');
    this.getLsrActivityStatus();
  }

  getLsrActivityStatus() {
    this.searchPanelsService.getActivityStatus().subscribe(data => {
      this.lsrActivityStatus.push(data);
      this.lsrActivityStatus = sortList(this.lsrActivityStatus, 'label');
    });
  }

  setDateRangeValue(category, dropdown) {
    if ( category === 'relative' ) {
      if ( dropdown === 'first' ) {
        this.activitySearch.selectedDateRange = this.dateRange[0].value;
      } else {
        this.activitySearch.selectedDateRangeSecondary = this.dateRange[0].value;
      }
    }
  }
}
