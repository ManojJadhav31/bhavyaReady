import { Component, OnInit } from '@angular/core';
import { LsrActivitySearchService } from '../services/lsr-activity-search.service';
import { ActivatedRoute } from '@angular/router';
import { TnDetailVo } from '../activation-lsr.constants';
import { UtilityService } from '../../../shared/services/utility.service';

@Component({
  selector: 'app-lsr-activity-deprovision-tns-page',
  templateUrl: './lsr-activity-deprovision-tns-page.component.html',
  styleUrls: ['./lsr-activity-deprovision-tns-page.component.scss']
})
export class LsrActivityDeprovisionTnsPageComponent implements OnInit {

  extOrderId: any;
  carrierId: any;
  carrierEId: any;
  companyName: any;
  focDate: any;
  activityName: string;
  productId: number;
  orderActivityIdPK: number;
  deProvisionMessage: boolean = false;
  deProvisionTNTaskMessage: boolean = false;
  successMessage: string;
  errorMessage: string;
  orderDetail: TnDetailVo;

  constructor(private lsrActivitySearchService: LsrActivitySearchService,
    private activatedRoute: ActivatedRoute, private utilService: UtilityService) {
  }

  ngOnInit() {
    this.extOrderId = this.activatedRoute.snapshot.params['extOrderId'];
    this.carrierId = this.activatedRoute.snapshot.params['carrierId'];
    this.companyName = this.activatedRoute.snapshot.params['companyName'];
    this.focDate = this.activatedRoute.snapshot.params['focDate'];
    this.activityName = this.activatedRoute.snapshot.params['activityName'];
    this.orderActivityIdPK = this.activatedRoute.snapshot.params['orderActivityIdPK'];
    if (this.activityName !== 'De-Provision Port Out TN (Manual)') {
      this.deProvisionMessage = true;
    }
    this.productId = this.activatedRoute.snapshot.params['productId'];
    this.productId = parseInt(this.productId.toString(), 0) || this.productId;
    if (this.productId === 2042 || this.productId === 2036) {
      this.deProvisionTNTaskMessage = true;
    }
    this.getDeProvisionTn();
  }

  getDeProvisionTn() {
    this.errorMessage = '';
    this.successMessage = '';
    this.lsrActivitySearchService.getDeProvisionTn(this.extOrderId).subscribe((response: TnDetailVo) => {
      this.orderDetail = response;
    }, error => this.errorMessage = error);
  }

  onUpdateForceCompleteClick() {
    this.errorMessage = '';
    this.successMessage = '';
    this.lsrActivitySearchService.updateActivities([this.orderActivityIdPK], 'forceCompleteActivity', this.utilService.getCorrelationId()).subscribe((response) => {
      if (response[0] && response[0].errorCode === 0) {
        this.successMessage = 'Successfully Updated';
      } else if(response[0] && response[0].errorCode !== 0) {
        this.errorMessage = response[0].errorMessage
      }
    }, error => {
      this.errorMessage = error
    })
  }
}
