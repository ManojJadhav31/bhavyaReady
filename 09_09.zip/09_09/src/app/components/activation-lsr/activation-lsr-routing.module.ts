import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LsrActivitySearchComponent } from './lsr-activity-search/lsr-activity-search.component';
import { LsrActivityDetailPageComponent } from './lsr-activity-detail-page/lsr-activity-detail-page.component';
import { LsrActivityDeprovisionTnsPageComponent } from './lsr-activity-deprovision-tns-page/lsr-activity-deprovision-tns-page.component';

const routes: Routes = [
  {
    path: '', pathMatch: 'full', redirectTo: 'search'
  },
  {
    path: 'search',
    component: LsrActivitySearchComponent
  },
  {
    path: 'detail/:extOrderId/:activityName/:productId/:status/:orderActivityIdPK/:parentOrderId',
    component: LsrActivityDetailPageComponent
  },
  {
    path: 'deprovision-tns/:extOrderId/:carrierId/:companyName/:focDate/:activityName/:productId/:orderActivityIdPK',
    component: LsrActivityDeprovisionTnsPageComponent
  },
  {
    path: 'activity-errors/:id', loadChildren: 'src/app/components/activity-error-details/activity-error-details.module#ActivityErrorDetailsModule'
  }
];

@NgModule({
  imports: [ RouterModule.forChild(routes) ],
  exports: [ RouterModule ]
})
export class ActivationLsrRoutingModule {
}
