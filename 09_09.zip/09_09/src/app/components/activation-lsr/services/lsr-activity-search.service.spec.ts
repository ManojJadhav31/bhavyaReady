import { getTestBed, inject, TestBed } from '@angular/core/testing';

import { LsrActivitySearchService } from './lsr-activity-search.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ApiService } from '../../../shared/services/api.service';
import { HttpClient } from '@angular/common/http';
import { request } from 'http';
import { LsrActivityAgentAssignDialogService } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.service';
import { LsrActivityAgentAssignDialogModule } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.module';

describe('LsrActivitySearchService', () => {
  let activitySearch: LsrActivitySearchService;
  let activityAgentAssignDialogService: LsrActivityAgentAssignDialogService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let apiService: ApiService;
  let httpClient: HttpClient;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, LsrActivityAgentAssignDialogModule],
      providers: [LsrActivitySearchService, ApiService]
    });
    injector = getTestBed();
    httpClient = TestBed.get(HttpClient);
    activitySearch = injector.get(LsrActivitySearchService);
    activityAgentAssignDialogService = injector.get(LsrActivityAgentAssignDialogService);
    httpMock = injector.get(HttpTestingController);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', inject(
    [LsrActivitySearchService],
    (service: LsrActivitySearchService) => {
      expect(service).toBeTruthy();
    }
  ));

  it('should post search results using the base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsrActivity/search?pageSize=1&page=0';
    activitySearch.searchLsrActivities('1', '1', '1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne('url');
    httpMock.verify();
    expect(req.request.method).toBe('POST');
  });
  it('should get LSR details using the base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsrActivity/LSRDetails?extOrderId=1';
    activitySearch.getLSRDetails('1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne('url');
    httpMock.verify();
    expect(req.request.method).toBe('POST');
  });
  it('should get the deprovision tns using the base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsractivity/deprovisionTn?extOrderId=1';
    activitySearch.getDeProvisionTn('1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne('url', 'get deprovision tns');
    httpMock.verify();
    expect(req.request.method).toBe('GET');
  });
  it('should assign agent using the base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsractivity/assignOrderAgent'
    const body = {
      agent: 'pai.rajavardhan',
      userId: 'nikethani.bhavya',
      carrierRequestId: 782361,
      correlationId: 'sldb-47157',
      systemId: 'workflow'
    }
    activityAgentAssignDialogService.assignAgent(body).subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('POST');
  });
  it('should forceComplete activities using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/forcecomplete';
    const dateTimeStr = 'SLDB-UpdateAction-' + Date().toString();
    activitySearch.updateActivities(['1'], 'forceCompleteActivity', dateTimeStr, 'completeReasonAction').subscribe(
      data => expect(data),
      fail
    );
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('POST');
  });
  it('should restart activities using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/restart';
    const dateTimeStr = 'SLDB-UpdateAction-' + Date().toString();
    activitySearch.updateActivities(['1'], 'restartActivity', dateTimeStr).subscribe(
      data => expect(data),
      fail
    );
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('POST');
  });
});
