import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { ApiService } from '../../../shared/services/api.service';
import { Observable } from 'rxjs';
import { UtilityService } from '../../../shared/services/utility.service';
import { AssignAgentRequest } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.constants';

@Injectable()
export class LsrActivitySearchService {

  constructor(private apiService: ApiService, private http: HttpClient, private utilityService: UtilityService) {
  }

  searchLsrActivities(data, pageSize, page): Observable<any> {
    page = page - 1;
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsractivity/search';
    let params = new HttpParams();
    params = params.append('pageSize', pageSize);
    params = params.append('page', page);
    const body = JSON.stringify(data);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');

    return this.http.post(url, body, {
      params: params,
      headers: headers
    }).pipe(catchError(error => this.apiService.handleException(error)));
  }

  getExportDetail(data) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/LSRSearchExport/export';
    const body = JSON.stringify(data);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    // return this.http.post(url, body, {headers: headers});
    return this.http.post(url, body, { responseType: 'blob', headers: headers }).pipe(
      map((response) => {
        return { fileName: 'lsr-details.csv', data: response };
      }),
      catchError(error => this.apiService.handleException(error))
    );
  }

  getDeProvisionTn(extOrderId) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsractivity/deProvisionTn';
    let params = new HttpParams();
    params = params.append('extOrderId', extOrderId);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');

    return this.http.get(url, { params: params, headers: headers }).pipe(
      catchError(error => this.apiService.handleException(error))
    );
  }

  getLSRDetails(extOrderId) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/lsractivity/LSRDetails';
    let params = new HttpParams();
    params = params.append('extOrderId', extOrderId);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.get(url, { params: params, headers: headers }).pipe(
      catchError(error => this.apiService.handleException(error))
    );
  }


  updateActivities(data: any[], operation: string, correlationId: string, completedActionReason?: string): Observable<any> {
    const userName = this.utilityService.getUserId()
    const requestPayload = {
      'correlationId': correlationId,
      'systemId': 'User',
      'userId': userName,
      'orderActivityPkArray': data,
    };
    let endPoint = '/ServiceDelivery/v1/Voice/tnActivitySearch/restart';
    if (operation === 'forceCompleteActivity') {
      endPoint = '/ServiceDelivery/v1/Voice/tnActivitySearch/forcecomplete';
      requestPayload['userComment'] = completedActionReason;
    }

    const url = this.apiService.orderApiUrl + endPoint;
    const body = JSON.stringify(requestPayload);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.post(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }

  updateLsr(requestPayload) {
    let endPoint = '/ServiceDelivery/v1/Voice/lsrorder/updateLsrRequest';
    const url = this.apiService.orderApiUrl + endPoint;
    const body = JSON.stringify(requestPayload);
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    return this.http.post(url, body, { headers: headers }).pipe(catchError(error => this.apiService.handleException(error)));
  }
  
}
