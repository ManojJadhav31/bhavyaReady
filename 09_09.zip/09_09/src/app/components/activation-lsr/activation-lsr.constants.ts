export interface ActivationLsrResult {
  lsrActivitySearchDTOs: LsrActivitySearchDTOs[];
  totalElementsCount: number;
}

export interface LsrActivitySearchDTOs {
  activity: string;
  activityName: string;
  assignedAgent: string;
  billingAccountNumber: number;
  bizOrg: string;
  businessName: string;
  carrierAdditionalNotes: string;
  carrierId: number;
  carrierIds: string[];
  exterOrderIds: string[];
  carrierSpid: number;
  city: string;
  companyName: string;
  completionDate: string;
  contactName: string;
  customerRequestDate: string;
  errorMessage: string;
  extOrderId: string;
  firstName: string;
  focDate: string;
  isDisplayable: string;
  lastName: string;
  loaFilename: string;
  lsrStatus: string;
  lsrStatusList: string[];
  middleInitial: string;
  orderActive: string;
  orderActivityIdPK: number;
  orderCompleteDate: string;
  orderCompleteDateFrom: string;
  orderCompleteDateTo: string;
  orderDate: string;
  orderDateFrom: string;
  orderDateTo: string;
  orderStatus: string;
  orderType: string;
  parentOrderId: number;
  parentOrderIds: string[];
  ponStatus: string;
  ponStatusList: string[];
  productId: number;
  purchaseOrderNumber: number;
  resellerName: string;
  slOrderId: number;
  state: string;
  status: string;
  streetDirectionalPrefix: string;
  streetName: string;
  streetNumber: number;
  streetNumberSuffix: string;
  streetType: string;
  switchNumber: number;
  trunkNumber: number;
  typeOfPort: string;
  ver: number;
  wtn: number;
  zipCode: number;

  /*local usages*/
  checked?: string[];
}




// interface DeProvisionTnDTO {
//   extOrderId: string;
//   activityName: string;
//   activityId: number;
//   tnStatus: number;
//   orderActivityPk: number;
// }

export interface TnDetailVo {
  activityState: string;
  tnDetails: string[];
}


export interface LSRDetailsPageResponse {
  activity: string;
  billingAccountNumber: string;
  bizOrgId: string;
  businessName: string;
  carrierRequestId: string;
  city: string;
  comments: string;
  contactName: string;
  firstName: string;
  focDate: string;
  lastName: string;
  legacyName: string;
  middleName: string;
  orderActiveYN: string;
  orderDate: string;
  parentTransId: string;
  purchaseOrder: string;
  purchaseOrderVersion: string;
  resellerName: string;
  state: string;
  status: string;
  streetName: string;
  streetNum: string;
  streetNumSuffix: string;
  tnDetailVO: TnDetailVO;
  type: string;
  zip: string;
  message: string;
}

interface TnDetailVO {
  activityState: string;
  tnDetails: string[];
}

export class UpdateLsrRequest {
  // approveLsrFlag: boolean;
  billingAccountNumber: string;
  comments: string;
  correlationId: string;
  focDate: Date;
  orderActivityPk: number;
  // parentTransId: number;
  reasonCode: string;
  reasonDesc: string;
  rejectLsrFlag: boolean;
  resellerName: string;
  otherResellerName: string; // other value for local use
  switchNumber: string;
  systemId: string;
  trunkNumber: string;
  userId: string;
}