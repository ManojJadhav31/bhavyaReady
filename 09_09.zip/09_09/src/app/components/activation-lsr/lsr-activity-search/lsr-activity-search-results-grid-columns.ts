export const ColumnType: any = {
  string: 'string',
  number: 'number',
  date: 'date'
};

export const LsrActivitySearchResultsGridColumns: any = [
  {
    caption: 'Carrier ID',
    value: 'extOrderId',
    visible: 'false',
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Activity ID',
    value: 'orderActivityIdPK',
    visible: false,
    type: ColumnType.number,
    class: { 'r12': true }
  },
  {
    caption: 'Activity Name',
    value: 'activityName',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Activity Status',
    value: 'status',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'PON Status',
    value: 'ponStatus',
    visible: 'false',
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'LSR Status',
    value: 'lsrStatus',
    visible: 'false',
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Activity Complete Date',
    value: 'orderCompletionDateFormatted',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r19': true }
  },
  {
    caption: 'FOC Date',
    value: 'focDateFormatted',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r10': true }
  },
  {
    caption: 'Order Date',
    value: 'orderDateFormatted',
    visible: 'false',
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r10': true }
  },
  {
    caption: 'CRD',
    value: 'customerRequestedDateFormatted',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r10': true }
  },
  {
    caption: 'Activity Create Date',
    value: 'activityCreatedDateFormatted',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r19': true }
  },
  {
    caption: 'Carrier PON',
    value: 'purchaseOrderNumber',
    visible: false,
    type: ColumnType.number,
    class: { 'r10': true }
  },
  {
    caption: 'TN',
    value: 'wtn',
    visible: false,
    type: ColumnType.number,
    class: { 'r10': true }
  },
  {
    caption: 'VER',
    value: 'ver',
    visible: false,
    type: ColumnType.number,
    class: { 'r7': true }
  },
  {
    caption: 'Legacy Company Name',
    value: 'companyName',
    visible: false,
    type: ColumnType.string,
    class: { 'r21': true }
  },
  {
    caption: 'Order Status',
    value: 'orderStatus',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Order Type',
    value: 'orderType',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  }, {
    caption: 'Activity',
    value: 'activity',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Carrier Additional Notes',
    value: 'carrierAdditionalNotes',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Biz Org',
    value: 'bizOrg',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'BAN',
    value: 'billingAccountNumber',
    visible: false,
    type: ColumnType.number,
    class: { 'r10': true }
  },
  {
    caption: 'Reseller',
    value: 'resellerName',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Type of Port',
    value: 'TypeOfPort',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Business Name',
    value: 'businessName',
    visible: false,
    type: ColumnType.string,
    class: { 'r16': true }
  },
  {
    caption: 'Parent Order Id',
    value: 'parentOrderId',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'Product',
    value: 'productId',
    visible: false,
    type: ColumnType.number,
    class: { 'r11': true }
  },
  {
    caption: 'City',
    value: 'city',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'State',
    value: 'state',
    visible: false,
    type: ColumnType.string,
    class: { 'r7': true }
  },
  {
    caption: 'Sl Order Id',
    value: 'slOrderId',
    visible: false,
    type: ColumnType.number,
    class: { 'r11': true }
  },
  {
    caption: 'Carrier Spid',
    value: 'carrierSpid',
    visible: false,
    type: ColumnType.string,
    class: { 'r9': true }
  },
  {
    caption: 'Assigned Agent',
    value: 'assignedAgent',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Trunk Number',
    value: 'trunkNumber',
    visible: false,
    type: ColumnType.number,
    class: { 'r11': true }
  },
  {
    caption: 'Switch Number',
    value: 'switchNumber',
    visible: false,
    type: ColumnType.number,
    class: { 'r12': true }
  },
  {
    caption: 'Contact Name',
    value: 'contactName',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'First Name',
    value: 'firstName',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Middle Initial',
    value: 'middleInitial',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Last Name',
    value: 'lastName',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Street Number',
    value: 'streetNumber',
    visible: false,
    type: ColumnType.number,
    class: { 'r13': true }
  },
  {
    caption: 'Street Directional Prefix',
    value: 'streetDirectionalPrefix',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Street Num Suffix',
    value: 'streetNumbersuffix',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Street Name',
    value: 'streetName',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Street Type',
    value: 'streetType',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Zip Code',
    value: 'zipCode',
    visible: false,
    type: ColumnType.number,
    class: { 'r8': true }
  },
  {
    caption: 'Order  Active',
    value: 'orderActive',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Carrier Eid',
    value: 'carrierId',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  }
];
