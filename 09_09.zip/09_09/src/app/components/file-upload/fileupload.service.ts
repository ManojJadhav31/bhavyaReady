import { Injectable } from '@angular/core';
import { ApiService } from '../../shared/services/api.service';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';

@Injectable()
export class FileUploadService {
  constructor(private apiService: ApiService, private http: HttpClient) {
  }

  upload(files) {
    const url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/upload';
    const req = new HttpRequest('POST', url, files);
    return this.http.request(req).pipe(
      map(data => {
        return data;
      }),
      catchError(error => this.apiService.handleError(error))
    );
  }

  uploadNew(formData) {
    const url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/upload';
    return this.http.post(url, formData).pipe(
      map(data => {
        return data;
      }),
      catchError(error => this.apiService.handleError(error))
    );
  }
}
