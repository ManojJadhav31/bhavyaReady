import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FileUploadComponent } from './file-upload.component';
import { FileUploadService } from './fileupload.service';
import { ApiService } from '../../shared/services/api.service';
import { OrderdetailPortoutComponent } from '../portout/search-portout/orderdetail-portout/orderdetail-portout.component';
import { RouterTestingModule } from '@angular/router/testing';
import { OrderDetailService } from '../portout/services/orderdetail-portout.service';
import { UtilityService } from '../../shared/services/utility.service';
import { OrderDetailServiceStub } from '../../../tests/mockdata/portout/orderdetail/orderdetail';
import { SharedModule } from '../../shared/shared.module';
import { StorageService } from '../../services/storage.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { of } from 'rxjs';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';


describe('FileUploadComponent', () => {
  let component: FileUploadComponent;
  let fixture: ComponentFixture<FileUploadComponent>;
  let fileService, files;

  beforeEach(async(() => {
    let fileServiceStub;
    fileServiceStub = {
      upload: () => true

    };
    TestBed.configureTestingModule({
      declarations: [ FileUploadComponent, OrderdetailPortoutComponent ],
      imports: [
        BrowserAnimationsModule,
        SharedModule,
        RouterTestingModule,
        UpdateReasonDialogModule
      ],
      providers: [ UtilityService,
        ApiService,
        StorageService,
        { provide: FileUploadService, useValue: fileServiceStub },
        { provide: OrderDetailService, useClass: OrderDetailServiceStub },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    fileService = fixture.debugElement.injector.get(FileUploadService);

    files = [ {
      name: 'template1.xls',
      size: 1024000
    } ];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check for a valid file extension', () => {
    component.error = '';
    component.isValidFileExtension(files);
    expect(component.error).toBe('');
  });

  it('should check for a valid file size', () => {
    component.error = '';
    component.isValidFileSize(files);
    expect(component.error).toBe('');
  });

  it('should be able to select files', () => {
    const event = {
      target: {
        files: [ {
          name: 'teamplate1.xls'
        }, {
          name: 'teamplate2.xls'
        }, {
          name: 'teamplate3.xls'
        } ]
      }
    };
    component.onFileChange(event);
    expect(component.files.length).toBeGreaterThan(0);
  });
  it('should be able to clear form', () => {
    component.files = files;
    component.clearForm();
    expect(component.files).toBe(null);
  });

  it('should be able to clear errors', () => {
    component.updateSuccessMsg = 'success';
    component.error = 'error';
    component.serviceErrors = [ 'error1', 'error2', 'error3' ];
    component.clearErrors();
    expect(component.updateSuccessMsg).toBe('');
    expect(component.error).toBe('');
    expect(component.serviceErrors.length).toBe(0);
  });

  describe('Create Order', () => {
    it('should not save an invalid file', () => {
      const response = of({
        body: {
          CarrierRequestId: 1
        }
      });
      component.isCreate = true;
      component.files = files;
      spyOn(component, 'isValidFiles').and.returnValue(false);
      spyOn(fileService, 'uploadNew').and.returnValue(response);
      component.createUpdateOrder({});
      expect(fileService.uploadNew).not.toHaveBeenCalled();
    });
    it('should upload a file', () => {
      const data = {
        body: {
          CarrierRequestId: 1
        }
      };
      component.files = [];
      spyOn(component, 'isValidFiles').and.returnValue(true);
      spyOn(fileService, 'uploadNew').and.returnValue(of(data));
      component.createUpdateOrder({});
      expect(fileService.uploadNew).toHaveBeenCalled();
    });
  });

  it('should be able to toggle oldCarrierName field', () => {
    const event = {
      currentTarget: {
        checked: true
      }
    };
    component.ocnChecked(event);
    expect(component.fileUploadForm.controls.oldCarrierName.enabled).toBe(true);

    event.currentTarget.checked = false;
    component.ocnChecked(event);
    expect(component.fileUploadForm.controls.oldCarrierName.enabled).toBe(false);
  });

  it('should be able to get order details', () => {
    component.isCreate = false;
    component.setFormInitialState();
    component.getOrderDetails();
    fixture.detectChanges();
    expect(component.fileUploadForm.controls.ver.value).toBe('2');
  });

});
