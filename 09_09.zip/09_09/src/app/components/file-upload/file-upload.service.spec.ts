import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FileUploadService } from './fileupload.service';
import { TestBed } from '@angular/core/testing';
import { ApiService } from '../../shared/services/api.service';
import { FormBuilder } from '@angular/forms';


describe('FileUploadService', () => {

  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let fileUploadService: FileUploadService;
  let apiService: ApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ FileUploadService, ApiService, FormBuilder ]
    });

    httpClient = TestBed.get(HttpClient);
    httpTestingController = TestBed.get(HttpTestingController);
    fileUploadService = TestBed.get(FileUploadService);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  describe('#upload', () => {
    const expectedResult: any = { type: 0 };
    it('should upload files', () => {
      const files: any[] = [ { data: '1' } ];
      const uploadUrl = apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/upload';
      fileUploadService.upload(files).subscribe(
        data => expect(data).toEqual(expectedResult, 'should return data'),
        fail
      );

      const req = httpTestingController.expectOne(uploadUrl);
      expect(req.request.method).toEqual('POST');
    });
  });
});
