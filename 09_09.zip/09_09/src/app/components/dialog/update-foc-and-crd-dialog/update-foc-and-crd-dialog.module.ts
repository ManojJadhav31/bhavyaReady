import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpdateFocAndCrdDialogComponent } from './update-foc-and-crd-dialog/update-foc-and-crd-dialog.component';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
  declarations: [UpdateFocAndCrdDialogComponent],
  exports: [UpdateFocAndCrdDialogComponent],
  imports: [SharedModule]
})
export class UpdateFocAndCrdDialogModule { }
