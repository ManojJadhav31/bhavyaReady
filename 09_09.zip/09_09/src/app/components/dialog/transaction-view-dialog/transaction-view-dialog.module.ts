import { NgModule } from '@angular/core';
import { TransactionViewDialogComponent } from './transaction-view-dialog/transaction-view-dialog.component';
import { TransactionDialogService } from './transaction-dialog.service';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
  declarations: [ TransactionViewDialogComponent ],
  exports: [ TransactionViewDialogComponent ],
  imports: [ SharedModule ],
  providers: [ TransactionDialogService ]
})
export class TransactionViewDialogModule {
}
