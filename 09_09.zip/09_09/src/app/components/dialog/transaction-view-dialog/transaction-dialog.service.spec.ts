import { getTestBed, TestBed } from '@angular/core/testing';
import { TransactionDialogService } from './transaction-dialog.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../../shared/services/api.service';
import { TnActivitySearchService } from '../../activation-service/services/tn-activity-search.service';

describe('TransactionDialogService', () => {
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let apiService: ApiService;
  let httpClient: HttpClient;
  let transactionDialogService: TransactionDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ TransactionDialogService, ApiService ]
    });
    injector = getTestBed();
    httpClient = TestBed.get(HttpClient);
    transactionDialogService = injector.get(TransactionDialogService);
    httpMock = injector.get(HttpTestingController);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    const service: TransactionDialogService = TestBed.get(TransactionDialogService);
    expect(service).toBeTruthy();
  });

  it('should call getErrorMessage for transaction', () => {
    const dataParam = [ '123546', '546587' ];
    const ids = transactionDialogService.generateQueryParam(dataParam);
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/Transaction/status?' + ids;
    transactionDialogService.getErrorMessage(dataParam).subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });
});
