import { Injectable } from '@angular/core';
import { UtilityService } from '../../../shared/services/utility.service';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../../shared/services/api.service';
import { AssignAgentRequest } from './lsr-activity-agent-assign-dialog.constants';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LsrActivityAgentAssignDialogService {

  constructor(private apiService: ApiService, private http: HttpClient, private utilityService: UtilityService) { }


  assignAgent(request: AssignAgentRequest) {
    const url = this.apiService.orderApiUrl + `/ServiceDelivery/v1/Voice/lsractivity/assignOrderAgent`;
    return this.http.post(url, request).pipe(
      catchError(error => this.apiService.handleException(error))
    );
  }
}
