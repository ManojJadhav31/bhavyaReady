
export class AssignAgentRequest {
    agent: string = '';
    carrierRequestId: number;
    correlationId: string;
    systemId: string;
    userId: string;
  }