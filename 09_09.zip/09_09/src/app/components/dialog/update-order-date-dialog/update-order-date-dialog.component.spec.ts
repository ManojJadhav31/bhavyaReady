import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateOrderDateDialogComponent } from './update-order-date-dialog.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from '../../../shared/shared.module';

describe('UpdateOrderDateDialogComponent', () => {
  let component: UpdateOrderDateDialogComponent;
  let fixture: ComponentFixture<UpdateOrderDateDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ BrowserAnimationsModule, SharedModule ],
      declarations: [ UpdateOrderDateDialogComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateOrderDateDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
