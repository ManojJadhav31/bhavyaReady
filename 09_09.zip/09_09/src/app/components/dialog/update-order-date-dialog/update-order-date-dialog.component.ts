import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { UtilityService } from '../../../shared/services/utility.service';

@Component({
  selector: 'app-update-order-date-dialog',
  templateUrl: './update-order-date-dialog.component.html',
  styleUrls: ['./update-order-date-dialog.component.scss']
})

export class UpdateOrderDateDialogComponent implements OnInit {

  public displayDialog: boolean = false;

  dateTypeOptions: any[] = [
    { name: 'Customer Acceptance Date', code: 'CustomerAcceptanceDate' },
    { name: 'Customer Request Date', code: 'CustomerRequestDate' },
    { name: 'FOC Date', code: 'FocDate' },
    { name: 'Revised Commit Date', code: 'RevisedCommitDate' }

  ];
  updateRequest: any = {
    dateType: {
      code: 'updateOrderDate'
    },
    // dateType: '',
    date: '',
    comments: ''
  };

  @Output('onSubmit') onSubmit: EventEmitter<any> = new EventEmitter();

  constructor(private utilityService: UtilityService) {
  }

  ngOnInit() {
  }

  onReset() {
    this.updateRequest = {
      dateType: {
        code: 'updateOrderDate'
      },
      // dateType: '',
      date: '',
      comments: ''
    };
  }

  onSave() {
    const response = {
      dateType: this.updateRequest.dateType.code,
      newDate: this.utilityService.getFormatedDate(this.updateRequest.date),
      orderComments: this.updateRequest.comments
    };
    this.onSubmit.emit(response);
  }
}
