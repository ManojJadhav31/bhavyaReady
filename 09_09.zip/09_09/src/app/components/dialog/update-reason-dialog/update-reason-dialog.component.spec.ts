import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateReasonDialogComponent } from './update-reason-dialog.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from '../../../shared/shared.module';


describe('UpdateReasonDialogComponent', () => {
  let component: UpdateReasonDialogComponent;
  let fixture: ComponentFixture<UpdateReasonDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ BrowserAnimationsModule, SharedModule ],
      declarations: [ UpdateReasonDialogComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateReasonDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
