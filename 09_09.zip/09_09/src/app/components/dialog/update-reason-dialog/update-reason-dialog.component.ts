import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UtilityService } from '../../../shared/services/utility.service';

@Component({
  selector: 'app-update-reason-dialog',
  templateUrl: './update-reason-dialog.component.html',
  styleUrls: ['./update-reason-dialog.component.scss']
})
export class UpdateReasonDialogComponent implements OnInit {

  public displaDialog: boolean = false;
  public userId: string;
  updateActionReason = { name: 'Choose', code: '' };
  actionReason = '';
  reasonCommentOptions: any = [
    { name: 'Choose', code: '' },
    { name: 'Completing Manual Task', code: 'Completing Manual Task' },
    { name: 'Completing Re-opened Task', code: 'Completing Re-opened Task' },
    {
      name: 'Completing task-Completed task didnt not create next task',
      code: 'Completing task-Completed task didnt not create next task'
    },
    { name: 'Completing task - Duplicate Task Created', code: 'Completing task - Duplicate Task Created' },
    { name: 'Completing task - Task did not auto-complete', code: 'Completing task - Task did not auto-complete' },
    { name: 'Completing task to move order forward', code: 'Completing task to move order forward' },
    { name: 'Other', code: 'Other' },
    { name: 'Provising complete', code: 'Provising complete' },
  ];


  @Input('onlyReason') onlyReason: boolean = false;
  @Output('onSubmit') onSubmit: EventEmitter<any> = new EventEmitter();

  constructor(private utilityService: UtilityService) {
  }

  ngOnInit() {
  }

  setUserId() {
    this.userId = this.utilityService.getUserId()
  }

  reset() {
    this.updateActionReason = { name: 'Choose', code: '' };
    this.actionReason = '';
  }

  onClickSave() {
    const response = {
      action: this.updateActionReason.code,
      errorMessage: this.actionReason
    };
    console.log(this.updateActionReason, this.actionReason);
    this.onSubmit.emit(response);
  }
}
