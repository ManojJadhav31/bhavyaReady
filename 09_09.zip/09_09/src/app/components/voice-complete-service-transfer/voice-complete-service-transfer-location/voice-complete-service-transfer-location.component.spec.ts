import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoiceCompleteServiceTransferLocationComponent } from './voice-complete-service-transfer-location.component';
import { SharedModule } from '../../../shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { ApiService } from '../../../shared/services/api.service';
import { StorageService } from '../../../services/storage.service';
import { UtilityService } from '../../../shared/services/utility.service';
import { VoiceCompleteServiceTransferViewComponent } from '../voice-complete-service-transfer-view/voice-complete-service-transfer-view.component';

describe('VoiceCompleteServiceTransferLocationComponent', () => {
  let component: VoiceCompleteServiceTransferLocationComponent;
  let fixture: ComponentFixture<VoiceCompleteServiceTransferLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [  VoiceCompleteServiceTransferViewComponent, VoiceCompleteServiceTransferLocationComponent  ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        SearchPanelsModule,
      ],
      providers: [
        ApiService,
        StorageService,
        UtilityService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoiceCompleteServiceTransferLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
