export function arraysEqual(arr1, arr2) {
  if (arr1.length !== arr2.length) {
    return false;
  }
  for (let i = arr1.length; i--;) {
    if (arr1[i] !== arr2[i]) {
      return false;
    }
  }
  return true;
}

export class ToFromDetails {
  customer: string;
  serviceId: string;
  locationService: string;
}

export class StepsInfo {
  customerDetails: boolean;
  completeServiceID: boolean;
  customerInfo: boolean;
  locationService: boolean;
}

export class LocationServiceTableData {
  fromLocation: string[];
  toLocation: string[];
}

export interface VoiceCompleteServiceTransferResult {
  tns: string;
  fromLocation: string;
  id: number;
}
export interface VoiceCompleteServiceTransferResultInnerGrid {
  tns: string;
  toLocation: string;
  checked?: string[];
}

export const CustomList = [
  { value: '10171', label: '10171 - WebMD' },
  { value: '10189', label: '10189 - Wells Fargo' },
  { value: '10505', label: '10505 - FactSet Research Systems Inc.' },
  { value: '10569', label: '10569 - Schnader Harrison Segal and Lewis LLP' },
  { value: '10681', label: '10681 - Freeborn &amp; Peters' },
  { value: '10810', label: '10810 - Mirus Information Services Inc.' },
  { value: '10929', label: '10929 - Compuware Corporation' },
  { value: '1-1106W3', label: '1-1106W3 - Greenball Corp.' },
  { value: '1-11JL1Y', label: '1-11JL1Y - Western Asset Management Company' },
  { value: '1-11MEQA', label: '1-11MEQA - Government Printing Office-GPO - End Cust' },
  { value: '1-11TM2A', label: '1-11TM2A - Goldentree Asset Management LP' },
  { value: '1-12OXMP', label: '1-12OXMP - University of Pittsburgh' },
  { value: '1-12Y8UH', label: '1-12Y8UH - Kennametal Inc.' },
  { value: '1-137Y4I', label: '1-137Y4I - Archdiocese of Phil' },
  { value: '1-137Y95', label: '1-137Y95 - Archdiocese of Philadelphia - CHS' },
  { value: '1-138ZU"', label: '-138ZU - American Fibertek - TC' },
  { value: '1-13P81F', label: '1-13P81F - AIG Technologies, Inc' },
  { value: '1-14AH0L', label: '1-14AH0L - Federal Farm Credit Banks Funding Corporation' },
  { value: '1-14GRQL', label: '1-14GRQL - Sirius XM Connected Vehicle Services Inc.' },
  { value: '1-14VISP', label: '1-14VISP - ORIX USA Corporation' },
  { value: '1-15ML45', label: '1-15ML45 - Isocentric Networks Inc - Vyvx' },
  { value: '1-15RNUG', label: '1-15RNUG - Porsche Cars North America' },
  { value: '1-16F99', label: '1-16F99 - DLA Piper LLP (US)' },
  { value: '1-16MKHH', label: '1-16MKHH - Verifone, Inc.' },
  { value: '1-16MM6', label: '1-16MM6 - HARRIS Corporation - GCSD' },
  { value: '1-16OHJ7', label: '1-16OHJ7 - Agco Corporation, Inc' },
  { value: '1-16Z0V', label: '1-16Z0V - Trend Micro Incorporated' },
  { value: '1-17751Q', label: '1-17751Q - Eventbrite, Inc.' },
  { value: '11913', label: '11913 - J.P. Morgan Chase Bank N.A.' },
  { value: '11978', label: '11978 - Kissimmee Utility Authority' },
  { value: '1-1984XZ', label: '1-1984XZ - HALO Pharmaceutical Inc.' },
  { value: '1-198RH', label: '1-198RH - QVC, Inc.' },
  { value: '1-19QWZF', label: '1-19QWZF - IBS Software Services Americas Inc.' },
  { value: '1-19Y4YC', label: '1-19Y4YC - TierPoint, LLC' },
  { value: '1-1B1DXH', label: '1-1B1DXH - Ryan, Inc.' },
  { value: '1-1BCEDF', label: '1-1BCEDF - Vantage Oncology, Inc.' },
  { value: '1-1BSAT', label: '1-1BSAT - ECPI University' },
  { value: '1-1C175', label: '1-1C175 - Logistics Plus, Inc' },
  { value: '1-1CHO6P', label: '1-1CHO6P - Palm Beach County' },
  { value: '1-1CSTU', label: '1-1CSTU - AMERICAN MEDICAL ASSOCIATION' },
  { value: '1-1DDGMA', label: '1-1DDGMA - Express, LLC' },
  { value: '1-1DHGHM', label: '1-1DHGHM - U.S. News &amp; World Report L.P.' },
  { value: '1-1EBH03', label: '1-1EBH03 - Mecklenburg County' },
  { value: '1-1GC66Z', label: '1-1GC66Z - Helix Energy Solutions Group' },
  { value: '1-1GW2OT', label: '1-1GW2OT - JDA Software Group, Inc.' },
  { value: '1-1I69M5', label: '1-1I69M5 - Global Vector LLC' },
  { value: '1-1K876T', label: '1-1K876T - AppRiver LLC' },
  { value: '1-1KOUOE', label: '1-1KOUOE - Fairmont Hotels &amp; Resorts Inc.' },
  { value: '1-1LG03M', label: '1-1LG03M - DRW  Holdings LLC' },
  { value: '1-1LHL01', label: '1-1LHL01 - Marketing &amp; Research Resources, Inc.' },
  { value: '1-1MTUGX', label: '1-1MTUGX - Heartland Payment Systems' },
  { value: '1-1OGNGL', label: '1-1OGNGL - Parallels Inc.' },
  { value: '1-1PQSV', label: '1-1PQSV - Options IT LLC' },
  { value: '1-1PSG7', label: '1-1PSG7 - Venus Fashion, Inc.' },
  { value: '1-1Q02X', label: '1-1Q02X - University of Florida' },
  { value: '1-1Q6JX', label: '1-1Q6JX - Zazzle Inc.' },
  { value: '1-1QDLY', label: '1-1QDLY - Jefferies LLC' },
  { value: '1-1QHFC', label: '1-1QHFC - CRT Medical Systems, Inc.' },
  { value: '1-1QHFU', label: '1-1QHFU - Barton Malow' },
  { value: '1-1RY3Y', label: '1-1RY3Y - Fairwinds Credit Union' },
  { value: '1-1RY7Y', label: '1-1RY7Y - Buckeye Partners, L.P.' },
  { value: '1-1SD18P', label: '1-1SD18P - Marvell Semiconductor, Inc.' },
  { value: '1-1SX7V', label: '1-1SX7V - Blue Cross Blue Shield Association EPA1' },
  { value: '1-1SXAR', label: '1-1SXAR - United States Steel Corporation' },
  { value: '1-1TC8X', label: '1-1TC8X - Wichita Airport Authority' },
  { value: '1-1U7BN', label: '1-1U7BN - Datanational Corporation' },
  { value: '1-1VM90', label: '1-1VM90 - Koch Business Solutions LP' },
  { value: '1-1WFKK', label: '1-1WFKK - General Cable Corporation' },
  { value: '1-1WPXW', label: '1-1WPXW - Educational Loan Servicing, Llc' },
  { value: '1-1XBO1', label: '1-1XBO1 - Royall &amp; Company Direct Response Marketing' },
  { value: '1-1XLXRX', label: '1-1XLXRX - Delta Apparel, Incorporated' },
  { value: '1-1XTIV', label: '1-1XTIV - Carpenter Technology Corporation' },
  { value: '1-1XUO03', label: '1-1XUO03 - LCH Clearnet, U.S. LLC' },
  { value: '1-1Y7NQG', label: '1-1Y7NQG - Teach For America, Inc.' },
  { value: '1-1YBQJ', label: '1-1YBQJ - EnPro Industries, Inc.' },
  { value: '1-1YQOXV', label: '1-1YQOXV - Riverbed Technology, Inc' },
  { value: '1-1YTTH', label: '1-1YTTH - Alfred Conhagen Inc of Louisiana' },
  { value: '1-1YZ00L', label: '1-1YZ00L - Accretive Health' },
  { value: '1-1ZY0JG', label: '1-1ZY0JG - Callcentric Wholesale Inc.' },
  { value: '1-20PUE', label: '1-20PUE - AmeriHealth Caritas' },
  { value: '1-20PW3', label: '1-20PW3 - Reed Smith LLP' },
  { value: '1-20VJK', label: '1-20VJK - Universal Property And Casualty Insurance' },
  { value: '1-20VU1', label: '1-20VU1 - Liberty Power Corp , Llc' },
  { value: '1-20XZB', label: '1-20XZB - Computer Point' },
  { value: '1-21IV6', label: '1-21IV6 - Northwest Savings Bank' },
  { value: '12215', label: '12215 - Cognizant Technology Solutions' },
  { value: '1-221GO', label: '1-221GO - DELOITTE SERVICES LP' },
  { value: '1-221JB', label: '1-221JB - UNIVERSITY OF TEXAS/TELECOM SV' },
  { value: '1-225QV', label: '1-225QV - Office Depot Inc.' },
  { value: '1-22ZCB', label: '1-22ZCB - Hanover Direct Inc' },
  { value: '1-235-1538', label: '1-235-1538 - IMS Health Inc.' },
  { value: '1-235-1611', label: '1-235-1611 - APHA - American Public Health Association' },
  { value: '1-235-1744', label: '1-235-1744 - Control Risks Group LLC' },
  { value: '1-235-1836', label: '1-235-1836 - AIR - AMERICAN INSTI' },
  { value: '1-235-1892', label: '1-235-1892 - IMAGE FIRST' },
  { value: '1-235-2533', label: '1-235-2533 - Asset Control Systems, Inc.' },
  { value: '1-235-2563', label: '1-235-2563 - Talkpoint Holdings, LLC' },
  { value: '1-235-2595', label: '1-235-2595 - United States Fire Insurance Company.' },
  { value: '1-235-2601', label: '1-235-2601 - Bryan Cave Leighton Paisner LLP' },
  { value: '1-235-2605', label: '1-235-2605 - Goldman, Sachs &amp; Co.' },
  { value: '1-235-2612', label: '1-235-2612 - Defy Media LLC' },
  { value: '1-235-2618', label: '1-235-2618 - CRAVATH, SWAINE &amp; MOORE' },
  { value: '1-235-2810', label: '1-235-2810 - Schiff Hardin LLP' },
  { value: '1-235-2828', label: '1-235-2828 - GlobeOp Financial Services LLC' },
  { value: '1-235-2894', label: '1-235-2894 - INTERNATIONAL CULINARY CENTER LLC' },
  { value: '1-235-2897', label: '1-235-2897 - Diplomatic, A New York Company' },
  { value: '1-235-2928', label: '1-235-2928 - Emmis Communications' },
  { value: '1-235-2937', label: '1-235-2937 - Take-Two Interactive Software Inc.' },
  { value: '1-235-3104', label: '1-235-3104 - GENWORTH FINANCIAL' },
  { value: '1-235-3499', label: '1-235-3499 - ANALYTICAL GRAPHICS' },
  { value: '1-235-3505', label: '1-235-3505 - Severn Trent Services, Inc' },
  { value: '1-235-3598', label: '1-235-3598 - GES GROUNDWATER &amp; ENVIRONMENTAL SVS' },
  { value: '1-235-374', label: '1-235-374 - VSE CORPORATION' },
  { value: '1-235-3836', label: '1-235-3836 - GENEX SE' },
  { value: '1-235-3890', label: '1-235-3890 - AIRLINE HYDRAULICS' },
  { value: '1-235-3902', label: '1-235-3902 - Stradley Ronon Stevens &amp; Young, LLP' },
  { value: '1-235-3936', label: '1-235-3936 - DECHERT LLP' },
  { value: '1-235-4', label: '1-235-4 - SHARED TECHNOLOGY SERVICES GROUP INC.' },
  { value: '1-235-4069', label: '1-235-4069 - DOYLESTOWN HOSPITAL' },
  { value: '1-235-4178', label: '1-235-4178 - DENTSPLY INTERNATION' },
  { value: '1-235-4387', label: '1-235-4387 - KNOLL INC' },
  { value: '1-235-91', label: '1-235-91 - Fair Isaac Corporation' },
  { value: '1-238-1117', label: '1-238-1117 - HomeNurse, Inc.' },
  { value: '1-238-1130', label: '1-238-1130 - Baptist Health - Jacksonville' },
  { value: '1-238-2585', label: '1-238-2585 - Minolta Business Solutions' },
  { value: '1-238-2657', label: '1-238-2657 - Holland &amp; Knight LLP' },
  { value: '1-238-2696', label: '1-238-2696 - SHRINERS HOSPITALS FOR CHILDERN' },
  { value: '1-238-2881', label: '1-238-2881 - Comprehensive Health Management Inc' },
  { value: '1-238-3777', label: '1-238-3777 - McKesson Corp' },
  { value: '1-238-4039', label: '1-238-4039 - DUKE ENERGY SERVICES' },
  { value: '1-238-4307', label: '1-238-4307 - Mary Kay Inc.' },
  { value: '1-238-488', label: '1-238-488 - LexisNexis' },
  { value: '1-238-771', label: '1-238-771 - The William Bonnell Company' },
  { value: '1-238-998', label: '1-238-998 - Digital Insurance' },
  { value: '1-23B-1553', label: '1-23B-1553 - BLUE CROSS AND BLUE SHIELD-TN' },
  { value: '1-23B-2013', label: '1-23B-2013 - BELCAN CORPORATION' },
  { value: '1-23B-2348', label: '1-23B-2348 - VORYS, SATER, SEYMOUR &amp; PEASE' },
  { value: '1-23B-3144', label: '1-23B-3144 - CORE BTS' },
  { value: '1-23B-3837', label: '1-23B-3837 - FAIRMOUNT MINERALS - Indirect Channel' },
  { value: '1-23B-3985', label: '1-23B-3985 - ABERCROMBIE &amp; FITCH' },
  { value: '1-23B-4497', label: '1-23B-4497 - KEYBANK' },
  { value: '1-23B-4542', label: '1-23B-4542 - NORDSON CORPORATION' },
  { value: '1-23B-603', label: '1-23B-603 - Knight Transportation' },
  { value: '1-23E-151', label: '1-23E-151 - Paylocity' },
  { value: '1-23E-1634', label: '1-23E-1634 - Enclos' },
  { value: '1-23E-251', label: '1-23E-251 - MACLEAN-FOGG' },
  { value: '1-23E-2862', label: '1-23E-2862 - digital river' },
  { value: '1-23E-3161', label: '1-23E-3161 - NATIONAL VAN LINES INC.' },
  { value: '1-23E-3303', label: '1-23E-3303 - KIP Telecom S.A.' },
  { value: '1-23E-3329', label: '1-23E-3329 - American Comsource Technologies, Inc.' },
];
export const ServiceIds = [
  { label: 'Select', value: null },
  { label: 'VWITNC', value: 'VWITNC' },
  { label: 'VWILLIAMS', value: 'VWILLIAMS' },
  { label: 'TELECOMUTR', value: 'TELECOMUTR' },
  { label: 'L3SCHED8', value: 'L3SCHED8' },
  { label: 'L3BRIDGETG', value: 'L3BRIDGETG' },
  { label: '3IPTFWILTE', value: '3IPTFWILTE' },
  { label: 'SESIAT1', value: 'SESIAT1' },
  { label: 'TELNETWWTF', value: 'TELNETWWTF' }
];

export const LocationServiceList = [
  { label: 'Williams IT N & C (Voice)', value: 'Williams IT N & C (Voice)' },
  { label: 'Level 3 Communications LLC - V', value: 'Level 3 Communications LLC - V' },
  { label: 'Level 3', value: 'Level 3' },
  { label: 'SES Testing - V', value: 'SES Testing - V' }
];

export const VCSTResultData: VoiceCompleteServiceTransferResult[] = [
  {
    fromLocation: 'From One',
    tns: '459823',
    id: 1
  },
  {
    tns: '459843',
    fromLocation: 'From One',
    id: 2
  }
];
export const VCSTResultDataInnerGrid: VoiceCompleteServiceTransferResultInnerGrid[] = [
  {
    tns: '459823',
    toLocation: 'Level 3 Communications LLC - V'
  },
  {
    tns: '459843',
    toLocation: 'v'
  }
];
