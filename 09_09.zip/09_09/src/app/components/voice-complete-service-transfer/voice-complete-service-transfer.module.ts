import { NgModule } from '@angular/core';
import { VoiceCompleteServiceTransferRoutingModule } from './voice-complete-service-transfer-routing.module';
import { VoiceCompleteServiceTransferViewComponent } from './voice-complete-service-transfer-view/voice-complete-service-transfer-view.component';
import { SharedModule } from '../../shared/shared.module';
import { VoiceCompleteServiceTransferLocationComponent } from './voice-complete-service-transfer-location/voice-complete-service-transfer-location.component';

@NgModule({
  declarations: [ VoiceCompleteServiceTransferViewComponent, VoiceCompleteServiceTransferLocationComponent ],
  imports: [
    SharedModule,
    VoiceCompleteServiceTransferRoutingModule
  ]
})
export class VoiceCompleteServiceTransferModule {
}
