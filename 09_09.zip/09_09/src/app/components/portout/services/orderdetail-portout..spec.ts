import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { OrderDetailService } from './orderdetail-portout.service';
import { PortoutService } from './portout.service';
import { ApiService } from '../../../shared/services/api.service';
import { StorageService } from '../../../services/storage.service';


xdescribe('OrderDetailPortoutService', () => {

  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let orderDetailService: OrderDetailService;
  let apiService: ApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ OrderDetailService, PortoutService, StorageService, ApiService ]
    });

    httpClient = TestBed.get(HttpClient);
    httpTestingController = TestBed.get(HttpTestingController);
    orderDetailService = TestBed.get(OrderDetailService);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();

  });

  afterEach(() => {
    httpTestingController.verify();
  });
describe('get order details',() => {
  const expectedResult: any = {type: 0};
it('should get order details', () => {
  const url = apiService.baseUrl + '/portout-' + apiService.envName + '/ServiceDelivery/v1/Voice/portOut/search?carrierRequesTypeId=' + 1 ;
  orderDetailService.getOrderDetails(1).subscribe(
    data => expect(data).toEqual(expectedResult, 'should return data'),
    fail
  );
  const req =  httpTestingController.expectOne(url);
  expect(req.request.method).toBe('GET')
 });
});
describe('Add/Remove tns', () => {
  const expectedResult: any = {type :0};
  it('should add tns',() => {
    const body = {
      carrierRequestId: '87678611',
      tn:'74657811'
    };
    const url = apiService.baseUrl + '/portout-' + apiService.envName + '/ServiceDelivery/v1/Voice/portOut/' + body.carrierRequestId + '/add/tn';
    orderDetailService.addTns(body).subscribe(
      data => expect(data).toEqual(expectedResult, 'should return data'),
      fail
    );
    const req = httpTestingController.expectOne(url);
    expect(req.request.method).toBe('PUT');
  });
  it('should remove tns',() => {
    const body = {
      carrierRequestId: '48686811',
      tn:'87264751'
    };
    const url = apiService.baseUrl + '/portout-' + apiService.envName + '/ServiceDelivery/v1/Voice/portOut/' + body.carrierRequestId + '/remove/tn';
    orderDetailService.removeTns(body).subscribe(
      data => expect(data).toEqual(expectedResult, 'should return data'),
      fail
    );
    const req =httpTestingController.expectOne(url);
    expect(req.request.method).toBe('PUT')
  });
});
describe('update order details',() => {
  const expectedResult: any = {type :0};
it('should update order details',() => {
  const params = {
   id:'93487111',
   focDate:'05/23/2020'
  };
  const body = {
    zipCode:'45324'
  };
  const url= apiService.baseUrl + '/portout-' + apiService.envName + '/ServiceDelivery/v1/Voice/portOut' + '?id=' + params.id + '&focDate=' + params.focDate;
  orderDetailService.updateOrderDetail(params,body).subscribe(
    data => expect(data).toEqual(expectedResult, 'should return data'),
    fail
  );
  const req =httpTestingController.expectOne(url);
  expect(req.request.method).toBe('PUT'); 
 });
});
describe('get tn details',() => {
  const expectedResult: any = {type: 0};
it('should get tn details',() => {
  const url = apiService.baseUrl + '/portout-' + apiService.envName + '/ServiceDelivery/v1/Voice/portOut/' + 1 + '/tns';
  orderDetailService.getTns(1).subscribe(
    data => expect(data).toEqual(expectedResult, 'should return data'),
    fail
  );
  const req = httpTestingController.expectOne(url);
  expect(req.request.method).toBe('GET');
 });
});
describe('Able to ADD BAN to big three tns',() => {
  const expectedResult: any = {type :0};
it('should be able to add BAN to big three tns',() => {
  const body = {
    carrierRequestId:'983461',
    tn:'47897111',
    ban:'47njmjk'
  };
  const url = apiService.baseUrl
})
})
})
