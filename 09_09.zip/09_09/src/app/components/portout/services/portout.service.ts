import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { ApiService } from '../../../shared/services/api.service';
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';


@Injectable()
export class PortoutService {
  constructor(private http: HttpClient, private apiService: ApiService) {
  }

  public postRequest(url: string, body: any) {
    const req = new HttpRequest('POST', url, body);
    return this.http.request(req).pipe(
      catchError(error => this.apiService.handleError(error))
    );
  }

  public getRequest(url: string, paramlist?: HttpParams) {
    let headers = new HttpHeaders();
    headers = headers.append('Cache-Control', 'no-cache');
    headers = headers.append('Pragma', 'no-cache');
    headers = headers.append('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');
    headers = headers.append('If-Modified-Since', '0');
    return this.http.get(url, { headers: headers, params: paramlist }).pipe(
      catchError(error => this.apiService.handleError(error))
    );
  }

  public putRequest(url: string, body: any, params: any = null) {
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    const header = { headers: headers };
    if ( params ) {
      header['params'] = params;
    }
    return this.http.put(url, body, header).pipe(
      catchError(error => this.apiService.handleError(error))
    );
  }
}

