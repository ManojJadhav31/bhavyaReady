import { inject, TestBed } from '@angular/core/testing';

import { PortoutService } from './portout.service';
import { HttpClientModule } from '@angular/common/http';
import { ApiService } from '../../../shared/services/api.service';

describe('PortoutService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule ],
      providers: [ PortoutService, ApiService ]
    });
  });

  it('should be created', inject([ PortoutService ], (service: PortoutService) => {
    expect(service).toBeTruthy();
  }));
});
