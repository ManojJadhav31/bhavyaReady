import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsPortoutComponent } from './reports-portout.component';

describe('ReportsPortoutComponent', () => {
  let component: ReportsPortoutComponent;
  let fixture: ComponentFixture<ReportsPortoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportsPortoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsPortoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
