import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports-portout',
  templateUrl: './reports-portout.component.html',
  styleUrls: [ './reports-portout.component.scss' ]
})
export class ReportsPortoutComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
