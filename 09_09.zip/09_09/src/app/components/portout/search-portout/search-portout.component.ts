import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { SearchPortoutService } from '../services/search-portout.service';
import { SearchPortoutResult } from './search-portout-result';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageService } from '../../../services/storage.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ConfirmationService, DataTable } from 'primeng/primeng';
import { UtilityService } from '../../../shared/services/utility.service';
import { PortoutResultsGridColumns } from './portout-search-results-grid-columns';
import { ColumnPickListDialogComponent } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog/column-pick-list-dialog.component';

@Component({
 
  selector: 'app-search-portout',
  templateUrl: './search-portout.component.html',
  styleUrls: [ './search-portout.component.scss' ],
  providers: [ SearchPortoutService, ConfirmationService ]
})
export class SearchPortoutComponent implements OnInit {
  public state: string;
  public errorMsg = '';
  public successMsg = '';
  public results: SearchPortoutResult[];
  public filteredResults: SearchPortoutResult[];
  public isSearchingOrders = false;
  public baseUrl: string;
  public searchOrderForm: FormGroup;
  public defaultDate: Date = new Date();
  public message: string;
  searchPanelCollapsed = {
    mainSearch: false,
    OrderSearch: false,
    LnpSearch: false,
    E911Search: false,
    EmeaSearch: false
  };
  @ViewChild('searchResultGrid') searchResultGrid: DataTable;
  totalRecords = 0;
  pageSize = 100;
  pageNumber = 1;
  firstPage = 0;
  showColumnFilterDialog = false;
  @ViewChild('columnPickListDialog') columnPickListDialog: ColumnPickListDialogComponent;
  public resultsGridColumns = PortoutResultsGridColumns;
  public defaultGridColumns: string[] = [ 'carrierRequestId', 'tnCount', 'focDate', 'errorMessage', 'errorCode', 'endUserName', 'purchaseOrderVersion', 'purchaseOrderNumber', 'status', 'ponStatus' ];
  gridColumnList: any = [];
  hiddenColumns: any = [];


  constructor(private searchPortoutService: SearchPortoutService,
              private router: Router,
              private storageService: StorageService,
              private route: ActivatedRoute,
              private fb: FormBuilder,
              private utilityService: UtilityService,
              private confirmationService: ConfirmationService) {
    this.storageService.setModule('search-portout');
    this.searchOrderForm = fb.group({
      carrierRequestId: new FormControl(),
      tn: new FormControl(),
      orderStatus: new FormControl(),
      pon: new FormControl(),
      startDate: new FormControl(),
      endDate: new FormControl(),
      ponStatus: new FormControl()
    });
  }

  ngOnInit() {
    this.results = [];
    this.filteredResults = [];
    this.fillOrderDetails();
  }

  fillOrderDetails() {
    const columnList = JSON.parse(JSON.stringify(this.resultsGridColumns));
    columnList.forEach((item) => {
      if ( this.defaultGridColumns.indexOf(item.value) !== -1 ) {
        item.visible = true;
      }
    });
    this.gridColumnList = columnList.filter(item => item.visible);
    this.hiddenColumns = columnList.filter(item => !item.visible);

    const details = this.storageService.getSearchDetails();
    const callSearch = this.route.snapshot.queryParams['search'];
    if ( details ) {
      if ( details.formData ) {
        this.searchOrderForm.controls.carrierRequestId.setValue(details.formData.carrierRequestId);
        this.searchOrderForm.controls.pon.setValue(details.formData.pon);
        this.searchOrderForm.controls.tn.setValue(details.formData.tn);
        this.searchOrderForm.controls.startDate.setValue(details.formData.startDate);
        this.searchOrderForm.controls.endDate.setValue(details.formData.endDate);
        this.searchOrderForm.controls.orderStatus.setValue(details.formData.orderStatus);
        this.searchOrderForm.controls.ponStatus.setValue(details.formData.ponStatus);
      }
      if ( details.pageConfig ) {
        this.firstPage = details.pageConfig.firstPage;
        this.pageNumber = details.pageConfig.pageNumber;
        this.pageSize = details.pageConfig.pageSize;
      }
      if ( details.results ) {
        this.results = details.results;
        if ( !callSearch ) {
          this.setFilteredData();
        }
      }

      const pickListDetails = this.storageService.getPickList();
      if ( pickListDetails ) {
        this.hiddenColumns = pickListDetails.hiddenColumns;
        this.gridColumnList = pickListDetails.gridColumnList;
      }
      if ( callSearch ) {
        this.onSearchOrder(this.searchOrderForm.value);
      }
    }
  }

  onSearchOrder(searchOrderFilter, hideMsg = true) {
    this.message = '';
    if ( hideMsg ) {
      this.errorMsg = '';
      this.successMsg = '';
    }
    if ( !searchOrderFilter.carrierRequestId && !searchOrderFilter.pon && !searchOrderFilter.tn &&
      !searchOrderFilter.startDate && !searchOrderFilter.endDate ) {
      this.errorMsg = 'Please enter at least one field other than LSR Status & PON Status';
      return;
    }
    this.results = null;
    this.filteredResults = null;
    this.isSearchingOrders = true;

    const formData: any = {};
    if ( searchOrderFilter.carrierRequestId ) {
      formData.carrierRequestId = searchOrderFilter.carrierRequestId.trim();
    }
    if ( searchOrderFilter.pon ) {
      formData.pon = searchOrderFilter.pon.trim();
    }
    if ( searchOrderFilter.tn ) {
      formData.tn = searchOrderFilter.tn.trim();
    }
    if ( searchOrderFilter.startDate ) {
      formData.startDate = this.utilityService.parseDate(searchOrderFilter.startDate, 'mdy');
    }
    if ( searchOrderFilter.endDate ) {
      formData.endDate = this.utilityService.parseDate(searchOrderFilter.endDate, 'mdy');
    }
    if ( searchOrderFilter.orderStatus ) {
      formData.orderStatus = searchOrderFilter.orderStatus;
    }
    if ( searchOrderFilter.ponStatus ) {
      formData.ponStatus = searchOrderFilter.ponStatus;
    }
    this.searchPortoutService.searchOrders(
      formData.carrierRequestId, formData.pon, formData.tn, formData.orderStatus,
      formData.startDate, formData.endDate, formData.ponStatus).subscribe(
      (results: SearchPortoutResult[]) => {
        this.results = results;
        setTimeout(() => {
          this.pageNumber = 1;
          this.setFilteredData();
          this.storageService.storeSearchDetailsGridPage(this.pageNumber, this.pageSize, this.firstPage);
        }, 1000);

        const formsData = {
          carrierRequestId: searchOrderFilter.carrierRequestId,
          pon: searchOrderFilter.pon,
          tn: searchOrderFilter.tn,
          startDate: searchOrderFilter.startDate,
          endDate: searchOrderFilter.endDate,
          orderStatus: searchOrderFilter.orderStatus,
          ponStatus: searchOrderFilter.ponStatus,
        };
        this.storageService.storeSearchDetails(formsData, results);
        if ( this.results.length <= 0 ) {
          this.errorMsg = 'No Matches Found';
        }
        this.isSearchingOrders = false;
      },
      (error) => {
        this.message = error;
        this.isSearchingOrders = false;
      }
    );
  }

  onCancelButtonClick(result) {
    this.confirmationService.confirm({
      message: 'Are you sure that you want to perform this action?',
      accept: () => {
        result.disableCancel = true;
        this.successMsg = '';
        this.errorMsg = '';
        this.isSearchingOrders = false;
        this.searchPortoutService.cancelOrders(result.carrierRequestId).subscribe((response) => {
          result.disableCancel = false;
          this.isSearchingOrders = false;
          this.successMsg = 'Order cancelled successfully';
          this.onSearchOrder(this.searchOrderForm.value, false);
        }, (error) => {
          result.disableCancel = false;
          this.message = error;
          // this.errorMsg = 'Error while canceling order';
          this.isSearchingOrders = false;
        });
      }
    });
  }

  setFilteredData() {
    const skip = ( this.pageNumber - 1 ) * this.pageSize;
    this.totalRecords = this.results.length;
    this.filteredResults = this.results.slice(skip, skip + this.pageSize);
  }

  onSelectEdit(result: any) {
    let supActionDisabled = false;
    if ( result.errorMessage && result.errorMessage !== '' ) {
      supActionDisabled = true;
    }
    this.router.navigate([ 'portout/upload/' + result.carrierRequestId + '/' + supActionDisabled]);
  }

  loadSearchResults(event) {
    this.firstPage = event.first;
    this.pageNumber = ( event.first / event.rows ) + 1;
    this.pageSize = event.rows;
    this.storageService.storeSearchDetailsGridPage(this.pageNumber, this.pageSize, this.firstPage);
    this.setFilteredData();
  }

  onClearFields() {
    this.results = [];
    this.filteredResults = [];
    this.storageService.resetDetails();
    this.fillOrderDetails();
    this.searchOrderForm.controls.carrierRequestId.setValue('');
    this.searchOrderForm.controls.tn.setValue('');
    this.searchOrderForm.controls.orderStatus.setValue('');
    this.searchOrderForm.controls.pon.setValue('');
    this.searchOrderForm.controls.startDate.setValue('');
    this.searchOrderForm.controls.endDate.setValue('');
    this.searchOrderForm.controls.ponStatus.setValue('');
    this.isSearchingOrders = false;
    this.errorMsg = '';
    this.message = '';
    this.successMsg = '';
  }

  showHideColumnFilterDialog() {
    this.columnPickListDialog.showDialog = true;
  }

  onPickListChange(list: any[]) {
    this.gridColumnList = JSON.parse(JSON.stringify(list));
  }

}

