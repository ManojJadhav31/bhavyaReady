import { Component, Input, OnInit } from '@angular/core';
import { SearchPortoutService } from '../../services/search-portout.service';

@Component({
  selector: 'app-portout-order-status-details',
  templateUrl: './portout-order-status-details.component.html',
  styleUrls: ['./portout-order-status-details.component.scss'],
  providers: [SearchPortoutService]
})
export class PortoutOrderStatusDetailsComponent implements OnInit {

  @Input('rowData') rowData: any;
  public tableData: any[] = [];
  columns: any[] = [
    { field: 'parentOrderNumber', header: 'Parent Order ID' },
    { field: 'tnCount', header: '# TN' },
    { field: 'parentOrderStatus', header: 'PON Status' },
    { field: 'productName', header: 'Product Name' },
    { field: 'carrierName', header: 'Carrier Name' }
  ];

  constructor(private searchPortoutService: SearchPortoutService) {
  }

  ngOnInit() {
    console.log(this.rowData);
    this.getTableData();
  }

  getTableData() {
    this.searchPortoutService.getOrderStatusDetails(this.rowData.carrierRequestId).subscribe((response) => {
      this.tableData = response;
    });
    // for ( let i = 0; i < 1; i++ ) {
    //   this.tableData.push({
    //     parentId: '220339337',
    //     tn: '1',
    //     focDate: '01/29/2019',
    //     status: 'FOC Received',
    //     orderType: 'New',
    //     productName: '(3)VoIP Local Inbound',
    //     carrierName:'LEVEL 3'
    //   },{
    //     parentId: '980338827',
    //     tn: '1',
    //     focDate: '05/23/2019',
    //     status: 'Completed',
    //     orderType: 'New',
    //     productName: '',
    //     carrierName:'Broadwing'
    //   },
    //   {
    //     parentId: '800273677',
    //     tn: '1',
    //     focDate: '05/25/2019',
    //     status: 'Created',
    //     orderType: 'New',
    //     productName: 'Voice Complete',
    //     carrierName:'LEVEL 3'
    //   }
    // );
    // }
  }

}
