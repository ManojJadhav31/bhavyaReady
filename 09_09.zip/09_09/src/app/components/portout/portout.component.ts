import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageService } from '../../services/storage.service';


@Component({
  selector: 'app-portout',
  templateUrl: './portout.component.html',
  styleUrls: [ './portout.component.scss' ]
})
export class PortoutComponent implements OnInit {

  public selectedTab = '';
  public UserName: string;

  constructor(private router: Router,
              private route: ActivatedRoute,
              private storageService: StorageService) {
  }

  ngOnInit() {
    this.UserName = localStorage.getItem('UserName') === 'undefined' ? undefined : localStorage.getItem('UserName');

    this.route.url.subscribe(data => {
      const url = this.router.url;
      if ( url.search('search') > 0 ) {
        this.selectedTab = 'search';
      } else if ( url.search('upload') > 0 ) {
        this.selectedTab = 'upload';
      } else if ( url.search('report') > 0 ) {
        this.selectedTab = 'report';
      }
    });
  }

  onTabChange(event) {
    this.storageService.shouldFillSearchForm = false;
    switch ( event.index ) {
      case 0:
        this.router.navigate([ '/portout/search' ]);
        break;
      case 1:
        this.router.navigate([ '/portout/upload' ]);
        break;
      case 2:
        this.router.navigate([ '/portout/report' ]);
        break;
    }
  }
}





