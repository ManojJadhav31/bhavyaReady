import {Component, OnInit} from '@angular/core';
import {TnActivitySearchService} from '../services/tn-activity-search.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-tn-activity-detail',
  templateUrl: './tn-activity-detail-page.component.html',
  styleUrls: ['./tn-activity-detail-page.component.scss'],

})
export class TnActivityDetailPageComponent implements OnInit {

  public orderDetail: any = {};
  activityId: string = null;
  public message: string;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private activitySearchService: TnActivitySearchService) {
  }

  ngOnInit() {
    this.route
      .params
      .subscribe(params => {
        this.activityId = params['activityId'];
        this.message = '';
        this.activitySearchService.getActivityDetail(this.activityId).subscribe(res => {
          if (res[0]) {
            this.orderDetail = res[0];
          }
        }, (error) => {
          this.message = error;
        });
      });
  }

  BackToOderDetailPage() {
    this.router.navigate(['./activation-service/tn-activity-search']);
  }

}
