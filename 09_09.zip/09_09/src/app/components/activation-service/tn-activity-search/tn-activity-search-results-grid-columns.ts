export const ColumnType: any = {
  string: 'string',
  number: 'number',
  date: 'date'
};

export const TnSearchResultsGridColumns: any = [
  {
    caption: 'TN Order Id',
    value: 'slOrderId',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Voice Order Id',
    value: 'voiceOrderId',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Parent Order Id',
    value: 'parentTransId',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'TN',
    value: 'tn',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },

  {
    caption: 'LNP Foc Date',
    value: 'lnpFocDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r17': true }
  },
  {
    caption: 'CRD',
    value: 'customerRequestDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r11': true }
  },
  {
    caption: 'LNP Order Status',
    value: 'lnpStatus',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Customer Name ',
    value: 'customerBizOrgName',
    visible: false,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'Activity Name',
    value: 'activityName',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Activity Status',
    value: 'activityStatus',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Activity Create Date',
    value: 'activityCreateDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r17': true }
  },
  {
    caption: 'Activity Complete Date',
    value: 'activityCompleteDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r19': true }
  },
  {
    caption: 'Activation Time',
    value: 'activationDate',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Activity ID',
    value: 'id',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Activity Name Id',
    value: 'activityNameId',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Activity Status Id',
    value: 'activityStatusId',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Admin Name',
    value: 'adminName',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Adopt Order',
    value: 'adoptYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'ALI Status',
    value: 'aliStatus',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Area Code',
    value: 'tnAreaCode',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'B2B API Version',
    value: 'b2bApiVersion',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Bill Start Date',
    value: 'billStartDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r17': true }
  },
  {
    caption: 'BTN',
    value: 'btn',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Business Name',
    value: 'businessName',
    visible: false,
    type: ColumnType.string,
    class: { 'r16': true }
  },
  {
    caption: 'City',
    value: 'city',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'City(Emea)',
    value: 'cityEmea',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Class of Service',
    value: 'classOfService',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Comment',
    value: 'accomments',
    visible: false,
    type: ColumnType.string,
    class: { 'r25': true }
  },
  {
    caption: 'Contact Language',
    value: 'contactLanguage',
    visible: false,
    type: ColumnType.string,
    class: { 'r16': true }
  },
  {
    caption: 'Country',
    value: 'country',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Country Code',
    value: 'countryCode',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'Customer Biz Org Id',
    value: 'customerBizOrgId',
    visible: false,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'Customer Acceptance Date',
    value: 'customerAcceptDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r21': true }
  },
  {
    caption: 'Customer Commit Date',
    value: 'commitDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r21': true }
  },
  
 
  // {
  //     caption: 'Customer Service Request',
  //     value: 'serviceId',
  //     visible: false,
  //     type: ColumnType.string,
  //     class: { 'r22': true }
  // },
  {
    caption: 'Desired Due Date',
    value: 'desiredDueDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r17': true }
  },
  {
    caption: 'Displayable Activity',
    value: 'isDisplayable',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'External Order Id',
    value: 'extOrderId',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Feature Packs',
    value: 'lnpFeatureCode',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Fips Code',
    value: 'fipsCode',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  }, 
  
  {
    caption: 'Install Date',
    value: 'installDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r17': true }
  },
  {
    caption: 'Internal Port',
    value: 'internalPortYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Last Update User',
    value: 'lastUpdatedUser',
    visible: false,
    type: ColumnType.string,
    class: { 'r22': true }
  },
  {
    caption: 'Last Update Date',
    value: 'lastUpdatedDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r19': true }
  },
  {
    caption: 'Lata',
    value: 'lata',
    visible: false,
    type: ColumnType.string,
    class: { 'r8': true }
  },
  {
    caption: 'LCT Response',
    value: 'lctResponse',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Listing Language',
    value: 'listingLanguage',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'LNP Last Event',
    value: 'lnpLastEvent',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'LNP LEC Response Date',
    value: 'lnpLecResponseDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r19': true }
  },
  {
    caption: 'LNP Option',
    value: 'lnpOption',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'LNP Order',
    value: 'lnpYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'LNP Order Error',
    value: 'lnpOrderError',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'LNP Order State',
    value: 'lnpOrderState',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
 
  {
    caption: 'LNP Project Id',
    value: 'lnpProjectId',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'LNP State Code',
    value: 'lnpStateCode',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'LNP Vendor Message',
    value: 'lnpVendorMessage',
    visible: false,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'LNP Wireless',
    value: 'lnpWirelessYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Location SCID',
    value: 'locationScid',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Market',
    value: 'market',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'New LRN',
    value: 'newLrn',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'New OCN',
    value: 'newOcn',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Number Type',
    value: 'numberType',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Old LRN',
    value: 'lnpOldLrn',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Old OCN',
    value: 'lnpOldOcn',
    visible: false,
    type: ColumnType.string,
    class: { 'r9': true }
  },
  {
    caption: 'Order  Action',
    value: 'orderAction',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Order Complete Date',
    value: 'orderCompleteDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r17': true }
  },
  {
    caption: 'Order Date',
    value: 'orderDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r17': true }
  },
  {
    caption: 'Order Source',
    value: 'orderSource',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Order Status',
    value: 'orderStatus',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Order Type',
    value: 'orderType',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Port Request Date',
    value: 'portRequestedDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r17': true }
  },
  {
    caption: 'Pre Dir',
    value: 'preDirectional',
    visible: false,
    type: ColumnType.string,
    class: { 'r8': true }
  },
  {
    caption: 'Post Dir',
    value: 'postDirectional',
    visible: false,
    type: ColumnType.string,
    class: { 'r9': true }
  },
  {
    caption: 'Product',
    value: 'product',
    visible: false,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'PSID',
    value: 'psid',
    visible: false,
    type: ColumnType.string,
    class: { 'r7': true }
  },
  {
    caption: 'RC Abbr',
    value: 'rcAbbr',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Rc State',
    value: 'rcState',
    visible: false,
    type: ColumnType.string,
    class: { 'r9': true }
  },
  {
    caption: 'Requester Email',
    value: 'requesterEmail',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Requester Name',
    value: 'RequesterName',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Revised Commit Date',
    value: 'revisedCommitDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r19': true }
  },
  {
    caption: 'Route Plan Name',
    value: 'routePlanName',
    visible: false,
    type: ColumnType.string,
    class: { 'r16': true }
  },
  {
    caption: 'Route Label',
    value: 'routingLabel',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Sales Channel',
    value: 'salesChannel',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Sales Rep Region',
    value: 'salesRepRegion',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'SCID',
    value: 'scid',
    visible: false,
    type: ColumnType.string,
    class: { 'r9': true }
  },
  {
    caption: 'Service Package',
    value: 'servicePackage',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Service Transfer',
    value: 'serviceTransferYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'State',
    value: 'stateProv',
    visible: false,
    type: ColumnType.string,
    class: { 'r7': true }
  },
  {
    caption: 'Street Name',
    value: 'streetName',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Street Number',
    value: 'streetNum',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Street Num Prefix',
    value: 'streetNumPrefix',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Street Num Suffix',
    value: 'streetNumsuffix',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Subscriber Name',
    value: 'subscriberName',
    visible: false,
    type: ColumnType.string,
    class: { 'r16': true }
  },
  {
    caption: 'Switch Type',
    value: 'switchType',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Unit',
    value: 'unit',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Value Added Tax',
    value: 'valueAddedTax',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Zip',
    value: 'zip',
    visible: false,
    type: ColumnType.string,
    class: { 'r8': true }
  },
  {
    caption: 'Zip Plus',
    value: 'zipPlus',
    visible: false,
    type: ColumnType.string,
    class: { 'r9': true }
  }
];
