import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivationServiceRoutingModule } from '../activation-service-routing.module';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { TnActivitySearchService } from '../services/tn-activity-search.service';
import { ActivationServiceComponent } from '../activation-service.component';
import { TnActivitySearchComponent } from '../tn-activity-search/tn-activity-search.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ApiService } from '../../../shared/services/api.service';
import { TnActivityOrderDetailPageComponent } from './tn-activity-order-detail-page.component';
import { TnActivityDetailPageComponent } from '../tn-activity-detail-page/tn-activity-detail-page.component';
import { Routes } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import {  ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';
 

const routes: Routes = [
  {
    path: 'activation-service', component: ActivationServiceComponent,
    children: [
      { path: '', redirectTo: 'tn-activity-search', pathMatch: 'full' },
      { path: 'tn-activity-search', component: TnActivitySearchComponent },
      { path: 'tn-activity-order-detail', component: TnActivityOrderDetailPageComponent },
      { path: 'tn-activity-detail', component: TnActivityDetailPageComponent }
    ]
  },
];


describe('TnActivityOrderDetailPageComponent', () => {
  let component: TnActivityOrderDetailPageComponent;
  let fixture: ComponentFixture<TnActivityOrderDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ActivationServiceComponent,
        TnActivitySearchComponent,
        TnActivityOrderDetailPageComponent,
        TnActivityDetailPageComponent
      ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        ActivationServiceRoutingModule,
        SearchPanelsModule,
        RouterTestingModule.withRoutes(routes),
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        TnActivitySearchService,
        ApiService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TnActivityOrderDetailPageComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form submit', () => {
    expect(component.BackToOderDetailPage()).toBeFalsy();
  });
});
