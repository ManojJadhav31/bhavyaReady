import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-activation-service',
  templateUrl: 'activation-service.component.html'
})

export class ActivationServiceComponent implements OnInit {

  public selectedTab = '';
  public showTab = true;

  constructor (private router: Router,
               private route: ActivatedRoute) {
  }

  ngOnInit () {
    this.route.url.subscribe(data => {
      const url = this.router.url;
      if (url.search('tnActivitySearch') > 0) {
        this.selectedTab = 'tnActivitySearch';
      } else if (url.search('tn-activity-order-detail') > 0) {
        this.showTab = false;
      } else if (url.search('tn-activity-detail') > 0) {
        this.showTab = false;
      } else {
        this.showTab = true;
      }
    });
  }

  onTabChange (event) {
    switch (event.index) {
      case 0:
        this.router.navigate(['/portout/tnActivitySearch']);
        break;
    }
  }
}
