import { Component, OnInit } from '@angular/core';
import { OrderSearchPricingDetailsGridColumns } from '../order-mgmt-search/order-mgmt-search-results-grid-columns';
import { ActivatedRoute } from '@angular/router';
import { OrderPricingDTOResponse } from '../order-management-constants';
import { OrderMgmtSearchService } from '../services/order-mgmt-search.service';

@Component({
  selector: 'app-pricing-information',
  templateUrl: './pricing-information.component.html',
  styleUrls: [ './pricing-information.component.scss' ]
})
export class PricingInformationComponent implements OnInit {

  gridColumnList: any = [];
  filteredResults: OrderPricingDTOResponse[] = [];
  public orderPricingRequest = {
    orderId: '', tn: ''
  };


  constructor( private orderMgmtSearchService: OrderMgmtSearchService, private activatedRoute: ActivatedRoute ) {
  }

  ngOnInit() {
    const columnList = JSON.parse(JSON.stringify(OrderSearchPricingDetailsGridColumns));
    this.gridColumnList = columnList.filter(item => item.visible);

    // console.log(this.activatedRoute.snapshot.params);
    this.orderPricingRequest.orderId = this.activatedRoute.snapshot.params['orderId'];
    this.orderPricingRequest.tn = this.activatedRoute.snapshot.params['tn'];
    this.getPricing();
  }

  getPricing() {
    this.orderMgmtSearchService.getOrderPricingInfo(this.orderPricingRequest.orderId, this.orderPricingRequest.tn)
      .subscribe(( response: OrderPricingDTOResponse[] ) => {
        this.filteredResults = response;
      }, () => {
        // this.filteredResults = OrderPricingInformationResult;
      });
  }


  // exportExcel () {
  //   this.orderPricingService.getExportDetail(this.orderPricingRequest.orderId, this.orderPricingRequest.tn).subscribe((response) => {
  //     const url = window.URL.createObjectURL(response.data);
  //     const a = document.createElement('a');
  //     document.body.appendChild(a);
  //     a.setAttribute('style', 'display:none');
  //     a.href = url;
  //     a.download = response.fileName;
  //     a.click();
  //     window.URL.revokeObjectURL(url);
  //     a.remove();
  //   }, error => {
  //   });
  // }
}
