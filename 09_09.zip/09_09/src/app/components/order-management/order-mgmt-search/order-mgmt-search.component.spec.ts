import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { OrderMgmtSearchComponent } from './order-mgmt-search.component';
import { OrderManagementComponent } from '../order-management.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OrderManagementRoutingModule } from '../order-management-routing.module';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { RouterTestingModule } from '@angular/router/testing';
import { OrderMgmtSearchService } from '../services/order-mgmt-search.service';
import { SearchPanelsService } from '../../search-panels/services/search-panels.service';
import { ApiService } from '../../../shared/services/api.service';
import { of } from 'rxjs';
import { OrderManagementSearchResult } from '../../../../tests/mockdata/order-management-search/order-management-search-result';
import { PortoutService } from '../../portout/services/portout.service';
import { StorageService } from '../../../services/storage.service';
import { OrderManagementOrderDetailPageComponent } from '../order-management-order-detail-page/order-management-order-detail-page.component';
import { SharedModule } from '../../../shared/shared.module';
import { PricingInformationComponent } from '../pricing-information/pricing-information.component';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

describe('OrderMgmtSearchComponent', () => {
  let component: OrderMgmtSearchComponent;
  let fixture: ComponentFixture<OrderMgmtSearchComponent>;
  let orderMgmtSearchService: OrderMgmtSearchService;
  let storageService: StorageService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderManagementComponent, OrderMgmtSearchComponent, OrderManagementOrderDetailPageComponent, PricingInformationComponent ],
      imports: [
        SharedModule,
        HttpClientModule,
        BrowserAnimationsModule,
        OrderManagementRoutingModule,
        SearchPanelsModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        OrderMgmtSearchService,
        SearchPanelsService,
        ApiService,
        PortoutService,
        StorageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderMgmtSearchComponent);
    component = fixture.componentInstance;
    orderMgmtSearchService = fixture.debugElement.injector.get(OrderMgmtSearchService);
    storageService = fixture.debugElement.injector.get(StorageService);
    spyOn(orderMgmtSearchService, 'searchActivities').and.returnValue(of(OrderManagementSearchResult));
    storageService.setModule('order-mgmt');
    component.panelFilter = {
      OrderSearch: false,
      LnpSearch: false,
      E911Search: false,
      EmeaSearch: false
    };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    /*if (data) {
      console.log(data);
    }*/
  });

  it('should expand search tabs on check box click', () => {
    component.filterPanels('OrderSearch', true);
    expect(component.panelFilter.OrderSearch).toBe(true);
  });

  it('should search for order management activities', () => {

    const activitySearch = {
      tnOrderId: '123123',
      selectedDateType: 'All'
    };
    component.searchActivities(activitySearch);
    expect(component.searchResults.length).toBeGreaterThanOrEqual(0);
    expect(component.filteredResults.length).toBeGreaterThanOrEqual(0);
    expect(component.totalRecords).toBeGreaterThanOrEqual(0);

  });
  it('should be able to clear form', () => {
    component.clearForm();
    expect(component.searchResults).toEqual([]);
  });

  it('should be able to show hide column filter dialog', () => {
    component.showHideColumnFilterDialog();
    expect(component.columnPickListDialog.showDialog).toEqual(true);
  });
  it('should be able to update order dates', fakeAsync(() => {
    component.updateAction.type.code = 'selectedOrder';
    component.updateAction.operation.code = 'orderDateUpdate';
    spyOn(orderMgmtSearchService, 'updateActivitiesOrderDate').and.returnValue(of(true));
    component.updateActivitySearch();
    component.successMessage = 'Update Successful';
    tick();
    expect(component.successMessage).toBe('Update Successful');
  }));
  it('should be able to update order comments', fakeAsync(() => {
    component.updateAction.type.code = 'selectedOrder';
    component.updateAction.operation.code = 'orderCommentUpdate';
    spyOn(orderMgmtSearchService, 'updateActivitiesOrderDate').and.returnValue(of(true));
    component.updateActivitySearch();
    component.successMessage = 'Update Successful';
    tick();
    expect(component.successMessage).toBe('Update Successful');
  }));

  it('should show hide column filter dialog', () => {
    const list = [ {
      caption: 'Order ID',
      value: 'carrierRequestId',
      visible: false,
      type: 'string',
      class: { 'r9': true }
    },
      {
        caption: '# Tn',
        value: 'tnCount',
        visible: false,
        type: 'string',
        class: { 'r6': true }
      } ];
    component.onPickListChange(list);
    expect(component.gridColumnList[0].value).toBe('carrierRequestId');
  });
});
