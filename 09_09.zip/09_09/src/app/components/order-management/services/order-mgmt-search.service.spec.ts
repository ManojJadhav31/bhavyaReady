import { getTestBed, inject, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ApiService } from '../../../shared/services/api.service';
import { HttpClient } from '@angular/common/http';
import { OrderMgmtSearchService } from './order-mgmt-search.service';

describe('OrderMgmtSearchService', () => {
  let orderSearch: OrderMgmtSearchService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let apiService: ApiService;
  let httpClient: HttpClient;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ OrderMgmtSearchService, ApiService ]
    });
    injector = getTestBed();
    httpClient = TestBed.get(HttpClient);
    orderSearch = injector.get(OrderMgmtSearchService);
    httpMock = injector.get(HttpTestingController);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', inject(
    [ OrderMgmtSearchService ],
    ( service: OrderMgmtSearchService ) => {
      expect(service).toBeTruthy();
    }
  ));

  it('should get order details using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/slOrder/1';
    orderSearch.getOrderDetail('1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url, 'get order details');
    httpMock.verify();
    expect(req.request.method).toBe('GET');
  });

  it('should get pricing details using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/pricing/' + 1 + '/' + 1;
    orderSearch.getOrderPricingInfo('1', '1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });

  it('should post search details using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/orderSearch/search/1/0';
    orderSearch.searchActivities('1', 1, 1).subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('POST');
  });
});
