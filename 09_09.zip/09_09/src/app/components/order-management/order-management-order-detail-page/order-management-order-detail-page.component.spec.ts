import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Routes } from '@angular/router';
import { OrderManagementComponent } from '../order-management.component';
import { OrderManagementOrderDetailPageComponent } from './order-management-order-detail-page.component';
import { OrderMgmtSearchComponent } from '../order-mgmt-search/order-mgmt-search.component';
import { OrderManagementRoutingModule } from '../order-management-routing.module';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { RouterTestingModule } from '@angular/router/testing';
import { StorageService } from '../../../services/storage.service';
import { SearchPanelsService } from '../../search-panels/services/search-panels.service';
import { OrderMgmtSearchService } from '../services/order-mgmt-search.service';
import { ApiService } from '../../../shared/services/api.service';
import { SharedModule } from '../../../shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PricingInformationComponent } from '../pricing-information/pricing-information.component';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

const routes: Routes = [
  {
    path: 'order-management', component: OrderManagementComponent,
    children: [
      { path: '', redirectTo: 'order-mgmt-search', pathMatch: 'full' },
      { path: 'order-mgmt-search', component: OrderMgmtSearchComponent },
      { path: 'order-mgmt-order-detail', component: OrderManagementOrderDetailPageComponent }
    ]
  },
];

describe('OrderManagementOrderDetailPageComponent', () => {
  let component: OrderManagementOrderDetailPageComponent;
  let fixture: ComponentFixture<OrderManagementOrderDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        OrderManagementComponent, OrderMgmtSearchComponent, OrderManagementOrderDetailPageComponent, PricingInformationComponent
      ],
      imports: [
        BrowserAnimationsModule,
        SharedModule,
        OrderManagementRoutingModule,
        SearchPanelsModule,
        RouterTestingModule.withRoutes(routes),
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        OrderMgmtSearchService,
        SearchPanelsService,
        StorageService,
        ApiService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderManagementOrderDetailPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form submit', () => {
    expect(component.BackToOderDetailPage()).toBeFalsy();
  });
});
