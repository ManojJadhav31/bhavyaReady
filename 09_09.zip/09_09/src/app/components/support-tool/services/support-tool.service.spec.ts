import { TestBed } from '@angular/core/testing';

import { SupportToolService } from './support-tool.service';

describe('SupportToolService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SupportToolService = TestBed.get(SupportToolService);
    expect(service).toBeTruthy();
  });
});
