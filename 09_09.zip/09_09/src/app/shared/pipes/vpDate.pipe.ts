import {Pipe, PipeTransform} from '@angular/core';
import {UtilityService} from '../services/utility.service';

@Pipe({name: 'vpdate'})
export class VpDatePipe implements PipeTransform {

  constructor (private utilityService: UtilityService) {

  }

  transform (value: string, format: string): string {
    return this.utilityService.parseDate(value, format);
  }
}
