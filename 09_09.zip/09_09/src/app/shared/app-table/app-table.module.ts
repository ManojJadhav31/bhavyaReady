import {NgModule} from '@angular/core';
import {AppTableComponent} from './app-table/app-table.component';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {PaginatorModule} from 'primeng/primeng';
import {CommonModule} from '@angular/common';
import {NgPipesModule} from 'ngx-pipes';

@NgModule({
  declarations: [AppTableComponent],
  exports: [AppTableComponent],
  imports: [CommonModule, PaginatorModule, ScrollingModule, NgPipesModule]
})
export class AppTableModule {
}
