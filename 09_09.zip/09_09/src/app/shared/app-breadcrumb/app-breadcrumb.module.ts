import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BreadcrumbModule} from 'primeng/primeng';
import {AppBreadcrumbComponent} from './app-breadcrumb/app-breadcrumb.component';

@NgModule({
  imports: [CommonModule, BreadcrumbModule],
  declarations: [AppBreadcrumbComponent],
  exports: [AppBreadcrumbComponent]
})
export class AppBreadcrumbModule {
}
