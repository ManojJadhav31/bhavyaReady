import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {AppBreadcrumbComponent} from './app-breadcrumb.component';
import {BreadcrumbModule} from 'primeng/primeng';
import {BrowserModule} from '@angular/platform-browser';
import {RouterTestingModule} from '@angular/router/testing';

describe('AppBreadcrumbComponent', () => {
  let component: AppBreadcrumbComponent;
  let fixture: ComponentFixture<AppBreadcrumbComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AppBreadcrumbComponent],
      imports: [BrowserModule, RouterTestingModule, BreadcrumbModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppBreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
