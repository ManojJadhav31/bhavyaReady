export function sortList(list: any[], attribute: string, order: 'ASC' | 'DESC' = 'ASC'): any[] {
  if (list) {
    return list.sort((objectA: any, objectB: any) => {
      if (objectA[attribute] && objectB[attribute]) {
        let a = objectA[attribute];
        let b = objectB[attribute];
        if (typeof objectA[attribute] === 'string' && typeof objectB[attribute] === 'string') {
          a = objectA[attribute].toLowerCase();
          b = objectB[attribute].toLowerCase();
        }
        if (order === 'DESC') {
          if (a > b) {
            return -1;
          } else if (a < b) {
            return 1;
          }
        } else {
          if (a < b) {
            return -1;
          } else if (a > b) {
            return 1;
          }
        }
      }
      return 0;
    });
  } else {
    return []
  }
}
export function sortStringList(list: any[]): any[] {
  if (list) {
    return list.sort((objectA: any, objectB: any) => {
      if (objectA && objectB) {
        let a = objectA;
        let b = objectB;
        if (typeof objectA === 'string' && typeof objectB === 'string') {
          a = objectA.toLowerCase();
          b = objectB.toLowerCase();
        }
        if (a < b) {
          return -1;
        } else if (a > b) {
          return 1;
        }
      }
      return 0;
    });
  } else {
    return []
  }
}
