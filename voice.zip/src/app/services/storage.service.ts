import { Injectable } from '@angular/core';

class SearchDetailsProto {
  formData: any;
  results: any;
  totalRecords: number;
  pageConfig: PageConfig = new PageConfig();
  pickList: PickList;
  panelList: string[];
}

class PageConfig {
  firstPage: number = 0;
  pageNumber: number = 1;
  pageSize: number = 25;
}

class PickList {
  hiddenColumns: any[];
  gridColumnList: any[];
}

interface TransactionIds {
  time: number;
  ids: string[];
  mode: string;
  success: boolean;
}

@Injectable()
export class StorageService {

  private searchDetails: Map<string, SearchDetailsProto> = new Map<string, SearchDetailsProto>();
  public shouldFillSearchForm: boolean;
  private module: string;
  private selectedActivityIds: Array<string> = [];
  private selectedParentOrderIds: Array<string>;
  private customerInfo: any;

  constructor() {
  }

  setModule(module) {
    this.module = module;
  }

  private getSearchDetailValues(field: string): any {
    if (!this.module) {
      this.handleError();
    }

    if (this.searchDetails[this.module]) {
      return this.searchDetails[this.module][field];
    }
    return undefined;
  }

  private setSearchDetailValues(field: string, value: any) {
    if (!this.module) {
      this.handleError();
    }
    if (this.searchDetails[this.module]) {
      this.searchDetails[this.module][field] = value;
    } else {
      this.searchDetails[this.module] = new SearchDetailsProto();
      this.searchDetails[this.module][field] = value;
    }
  }

  getCachedCustomerInfo(): any {
    return this.customerInfo;
  }
  setCustomerInfo(cusInfo: any) {
    this.customerInfo = cusInfo;
  }

  storePanelSearchList(list) {
    this.setSearchDetailValues('panelList', list);
    localStorage.setItem(this.module + '_panelList', JSON.stringify(list));
  }

  private getPanelSearchList(): string[] {
    // this.setSearchDetailValues(this.module + '_panelList', list);
    return JSON.parse(localStorage.getItem(this.module + '_panelList'));
  }

  setTransactionActivityIdsList(list: any[]) {
    localStorage.setItem(this.module + '_transactionIds', JSON.stringify(list));
  }

  setTransactionActivityIds(ids: string[], mode: string, timeStamp = new Date(), success = false) {
    let list = this.getTransactionActivityIds();
    if (!list) {
      list = [];
    }
    const findObject = list.find(object => {
      return object.time === timeStamp.getTime();
    });
    if (findObject) {
      findObject.ids = ids;
      findObject.mode = mode;
      findObject.success = success;
    } else {
      list.push({
        time: timeStamp.getTime(),
        ids: ids,
        mode: mode,
        success: success
      });
    }
    localStorage.setItem(this.module + '_transactionIds', JSON.stringify(list));
  }

  getTransactionActivityIds(): TransactionIds[] {
    let list = <any>localStorage.getItem(this.module + '_transactionIds');
    if (list) {
      list = JSON.parse(list);
    }
    return list || [];
  }

  storeSearchDetails(formData: any, results: any, totalRecords?: number): void {
    this.setSearchDetailValues('formData', formData);
    this.setSearchDetailValues('results', results);
    this.setSearchDetailValues('totalRecords', totalRecords);
  }

  storePickList(pickList: PickList): void {
    this.setSearchDetailValues('pickList', pickList);
    localStorage.setItem(this.module, JSON.stringify(pickList));
  }

  getPickList(): PickList {
    return JSON.parse(localStorage.getItem(this.module));
    // return this.getSearchDetailValues('pickList');
  }

  storeSelectedActivityIds(activityIds: Array<string>, isEmpty: boolean): void {
    if (isEmpty && !this.selectedActivityIds) {
      this.selectedActivityIds = [];
    }
    else {
      if (this.selectedActivityIds.length > 0) {
        activityIds.forEach(id => {
          this.selectedActivityIds.push(id);
        });
      }
      else {
        this.selectedActivityIds = activityIds;
      }
    }
  }

  getSelectedActivityIds(): Array<string> {
    return this.selectedActivityIds;
  }

  storeSearchDetailsGridPage(pageNumber: number, pageSize?: number, firstPage?: number): void {
    const pageConfig = new PageConfig();
    pageConfig.pageNumber = pageNumber || 1;
    pageConfig.pageSize = pageSize || 25;
    pageConfig.firstPage = firstPage || 0;
    this.setSearchDetailValues('pageConfig', pageConfig);
  }

  private getGridPageConfig(): PageConfig {
    if (this.getSearchDetailValues('pageConfig')) {
      return this.getSearchDetailValues('pageConfig');
    }
    return {
      firstPage: 0,
      pageNumber: 1,
      pageSize: 25
    };
  }

  resetDetails(): void {
    this.searchDetails[this.module] = undefined;
    this.selectedActivityIds = undefined;
  }

  getSearchDetails(): SearchDetailsProto {
    if (!this.module) {
      this.handleError();
    }
    if (!this.searchDetails[this.module]) {
      this.searchDetails[this.module] = new Map<string, SearchDetailsProto>();
      this.searchDetails[this.module]['pickList'] = this.getPickList();
      this.searchDetails[this.module]['panelList'] = this.getPanelSearchList();
    }
    return this.searchDetails[this.module];
  }

  handleError() {
    throw new Error('You need to set module first in storage service to use its function');
  }
}


