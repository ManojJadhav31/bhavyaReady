import { RouterModule, Routes } from '@angular/router';

const appRoutes: Routes = [
  {
    path: 'portout-ui', redirectTo: 'portout', pathMatch: 'full'
  },
  {
    path: 'portout',
    loadChildren: 'src/app/components/portout/portout.module#PortoutModule'
  },
  {
    path: 'activation-service',
    loadChildren: 'src/app/components/activation-service/activation-service.module#ActivationServiceModule'
  },
  {
    path: 'lsr-activity',
    loadChildren: 'src/app/components/activation-lsr/activation-lsr.module#ActivationLsrModule'
  },
  {
    path:'lsr-order',
    loadChildren:'src/app/components/order-lsr/order-lsr.module#OrderLsrModule'
  },
  {
    path: 'order-management',
    loadChildren: 'src/app/components/order-management/order-management.module#OrderManagementModule'
  },
  {
    path: 'pon-activation',
    loadChildren: 'src/app/components/pon-activation/pon-activation.module#PonActivationModule'
  },
  {
    path: 'voice-complete-service-transfer',
    loadChildren: 'src/app/components/voice-complete-service-transfer/voice-complete-service-transfer.module#VoiceCompleteServiceTransferModule'
  },
  {
      path: 'support-tool',
      loadChildren: 'src/app/components/support-tool/support-tool.module#SupportToolModule'
  }
];
export const appRouting = RouterModule.forRoot(appRoutes);
