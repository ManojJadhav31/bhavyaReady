import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { ApiService } from './shared/services/api.service';
import { UtilityService } from './shared/services/utility.service';
import { StorageService } from './services/storage.service';
import { appRouting } from './app.routes';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DatePipe } from '@angular/common';

export function ConfigLoader(apiService: ApiService) {
  return () => apiService.getBaseUrl();
}

const GlobalServices = [
  UtilityService,
  ApiService,
  StorageService
];

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, BrowserAnimationsModule, appRouting, SharedModule],
  bootstrap: [AppComponent],
  providers: [GlobalServices, DatePipe,
    { provide: APP_INITIALIZER, useFactory: ConfigLoader, deps: [ApiService], multi: true, }
  ]
})
export class AppModule {
}
