import {AbstractControl, ValidatorFn} from '@angular/forms';


export function StateValidator (): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    const regexExpr = RegExp('(^[A-Za-z]{2}$)');
    const result = regexExpr.test(control.value);
    return result ? {'State': {value: control.value}} : null;
  };
}

export function ZipCodeValidator (): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    const regexExpr = RegExp('(^0[0-9]{4}$)');
    const result = regexExpr.test(control.value);
    return result ? {'ZipCode': {value: control.value}} : null;
  };
}
