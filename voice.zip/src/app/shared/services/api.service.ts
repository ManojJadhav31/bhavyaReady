import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';

@Injectable()
export class ApiService {

  public baseUrl: string = '';
  public envName: string = '';
  public sauiURL: string = '';
  public orderApiUrl: string = '';
  public portoutToolApiUrl: string = '';
  public saui3FlowURL: string = '';

  constructor( private http: HttpClient ) {
  }

  getBaseUrl() {
    return new Promise(( resolve, reject ) => {
      this.http.get('./ui/properties/all')
        .subscribe(res => {
          const data = ( res as any );
          this.baseUrl = data.baseUrl;
          this.envName = data.envName;
          this.sauiURL = data.sauiURL;
          console.log('baseUrl :' + this.baseUrl);
          console.log('envName:' + this.envName);
          console.log('sauiURL:' + this.sauiURL);

          if ( this.envName === 'prod' ) {
            this.orderApiUrl = this.baseUrl + 'order';
            this.portoutToolApiUrl = this.baseUrl + 'portout-tool';
            this.saui3FlowURL = this.sauiURL;
          } else {
            this.orderApiUrl = this.baseUrl + 'order-' + this.envName;
            this.portoutToolApiUrl = this.baseUrl + 'portout-tool-' + this.envName;
            this.saui3FlowURL = this.sauiURL;
          }
          resolve(true);
        }, error => {
          // this.baseUrl = 'http://10.193.244.230:8080/';
          this.baseUrl = 'http://voicemsidc01-env1:9999/';
          this.envName = 'env4';
          this.sauiURL = 'http://sldb-env1.level3.com/saui_update/SAUI_Update_Service';
          if ( this.envName === 'prod' ) {
            this.orderApiUrl = this.baseUrl + 'order';
            this.portoutToolApiUrl = this.baseUrl + 'portout-tool';
            this.saui3FlowURL = this.sauiURL;
          } else {
            this.orderApiUrl = this.baseUrl + 'order-' + this.envName;
            this.portoutToolApiUrl = this.baseUrl + 'portout-tool-' + this.envName;
            this.saui3FlowURL = this.sauiURL;
          }
          resolve(true);
        });
    });
  }

  // Mock  APi Service for test cases
  setLocalBaseUrl() {
    this.baseUrl = 'http://voicemsidc01-env1:9999/';
    this.envName = 'env2';

    if ( this.envName === 'prod' ) {
      this.orderApiUrl = this.baseUrl + 'order';
      this.portoutToolApiUrl = this.baseUrl + 'portout-tool';
    } else {
      this.orderApiUrl = this.baseUrl + 'order-' + this.envName;
      this.portoutToolApiUrl = this.baseUrl + 'portout-tool-' + this.envName;
    }
  }


  handleError( error ): Observable<string> {
    let message = '';
    if ( error.status === 400 ) {
      const innerError = error.error;
      if ( innerError && innerError.level3Response.exception.detail ) {
        message = innerError.level3Response.exception.detail;
      } else {
        message = 'An unexpected error occured, due to the services being down or technical error.';
      }
    } else if ( error.status === 400004 ) {
      const innerError = error.error;
      if ( innerError.level3Response.exception.detail ) {
        message = innerError.level3Response.exception.detail;
      } else {
        message = 'An unexpected error occured, due to the services being down or technical error.';
      }
    } else if ( error.status === 500 ) {
      const innerError = error.error;
      if ( innerError.level3Response.exception.detail ) {
        message = innerError.level3Response.exception.detail;
      } else {
        message = 'An unexpected error occured, due to the services being down or technical error.';
      }
    } else if(error.status === 500001) {
      const innerError =  error.error;
      if(innerError.level3Response.exception.detail) {
        message = innerError.level3Response.exception.detail
      } else {
        message = 'An unexpected error occured, due to the services bwing down or technical error.'
      }
    }else if ( error.status === 204 ) {
      const innerError = error.error;
      if ( innerError.level3Response.exception.detail ) {
        message = innerError.level3Response.exception.detail;
      }
    } else if ( error._body ) {
      if ( error._body.type === 'error' ) {
        message = 'Error calling backend service';
      } else {
        if ( error.json() ) {
          message = error.json().level3Response.exception.detail + error.json().level3Response.exception.message;
        } else {
          message = error;
        }
      }
    } else {
      message = 'An unexpected error occured, due to  the services being down or technical error.';
    }
    return throwError(message);
  }

  handleException( error ) {
    let message = '';
    if ( error.status === 500 ) {
      const innerError = error.error;
      if ( error.error === 'Internal Server Error' ) {
        message = 'this error occurs when here is error while exporting a file with large records';
      } else if ( innerError && innerError.message ) {
        message = innerError.message;
      }
    } else if(error.status === 500001) {
      const innerError = error.error;
      if(error.error === '500001') {
        message = innerError.level3Response.exception.detail;
      } else {
        message = 'An unexpected error occured,  due to the services being down or technical error'
      }
    } else if ( error.status === 400004 ) {
      const innerError = error.error;
      if ( innerError.level3Response.exception.detail ) {
        message = innerError.level3Response.exception.detail;
      } else {
        message = 'An unexpected error occured, due to  the services being down or technical error.';
      }
    } else if ( error.status === 400 ) {
      const innerError = error.error;
      if ( innerError && innerError.message ) {
        message = innerError.message;
      }
    } else if ( error.status === 0 ) {
      message = 'Error calling backend service';
    } else {
      message = 'An unexpected error occured, due to  the services being down or technical error.';
    }
    return throwError(message);
  }
}
