import { Injectable } from '@angular/core';
import * as dateFn from 'date-fns';
import { DatePipe } from '@angular/common';

@Injectable()
export class UtilityService {


  constructor(private datePipe: DatePipe) {
  }

  parseDate(dateTime, format): string {
    if (dateTime == null)
      return;
    let _date = null;
    if (dateTime instanceof Date) {
      _date = dateTime;
    } else {
      _date = dateTime.split('T')[0];
    }
    const date = new Date(_date);
    let strDate = date.toISOString().substring(0, 10);
    if (format === 'mdy') {
      const dArray = strDate.split('-');
      strDate = dArray[1] + '/' + dArray[2] + '/' + dArray[0];
    }

    return strDate;
  }

  getFormatedDate(date: Date, format: string = 'MM/dd/yyyy 12:00:00 aa'): string {
    return this.datePipe.transform(date, format)
  }

  getCorrelationId(prefix: string = 'SLDB-'): string {
    const dateTime = new Date();
    return prefix + dateTime.getTime();
  }

  getSystemId(): string {
    return 'User';
  }

  getUserId() {
    return localStorage.getItem('UserName');
  }

  createArrayFromTextArea(value): any[] {
    const newValue = value.replace(new RegExp('\r?\n', 'g'), ',');
    const extOrder = newValue.split(',');
    if (extOrder.length > 0) {
      return extOrder.filter((object) => {
        return object ? true : false;
      });
    }
    return [value];
  }

  fillDateTypePayload(activitySearch, body) {
    switch (activitySearch.selectedDateType) {
      case 'BillStartDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.billStartDateFrom = activitySearch.selectedDateFromDate;
          body.billStartDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.billStartDateFrom = relativeDate.fromDate;
          body.billStartDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerCommitDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.commitDateFrom = activitySearch.selectedDateFromDate;
          body.commitDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.commitDateFrom = relativeDate.fromDate;
          body.commitDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerRequestDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.customerRequestDateFrom = activitySearch.selectedDateFromDate;
          body.customerRequestDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.customerRequestDateFrom = relativeDate.fromDate;
          body.customerRequestDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerAcceptanceDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.customerAcceptDateFrom = activitySearch.selectedDateFromDate;
          body.customerAcceptDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.customerAcceptDateFrom = relativeDate.fromDate;
          body.customerAcceptDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'FocDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.lnpFocDateFrom = activitySearch.selectedDateFromDate;
          body.lnpFocDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.lnpFocDateFrom = relativeDate.fromDate;
          body.lnpFocDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'InstallDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.installDateFrom = activitySearch.selectedDateFromDate;
          body.installDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.installDateFrom = relativeDate.fromDate;
          body.installDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'LastUpdatedDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.lastUpdatedDateFrom = activitySearch.selectedDateFromDate;
          body.lastUpdatedDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.lastUpdatedDateFrom = relativeDate.fromDate;
          body.lastUpdatedDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'OrderCompletionDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.orderCompleteDateFrom = activitySearch.selectedDateFromDate;
          body.orderCompleteDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.orderCompleteDateFrom = relativeDate.fromDate;
          body.orderCompleteDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'orderCompleteDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.orderCompleteDateFrom = activitySearch.selectedDateFromDate;
          body.orderCompleteDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.orderCompleteDateFrom = relativeDate.fromDate;
          body.orderCompleteDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'OrderDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.orderDateFrom = activitySearch.selectedDateFromDate;
          body.orderDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.orderDateFrom = relativeDate.fromDate;
          body.orderDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'PortRequestDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.portRequestedDateFrom = activitySearch.selectedDateFromDate;
          body.portRequestedDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.portRequestedDateFrom = relativeDate.fromDate;
          body.portRequestedDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'RevisedCommitDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.revisedCommitDateFrom = activitySearch.selectedDateFromDate;
          body.revisedCommitDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.revisedCommitDateFrom = relativeDate.fromDate;
          body.revisedCommitDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'DesiredDueDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.desiredDueDateFrom = activitySearch.selectedDateFromDate;
          body.desiredDueDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.desiredDueDateFrom = relativeDate.fromDate;
          body.desiredDueDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'ActivityCreateDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.activityCreateDateFrom = activitySearch.selectedDateFromDate;
          body.activityCreateDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.activityCreateDateFrom = relativeDate.fromDate;
          body.activityCreateDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'ActivityCompleteDate': {
        if (activitySearch.selectedDateCategories === 'range') {
          body.activityCompleteDateFrom = activitySearch.selectedDateFromDate;
          body.activityCompleteDateTo = activitySearch.selectedDateToDate;
        } else if (activitySearch.selectedDateCategories === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRange);
          body.activityCompleteDateFrom = relativeDate.fromDate;
          body.activityCompleteDateTo = relativeDate.toDate;
        }
        break;
      }
    }
  }

  fillDateTypeSecondaryPayload(activitySearch, body) {
    switch (activitySearch.selectedDateTypeSecondary) {
      case 'BillStartDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.billStartDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.billStartDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.billStartDateFrom = relativeDate.fromDate;
          body.billStartDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerCommitDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.commitDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.commitDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.commitDateFrom = relativeDate.fromDate;
          body.commitDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerRequestDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.customerRequestDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.customerRequestDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.customerRequestDateFrom = relativeDate.fromDate;
          body.customerRequestDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerAcceptanceDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.customerAcceptDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.customerAcceptDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.customerAcceptDateFrom = relativeDate.fromDate;
          body.customerAcceptDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'FocDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.lnpFocDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.lnpFocDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.lnpFocDateFrom = relativeDate.fromDate;
          body.lnpFocDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'InstallDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.installDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.installDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.installDateFrom = relativeDate.fromDate;
          body.installDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'LastUpdatedDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.lastUpdatedDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.lastUpdatedDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.lastUpdatedDateFrom = relativeDate.fromDate;
          body.lastUpdatedDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'OrderCompletionDate': {
        if (activitySearch.orderComz === 'range') {
          body.orderCompleteDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.orderCompleteDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.orderCompleteDateFrom = relativeDate.fromDate;
          body.orderCompleteDateTo = relativeDate.toDate;
        }

        break;
      }
      case 'OrderDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.orderDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.orderDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.orderDateFrom = relativeDate.fromDate;
          body.orderDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'PortRequestDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.portRequestedDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.portRequestedDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.portRequestedDateFrom = relativeDate.fromDate;
          body.portRequestedDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'RevisedCommitDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.revisedCommitDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.revisedCommitDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.revisedCommitDateFrom = relativeDate.fromDate;
          body.revisedCommitDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'DesiredDueDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.desiredDueDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.desiredDueDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.desiredDueDateFrom = relativeDate.fromDate;
          body.desiredDueDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'ActivityCreateDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.activityCreateDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.activityCreateDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.activityCreateDateFrom = relativeDate.fromDate;
          body.activityCreateDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'ActivityCompleteDate': {
        if (activitySearch.selectedDateCategoriesSecondary === 'range') {
          body.activityCompleteDateFrom = activitySearch.selectedDateCategoriesSecondaryFromDate;
          body.activityCompleteDateTo = activitySearch.selectedDateCategoriesSecondaryToDate;
        } else if (activitySearch.selectedDateCategoriesSecondary === 'relative') {
          const relativeDate = this.getRelativeDate(activitySearch.selectedDateRangeSecondary);
          body.activityCompleteDateFrom = relativeDate.fromDate;
          body.activityCompleteDateTo = relativeDate.toDate;
        }
        break;
      }
    }
  }


  getRelativeDate(relation) {
    const relativeDate = {
      fromDate: new Date(),
      toDate: new Date()
    };
    let today = new Date();
    switch (relation) {
      case 'tomorrow': {
        const date = dateFn.addDays(today, 1);
        relativeDate.fromDate = date;
        relativeDate.toDate = date;
        break;
      }
      case 'yesterday': {
        const date = dateFn.addDays(today, -1);
        relativeDate.fromDate = date;
        relativeDate.toDate = date;
        break;
      }
      case 'nextBusinessDay': {
        const date = this.getNextBusinessDay(dateFn.addDays(today, 1));
        relativeDate.fromDate = date;
        relativeDate.toDate = date;
        break;
      }
      case 'previousBusinessDay': {
        const date = this.getPreviousBusinessDay(dateFn.addDays(today, -1));
        relativeDate.fromDate = date;
        relativeDate.toDate = date;
        break;
      }
      case 'next2Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 2);
        break;
      }
      case 'past2Days': {
        relativeDate.fromDate = dateFn.addDays(today, -2);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next3Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 3);
        break;
      }
      case 'past3Days': {
        relativeDate.fromDate = dateFn.addDays(today, -3);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next5Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 5);
        break;
      }
      case 'past5Days': {
        relativeDate.fromDate = dateFn.addDays(today, -5);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next10Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 10);
        break;
      }
      case 'past10Days': {
        relativeDate.fromDate = dateFn.addDays(today, -10);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'past30Days': {
        relativeDate.fromDate = dateFn.addDays(today, -30);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next30Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 30);
        break;
      }
      case 'past60Days': {
        relativeDate.fromDate = dateFn.addDays(today, -60);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'past90Days': {
        relativeDate.fromDate = dateFn.addDays(today, -90);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next5BusinessDays': {
        for (let i = 1; i <= 5; i++) {
          today = this.getNextBusinessDay(dateFn.addDays(today, 1));
          if (i === 1) {
            relativeDate.fromDate = today;
          } else if (i === 5) {
            relativeDate.toDate = today;
          }
        }
        break;
      }
      case 'past5BusinessDays': {
        for (let i = 1; i <= 5; i++) {
          today = this.getPreviousBusinessDay(dateFn.addDays(today, -1));
          if (i === 5) {
            relativeDate.fromDate = today;
          } else if (i === 1) {
            relativeDate.toDate = today;
          }
        }
        break;
      }
      case 'next10BusinessDays': {
        for (let i = 1; i <= 10; i++) {
          today = this.getNextBusinessDay(dateFn.addDays(today, 1));
          if (i === 1) {
            relativeDate.fromDate = today;
          } else if (i === 10) {
            relativeDate.toDate = today;
          }
        }
        break;
      }
      case 'past10BusinessDays': {
        for (let i = 1; i <= 10; i++) {
          today = this.getPreviousBusinessDay(dateFn.addDays(today, -1));
          if (i === 10) {
            relativeDate.fromDate = today;
          } else if (i === 1) {
            relativeDate.toDate = today;
          }
        }
        break;
      }
      case 'previous30DaysToNext60Days': {
        relativeDate.fromDate = dateFn.addDays(today, -30);
        relativeDate.toDate = dateFn.addDays(today, 60);
        break;
      }

      case 'today': {
        relativeDate.fromDate = today;
        relativeDate.toDate = today;
        break;
      }
    }
    return relativeDate;
  }

  getNextBusinessDay(date) {
    if (dateFn.getDay(date) === 6 || dateFn.getDay(date) === 0) {
      return this.getNextBusinessDay(dateFn.addDays(date, 1));
    } else {
      return date;
    }
  }

  getPreviousBusinessDay(date) {
    if (dateFn.getDay(date) === 6 || dateFn.getDay(date) === 0) {
      return this.getPreviousBusinessDay(dateFn.addDays(date, -1));
    } else {
      return date;
    }
  }
}


