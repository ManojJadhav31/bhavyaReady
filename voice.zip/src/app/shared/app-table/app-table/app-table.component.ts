import {
  AfterContentInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ContentChildren,
  EventEmitter,
  Input,
  OnInit,
  Output,
  QueryList,
  TemplateRef
} from '@angular/core';
import {PrimeTemplate} from 'primeng/shared';

@Component({
  selector: 'app-table',
  templateUrl: './app-table.component.html',
  styleUrls: ['./app-table.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppTableComponent implements OnInit, AfterContentInit {

  @Input('show-footer') showFooter = false;
  @Input('pageSize') rows = 100;
  @Input('first') first = 0;
  @Input('rowsPerPageOptions') rowsPerPageOptions: number[] = [50, 100, 200, 500, 1000, 10000];
  @Input('paginatorDropdownAppendTo') paginatorDropdownAppendTo: number;
  @Input('table-height') tableHeight = 200;
  @Input('row-height') rowHeight = 30;
  @Input('column-title') columnTitle = 'caption';
  @Input('column-value') columnValue = 'value';

  @Input() loadingIcon: string = 'pi pi-spinner';
  @Input() loading: boolean;

  @ContentChildren(PrimeTemplate) templates: QueryList<PrimeTemplate>;
  headerTemplate: TemplateRef<any>;
  bodyTemplate: TemplateRef<any>;
  captionTemplate: TemplateRef<any>;
  footerTemplate: TemplateRef<any>;
  @Output('onPageChange') public onPageChange = new EventEmitter();

  @Input('totalRecords')
  set totalRecords(value) {
    this._totalRecords = value;
  }

  public _totalRecords = 0;

  @Input('value')
  set value(value) {
    if (value) {
      this.actualData = value;
      this.setTableHeight();
    }
  }

  @Input('columns')
  set columns(value) {
    if (value) {
      this._columns = value;
    }
  }

  _columns: any[] = [];
  actualData: any[] = [];
  showTable = true;
  sort = {
    type: 'ASC',
    field: ''
  };

  constructor(private changeDetector: ChangeDetectorRef) {
  }

  ngOnInit(): void {
  }

  onPageChanges($event) {
    this.onPageChange.emit($event);
  }

  setTableHeight() {

    if (this.actualData.length <= 0) {
      this.tableHeight = 80;
    } 
    else if (this.actualData.length <= 10) {
      this.tableHeight = 400;
    } else if (this.actualData.length <= 20) {
      this.tableHeight = 400;
    } else if (this.actualData.length <= 50) {
      this.tableHeight = 470;
    } else if (this.actualData.length <= 100) {
      this.tableHeight = 570;
    } else if (this.actualData.length <= 200) {
      this.tableHeight = 580;
    } else if (this.actualData.length <= 500) {
      this.tableHeight = 600;
    } else if (this.actualData.length <= 1000) {
      this.tableHeight = 610;
    } 
    else {
      this.tableHeight = 630;
    }
  }

  ngAfterContentInit(): void {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case 'caption':
          this.captionTemplate = item.template;
          break;

        case 'header':
          this.headerTemplate = item.template;
          break;

        case 'body':
          this.bodyTemplate = item.template;
          break;

        case 'footer':
          this.footerTemplate = item.template;
          break;
      }
    });
  }

  sortByColumn(column) {
    if (this.sort.field === column[this.columnValue] || this.sort.field === '-' + column[this.columnValue]) {
      this.sort.type = this.sort.type === 'ASC' ? 'DESC' : 'ASC';
      if (this.sort.type === 'ASC') {
        this.sort.field = column[this.columnValue];
      } else {
        this.sort.field = '-' + column[this.columnValue];
      }
    } else {
      this.sort.type = 'DESC';
      this.sort.field = '-' + column[this.columnValue];
    }
  }

}
