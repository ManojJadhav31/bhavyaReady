import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {AppTableComponent} from './app-table.component';
import {CommonModule} from '@angular/common';
import {PaginatorModule} from 'primeng/primeng';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {NgPipesModule} from 'ngx-pipes';

describe('AppTableComponent', () => {
  let component: AppTableComponent;
  let fixture: ComponentFixture<AppTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule, PaginatorModule, ScrollingModule, NgPipesModule],
      declarations: [AppTableComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
