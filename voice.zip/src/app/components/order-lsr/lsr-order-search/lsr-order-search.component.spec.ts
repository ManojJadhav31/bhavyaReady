import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LsrOrderSearchComponent } from './lsr-order-search.component';

describe('LsrOrderSearchComponent', () => {
  let component: LsrOrderSearchComponent;
  let fixture: ComponentFixture<LsrOrderSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LsrOrderSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LsrOrderSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
