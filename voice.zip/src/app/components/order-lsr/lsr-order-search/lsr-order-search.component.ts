import { Component, OnInit, ViewChild } from '@angular/core';
import { StorageService } from '../../../services/storage.service';
import { ColumnPickListDialogComponent } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog/column-pick-list-dialog.component';
import { Observable, Subscription, forkJoin } from 'rxjs';
import { UtilityService } from '../../../shared/services/utility.service';
import * as dateFn from 'date-fns';
import * as XLSX from 'xlsx';
import { LsrOrderSearchService } from '../services/lsr-order-search.service';
import { LsrOrderSearchDTOs, LsrOrderResult } from '../order-lsr.constants';
import { UpdateOrderDateDialogComponent } from '../../dialog/update-order-date-dialog/update-order-date-dialog.component';
import { TransactionViewDialogComponent } from '../../dialog/transaction-view-dialog/transaction-view-dialog/transaction-view-dialog.component';
import { LsrSearchRequest } from '../../search-panels/search-panel-constants';
import { LsrOrderSearchResultsGridColumns } from '../lsr-order-search/lsr-order-search-results-grid-columns';
import { LsrActivityAgentAssignDialogService } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.service';
import { AssignAgentRequest } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.constants';
import { LsrActivityAgentAssignDialogComponent } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.component';
import { UpdateFocAndCrdDialogComponent } from '../../dialog/update-foc-and-crd-dialog/update-foc-and-crd-dialog/update-foc-and-crd-dialog.component';
import { UpdateReasonDialogComponent } from '../../dialog/update-reason-dialog/update-reason-dialog.component';


@Component({
  selector: 'app-lsr-order-search',
  templateUrl: './lsr-order-search.component.html',
  styleUrls: ['./lsr-order-search.component.scss']
})
export class LsrOrderSearchComponent implements OnInit {
  public orderSearch: LsrSearchRequest = new LsrSearchRequest();
  public panelFilter: PanelFilter;
  public panelFilterList: string[] = [];
  public searchPanelCollapsed = {
    lsrSearch: false,
    lsrAdvancedSearch: false
  };
  public filerPanelsCheckBox = {
    lsrAdvancedSearch: []
  };
  displayCompletedActivitydialog = false;

  /** for pick list */
  @ViewChild('columnPickListDialog') columnPickListDialog: ColumnPickListDialogComponent;
  @ViewChild('transactionDetailsDialog') transactionDetailsDialog: TransactionViewDialogComponent;
  @ViewChild('updateFocAndCrdDialog') updateFocAndCrdDialog: UpdateFocAndCrdDialogComponent;
  @ViewChild('updateReasonDialog') updateReasonDialog: UpdateReasonDialogComponent;

  public lsrOrderSearchResultsGridColumns = LsrOrderSearchResultsGridColumns;
  public defaultGridColumns: string[] = ['carrierId', 'orderActivityIdPK', 'activityName', 'status', 'ponStatus', 'lsrStatus', 'completionDate', 'focDate', 'orderDate', 'customerRequestDate', 'purchaseOrderNumber',
    'ver', 'companyName', 'orderStatus', 'orderType', 'orderSource', 'activity', 'carrierAdditionalNotes', 'bizOrg', 'billingAccountNumber', 'resellerName', 'typeOfPort', 'businessName',
    'parentOrderId', 'product', 'city', 'state'];
  public gridColumnList: any[] = [];
  public hiddenColumns: any[] = [];

  /**table*/
  public isSearching = false;
  public selectedActivityIds: any[] = [];
  public searchResults: LsrOrderSearchDTOs[] = [];
  public filteredResults: LsrOrderSearchDTOs[] = [];
  public message;
  public updateError;
  public totalRecords = 0;
  public paginationObject = {
    pageNumber: 1,
    pageSize: 100,
    firstPage: 0,
    skip: 0
  };
  public selectAllCheckBox = ['false'];

  /**actions*/
  isExporting = false;
  actionToPerform = { name: 'Export', code: 'export' };
  exportType: any = { name: 'Selected Result', code: 'selected' };
  actionDropdownOptions: any[] = [
    { name: 'export', code: 'export' }
  ];
  exportOptions: any = [
    { name: 'All Results', code: 'all' },
    { name: 'Selected Result', code: 'selected' }
  ];
  updateOptions: any = [
    { name: 'All Displayed Results', code: 'all' },
    { name: 'Selected Result', code: 'selected' }
  ];
  updateAction = {
    type: { name: 'Selected Activities', code: 'selected' },
    operation: { name: 'Restart Activity', code: 'restartActivity' }
  };
  updateActionReason = { name: 'Choose', code: '' };

  resultType: any = {
    code: 'all'
  };
  updateErrorShowTrunk = {
    length: 500,
    showMore: false
  };
  updateErrorMesg = '';
  successMessage = '';
  isUpdating: boolean = false;
  resultOptions: any = [
    { name: 'Export Results', code: 'all' },
    // { name: 'Export All', code: 'exportAll' },
    // { name: 'Export TNS', code: 'tns' }

  ];

  public searchSubscription: Subscription;
  UserName: string;

  /**assign agent dialog*/
  @ViewChild('activityAgentAssignDialog') activityAgentAssignDialog: LsrActivityAgentAssignDialogComponent;

  constructor(public storageService: StorageService, public utilSerivce: UtilityService, public lsrOrderSearchService: LsrOrderSearchService,
    public lsrActivityAgentAssignDialogService: LsrActivityAgentAssignDialogService) {
  }

  ngOnInit() {
    this.storageService.setModule('lsr-order');
    this.UserName = localStorage.getItem('UserName') !== 'undefined' ? localStorage.getItem('UserName') : undefined;
    if (this.UserName) {
      this.actionDropdownOptions.push({ name: 'Update FOC and CRD', code: 'updateFOCandCRD' });
      this.actionDropdownOptions.push({ name: 'Cancel', code: 'cancelLsrOrder' });
    }
    this.orderSearch.selectedDateType = 'All';
    this.panelFilter = {
      lsrSearch: false,
      lsrAdvancedSearch: false
    };

    const columnList = JSON.parse(JSON.stringify(this.lsrOrderSearchResultsGridColumns));
    columnList.forEach((item) => {
      if (this.defaultGridColumns.indexOf(item.value) !== -1) {
        item.visible = true;
      }
    });
    this.gridColumnList = columnList.filter(item => item.visible);
    console.log(this.gridColumnList);
    this.hiddenColumns = columnList.filter(item => !item.visible);
    this.setPresetData();
  }
  setPresetData() {

    const searchDetails = this.storageService.getSearchDetails();
    if (searchDetails) {
      if (searchDetails.formData) {
        Object.assign(this.orderSearch, searchDetails.formData);
      }
      if (searchDetails.results) {
        Object.assign(this.searchResults, searchDetails.results);
        this.totalRecords = searchDetails.totalRecords;
        Object.assign(this.filteredResults, searchDetails.results);
        this.paginationObject.skip = 0;
        this.searchPanelCollapsed['mainSearch'] = true;
      }
      if (searchDetails.pageConfig) {
        this.paginationObject.firstPage = searchDetails.pageConfig.firstPage;
        this.paginationObject.pageNumber = searchDetails.pageConfig.pageNumber;
        this.paginationObject.pageSize = searchDetails.pageConfig.pageSize;
      }

      if (searchDetails.panelList) {
        searchDetails.panelList.forEach((key) => {
          if (searchDetails.results && searchDetails.totalRecords) {
            this.searchPanelCollapsed[key] = true;
          }
          this.filerPanelsCheckBox[key] = ['true'];
          this.filterPanels(key, true);
        });
      }

      const pickListDetails = this.storageService.getPickList();
      if (pickListDetails) {
        this.hiddenColumns = pickListDetails.hiddenColumns;
        this.gridColumnList = pickListDetails.gridColumnList;
      }
    }
  }

  filterPanels(key, event) {
    if (key === 'lsrAdvancedSearch') {
      this.panelFilter.lsrAdvancedSearch = event;
    }
    if (event) {
      const index = this.panelFilterList.indexOf(key);
      if (index === -1) {
        this.panelFilterList.push(key);
      }
    } else {
      const index = this.panelFilterList.indexOf(key);
      if (index !== -1) {
        this.panelFilterList.splice(index, 1);
      }
    }
    this.storageService.storePanelSearchList(this.panelFilterList);
  }

  showHideColumnFilterDialog() {
    this.columnPickListDialog.showDialog = true;
  }

  onPickListChange(list: any[]) {
    this.gridColumnList = JSON.parse(JSON.stringify(list));
  }

  onRowCheckboxChnage(event, row) {
    const selectedResult = this.filteredResults.filter(item => {
      if (item.checked && item.checked[0] === 'true') {
        return true;
      } else {
        return false;
      }
    });
    if (selectedResult.length > 0 && (this.filteredResults.length === selectedResult.length)) {
      this.selectAllCheckBox = ['true'];
    } else {
      this.selectAllCheckBox = [];
    }

    if (event) {
      this.selectedActivityIds.push(row);
    } else {
      const index = this.selectedActivityIds.findIndex((obj) => {
        return obj.orderActivityIdPK === row.orderActivityIdPK;
      });
      if (index !== -1) {
        this.selectedActivityIds.splice(index, 1);
      }
    }
  }

  checkAllRows(event) {
    this.filteredResults.forEach(row => {
      if (this.actionToPerform.code === 'export') {
        row.checked = event ? ['true'] : [];
        if (event) {
          this.selectedActivityIds.push(row);
        }
      } else if (event) {
        if (!this.checkDisable(row, this.actionToPerform)) {
          row.checked = event ? ['true'] : [];
          if (event) {
            this.selectedActivityIds.push(row);
          }
        }
      } else {
        row.checked = event ? ['true'] : [];
        if (event) {
          this.selectedActivityIds.push(row);
        }
      }
    });
    if (!event) {
      this.selectedActivityIds = [];
    }
  }
  onChangeAction(event, action) {
    this.filteredResults.forEach(row => {
      if (this.checkDisable(row, action)) {
        row.checked = [];
      } else if (this.checkDisable(row, action)) {
        row.checked = [];
      }
    });
  }

  checkDisable(row, action): boolean {
    if (action.code === 'updateFOCandCRD' || action.code === 'cancelLsrOrder') {
      if (row.orderStatus === 'Completed' || row.orderSource === 'Project Portout Tool') {
        return true;
      }
    }
    return false;
  }

  exportExcelLocally(options, exportData) {
    debugger
    if (exportData.length > 0) {
      const xlsData = [];
      xlsData.push(options.headers);
      exportData.forEach(f => {
        const arr = [];
        Object.keys(f).forEach(key => {
          arr.push(f[key]);
        });
        xlsData.push(arr);
      });
      const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(xlsData);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      XLSX.writeFile(wb, 'OrderResults.csv');
    }
    this.isExporting = false;
  }

  exportExcelFromService(exportColumns?: string[]) {
    this.createBodyForService(this.orderSearch).subscribe((returnBody) => {
      if (exportColumns) {
        returnBody['exportColumns'] = exportColumns;
      }
      this.lsrOrderSearchService.getExportDetail(returnBody).subscribe((response) => {
        const url = window.URL.createObjectURL(response.data);
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.setAttribute('style', 'display:none');
        a.href = url;
        a.download = response.fileName;
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        this.isExporting = false;
      }, error => {
        this.message = error;
        this.isExporting = false;
      });
    });
  }

  exportOrderSearch() {
    debugger
    let exportData = [];
    if (this.filteredResults.length > 0) {
      this.isExporting = true;
      const options = {
        showLabels: true,
        headers: this.gridColumnList.map(col => {
          return col.caption;
        })
      };
      let selectedResult = this.filteredResults.filter(item => {
        if (item.checked && item.checked[0] === 'true') {
          return true;
        } else {
          return false;
        }
      });
      if (this.exportType.code === 'selected') {
        if (this.resultType.code === 'tns') {
          options.headers = ['TN'];
          exportData = selectedResult.map(row => {
            const data = {};
            data['tn'] = row['tn'];
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else if (this.resultType.code === 'all') {
          exportData = selectedResult.map(row => {
            const data = {};
            this.gridColumnList.forEach(col => {
              data[col.value] = row[col.value] || '';
            });
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else {
          this.isExporting = false;
        }
      } else if (this.exportType.code === 'all') {
        if (this.resultType.code === 'tns') {
          this.exportExcelFromService(['tn']);
        } else if (this.resultType.code === 'all') {
          selectedResult = this.filteredResults;
          exportData = selectedResult.map(row => {
            const data = {};
            this.gridColumnList.forEach(col => {
              data[col.value] = row[col.value] || '';
            });
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else if (this.resultType.code === 'exportAll') {
          const exportColumns = this.gridColumnList.map(col => {
            return col.value;
          });
          this.exportExcelFromService(exportColumns);
        } else {
          this.isExporting = false;
        }
      } else {
        this.isExporting = false;
      }
    }
  }

  filterGridResults(value, filter) {
    const results = [];
    if (value) {
      this.gridColumnList.forEach(col => {
        this.searchResults.forEach(item => {
          if (item[col.value]) {
            if (item[col.value].toString().toLowerCase().indexOf(value.toLowerCase()) !== -1) {
              if (results.indexOf(item) === -1) {
                results.push(item);
              }
            }
          }
        });
      });
      this.filteredResults = results;
    } else {
      this.filteredResults = this.searchResults;
    }
  }

  loadSearchResults(event, filteredResults) {
    this.updateError = '';
    const selectedActivitiesIds: Array<string> = [];
    this.paginationObject.firstPage = event.first;
    this.paginationObject.pageNumber = (event.first / event.rows) + 1;
    this.paginationObject.pageSize = event.rows;
    filteredResults.forEach(item => {
      if (item.checked && item.checked[0] === 'true') {
        selectedActivitiesIds.push(item.orderActivityIdPK);
      }
    });
    this.storageService.storeSelectedActivityIds(selectedActivitiesIds, false);
    this.storageService.storeSearchDetailsGridPage(this.paginationObject.pageNumber, this.paginationObject.pageSize, this.paginationObject.firstPage);
    if (this.totalRecords > 0) {
      this.search(true);
    }
  }

  clearForm() {
    /*to clear stored search details*/
    this.storageService.resetDetails();
    this.setPresetData();
    this.isUpdating = false;
    this.isExporting =false;
    this.isSearching = false;
    this.message = '';
    // change to make clear button work
    this.orderSearch = new LsrSearchRequest();
    this.orderSearch.selectedDateType = 'All';
    this.searchResults = [];
    this.paginationObject = {
      pageNumber: 1,
      pageSize: this.paginationObject.pageSize,
      firstPage: 0,
      skip: 0
    };
    this.totalRecords = 0;
    this.filteredResults = [];
    this.orderSearch.isDisplayable = 'Y';
    // this.orderSearch.orderActive = 'Y';
    this.message = '';
    this.updateError = '';
    this.successMessage = '';
  }

  search(checkCheckbox = false) {
    this.updateError = '';
    this.message = '';
    this.selectedActivityIds = [];
    this.paginationObject.pageNumber = 1;
    this.paginationObject.firstPage = 0;
    this.storageService.storeSelectedActivityIds([], true);
    this.searchOrderActivities();
  }

  searchOrderActivities(checkCheckbox = false) {
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
    console.log(this.orderSearch);
    this.orderSearch.noData = {
      error: false
    };
    if (this.orderSearch.parentOrderId || this.orderSearch.extOrderId || this.orderSearch.wtn || (this.orderSearch.wtn === null && this.orderSearch.tns) || this.orderSearch.selectedDateType !== 'All') {
      this.orderSearch.requiredFieldsError = {
        error: false
      };
    } else {
      this.orderSearch.requiredFieldsError = {
        error: true,
        msg: 'Please enter at least one of the required fields'
      };
      return;
    }
    if (this.orderSearch.requiredFieldsError.error === false) {
      if (this.orderSearch.selectedDateType !== 'All') {
        this.utilSerivce.fillDateTypePayload(this.orderSearch, this.orderSearch);
        let error = false;
        if (this.orderSearch.parentOrderId || this.orderSearch.wtn || this.orderSearch.extOrderId) {
          error = false;
        } else if (this.orderSearch.selectedDateCategories === 'range' && this.checkNonRequiredField(this.orderSearch)) {
          if (dateFn.differenceInCalendarDays(this.orderSearch.selectedDateToDate, this.orderSearch.selectedDateFromDate) >= 90) {
            error = true;
          }
        } else if (this.orderSearch.selectedDateCategories === 'relative' && this.orderSearch.selectedDateRange === 'pass90Days' && this.checkNonRequiredField(this.orderSearch)) {
          error = true;
        }
        if (error) {
          this.orderSearch.requiredFieldsError = {
            error: true,
            msg: 'You can not select date type past 90 days date'
          };
          return;
        }
      }
    }

    this.createBodyForService(this.orderSearch).subscribe((returnBody) => {
      const body = returnBody;
      this.searchResults = [];
      this.filteredResults = [];
      this.totalRecords = 0;
      // this.skip = 0;
      this.isSearching = true;
      this.message = '';
      this.searchSubscription = this.lsrOrderSearchService.searchOrderActivities(body, this.paginationObject.pageSize, this.paginationObject.pageNumber).subscribe((res: LsrOrderResult) => {
        this.isSearching = false;
        const data = (res as any);
        if (data.lsrOrderSearchDTOs && data.lsrOrderSearchDTOs.length > 0) {
          this.searchPanelCollapsed = {
            lsrAdvancedSearch: true,
            lsrSearch: true
          };
          // make activity as select to update
          const orderSearchResult = JSON.parse(JSON.stringify(data.lsrOrderSearchDTOs));
          if (checkCheckbox) {
            orderSearchResult.forEach(activity => {
              const findObject = this.selectedActivityIds.find(obj => obj.orderActivityIdPK === activity.orderActivityIdPK);
              if (findObject) {
                activity.checked = 'true';
              }
            });
          } else {
            this.selectedActivityIds = [];
          }
          this.searchResults = orderSearchResult;
          this.filteredResults = orderSearchResult;
          this.totalRecords = data.totalRecordsCount;
          this.paginationObject.skip = 0;
          /*used to store current search details*/
          this.storageService.storeSearchDetails(this.orderSearch, this.searchResults, this.totalRecords);
        } else {
          this.orderSearch.noData = {
            error: true
          };
        }
      }, error => {
        this.message = error;
        this.isSearching = false;
      });
    });
  }

  checkNonRequiredField(orderSearch) {
    if (orderSearch.purchaseOrderNumber || orderSearch.activityName || orderSearch.isDisplayable || orderSearch.orderStatus
      || orderSearch.companyName || orderSearch.assignedAgent || orderSearch.orderType || orderSearch.ponStatus || orderSearch.lsrStatus || orderSearch.selectedDateCategoriesSecondaryToDate || orderSearch.selectedDateCategoriesSecondaryFromDate) {
      return true;
    }
    if (this.filerPanelsCheckBox.lsrAdvancedSearch[0] && this.filerPanelsCheckBox.lsrAdvancedSearch[0] === 'true') {
      if (orderSearch.billingAccountNumber || orderSearch.ver || orderSearch.typeOfPort || orderSearch.resellerName || orderSearch.businessName
        || orderSearch.lastName || orderSearch.firstName || orderSearch.contactName) {
        return true;
      }
    }
    return false;
  }

  createBodyForService(orderSearch): Observable<any> {
    return new Observable((observer) => {
      const body: any = {};

      // ----------- Default Search Params -----------
      body.isDisplayable = orderSearch.isDisplayable || undefined;
      body.orderType = orderSearch.orderType || undefined;
      body.purchaseOrderNumber = orderSearch.purchaseOrderNumber || undefined;
      // body.orderActive = orderSearch.orderActive || undefined;
      body.companyName = orderSearch.companyName || undefined;
      body.assignedAgent = orderSearch.assignedAgent || undefined;
      // if (orderSearch.status && orderSearch.status.length > 0) {
      //   body.activityStatusList = orderSearch.status;
      // }
      if (orderSearch.activityName && orderSearch.activityName.length > 0) {
        body.activityNameList = orderSearch.activityName;
      }
      if (orderSearch.orderStatus && orderSearch.orderStatus.length > 0) {
        body.orderStatusList = orderSearch.orderStatus;
      }
      if (orderSearch.ponStatus && orderSearch.ponStatus.length > 0) {
        body.ponStatusList = orderSearch.ponStatus;
      }
      if (orderSearch.lsrStatus && orderSearch.lsrStatus.length > 0) {
        body.lsrStatusList = orderSearch.lsrStatus;
      }
      if (orderSearch.showTnTextArea) {
        body.tns = this.utilSerivce.createArrayFromTextArea(orderSearch.tns);
      } else {
        if (orderSearch.wtn) {
          body.tns = this.utilSerivce.createArrayFromTextArea(orderSearch.wtn);
        }
      }
      if (body.tns) {
        if (body.tns.length === 0) {
          delete body.tns;
        }
      }
      if (orderSearch.parentOrderId) {
        body.parentOrderIds = this.utilSerivce.createArrayFromTextArea(orderSearch.parentOrderId);
      }
      if (orderSearch.extOrderId) {
        body.extOrderIds = this.utilSerivce.createArrayFromTextArea(orderSearch.extOrderId);
      }
      if (orderSearch.selectedDateType !== 'All') {
        this.utilSerivce.fillDateTypePayload(orderSearch, body);
      }

      //  ----------- LSR Advanced Search -----------
      body.billingAccountNumber = orderSearch.billingAccountNumber || undefined;
      body.ver = orderSearch.ver || undefined;
      body.businessName = orderSearch.businessName || undefined;
      body.lastName = orderSearch.lastName || undefined;
      body.contactName = orderSearch.contactName || undefined;
      body.firstName = orderSearch.firstName || undefined;
      body.typeOfPort = orderSearch.typeOfPort || undefined;
      body.resellerName = orderSearch.resellerName || undefined;

      observer.next(body);
    });
  }

  onAssignAgent(dataItem: LsrOrderSearchDTOs) {
    this.successMessage = null;
    this.updateError = null;
    this.activityAgentAssignDialog.requestPayload = new AssignAgentRequest();
    this.activityAgentAssignDialog.requestPayload.carrierRequestId = dataItem.carrierId;
    this.activityAgentAssignDialog.requestPayload.userId = this.utilSerivce.getUserId();
    this.activityAgentAssignDialog.requestPayload.systemId = this.utilSerivce.getSystemId();
    this.activityAgentAssignDialog.requestPayload.correlationId = this.utilSerivce.getCorrelationId();
    this.activityAgentAssignDialog.showDialog = true;
  }

  onAgentSubmit() {
    this.lsrActivityAgentAssignDialogService.assignAgent(this.activityAgentAssignDialog.requestPayload).subscribe((response: any) => {
      if (response.errorCode === 0) {
        this.successMessage = 'Assigned agent successfully updated.'
      } else {
        this.updateError = response.errorMessage;
      }
      this.activityAgentAssignDialog.showDialog = false;
      this.activityAgentAssignDialog.requestPayload = new AssignAgentRequest();
      this.searchOrderActivities();
    }, (error) => this.updateError = error);
  }

  updateLsrOrderFOC() {
    this.updateFocAndCrdDialog.displayDialog = true;
    this.updateFocAndCrdDialog.setRequest();
  }

  onUpdateFocAndCrdDialogSubmit(event) {
    console.log(event);
    this.updateFocAndCrdDialog.displayDialog = false;
    this.onUpdateLsrOrder(event);
  }

  onOpenReasonDialog() {
    this.updateReasonDialog.setUserId();
    this.updateReasonDialog.displaDialog = true;
  }

  onReasonSubmit(event) {
    this.updateReasonDialog.displaDialog = false;
    this.onUpdateLsrOrder(event.errorMessage);
  }

  openTransactionDialog() {
    this.transactionDetailsDialog.loadErrorList();
    this.transactionDetailsDialog.displayDialog = true;
  }

  onCloseTransactionDialog() {
    this.transactionDetailsDialog.displayDialog = false;
  }

  onUpdateLsrOrder(extraDetails?: any) {
    this.updateError = '';
    this.updateErrorMesg = '';
    this.successMessage = '';
    let exportData = [];
    if (this.filteredResults.length > 0) {
      this.isUpdating = true;
      exportData = this.selectedActivityIds;
      if (this.exportType.code === 'all') {
        exportData = this.filteredResults.filter(item => {
          if (item.orderStatus !== 'Completed') {
            return true;
          } else {
            return false;
          }
        });
        if (exportData.length === 0) {
          this.isUpdating = false;
          this.updateError = 'Trying to Perform ' + this.actionToPerform.name + ' Action on Completed Activities & on Project Portout Tool Orders';
          return;
        }
      } else if (exportData.length === 0) {
        this.isUpdating = false;
        this.updateError = 'Please select atleast one record to perform action';
        return;
      }
      let count = 0;
      let hitApi = false;
      let activityIds = [];

      const dateTime = new Date();
      const dateTimeStr = 'SLDB-' + dateTime.getTime();

      let errorResponse = false;
      let successfulResponse = false;
      const listOfResultIds = [];

      const codeForAcvtivity = ['cancelLsrOrder'];
      const codeForParentId = ['updateFOCandCRD'];

      if (codeForAcvtivity.indexOf(this.actionToPerform.code) !== -1) {
        let extOrderId = exportData.map(
          object => object.extOrderId
        );
        extOrderId = extOrderId.filter(function (item, pos) {
          return extOrderId.indexOf(item) == pos;
        });
        console.log(extOrderId)
        const responseArray: any[] = [];
        switch (this.actionToPerform.code) {
          case 'cancelLsrOrder':
            for (let index = 0; index < extOrderId.length; index++) {
              const data = {
                extOrderId: extOrderId[index]
              }
              data['carrierSpid'] = exportData.find(e => e.extOrderId === extOrderId[index]).carrierSpid;
              this.lsrOrderSearchService.cancelLsrOrder(data, this.actionToPerform.code, dateTimeStr, extraDetails).subscribe((response) => {
                console.log(response);
                if (response.errorCode === 0 && !errorResponse) {
                  successfulResponse = true;
                  listOfResultIds.push(response);
                } else if (response.errorCode !== 0) {
                  errorResponse = true;
                  listOfResultIds.push(response);
                }

                if (successfulResponse) {
                  this.isUpdating = false;
                  if (exportData.length === 1) {
                    this.successMessage = 'Update Successful';
                  } else {
                    this.successMessage = 'multiple';
                    this.storageService.setTransactionActivityIds(listOfResultIds, this.actionToPerform.code, dateTime, true);
                  }
                } else if (errorResponse) {
                  this.isUpdating = false;
                  if (exportData.length === 1) {
                    this.updateError = response[0].errorMessage;
                  } else {
                    this.updateError = 'multiple';
                    this.storageService.setTransactionActivityIds(listOfResultIds, this.actionToPerform.code, dateTime);
                  }
                }
                this.searchOrderActivities();
              }, (error) => {
                this.updateErrorMesg = error;
                this.isUpdating = false;
              });
            }

        }
      } else if (codeForParentId.indexOf(this.actionToPerform.code) !== -1) {
        let parentOrderId = exportData.map(
          object => object.parentOrderId
        );
        parentOrderId = parentOrderId.filter(function (item, pos) {
          return parentOrderId.indexOf(item) == pos;
        });
        console.log(parentOrderId)
        const responseArray: any[] = [];
        switch (this.actionToPerform.code) {
          case 'updateFOCandCRD':
            for (let index = 0; index < parentOrderId.length; index++) {
              this.lsrOrderSearchService.updateLsrOrderRequest(parentOrderId[index], extraDetails, dateTimeStr).subscribe((response) => {
                extraDetails['orderComments'] = extraDetails.comments;
                extraDetails['dateType'] = 'CustomerRequestDate';
                extraDetails['newDate'] = extraDetails.date;
                response['parentOrderId'] = parentOrderId[index];
                response['for'] = 'FOC Date';
                if (response.errorCode === 0) {
                  successfulResponse = true;
                  listOfResultIds.push(response);
                } else if (response.errorCode !== 0) {
                  errorResponse = true;
                  listOfResultIds.push(response);
                }
                this.lsrOrderSearchService.updateActivitiesOrderDate(parentOrderId[index], extraDetails, dateTimeStr).subscribe((orderDateResponse) => {
                  orderDateResponse['parentOrderId'] = parentOrderId[index]
                  orderDateResponse['for'] = 'CRD';
                  if (orderDateResponse.errorCode === 0 && !errorResponse) {
                    successfulResponse = true;
                    listOfResultIds.push(orderDateResponse);
                  } else if (orderDateResponse.errorCode !== 0) {
                    errorResponse = true;
                    listOfResultIds.push(orderDateResponse);
                  }

                  if (successfulResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.successMessage = 'Update Successful';
                    } else {
                      this.successMessage = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.actionToPerform.code, dateTime, true);
                    }
                  } else if (errorResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.updateError = orderDateResponse[0].errorMessage;
                    } else {
                      this.updateError = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.actionToPerform.code, dateTime);
                    }
                  }
                  console.log(listOfResultIds);
                  this.searchOrderActivities();
                });
              }, (error) => {
                this.updateErrorMesg = error;
                this.isUpdating = false;
              });
            }

        }
      } else {
        this.isUpdating = false;
      }
    }
  }
}

interface PanelFilter {
  lsrSearch: boolean;
  lsrAdvancedSearch: boolean;
}

