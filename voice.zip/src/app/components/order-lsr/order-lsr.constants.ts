export interface LsrOrderResult {
    lsrOrderSearchDTOs: LsrOrderSearchDTOs[];
    totalElementsCount: number;
  }

export interface LsrOrderSearchDTOs {
    activity: string;
    activityName: string;
    assignedAgent: string;
    billingAccountNumber: number;
    bizOrg: string;
    businessName: string;
    carrierAdditionalNotes: string;
    carrierId: number;
    carrierIds:string[];
    exterOrderIds:string[];
    carrierSpid: number;
    city: string;
    companyName: string;
    completionDate: string;
    contactName: string;
    customerRequestDate: string;
    errorMessage: string;
    extOrderId: string;
    firstName: string;
    focDate: string;
    isDisplayable: string;
    lastName: string;
    loaFilename: string;
    lsrStatus: string;
    lsrStatusList:string[];
    middleInitial: string;
    orderActive: string;
    orderActivityIdPK: number;
    orderCompleteDate: string;
    orderCompleteDateFrom: string;
    orderCompleteDateTo: string;
    orderDate: string;
    orderDateFrom: string;
    orderDateTo: string;
    orderStatus: string;
    orderType: string;
    orderSource:string;
    parentOrderId: number;
    parentOrderIds:string[];
    ponStatus: string;
    ponStatusList: string[];
    productId: number;
    purchaseOrderNumber: number;
    resellerName: string;
    slOrderId: number;
    state: string;
    status: string;
    streetDirectionalPrefix: string;
    streetName: string;
    streetNumber: number;
    streetNumberSuffix: string;
    streetType: string;
    switchNumber: number;
    trunkNumber: number;
    typeOfPort: string;
    ver: number;
    wtn: number;
    zipCode: number;
  
    /*local usages*/
    checked?: string[];
}

enum ColumnType {
    string = 'string',
    number = 'number',
    date = 'date'
};

export interface GridColumnDetails {
    caption: string;
    value: string;
    visible: boolean;
    type: ColumnType;
    class: any
}



export const RejectedOrderGridColumns: GridColumnDetails[] = [
    {
        caption: 'CarrierId',
        value: 'extOrderId',
        visible: true,
        type: ColumnType.string,
        class: { 'r11': true }
    },
    {
        caption: 'Order Status',
        value: 'orderStatus',
        visible: true,
        type: ColumnType.string,
        class: { 'r12': true }
    },
    {
        caption: 'Order Date',
        value: 'orderDate',
        visible: true,
        type: ColumnType.date,
        class: { 'r11': true }
    },
    {
        caption: 'RejectReasonCode',
        value: 'errorCode',
        visible: true,
        type: ColumnType.string,
        class: { 'r11': true }
    },
    {
        caption: 'RejectReasonComments',
        value: 'errorMessage',
        visible: true,
        type: ColumnType.string,
        class: { 'r19': true }
    },
    {
        caption: 'Carrrier Additional Notes',
        value: 'carrierAdditionalNotes',
        visible: true,
        type: ColumnType.string,
        class: { 'r11': true }
    },
   
]


export interface RejectedOrderResponse {
    activity: string;
    activityNameList: string[];
    activityStatusList: string[];
    assignedAgent: string;
    billingAccountNumber: string;
    bizOrg: string;
    businessName: string;
    carrierAdditionalNotes: string;
    carrierId: string;
    carrierSpid: string;
    city: string;
    companyName: string;
    contactName: string;
    customerRequestDate: string;
    errorCode: string;
    errorMessage: string;
    extOrderId: string;
    extOrderIds: string[];
    firstName: string;
    focDate: string;
    lastName: string;
    loaFilename: string;
    lsrStatus: string;
    lsrStatusList: string[];
    middleInitial: string;
    orderActive: string;
    orderCompleteDate: string;
    orderCompleteDateFrom: string;
    orderCompleteDateTo: string;
    orderDate: string;
    orderDateFrom: string;
    orderDateTo: string;
    orderSource: string;
    orderStatuList: string[];
    orderStatus: string;
    orderType: string;
    parentOrderId: string;
    parentOrderIds: string[];
    ponStatus: string;
    ponStatusList: string[];
    productId: string;
    purchaseOrderNumber: string;
    purchaseOrderVersion: string;
    resellerName: string;
    salesOrderId: string;
    state: string;
    streetDirectionalPrefix: string;
    streetName: string;
    streetNumber: string;
    streetNumberSuffix: string;
    streetType: string;
    switchNumber: string;
    tns: string[];
    trunkNumber: string;
    typeOfPort: string;
    wtn: string;
    zipCode: string;
}