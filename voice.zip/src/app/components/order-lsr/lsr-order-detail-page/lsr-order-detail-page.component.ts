import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LsrActivitySearchService } from '../../activation-lsr/services/lsr-activity-search.service';
import { LSRDetailsPageResponse } from '../../activation-lsr/activation-lsr.constants';
import { UpdateLsrDialogComponent } from '../../activation-lsr/update-lsr-dialog/update-lsr-dialog.component';

@Component({
  selector: 'app-lsr-order-detail-page',
  templateUrl: './lsr-order-detail-page.component.html',
  styleUrls: ['./lsr-order-detail-page.component.scss']
})
export class LsrOrderDetailPageComponent implements OnInit {

  extOrderId: any;
  carrierId: any;
  activityStatus: string;
  activityName: string;
  productId: number;
  orderDetail: LSRDetailsPageResponse;
  errorMessage: string;

  @ViewChild('updateLsrDialogComponent') updateLsrDialogComponent: UpdateLsrDialogComponent;

  constructor(private activatedRoute: ActivatedRoute, private lsrActivitySearchService: LsrActivitySearchService) {
  }

  ngOnInit() {
    this.carrierId = this.activatedRoute.snapshot.params['carrierId'];
    this.extOrderId = this.activatedRoute.snapshot.params['extOrderId'];
    this.activityName = this.activatedRoute.snapshot.params['activityName'];
    this.activityStatus = this.activatedRoute.snapshot.params['status'];
    this.productId = this.activatedRoute.snapshot.params['productId'];
    this.productId = parseInt(this.productId.toString(), 0) || this.productId;
    this.getOrderDetails();
  }

  getOrderDetails() {
    this.errorMessage = '';
    this.lsrActivitySearchService.getLSRDetails(this.extOrderId).subscribe((response: LSRDetailsPageResponse) => {
      this.orderDetail = response;
    }, error => this.errorMessage = error);
  }

  onUpdateLsrClick() {
    this.updateLsrDialogComponent.showDialog = true;
  }
}
