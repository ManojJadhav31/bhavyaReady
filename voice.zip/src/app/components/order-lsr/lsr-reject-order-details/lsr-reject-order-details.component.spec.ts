import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LsrRejectOrderDetailsComponent } from './lsr-reject-order-details.component';

describe('LsrRejectOrderDetailsComponent', () => {
  let component: LsrRejectOrderDetailsComponent;
  let fixture: ComponentFixture<LsrRejectOrderDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LsrRejectOrderDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LsrRejectOrderDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
