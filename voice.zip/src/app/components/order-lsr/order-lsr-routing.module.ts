import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LsrOrderSearchComponent } from './lsr-order-search/lsr-order-search.component';
import { LsrRejectOrderDetailsComponent } from './lsr-reject-order-details/lsr-reject-order-details.component';
import { LsrOrderDetailPageComponent } from './lsr-order-detail-page/lsr-order-detail-page.component';



const routes: Routes = [
  {
    path: '', pathMatch: 'full', redirectTo: 'search'
  },
  {
    path: 'search',
    component:LsrOrderSearchComponent
  },
  {
    path: 'rejectedOrders/:extOrderId',
    component: LsrRejectOrderDetailsComponent
  },
  {
    path: 'detail/:extOrderId/:activityName/:productId/:status',
    component: LsrOrderDetailPageComponent
  }
 
];

@NgModule({
  imports: [ RouterModule.forChild(routes) ],
  exports: [ RouterModule ]
})
export class OrderLsrRoutingModule {
}
