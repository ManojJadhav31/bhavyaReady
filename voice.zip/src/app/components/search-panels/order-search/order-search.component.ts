import { Component, Input, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SearchPanelsService } from '../services/search-panels.service';
import { SearchRequestObject } from '../search-panel-constants';


// declare var $;
// declare var xml2json;
@Component({
  selector: 'app-order-search',
  templateUrl: './order-search.component.html',
  styleUrls: ['./order-search.component.scss']
})

export class OrderSearchComponent implements OnInit {

  @Input() parentPanel: string;
  @Input() activitySearch: SearchRequestObject = new SearchRequestObject();

  products: any = [];
  customerList: any = [];
  customer: any = [];
  orderStatus: any = [];
  selectedOrderStatus: any;
  reasonCodeList: any = [];
  selectedReasonCode: any;
  orderOptions: any = [];
  selectedOrderOption: any;
  orderAction: any = [];
  orderActiveFlag: any = [];
  selectedOrderAction: any = [];
  orderType: any = [];
  selectedOrderType: any;
  servicePackage: any = [];
  selectedServicePackage: any;
  l3InitiatedOrder: any = [];
  selectedInitiatedOrder: any;
  selectedFeatureCode: any;
  firstUsageBilling: any = [];
  lastBoundError: any = [];
  selectedBoundError: any;
  featureCode: any = [];
  jeopardyErrors: any = [];
  selectedJeopardyError: any;
  switchType: any = [];
  selectedSwitchType: any;
  rcStateList: any[] = [];

  constructor(private searchPanelsService: SearchPanelsService,
    private http: HttpClient
  ) {

    this.switchType = [
      { selected: 'selected', value: null, label: 'All' },
      { value: 'SONUS', label: 'SONUS' },
      { value: 'VIPER', label: 'VIPER' }
    ];
    this.lastBoundError = [
      { value: null, selected: 'selected', label: ' All' },
      { value: 'Y', label: 'Yes' },
      { value: 'N', label: 'No' }
    ];

    this.orderStatus = [
      { value: '', selected: 'selected', label: 'All' },
      { value: 'Accepted', label: 'Accepted' },
      { value: 'Active', label: 'Active' },
      { value: 'Agent Assigned', label: 'Agent Assigned' },
      { value: 'Cancel', label: 'Cancel' },
      { value: 'Cancel Confirmed', label: 'Cancel Confirmed' },
      { value: 'Cancel Submitted', label: 'Cancel Submitted' },
      { value: 'Cancelled', label: 'Cancelled' },
      { value: 'Completed', label: 'Completed' },
      { value: 'CRD 30+ Days', label: 'CRD 30+ Days' },
      { value: 'Created', label: 'Created' },
      { value: 'Credit Check Approved', label: 'Credit Check Approved' },
      { value: 'Credit Check Failure', label: 'Credit Check Failure' },
      { value: 'Credit Check Override Approved', label: 'Credit Check Override Approved' },
      { value: 'Credit Rejected', label: 'Credit Rejected' },
      { value: 'CSR Pending', label: 'CSR Pending' },
      { value: 'CSR Rejected', label: 'CSR Rejected' },
      { value: 'CSR Requested', label: 'CSR Requested' },
      { value: 'Customer Hold', label: 'Customer Hold' },
      { value: 'Foc Received', label: 'Foc Received' },
      { value: 'FOC Received', label: 'FOC Received' },
      { value: 'In Progress', label: 'In Progress' },
      { value: 'Installed', label: 'Installed' },
      { value: 'LSR Jeopardy', label: 'LSR Jeopardy' },
      { value: 'LSR Pending', label: 'LSR Pending' },
      { value: 'LSR Submitted', label: 'LSR Submitted' },
      { value: 'New', label: 'New' },
      { value: 'Partial FOC/Jeopardy', label: 'Partial FOC/Jeopardy' },
      { value: 'Partial FOC/Partial Jeopardy/Waiting on LSP', label: 'Partial FOC/Partial Jeopardy/Waiting on LSP' },
      { value: 'Partial FOC/Waiting on LSP', label: 'Partial FOC/Waiting on LSP' },
      { value: 'Partially Submitted', label: 'Partially Submitted' },
      { value: 'Pending', label: 'Pending' },
      { value: 'Pending 1000 Quantity Process', label: 'Pending 1000 Quantity Process' },
      { value: 'Pending 300 Quantity Process', label: 'Pending 300 Quantity Process' },
      { value: 'Pending Access Hold', label: 'Pending Access Hold' },
      { value: 'Pending Activation', label: 'Pending Activation' },
      { value: 'Pending CCM Confirmation', label: 'Pending CCM Confirmation' },
      { value: 'Pending Credit Check', label: 'Pending Credit Check' },
      { value: 'Pending Disconnect', label: 'Pending Disconnect' },
      { value: 'Pending LSR', label: 'Pending LSR' },
      { value: 'Pending Submit', label: 'Pending Submit' },
      { value: 'Pending Subscriber Info', label: 'Pending Subscriber Info' },
      { value: 'Processing', label: 'Processing' },
      { value: 'Processing Approved TN Quantity', label: 'Processing Approved TN Quantity' },
      { value: 'Processing Cancel', label: 'Processing Cancel' },
      { value: 'Processing Create', label: 'Processing Create' },
      { value: 'Processing Reserve', label: 'Processing Reserve' },
      { value: 'Processing Submit', label: 'Processing Submit' },
      { value: 'Project ID Requested', label: 'Project ID Requested' },
      { value: 'Rejected', label: 'Rejected' },
      { value: 'SA Check Completed', label: 'SA Check Completed' },
      { value: 'SA Check Failure', label: 'SA Check Failure' },
      { value: 'SA Check Processing', label: 'SA Check Processing' },
      { value: 'Submitted', label: 'Submitted' },
      { value: 'SUPP Pending', label: 'SUPP Pending' },
      { value: 'SUPP Submitted', label: 'SUPP Submitted' },
      { value: 'Waiting on LSP/Jeopardy', label: 'Waiting on LSP/Jeopardy' }
    ];
    this.orderOptions = [
      { value: null, selected: 'selected', label: 'All' },
      { value: 'Y', label: 'Yes' },
      { value: 'N', label: 'No' }
    ];
    this.orderActiveFlag = [
      { value: null, label: 'All' },
      { value: 'Y', selected: 'selected', label: 'Yes' },
      { value: 'N', label: 'No' }
    ];
    this.orderAction = [
      { value: null, selected: 'selected', label: 'All' },
      { value: 'Change', label: 'Change' },
      { value: 'Disconnect', label: 'Disconnect' },
      { value: 'Install', label: 'Install' },
      { value: 'Renew', label: 'Renew' },
    ];
    this.firstUsageBilling = [
      { selected: 'selected', value: '', label: 'All' },
      { value: 'N', label: 'No' },
      { value: 'Null', label: 'Null' },
      { value: 'Y', label: 'Yes' },
    ];
    this.orderType = [
      { value: null, selected: 'selected', label: 'All' },
      { value: 'Cancel', label: 'Cancel' },
      { value: 'New', label: 'New' },
      { value: 'Supplemental', label: 'supplememtal' },
    ];
    this.servicePackage = [
      { value: null, selected: 'selected', label: 'All' },
      { value: 'Fixed', label: 'Fixed' },
      { value: 'Home Tone', label: 'Home Tone' },
      { value: 'Home Tone Basic', label: 'Home Tone Basic' },
      { value: 'Level(3) AOLTone', label: 'Level(3) AOLTone' },
      { value: 'Level(3) AOLTone 400 Minute Any Distance Plan', label: 'Level(3) AOLTone 400 Minute Any Distance Plan' },
      { value: 'Level(3) AOLTone Basic', label: 'Level(3) AOLTone Basic' },
      { value: 'Primary Local and Domestic LD Flat Rate', label: 'Primary Local and Domestic LD Flat Rate' },
      { value: 'Primary Local Flat Rate', label: 'Primary Local Flat Rate' },
      { value: 'Secondary Local and Domestic LD Flat Rate', label: 'Secondary Local and Domestic LD Flat Rate' },
      { value: 'Secondary Local Flat Rate', label: 'Secondary Local Flat Rate' },
      { value: 'Usage', label: 'Usage' },
      { value: 'Usage Blended', label: 'Usage Blended' },
    ];
    this.featureCode = [
      { selected: 'selected', value: '', label: 'All' },
      { value: 'LNP001H', label: 'LNP001H' },
      { value: 'LNP001N', label: 'LNP001N' },
      { value: 'LNP001T', label: 'LNP001T' },
      { value: 'LNP002H', label: 'LNP002H' },
      { value: 'LNP002N', label: 'LNP002N' },
      { value: 'LNP002T', label: 'LNP002T' },
      { value: 'LNP003H', label: 'LNP003H' },
      { value: 'LNP003N', label: 'LNP003N' },
      { value: 'LNP003T', label: 'LNP003T' },
      { value: 'LNP004H', label: 'LNP004H' },
      { value: 'LNP004N', label: 'LNP004N' },
      { value: 'LNP004T', label: 'LNP004T' },
      { value: 'LNP005H', label: 'LNP005H' },
      { value: 'LNP005N', label: 'LNP005N' },
      { value: 'LNP005T', label: 'LNP005T' },
      { value: 'LNP006H', label: 'LNP006H' },
      { value: 'LNP006N', label: 'LNP006N' },
      { value: 'LNP006T', label: 'LNP006T' },
      { value: 'LNP007H', label: 'LNP007H' },
      { value: 'LNP007N', label: 'LNP007N' },
      { value: 'LNP007T', label: 'LNP007T' },
      { value: 'LNP008H', label: 'LNP008H' },
      { value: 'LNP008N', label: 'LNP008N' },
      { value: 'LNP008T', label: 'LNP008T' },
      { value: 'LNP009H', label: 'LNP009H' },
      { value: 'LNP009N', label: 'LNP009N' },
      { value: 'LNP009T', label: 'LNP009T' },
      { value: 'LNP010H', label: 'LNP010H' },
      { value: 'LNP010N', label: 'LNP010N' },
      { value: 'LNP010T', label: 'LNP010T' },
      { value: 'LNP011H', label: 'LNP011H' },
      { value: 'LNP011N', label: 'LNP011N' },
      { value: 'LNP011T', label: 'LNP011T' },
      { value: 'LNP012H', label: 'LNP012H' },
      { value: 'LNP012N', label: 'LNP012N' },
      { value: 'LNP012T', label: 'LNP012T' },
      { value: 'LNP013H', label: 'LNP013H' },
      { value: 'LNP013N', label: 'LNP013N' },
      { value: 'LNP013T', label: 'LNP013T' },
      { value: 'LNP014H', label: 'LNP014H' },
      { value: 'LNP014N', label: 'LNP014N' },
      { value: 'LNP014T', label: 'LNP014T' },
      { value: 'LNP015H', label: 'LNP015H' },
      { value: 'LNP015N', label: 'LNP015N' },
      { value: 'LNP015T', label: 'LNP015T' },
      { value: 'LNP016H', label: 'LNP016H' },
      { value: 'LNP016N', label: 'LNP016N' },
      { value: 'LNP016T', label: 'LNP016T' },
      { value: 'LNP017H', label: 'LNP017H' },
      { value: 'LNP017N', label: 'LNP017N' },
      { value: 'LNP017T', label: 'LNP017T' },
      { value: 'LNP099N', label: 'LNP099N' },
    ];
    this.jeopardyErrors = [
      { selected: 'selected', value: '', label: 'All' },
      { value: 'LNP001J', label: 'LNP001J: 800 Number' },
      { value: 'LNP002J', label: 'LNP002J: Centrex' },
      { value: 'LNP003J', label: 'LNP003J: Contracted' },
      { value: 'LNP005J', label: 'LNP005J: DSL' },
      { value: 'LNP006J', label: 'LNP006J: Foreign Exchange' },
      { value: 'LNP007J', label: 'LNP007J: Hunting Feature' },
      { value: 'LNP008J', label: 'LNP008J: ISDN' },
      { value: 'LNP009J', label: 'LNP009J: LSP Freeze' },
      { value: 'LNP010J', label: 'LNP010J: Remote Call Forwarding' },
      { value: 'LNP011J', label: 'LNP011J: Ring Mate' },
      { value: 'LNP101J', label: 'LNP101J: Address Mismatch' },
      { value: 'LNP103S', label: 'LNP103S: TN Disconnected' },
      { value: 'LNP105S', label: 'LNP105S: Port TN Mis-Match' },
      { value: 'LNP106J', label: 'LNP106J: Features' },
      { value: 'LNP106S', label: 'LNP106S: TN Non-portable Due to Contract' },
      { value: 'LNP107J', label: 'LNP107J: ICA' },
      { value: 'LNP108J', label: 'LNP108J: LOA' },
      { value: 'LNP109J', label: 'LNP109J: LOA Rejected' },
      { value: 'LNP110J', label: 'LNP110J: Name Mismatch' },
      { value: 'LNP113J', label: 'LNP113J: COB  ' },
      { value: 'LNP114J', label: 'LNP114J: Wrong BTN' },
      { value: 'LNP115J', label: 'LNP115J: Too Many TNs (Project)' },
      { value: 'LNP116J', label: 'LNP116J: TOS' },
      { value: 'LNP119J', label: 'LNP119J: Pending order on account' },
      { value: 'LNP121J', label: 'LNP121J: Disaster Area' },
      { value: 'LNP122J', label: 'LNP122J: Hawaiian Telcom Complex Cut' },
      { value: 'LNP125J', label: 'LNP125J: Partial Port' },
      { value: 'LNP126J', label: 'LNP126J: Auth Name Mismatch' },
      { value: 'LNP127J', label: 'LNP127J: Illegible Authname' },
      { value: 'LNP129J', label: 'LNP129J: Manual Address Mismatch' },
      { value: 'LNP130J', label: 'LNP130J: Manual Name Mismatch' },
      { value: 'LNP131J', label: 'LNP131J: MCI Reseller Required' },
      { value: 'LNP133J', label: 'LNP133J: Reassign BTN' },
      { value: 'LNP135J', label: 'LNP135J: FOC Date in Jeopardy by LSP' },
      { value: 'LNP138J', label: 'LNP138J: Multiple BTN' },
      { value: 'LNP140J', label: 'LNP140J: Subscriber SSN Required or Rejected' },
      { value: 'LNP141J', label: 'LNP141J: Subscriber WirelessAccountNumber Required/Rejected' },
      { value: 'LNP142J', label: 'LNP142J: Subscriber Wireless Account PIN Required/Rejected' },
      { value: 'LNP143J', label: 'LNP143J: BellSouth Complex Order' },
      { value: 'LNP144J', label: 'LNP144J: Resold TN w/ CSR' },
      { value: 'LNP145J', label: 'LNP145J: Resold Account (LSR Phase)' },
      { value: 'LNP146J', label: 'LNP146J: Customer remaining with current LSP' },
      { value: 'LNP147J', label: 'LNP147J: LSP Strike' },
      { value: 'LNP148J', label: 'LNP148J:  LSP Blackout' },
      { value: 'LNP149J', label: 'LNP149J: Zip Code Mismatch Reason Code' },
      { value: 'LNP150J', label: 'LNP150J: Account Number and PIN Required WireLine' },
      { value: 'LNP151J', label: 'LNP151J: Account Number and/or PIN Rejected WireLine ' },
      { value: 'LNP152J', label: 'LNP152J: New LSP Found' },
      { value: 'LNP153J', label: 'LNP153J: BTN Disconnected' },
      { value: 'LNP154J', label: 'LNP154J: Wireline PIN Number Required' },
      { value: 'LNP155J', label: 'LNP155J: Multiple orders on same account' },
      { value: 'LNP156J', label: 'LNP156J: Account Inactive with Current service Provider' },
      { value: 'LNP997J', label: 'LNP997J: Port-in Conflict' },
      { value: 'LNP998J', label: 'LNP998J: Unknown Feature' },
      { value: 'LNP999J', label: 'LNP999J: Unknown Jeopardy Code' },
    ];

    this.rcStateList = [
      { value: 'AK', label: 'AK' },
      { value: 'AL', label: 'AL' },
      { value: 'AR', label: 'AR' },
      { value: 'AZ', label: 'AZ' },
      { value: 'CA', label: 'CA' },
      { value: 'CO', label: 'CO' },
      { value: 'CT', label: 'CT' },
      { value: 'DC', label: 'DC' },
      { value: 'DE', label: 'DE' },
      { value: 'FL', label: 'FL' },
      { value: 'GA', label: 'GA' },
      { value: 'HI', label: 'HI' },
      { value: 'IA', label: 'IA' },
      { value: 'ID', label: 'ID' },
      { value: 'IL', label: 'IL' },
      { value: 'IN', label: 'IN' },
      { value: 'KS', label: 'KS' },
      { value: 'KY', label: 'KY' },
      { value: 'LA', label: 'LA' },
      { value: 'MA', label: 'MA' },
      { value: 'MD', label: 'MD' },
      { value: 'ME', label: 'ME' },
      { value: 'MI', label: 'MI' },
      { value: 'MN', label: 'MN' },
      { value: 'MO', label: 'MO' },
      { value: 'MS', label: 'MS' },
      { value: 'MT', label: 'MT' },
      { value: 'NC', label: 'NC' },
      { value: 'ND', label: 'ND' },
      { value: 'NE', label: 'NE' },
      { value: 'NH', label: 'NH' },
      { value: 'NJ', label: 'NJ' },
      { value: 'NM', label: 'NM' },
      { value: 'NV', label: 'NV' },
      { value: 'NY', label: 'NY' },
      { value: 'OH', label: 'OH' },
      { value: 'OK', label: 'OK' },
      { value: 'OR', label: 'OR' },
      { value: 'PA', label: 'PA' },
      { value: 'PR', label: 'PR' },
      { value: 'RI', label: 'RI' },
      { value: 'SC', label: 'SC' },
      { value: 'SD', label: 'SD' },
      { value: 'TN', label: 'TN' },
      { value: 'TX', label: 'TX' },
      { value: 'UT', label: 'UT' },
      { value: 'VA', label: 'VA' },
      { value: 'VI', label: 'VI' },
      { value: 'VT', label: 'VT' },
      { value: 'WA', label: 'WA' },
      { value: 'WI', label: 'WI' },
      { value: 'WV', label: 'WV' },
      { value: 'WY', label: 'WY' }
    ]
  }

  ngOnInit() {
    this.getCustomerList();
    this.getProducts();
    this.getReasonCodeList();
    this.activitySearch.orderActiveYn = 'Y';

  }

  getCustomerList() {
    this.searchPanelsService.getCustomerList().subscribe(data => {
      (data as any).forEach(customer => {
        this.customerList.push({value:customer.bizOrgId + ' - ' + customer.name, label: customer.bizOrgId + '-' + customer.name });
      });
    });
  };

  getProducts() {
    this.searchPanelsService.getProducts().subscribe(data => {
      this.products.push(data);
    });
  };

  getReasonCodeList() {
    this.searchPanelsService.getReasonCodeList().subscribe(data => {
      (data as any).forEach(reason => {
        this.reasonCodeList.push({ value: reason, label: reason });
      });
    });
  };
}
