import { Component, Input, OnInit } from '@angular/core';
import { LsrSearchRequest } from '../search-panel-constants';

@Component({
  selector: 'app-lsr-advanced-search',
  templateUrl: './lsr-advanced-search.component.html',
  styleUrls: [ './lsr-advanced-search.component.scss' ]
})
export class LsrAdvancedSearchComponent implements OnInit {
  @Input() parentPanel: string;
  @Input() activitySearch: LsrSearchRequest = new LsrSearchRequest();

  public product: any[] = [
    { value:null, selected: 'selected', label: 'All' },
    { value: '2042', label: 'ELS' },
    { value: '2036', label: 'LI' },
    { value: '2032', label: 'Managed Modem' },
    { value: '2025', label: 'Voice Complete' }
  ];
  public portTypeOptions: any[] = [
    { value:null, selected:'selected', label:'All' },
    { value: 'COMPLEX', label: 'COMPLEX' },
    { value: 'SIMPLE', label: 'SIMPLE' }
  ];

  constructor() {
  }

  ngOnInit() {
  }

}
