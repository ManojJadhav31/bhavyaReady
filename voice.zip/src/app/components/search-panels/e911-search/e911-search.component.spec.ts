import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {E911SearchComponent} from './e911-search.component';
import {DefaultSearchComponent} from '../default-search/default-search.component';
import {EmeaSearchComponent} from '../emea-search/emea-search.component';
import {LnpOrderSearchComponent} from '../lnp-order-search/lnp-order-search.component';
import {OrderSearchComponent} from '../order-search/order-search.component';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {SearchPanelsService} from '../services/search-panels.service';
import {PortoutService} from '../../portout/services/portout.service';
import {ApiService} from '../../../shared/services/api.service';
import {SharedModule} from '../../../shared/shared.module';
import { StorageService } from '../../../services/storage.service';


describe('E911SearchComponent', () => {
  let component: E911SearchComponent;
  let fixture: ComponentFixture<E911SearchComponent>;
  let searchPanelService: SearchPanelsService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        DefaultSearchComponent,
        E911SearchComponent,
        EmeaSearchComponent,
        LnpOrderSearchComponent,
        OrderSearchComponent
      ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        SharedModule,
        BrowserAnimationsModule
      ],
      providers: [
        SearchPanelsService,
        PortoutService,
        ApiService,
        StorageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(E911SearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set aliStatus and esOption', async(() => {
    expect(component.aliStatus[0].value).toEqual('');
    expect(component.esOption[0].selected).toEqual('selected');
  }));

});
