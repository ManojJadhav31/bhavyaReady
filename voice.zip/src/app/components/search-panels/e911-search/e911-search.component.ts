import { Component, Input, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SearchPanelsService } from '../services/search-panels.service';
import { SearchRequestObject } from '../search-panel-constants';
import { sortList } from 'src/app/core/utills';

@Component({
  selector: 'app-e911-search',
  templateUrl: './e911-search.component.html',
  styleUrls: ['./e911-search.component.scss']
})
export class E911SearchComponent implements OnInit {

  @Input() parentPanel: string;
  @Input() activitySearch: SearchRequestObject = new SearchRequestObject();

  aliStatus: any = [];
  selectedAliStatus: any;
  esOption: any = [];
  selectedEsOption: any;
  selectedContactLanguage: any;
  selectedListingLanguage: any;


  constructor(private searchPanelsService: SearchPanelsService,
    private http: HttpClient) {
    this.aliStatus = [
      { value: '', selected: '', label: 'All' },
      { value: 'ASSUMED COMPLETE', label: 'Assumed Complete' },
      { value: 'CANCELLED', label: 'Cancelled' },
      { value: 'COMPLETE', label: 'Complete' },
      { value: 'ERROR', label: 'Error' },
      { value: 'INTRADO ERROR', label: 'Intrado Error' },
      { value: 'INTRADO PROCESSING', label: 'Intrado Processing' },
      { value: 'LEVEL 3 ERROR', label: 'Level 3 Error' },
      { value: 'LNP PROCESSING', label: 'LNP Processing' },
      { value: 'N/A', label: 'N/A' },
      { value: 'NEW', label: 'New' },
      { value: 'SENT', label: 'Sent' },
      { value: 'VENDOR PROCESSING', label: 'Vendor Processing' },
    ];
    this.esOption = [
      { selected: 'selected', value: '', label: 'All' },
      { value: 'CP', label: 'E911 Customer Provided' },
      { value: 'LYNC', label: 'E911 Lync' },
      { value: 'STANDARD', label: 'E911 Standard' },
      { value: 'STATIC', label: 'E911 Static' },
      { value: 'VPC', label: 'E911 VPC' },
      { value: 'ES STANDARD', label: 'ES Standard' },
      { value: 'NONE', label: 'None' },
      { value: 'UNKNOWN', label: 'Unknown' },

    ];

  }

  ngOnInit() {
    this.esOption = sortList(this.esOption, 'label');
    this.aliStatus = sortList(this.aliStatus, 'label');
  }

}
