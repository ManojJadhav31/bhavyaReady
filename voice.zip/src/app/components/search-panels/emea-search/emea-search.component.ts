import {Component, Input, OnInit} from '@angular/core';
import {SearchRequestObject} from '../search-panel-constants';
import { sortList } from 'src/app/core/utills';

@Component({
  selector: 'app-emea-search',
  templateUrl: './emea-search.component.html',
  styleUrls: ['./emea-search.component.scss']
})
export class EmeaSearchComponent implements OnInit {

  @Input() parentPanel: string;
  @Input() activitySearch: SearchRequestObject = new SearchRequestObject();

  country: any = [];
  selectedCountry: any;
  featureCode: any = [];
  selectedFeatureCode: any;
  firstUsageBilling: any = [];
  selectedBilling: any;
  esOption: any = [];
  selectedEsOption: any;
  jeopardyErrors: any = [];
  listingLanguage: any = [];
  contactLanguage: any = [];

  constructor() {
    this.country = [
      {value: '', label: 'All'},
      {value: 'Austria', label: 'Austria'},
      {value: 'Belgium', label: 'Belgium'},
      {value: 'France', label: 'France'},
      {value: 'Germany', label: 'Germany'},
      {value: 'Ireland', label: 'Ireland'},
      {value: 'Netherlands', label: 'Netherlands'},
      {value: 'Spain', label: 'Spain'},
      {value: 'Switzerland', label: 'Switzerland'},
      {value: 'United Kingdom', label: 'United Kingdom'},
      {value: 'United States', label: 'United States'},
    ];
    this.featureCode = [
      {selected: 'selected', value: '', label: 'All'},
      {value: 'LNP001H', label: 'LNP001H'},
      {value: 'LNP001N', label: 'LNP001N'},
      {value: 'LNP001T', label: 'LNP001T'},
      {value: 'LNP002H', label: 'LNP002H'},
      {value: 'LNP002N', label: 'LNP002N'},
      {value: 'LNP002T', label: 'LNP002T'},
      {value: 'LNP003H', label: 'LNP003H'},
      {value: 'LNP003N', label: 'LNP003N'},
      {value: 'LNP003T', label: 'LNP003T'},
      {value: 'LNP004H', label: 'LNP004H'},
      {value: 'LNP004N', label: 'LNP004N'},
      {value: 'LNP004T', label: 'LNP004T'},
      {value: 'LNP005H', label: 'LNP005H'},
      {value: 'LNP005N', label: 'LNP005N'},
      {value: 'LNP005T', label: 'LNP005T'},
      {value: 'LNP006H', label: 'LNP006H'},
      {value: 'LNP006N', label: 'LNP006N'},
      {value: 'LNP006T', label: 'LNP006T'},
      {value: 'LNP007H', label: 'LNP007H'},
      {value: 'LNP007N', label: 'LNP007N'},
      {value: 'LNP007T', label: 'LNP007T'},
      {value: 'LNP008H', label: 'LNP008H'},
      {value: 'LNP008N', label: 'LNP008N'},
      {value: 'LNP008T', label: 'LNP008T'},
      {value: 'LNP009H', label: 'LNP009H'},
      {value: 'LNP009N', label: 'LNP009N'},
      {value: 'LNP009T', label: 'LNP009T'},
      {value: 'LNP010H', label: 'LNP010H'},
      {value: 'LNP010N', label: 'LNP010N'},
      {value: 'LNP010T', label: 'LNP010T'},
      {value: 'LNP011H', label: 'LNP011H'},
      {value: 'LNP011N', label: 'LNP011N'},
      {value: 'LNP011T', label: 'LNP011T'},
      {value: 'LNP012H', label: 'LNP012H'},
      {value: 'LNP012N', label: 'LNP012N'},
      {value: 'LNP012T', label: 'LNP012T'},
      {value: 'LNP013H', label: 'LNP013H'},
      {value: 'LNP013N', label: 'LNP013N'},
      {value: 'LNP013T', label: 'LNP013T'},
      {value: 'LNP014H', label: 'LNP014H'},
      {value: 'LNP014N', label: 'LNP014N'},
      {value: 'LNP014T', label: 'LNP014T'},
      {value: 'LNP015H', label: 'LNP015H'},
      {value: 'LNP015N', label: 'LNP015N'},
      {value: 'LNP015T', label: 'LNP015T'},
      {value: 'LNP016H', label: 'LNP016H'},
      {value: 'LNP016N', label: 'LNP016N'},
      {value: 'LNP016T', label: 'LNP016T'},
      {value: 'LNP017H', label: 'LNP017H'},
      {value: 'LNP017N', label: 'LNP017N'},
      {value: 'LNP017T', label: 'LNP017T'},
      {value: 'LNP099N', label: 'LNP099N'},
    ];
    this.esOption = [
      {selected: 'selected', value: '', label: 'All'},
      {value: 'CP', label: 'E911 Customer Provided'},
      {value: 'LYNC', label: 'E911 Lync'},
      {value: 'STANDARD', label: 'E911 Standard'},
      {value: 'STATIC', label: 'E911 Static'},
      {value: 'VPC', label: 'E911 VPC'},
      {value: 'ES STANDARD', label: 'ES Standard'},
      {value: 'NONE', label: 'None'},
      {value: 'UNKNOWN', label: 'Unknown'},
    ];
    this.jeopardyErrors = [
      {selected: 'selected', value: '', label: 'All'},
      {value: 'LNP001J', label: 'LNP001J: 800 Number'},
      {value: 'LNP002J', label: 'LNP002J: Centrex'},
      {value: 'LNP003J', label: 'LNP003J: Contracted'},
      {value: 'LNP005J', label: 'LNP005J: DSL'},
      {value: 'LNP006J', label: 'LNP006J: Foreign Exchange'},
      {value: 'LNP007J', label: 'LNP007J: Hunting Feature'},
      {value: 'LNP008J', label: 'LNP008J: ISDN'},
      {value: 'LNP009J', label: 'LNP009J: LSP Freeze'},
      {value: 'LNP010J', label: 'LNP010J: Remote Call Forwarding'},
      {value: 'LNP011J', label: 'LNP011J: Ring Mate'},
      {value: 'LNP101J', label: 'LNP101J: Address Mismatch'},
      {value: 'LNP103S', label: 'LNP103S: TN Disconnected'},
      {value: 'LNP105S', label: 'LNP105S: Port TN Mis-Match'},
      {value: 'LNP106J', label: 'LNP106J: Features'},
      {value: 'LNP106S', label: 'LNP106S: TN Non-portable Due to Contract'},
      {value: 'LNP107J', label: 'LNP107J: ICA'},
      {value: 'LNP108J', label: 'LNP108J: LOA'},
      {value: 'LNP109J', label: 'LNP109J: LOA Rejected'},
      {value: 'LNP110J', label: 'LNP110J: Name Mismatch'},
      {value: 'LNP113J', label: 'LNP113J: COB  '},
      {value: 'LNP114J', label: 'LNP114J: Wrong BTN'},
      {value: 'LNP115J', label: 'LNP115J: Too Many TNs (Project)'},
      {value: 'LNP116J', label: 'LNP116J: TOS'},
      {value: 'LNP119J', label: 'LNP119J: Pending order on account'},
      {value: 'LNP121J', label: 'LNP121J: Disaster Area'},
      {value: 'LNP122J', label: 'LNP122J: Hawaiian Telcom Complex Cut'},
      {value: 'LNP125J', label: 'LNP125J: Partial Port'},
      {value: 'LNP126J', label: 'LNP126J: Auth Name Mismatch'},
      {value: 'LNP127J', label: 'LNP127J: Illegible Authname'},
      {value: 'LNP129J', label: 'LNP129J: Manual Address Mismatch'},
      {value: 'LNP130J', label: 'LNP130J: Manual Name Mismatch'},
      {value: 'LNP131J', label: 'LNP131J: MCI Reseller Required'},
      {value: 'LNP133J', label: 'LNP133J: Reassign BTN'},
      {value: 'LNP135J', label: 'LNP135J: FOC Date in Jeopardy by LSP'},
      {value: 'LNP138J', label: 'LNP138J: Multiple BTN'},
      {value: 'LNP140J', label: 'LNP140J: Subscriber SSN Required or Rejected'},
      {value: 'LNP141J', label: 'LNP141J: Subscriber WirelessAccountNumber Required/Rejected'},
      {value: 'LNP142J', label: 'LNP142J: Subscriber Wireless Account PIN Required/Rejected'},
      {value: 'LNP143J', label: 'LNP143J: BellSouth Complex Order'},
      {value: 'LNP144J', label: 'LNP144J: Resold TN w/ CSR'},
      {value: 'LNP145J', label: 'LNP145J: Resold Account (LSR Phase)'},
      {value: 'LNP146J', label: 'LNP146J: Customer remaining with current LSP'},
      {value: 'LNP147J', label: 'LNP147J: LSP Strike'},
      {value: 'LNP148J', label: 'LNP148J:  LSP Blackout'},
      {value: 'LNP149J', label: 'LNP149J: Zip Code Mismatch Reason Code'},
      {value: 'LNP150J', label: 'LNP150J: Account Number and PIN Required WireLine'},
      {value: 'LNP151J', label: 'LNP151J: Account Number and/or PIN Rejected WireLine '},
      {value: 'LNP152J', label: 'LNP152J: New LSP Found'},
      {value: 'LNP153J', label: 'LNP153J: BTN Disconnected'},
      {value: 'LNP154J', label: 'LNP154J: Wireline PIN Number Required'},
      {value: 'LNP155J', label: 'LNP155J: Multiple orders on same account'},
      {value: 'LNP156J', label: 'LNP156J: Account Inactive with Current service Provider'},
      {value: 'LNP997J', label: 'LNP997J: Port-in Conflict'},
      {value: 'LNP998J', label: 'LNP998J: Unknown Feature'},
      {value: 'LNP999J', label: 'LNP999J: Unknown Jeopardy Code'},
    ];
    this.contactLanguage = [
      {selected: 'selected', value: null, label: 'All'},
      {value: 'DE', label: 'DE'},
      {value: 'EN', label: 'EN'},
      {value: 'FR', label: 'FR'},
      {value: 'NL', label: 'NL'}
    ];
    this.listingLanguage = [
      {selected: 'selected', value: null, label: 'All'},
      {value: 'DE', label: 'DE'},
      {value: 'FR', label: 'FR'},
      {value: 'NL', label: 'NL'},
    ];

  }

  ngOnInit() {
    this.country = sortList(this.country, 'label');
    this.featureCode = sortList(this.featureCode, 'label');
    this.esOption = sortList(this.esOption, 'label');
    this.jeopardyErrors = sortList(this.jeopardyErrors, 'label');
    this.contactLanguage = sortList(this.contactLanguage, 'label');
    this.listingLanguage = sortList(this.listingLanguage, 'label');
  }

}
