import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { TnActivitySearchComponent } from './tn-activity-search/tn-activity-search.component';
import { ActivationServiceComponent } from './activation-service.component';
import { TnActivityOrderDetailPageComponent } from './tn-activity-order-detail-page/tn-activity-order-detail-page.component';
import { TnActivityDetailPageComponent } from './tn-activity-detail-page/tn-activity-detail-page.component';
import { ActivationServiceRoutingModule } from './activation-service-routing.module';
import { RouterTestingModule } from '@angular/router/testing';
import { TnActivitySearchService } from './services/tn-activity-search.service';
import { ApiService } from '../../shared/services/api.service';
import { SearchPanelsModule } from '../search-panels/search-panels.module';
import { StorageService } from '../../services/storage.service';
import { SharedModule } from '../../shared/shared.module';
import { UpdateOrderDateDialogModule } from '../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

describe('ActivationServiceComponent', () => {
  let component: ActivationServiceComponent;
  let fixture: ComponentFixture<ActivationServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ActivationServiceComponent,
        TnActivitySearchComponent,
        TnActivityOrderDetailPageComponent,
        TnActivityDetailPageComponent
      ],
      imports: [
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        SharedModule,
        BrowserAnimationsModule,
        ActivationServiceRoutingModule,
        SearchPanelsModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        TnActivitySearchService,
        ApiService,
        StorageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivationServiceComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('event check', () => {
    expect(component.onTabChange(0)).toBeFalsy();
  });
});
