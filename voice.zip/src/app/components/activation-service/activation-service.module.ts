import { NgModule } from '@angular/core';
import { ActivationServiceRoutingModule } from './activation-service-routing.module';
import { TnActivitySearchService } from './services/tn-activity-search.service';
import { SearchPanelsModule } from '../search-panels/search-panels.module';
import { SharedModule } from '../../shared/shared.module';
import { TnActivityDetailPageComponent } from './tn-activity-detail-page/tn-activity-detail-page.component';
import { ActivationServiceComponent } from './activation-service.component';
import { TnActivityOrderDetailPageComponent } from './tn-activity-order-detail-page/tn-activity-order-detail-page.component';
import { TnActivitySearchComponent } from './tn-activity-search/tn-activity-search.component';
import { VirtualScrollerModule } from 'ngx-virtual-scroller';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { UpdateOrderDateDialogModule } from '../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

@NgModule({
  imports: [
    SharedModule,
    ActivationServiceRoutingModule,
    SearchPanelsModule,
    VirtualScrollerModule,
    ScrollingModule,
    UpdateOrderDateDialogModule,
    TransactionViewDialogModule,
    UpdateReasonDialogModule,
    ColumnPickListDialogModule
  ],
  declarations: [
    ActivationServiceComponent, TnActivitySearchComponent,
    TnActivityOrderDetailPageComponent, TnActivityDetailPageComponent ],
  providers: [ TnActivitySearchService ],
})
export class ActivationServiceModule {
}
