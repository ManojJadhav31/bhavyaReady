import { getTestBed, inject, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ApiService } from '../../../shared/services/api.service';
import { HttpClient } from '@angular/common/http';
import { TnActivitySearchService } from './tn-activity-search.service';


describe('TnActivitySearchService', () => {
  let activitySearch: TnActivitySearchService;
  let httpMock: HttpTestingController;
  let injector: TestBed;
  let apiService: ApiService;
  let httpClient: HttpClient;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TnActivitySearchService, ApiService]
    });
    injector = getTestBed();
    httpClient = TestBed.get(HttpClient);
    activitySearch = injector.get(TnActivitySearchService);
    httpMock = injector.get(HttpTestingController);
    apiService = TestBed.get(ApiService);
    apiService.setLocalBaseUrl();
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', inject(
    [TnActivitySearchService],
    (service: TnActivitySearchService) => {
      expect(service).toBeTruthy();
    }
  ));

  it('should get order details using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/slOrder/1';
    activitySearch.getOrderDetail('1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url, 'get order details');
    httpMock.verify();
    expect(req.request.method).toBe('GET');
  });

  it('should get activity details using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/order/activity/1';
    activitySearch.getActivityDetail('1').subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('GET');
  });

  it('should post search details using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/search/1/0';
    activitySearch.searchActivities('1', 1, 1).subscribe(data => expect(data), fail);
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('POST');
  });
  it('should forceComplete activities using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/forcecomplete';
    const dateTimeStr = 'SLDB-UpdateAction-' + Date().toString();
    activitySearch.updateActivities(['1'], 'forceCompleteActivity', dateTimeStr, 'completeReasonAction').subscribe(
      data => expect(data),
      fail
    );
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('POST');

  });
  it('should restart activities using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/restart';
    const dateTimeStr = 'SLDB-UpdateAction-' + Date().toString();
    activitySearch.updateActivities(['1'], 'restartActivity', dateTimeStr).subscribe(
      data => expect(data),
      fail
    );
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('POST');
  });
  it('should update order dates using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/order/date';
    const dateTimeStr = 'SLDB-UpdateAction-' + Date().toString;
    activitySearch.updateActivitiesOrderDate('1', 'orderDateUpdate', 'extraDetails').subscribe(
      data => expect(data),
      fail
    );
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('PUT');
  });
  it('should update order comments using base url', () => {
    const url = apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/tnActivitySearch/order/comments';
    const dateTimeStr = 'SLDB-UpdateAction-' + Date().toString;
    activitySearch.updateActivitiesOrderComment('1', dateTimeStr, 'extraDetails').subscribe(
      data => expect(data),
      fail
    );
    const req = httpMock.expectOne(url);
    expect(req.request.method).toBe('PUT');
  });
});
