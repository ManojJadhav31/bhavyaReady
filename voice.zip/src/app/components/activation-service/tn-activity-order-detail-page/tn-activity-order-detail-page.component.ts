import {Component, OnInit} from '@angular/core';
import {TnActivitySearchService} from '../services/tn-activity-search.service';
import {ActivatedRoute, Router} from '@angular/router';


@Component({
  selector: 'app-tn-activity-order-detail-page',
  templateUrl: './tn-activity-order-detail-page.component.html',
  styleUrls: ['./tn-activity-order-detail-page.component.scss'],

})
export class TnActivityOrderDetailPageComponent implements OnInit {

  public orderDetail: any = {};
  slOrderId: string = null;
  public changeSummaryTableData: any[] = [];
  public CommentsTableData: any[] = [];
  message: string;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private tnActSearchService: TnActivitySearchService) {


  }

  ngOnInit() {
    this.route
      .params
      .subscribe(params => {
        this.slOrderId = params['slOrderId'];
        this.message = '';
        this.tnActSearchService.getOrderDetail(this.slOrderId).subscribe(res => {
          if (res[0]) {
            this.orderDetail = res[0];
            this.setupDataForUI();
          }
        }, (error) => {
          this.message = error;
        });
      });
  }

  setupDataForUI() {
    if (this.orderDetail['orderChange']) {
      this.changeSummaryTableData.push({orderChange: this.orderDetail['orderChange']});
    }

    if (this.orderDetail['comments'] || this.orderDetail['customer'] || this.orderDetail['commentDate']) {
      this.CommentsTableData.push({
        comments: this.orderDetail['comments'],
        customer: this.orderDetail['customer'],
        commentDate: this.orderDetail['commentDate']
      });
    }
  }

  BackToOderDetailPage() {
    this.router.navigate(['./activation-service/tn-activity-search']);
  }

}
