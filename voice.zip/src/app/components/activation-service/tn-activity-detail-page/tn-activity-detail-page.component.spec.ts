import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TnActivityDetailPageComponent } from './tn-activity-detail-page.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivationServiceRoutingModule } from '../activation-service-routing.module';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { TnActivitySearchService } from '../services/tn-activity-search.service';
import { ActivationServiceComponent } from '../activation-service.component';
import { TnActivitySearchComponent } from '../tn-activity-search/tn-activity-search.component';
import { TnActivityOrderDetailPageComponent } from '../tn-activity-order-detail-page/tn-activity-order-detail-page.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ApiService } from '../../../shared/services/api.service';
import { UtilityService } from '../../../shared/services/utility.service';
import { SharedModule } from '../../../shared/shared.module';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';


describe('TnActivityDetailPageComponent', () => {
  let component: TnActivityDetailPageComponent;
  let fixture: ComponentFixture<TnActivityDetailPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ActivationServiceComponent,
        TnActivitySearchComponent,
        TnActivityOrderDetailPageComponent,
        TnActivityDetailPageComponent
      ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        ActivationServiceRoutingModule,
        SearchPanelsModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        TnActivitySearchService,
        ApiService,
        UtilityService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TnActivityDetailPageComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Event check', () => {
    expect(component.BackToOderDetailPage()).toBeFalsy();
  });
});
