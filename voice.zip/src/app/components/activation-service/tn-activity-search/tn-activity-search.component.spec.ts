import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { TnActivitySearchComponent } from './tn-activity-search.component';
import { ActivationServiceComponent } from '../activation-service.component';
import { TnActivityOrderDetailPageComponent } from '../tn-activity-order-detail-page/tn-activity-order-detail-page.component';
import { TnActivityDetailPageComponent } from '../tn-activity-detail-page/tn-activity-detail-page.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivationServiceRoutingModule } from '../activation-service-routing.module';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { RouterTestingModule } from '@angular/router/testing';
import { TnActivitySearchService } from '../services/tn-activity-search.service';
import { ApiService } from '../../../shared/services/api.service';
import { of } from 'rxjs';
import { activationSearchResult } from '../../../../tests/mockdata/activation-service/activationSearchResults';
import { StorageService } from '../../../services/storage.service';
import { SharedModule } from '../../../shared/shared.module';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';

describe('TnActivitySearchComponent', () => {
  let component: TnActivitySearchComponent;
  let fixture: ComponentFixture<TnActivitySearchComponent>;
  let tnActSearchService: TnActivitySearchService;
  let storageService: StorageService;
 

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ActivationServiceComponent,
        TnActivitySearchComponent,
        TnActivityOrderDetailPageComponent,
        TnActivityDetailPageComponent
      ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        ActivationServiceRoutingModule,
        SearchPanelsModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        TnActivitySearchService,
        ApiService,
        StorageService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TnActivitySearchComponent);
    component = fixture.componentInstance;

    tnActSearchService = fixture.debugElement.injector.get(TnActivitySearchService);
    storageService = fixture.debugElement.injector.get(StorageService);
    storageService.setModule('tn-activity');
    // spyOn(tnActSearchService, 'searchActivities').and.returnValue(of(activationSearchResult));
    spyOn(storageService, 'getSelectedActivityIds').and.returnValue(of([]));

    component.filteredResults = activationSearchResult.orderTNActivitySummaryDTOList;

    component.panelFilter = {
      OrderSearch: false,
      LnpSearch: false,
      E911Search: false,
      EmeaSearch: false
    };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should expand search panels', () => {
    component.filterPanels('OrderSearch', true);
    expect(component.panelFilter.OrderSearch).toBe(true);
  });

  it('should search activities', () => {
    const activitySearch = {
      tnOrderId: '123123',
      selectedDateType: 'All'
    };
    component.searchActivities(activitySearch);
    expect(component.searchResults.length).toBeGreaterThanOrEqual(0);
    expect(component.filteredResults.length).toBeGreaterThanOrEqual(0);
    expect(component.totalRecords).toBeGreaterThanOrEqual(0);
  });

  it('should navigate to detail screen', () => {
    const app = fixture.debugElement.componentInstance;
    const item = {
      slOrderId: 123124
    };
    spyOn(component, 'gotoDetail').and.returnValue(true);
    const result = app.gotoDetail(item); // trigger click on first inner
    expect(result).toBe(true);
  });

  it('should navigate to activity detail screen', () => {
    const app = fixture.debugElement.componentInstance;
    const item = {
      id: 123124
    };
    spyOn(component, 'gotoActivityDetail').and.returnValue(true);
    const result = app.gotoActivityDetail(item); // trigger click on first inner
    expect(result).toBe(true);
  });

  it('should be able to clear form', () => {
    component.clearForm();
    expect(component.activitySearch.tnOrderId).toBe(undefined);

  });

  it('should be able to export data', () => {
    component.exportActivitySearch();
    expect(component).toBeTruthy();
  });

  it('should be able to show hide column filter dialog', () => {
    component.showHideColumnFilterDialog();
    expect(component.columnPickListDialog.showDialog).toBe(true);
  });

  it('should be able to verify update activity method', () => {
    component.updateActivitySearch();
    expect(component.updateActivitySearch).toBeDefined;
  });

  it('should be able to update activity with restart activity', fakeAsync(() => {
    component.updateAction.type.code = 'selected';
    component.updateAction.operation.code = 'restartActivity';
    spyOn(tnActSearchService, 'updateActivities').and.returnValue(of(true));
    spyOn(tnActSearchService, 'searchActivities').and.returnValue(of(true));
    component.updateActivitySearch();
    component.successMessage = 'Update Successful';
    tick();
    expect(component.successMessage).toBe('Update Successful');
  }));

  it('should be able to force complete activity ', fakeAsync(() => {
    component.updateAction.type.code = 'selected';
    component.updateAction.operation.code = 'forceCompleteActivity';
    spyOn(tnActSearchService, 'updateActivities').and.returnValue(of(true));
    spyOn(tnActSearchService, 'searchActivities').and.returnValue(of(true));
    component.updateActivitySearch();
    tick();
    expect(component).toBeTruthy();
  }));
  it('should be able to update order dates', fakeAsync(() => {
    component.updateAction.type.code = 'selectedOrder';
    component.updateAction.operation.code = 'orderCommentUpdate';
    spyOn(tnActSearchService, 'updateActivitiesOrderDate').and.returnValue(of(true));
    spyOn(tnActSearchService, 'searchActivities').and.returnValue(of(true));
    component.updateActivitySearch();
    component.successMessage = 'Update Successful';
    tick();
    expect(component.successMessage).toBe('Update Successful');
  }));

  it('should show hide column filter dialog', () => {
    const list = [ {
      caption: 'Activity ID',
      value: 'carrierRequestId',
      visible: false,
      type: 'string',
      class: { 'r9': true }
    },
      {
        caption: '# Tn',
        value: 'tnCount',
        visible: false,
        type: 'string',
        class: { 'r6': true }
      } ];
    component.onPickListChange(list);
    expect(component.gridColumnList[0].value).toBe('carrierRequestId');
  });
});
