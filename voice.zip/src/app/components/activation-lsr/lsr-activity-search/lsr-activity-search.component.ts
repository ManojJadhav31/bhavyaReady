import { Component, OnInit, ViewChild } from '@angular/core';
import { LsrSearchRequest } from '../../search-panels/search-panel-constants';
import { StorageService } from '../../../services/storage.service';
import { ColumnPickListDialogComponent } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog/column-pick-list-dialog.component';
import { LsrActivitySearchResultsGridColumns } from './lsr-activity-search-results-grid-columns';
import { ActivationLsrResult, LsrActivitySearchDTOs } from '../activation-lsr.constants';
import { Observable, Subscription } from 'rxjs';
import { UtilityService } from '../../../shared/services/utility.service';
import * as dateFn from 'date-fns';
import { LsrActivitySearchService } from '../services/lsr-activity-search.service';
import * as XLSX from 'xlsx';
import { UpdateOrderDateDialogComponent } from '../../dialog/update-order-date-dialog/update-order-date-dialog.component';
import { TransactionViewDialogComponent } from '../../dialog/transaction-view-dialog/transaction-view-dialog/transaction-view-dialog.component';
import { UpdateReasonDialogComponent } from '../../dialog/update-reason-dialog/update-reason-dialog.component';
import { LsrActivityAgentAssignDialogComponent } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.component';
import { AssignAgentRequest } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.constants';
import { LsrActivityAgentAssignDialogService } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.service';

@Component({
  selector: 'app-lsr-activity-search',
  templateUrl: './lsr-activity-search.component.html',
  styleUrls: ['./lsr-activity-search.component.scss', '../../activation-service/tn-activity-search/tn-activity-search.component.scss']
})
export class LsrActivitySearchComponent implements OnInit {

  public activitySearch: LsrSearchRequest = new LsrSearchRequest();
  public panelFilter: PanelFilter;
  public panelFilterList: string[] = [];
  public searchPanelCollapsed = {
    lsrSearch: false,
    lsrAdvancedSearch: false
  };
  public filerPanelsCheckBox = {
    lsrAdvancedSearch: []
  };
  displayCompletedActivitydialog = false;

  /** for pick list */
  @ViewChild('columnPickListDialog') columnPickListDialog: ColumnPickListDialogComponent;
  @ViewChild('transactionDetailsDialog') transactionDetailsDialog: TransactionViewDialogComponent;
  @ViewChild('updateReasonOnlyDialog') updateReasonOnlyDialog: UpdateReasonDialogComponent;
  @ViewChild('updateWithReasonDialog') updateWithReasonDialog: UpdateReasonDialogComponent;
  public lsrActivitySearchResultsGridColumns = LsrActivitySearchResultsGridColumns;
  public defaultGridColumns: string[] = ['carrierId', 'orderActivityIdPK', 'activityName', 'status', 'ponStatus', 'lsrStatus', 'completionDate', 'focDate', 'orderDate', 'customerRequestDate', 'purchaseOrderNumber',
    'ver', 'companyName', 'orderStatus', 'orderType', 'activity', 'carrierAdditionalNotes', 'bizOrg', 'billingAccountNumber', 'resellerName', 'typeOfPort', 'businessName',
    'parentOrderId', 'product', 'city', 'state'];
  public gridColumnList: any[] = [];
  public hiddenColumns: any[] = [];

  /**table*/
  public isSearching = false;
  public selectedActivityIds: any[] = [];
  public searchResults: LsrActivitySearchDTOs[] = [];
  public filteredResults: LsrActivitySearchDTOs[] = [];
  public message;
  public updateError;
  public totalRecords = 0;
  public paginationObject = {
    pageNumber: 1,
    pageSize: 100,
    firstPage: 0,
    skip: 0
  };
  public selectAllCheckBox = ['false'];

  /**actions*/
  isExporting = false;
  actionToPerform = { name: 'Export', code: 'export' };
  exportType: any = { name: 'Selected Result', code: 'selected' };
  actionDropdownOptions: any[] = [
    { name: 'export', code: 'export' },
  ];
  exportOptions: any = [
    { name: 'All Result', code: 'all' },
    { name: 'Selected Result', code: 'selected' }
  ];
  updateOptionsOperations: any = [
    { name: 'Restart Activity', code: 'restartActivity' },
    { name: 'Complete Activity', code: 'forceCompleteActivity' }
  ];
  updateAction = {
    type: { name: 'Selected Activities', code: 'selected' },
    operation: { name: 'Restart Activity', code: 'restartActivity' }
  };
  updateActionReason = { name: 'Choose', code: '' };
  completedActionReason = '';
  updateOptions: any = [
    { name: 'All Displayed Results', code: 'all' },
    { name: 'Selected Activities', code: 'selected' },
  ];
  resultType: any = {
    code: 'all'
  };
  updateErrorShowTrunk = {
    length: 500,
    showMore: false
  };
  updateErrorMesg = '';
  successMessage = '';
  isUpdating: boolean = false;
  // resultOptions: any = [
  //   { name: 'Export Results', code: 'all' },
  //   { name: 'Export All', code: 'exportAll' },
  // ];
  resultOptions: any = [
    { name: 'Export Results', code: 'all' }
  ]
  public searchSubscription: Subscription;
  UserName: string;

  /**assign agent dialog*/
  @ViewChild('activityAgentAssignDialog') activityAgentAssignDialog: LsrActivityAgentAssignDialogComponent;

  constructor(public storageService: StorageService, public utilService: UtilityService,
    public lsrActivitySearchService: LsrActivitySearchService, public lsrActivityAgentAssignDialogService: LsrActivityAgentAssignDialogService) {
  }

  ngOnInit() {
    this.storageService.setModule('lsr-activity');
    this.UserName = localStorage.getItem('UserName') !== 'undefined' ? localStorage.getItem('UserName') : undefined;
    if (this.UserName) {
      this.actionDropdownOptions.push({
        name: 'Update', code: 'update'
      });
    }
    this.activitySearch.selectedDateType = 'All';
    this.panelFilter = {
      lsrSearch: false,
      lsrAdvancedSearch: false
    };

    const columnList = JSON.parse(JSON.stringify(this.lsrActivitySearchResultsGridColumns));
    columnList.forEach((item) => {
      if (this.defaultGridColumns.indexOf(item.value) !== -1) {
        item.visible = true;
      }
    });
    this.gridColumnList = columnList.filter(item => item.visible);
    console.log(this.gridColumnList);
    this.hiddenColumns = columnList.filter(item => !item.visible);
    this.setPresetData();
  }

  setPresetData() {

    const searchDetails = this.storageService.getSearchDetails();
    if (searchDetails) {
      if (searchDetails.formData) {
        Object.assign(this.activitySearch, searchDetails.formData);
      }
      if (searchDetails.results) {
        Object.assign(this.searchResults, searchDetails.results);
        this.totalRecords = searchDetails.totalRecords;
        Object.assign(this.filteredResults, searchDetails.results);
        this.paginationObject.skip = 0;
        this.searchPanelCollapsed['mainSearch'] = true;
      }
      if (searchDetails.pageConfig) {
        this.paginationObject.firstPage = searchDetails.pageConfig.firstPage;
        this.paginationObject.pageNumber = searchDetails.pageConfig.pageNumber;
        this.paginationObject.pageSize = searchDetails.pageConfig.pageSize;
      }

      if (searchDetails.panelList) {
        searchDetails.panelList.forEach((key) => {
          if (searchDetails.results && searchDetails.totalRecords) {
            this.searchPanelCollapsed[key] = true;
          }
          this.filerPanelsCheckBox[key] = ['true'];
          this.filterPanels(key, true);
        });
      }

      const pickListDetails = this.storageService.getPickList();
      if (pickListDetails) {
        this.hiddenColumns = pickListDetails.hiddenColumns;
        this.gridColumnList = pickListDetails.gridColumnList;
      }
    }
  }

  filterPanels(key, event) {
    if (key === 'lsrAdvancedSearch') {
      this.panelFilter.lsrAdvancedSearch = event;
    }
    if (event) {
      const index = this.panelFilterList.indexOf(key);
      if (index === -1) {
        this.panelFilterList.push(key);
      }
    } else {
      const index = this.panelFilterList.indexOf(key);
      if (index !== -1) {
        this.panelFilterList.splice(index, 1);
      }
    }
    this.storageService.storePanelSearchList(this.panelFilterList);
  }

  showHideColumnFilterDialog() {
    this.columnPickListDialog.showDialog = true;
  }

  onPickListChange(list: any[]) {
    this.gridColumnList = JSON.parse(JSON.stringify(list));
  }

  onRowCheckboxChnage(event, row) {
    const selectedResult = this.filteredResults.filter(item => {
      if (item.checked && item.checked[0] === 'true') {
        return true;
      } else {
        return false;
      }
    });
    if (selectedResult.length > 0 && (this.filteredResults.length === selectedResult.length)) {
      this.selectAllCheckBox = ['true'];
    } else {
      this.selectAllCheckBox = [];
    }

    if (event) {
      this.selectedActivityIds.push(row);
    } else {
      const index = this.selectedActivityIds.findIndex((obj) => {
        return obj.orderActivityIdPK === row.orderActivityIdPK;
      });
      if (index !== -1) {
        this.selectedActivityIds.splice(index, 1);
      }
    }
  }

  checkAllRows(event) {
    this.filteredResults.forEach(row => {
      if (this.actionToPerform.code === 'export') {
        row.checked = event ? ['true'] : [];
        if (event) {
          this.selectedActivityIds.push(row);
        }
      } else if (event) {
        if (!(row.status == 'Completed' && this.actionToPerform.code === 'update' && (this.updateAction.type.code == 'selected' || this.updateAction.type.code === 'all'))) {
          row.checked = event ? ['true'] : [];
          if (event) {
            this.selectedActivityIds.push(row);
          }
        }
      } else {
        row.checked = event ? ['true'] : [];
        if (event) {
          this.selectedActivityIds.push(row);
        }
      }
    });
    if (!event) {
      this.selectedActivityIds = [];
    }
  }
  onChangeAction(event, action) {
    this.filteredResults.forEach(row => {
      if (action.code === 'update' && row.status === 'Completed') {
        row.checked = [];
      }
    });
  }


  exportExcelLocally(options, exportData) {
    if (exportData.length > 0) {
      const xlsData = [];
      xlsData.push(options.headers);
      exportData.forEach(f => {
        const arr = [];
        Object.keys(f).forEach(key => {
          arr.push(f[key]);
        });
        xlsData.push(arr);
      });
      const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(xlsData);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      XLSX.writeFile(wb, 'ActivityResults.csv');
    }
    this.isExporting = false;
  }

  exportExcelFromService(exportColumns?: string[]) {
    this.createBodyForService(this.activitySearch).subscribe((returnBody) => {
      if (exportColumns) {
        returnBody['exportColumns'] = exportColumns;
      }
      this.lsrActivitySearchService.getExportDetail(returnBody).subscribe((response) => {
        const url = window.URL.createObjectURL(response.data);
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.setAttribute('style', 'display:none');
        a.href = url;
        a.download = response.fileName;
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        this.isExporting = false;
      }, error => {
        this.message = error;
        this.isExporting = false;
      });
    });
  }

  exportActivitySearch() {
    let exportData = [];
    if (this.filteredResults.length > 0) {
      this.isExporting = true;
      const options = {
        showLabels: true,
        headers: this.gridColumnList.map(col => {
          return col.caption;
        })
      };
      let selectedResult = this.filteredResults.filter(item => {
        if (item.checked && item.checked[0] === 'true') {
          return true;
        } else {
          return false;
        }
      });
      if (this.exportType.code === 'selected') {
        if (this.resultType.code === 'tns') {
          options.headers = ['TN'];
          exportData = selectedResult.map(row => {
            const data = {};
            data['tn'] = row['tn'];
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else if (this.resultType.code === 'all') {
          exportData = selectedResult.map(row => {
            const data = {};
            this.gridColumnList.forEach(col => {
              data[col.value] = row[col.value] || '';
            });
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else {
          this.isExporting = false;
        }
      } else if (this.exportType.code === 'all') {
        if (this.resultType.code === 'tns') {
          this.exportExcelFromService(['tn']);
        } else if (this.resultType.code === 'all') {
          selectedResult = this.filteredResults;
          exportData = selectedResult.map(row => {
            const data = {};
            this.gridColumnList.forEach(col => {
              data[col.value] = row[col.value] || '';
            });
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else if (this.resultType.code === 'exportAll') {
          const exportColumns = this.gridColumnList.map(col => {
            return col.value;
          });
          this.exportExcelFromService(exportColumns);
        } else {
          this.isExporting = false;
        }
      } else {
        this.isExporting = false;
      }
    }
  }


  filterGridResults(value, filter) {
    const results = [];
    if (value) {
      this.gridColumnList.forEach(col => {
        this.searchResults.forEach(item => {
          if (item[col.value]) {
            if (item[col.value].toString().toLowerCase().indexOf(value.toLowerCase()) !== -1) {
              if (results.indexOf(item) === -1) {
                results.push(item);
              }
            }
          }
        });
      });
      this.filteredResults = results;
    } else {
      this.filteredResults = this.searchResults;
    }
  }

  loadSearchResults(event, filteredResults) {
    this.updateError = '';
    const selectedActivitiesIds: Array<string> = [];
    this.paginationObject.firstPage = event.first;
    this.paginationObject.pageNumber = (event.first / event.rows) + 1;
    this.paginationObject.pageSize = event.rows;
    filteredResults.forEach(item => {
      if (item.checked && item.checked[0] === 'true') {
        selectedActivitiesIds.push(item.orderActivityIdPK);
      }
    });
    this.storageService.storeSelectedActivityIds(selectedActivitiesIds, false);
    this.storageService.storeSearchDetailsGridPage(this.paginationObject.pageNumber, this.paginationObject.pageSize, this.paginationObject.firstPage);
    if (this.totalRecords > 0) {
      this.search(true);
    }
  }

  clearForm() {
    /*to clear stored search details*/
    this.storageService.resetDetails();
    this.isUpdating= false;
    this.isExporting =false;
    this.setPresetData();
    this.isSearching = false;
    this.message = '';
    // change to make clear button work
    this.activitySearch = new LsrSearchRequest();
    this.activitySearch.selectedDateType = 'All';
    this.searchResults = [];
    this.paginationObject = {
      pageNumber: 1,
      pageSize: this.paginationObject.pageSize,
      firstPage: 0,
      skip: 0
    };
    this.totalRecords = 0;
    this.filteredResults = [];
    this.activitySearch.isDisplayable = 'Y';
    this.activitySearch.orderActive = 'Y';
    this.message = '';
    this.successMessage = null;
    this.updateError = '';
  }

  search(checkCheckbox = false) {
    this.successMessage = null;
    this.updateError = '';
    this.message = '';
    this.selectedActivityIds = [];
    this.paginationObject.pageNumber = 1;
    this.paginationObject.firstPage = 0;
    this.storageService.storeSelectedActivityIds([], true);
    this.searchActivities();
  }

  searchActivities(checkCheckbox = false) {
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
    console.log(this.activitySearch);
    this.activitySearch.noData = {
      error: false
    };
    if (this.activitySearch.parentOrderId || this.activitySearch.extOrderId || this.activitySearch.wtn || (this.activitySearch.wtn === null && this.activitySearch.tns) || this.activitySearch.selectedDateType !== 'All') {
      this.activitySearch.requiredFieldsError = {
        error: false
      };
    } else {
      this.activitySearch.requiredFieldsError = {
        error: true,
        msg: 'Please enter at least one of the required fields'
      };
      return;
    }
    if (this.activitySearch.requiredFieldsError.error === false) {
      if (this.activitySearch.selectedDateType !== 'All') {
        this.utilService.fillDateTypePayload(this.activitySearch, this.activitySearch);
        let error = false;
        if (this.activitySearch.parentOrderId || this.activitySearch.wtn || this.activitySearch.extOrderId) {
          error = false;
        } else if (this.activitySearch.selectedDateCategories === 'range' && this.checkNonRequiredField(this.activitySearch)) {
          if (dateFn.differenceInCalendarDays(this.activitySearch.selectedDateToDate, this.activitySearch.selectedDateFromDate) >= 60) {
            error = true;
          }
        } else if (this.activitySearch.selectedDateCategories === 'relative' && this.activitySearch.selectedDateRange === 'past60Days' && this.checkNonRequiredField(this.activitySearch)) {
          error = true;
        }
        if (error) {
          this.activitySearch.requiredFieldsError = {
            error: true,
            msg: 'You can not select date type past 90 days date'
          };
          return;
        }
      }
    }

    this.createBodyForService(this.activitySearch).subscribe((returnBody) => {
      const body = returnBody;
      this.searchResults = [];
      this.filteredResults = [];
      this.totalRecords = 0;
      // this.skip = 0;
      this.isSearching = true;
      this.message = '';
      this.searchSubscription = this.lsrActivitySearchService.searchLsrActivities(body, this.paginationObject.pageSize, this.paginationObject.pageNumber).subscribe((res: ActivationLsrResult) => {
        this.isSearching = false;
        const data = (res as any);
        if (data.lsrActivitySearchDTOs && data.lsrActivitySearchDTOs.length > 0) {
          this.searchPanelCollapsed = {
            lsrAdvancedSearch: true,
            lsrSearch: true
          };
          // make activity as select to update
          const activitySerchResult = JSON.parse(JSON.stringify(data.lsrActivitySearchDTOs));
          if (checkCheckbox) {
            activitySerchResult.forEach(activity => {
              const findObject = this.selectedActivityIds.find(obj => obj.orderActivityIdPK === activity.orderActivityIdPK);
              if (findObject) {
                activity.checked = 'true';
              }
            });
          } else {
            this.selectedActivityIds = [];
          }
          this.searchResults = activitySerchResult;
          this.filteredResults = activitySerchResult;
          this.totalRecords = data.totalElementsCount;
          this.paginationObject.skip = 0;
          /*used to store current search details*/
          this.storageService.storeSearchDetails(this.activitySearch, this.searchResults, this.totalRecords);
        } else {
          this.activitySearch.noData = {
            error: true
          };
        }
      }, error => {
        this.message = error;
        this.isSearching = false;
      });
    });
  }

  checkNonRequiredField(activitySearch) {
    if (activitySearch.purchaseOrderNumber || activitySearch.Status || activitySearch.activityName || activitySearch.isDisplayable || activitySearch.orderStatus
      || activitySearch.companyName || activitySearch.assignedAgent || activitySearch.orderType || activitySearch.ponStatus || activitySearch.lsrStatus || activitySearch.selectedDateCategoriesSecondaryToDate || activitySearch.selectedDateCategoriesSecondaryFromDate) {
      return true;
    }
    if (this.filerPanelsCheckBox.lsrAdvancedSearch[0] && this.filerPanelsCheckBox.lsrAdvancedSearch[0] === 'true') {
      if (activitySearch.billingAccountNumber || activitySearch.ver || activitySearch.typeOfPort || activitySearch.resellerName || activitySearch.businessName
        || activitySearch.lastName || activitySearch.firstName || activitySearch.contactName) {
        return true;
      }
    }
    return false;
  }

  createBodyForService(activitySearch): Observable<any> {
    return new Observable((observer) => {
      const body: any = {};

      // ----------- Default Search Params -----------
      body.isDisplayable = activitySearch.isDisplayable || undefined;
      body.orderType = activitySearch.orderType || undefined;
      body.purchaseOrderNumber = activitySearch.purchaseOrderNumber || undefined;
      body.orderActive = activitySearch.orderActive || undefined;
      body.companyName = activitySearch.companyName || undefined;
      body.assignedAgent = activitySearch.assignedAgent || undefined;
      if (activitySearch.status && activitySearch.status.length > 0) {
        body.activityStatusList = activitySearch.status;
      }
      if (activitySearch.activityName && activitySearch.activityName.length > 0) {
        body.activityNameList = activitySearch.activityName;
      }
      if (activitySearch.orderStatus && activitySearch.orderStatus.length > 0) {
        body.orderStatusList = activitySearch.orderStatus;
      }
      if (activitySearch.ponStatus && activitySearch.ponStatus.length > 0) {
        body.ponStatusList = activitySearch.ponStatus;
      }
      if (activitySearch.lsrStatus && activitySearch.lsrStatus.length > 0) {
        body.lsrStatusList = activitySearch.lsrStatus;
      }
      if (activitySearch.showTnTextArea) {
        body.tns = this.utilService.createArrayFromTextArea(activitySearch.tns);
      } else {
        if (activitySearch.wtn) {
          body.tns = this.utilService.createArrayFromTextArea(activitySearch.wtn);
        }
      }
      if (body.tns) {
        if (body.tns.length === 0) {
          delete body.tns;
        }
      }
      if (activitySearch.parentOrderId) {
        body.parentOrderIds = this.utilService.createArrayFromTextArea(activitySearch.parentOrderId);
      }
      if (activitySearch.extOrderId) {
        body.extOrderIds = this.utilService.createArrayFromTextArea(activitySearch.extOrderId);
      }
      if (activitySearch.selectedDateType !== 'All') {
        this.utilService.fillDateTypePayload(activitySearch, body);
      }

      //  ----------- LSR Advanced Search -----------
      body.billingAccountNumber = activitySearch.billingAccountNumber || undefined;
      body.ver = activitySearch.ver || undefined;
      body.businessName = activitySearch.businessName || undefined;
      body.lastName = activitySearch.lastName || undefined;
      body.contactName = activitySearch.contactName || undefined;
      body.firstName = activitySearch.firstName || undefined;
      body.typeOfPort = activitySearch.typeOfPort || undefined;
      body.resellerName = activitySearch.resellerName || undefined;

      observer.next(body);
    });
  }

  onAssignAgent(dataItem: LsrActivitySearchDTOs) {
    this.successMessage = null;
    this.updateError = null;
    this.activityAgentAssignDialog.requestPayload = new AssignAgentRequest();
    this.activityAgentAssignDialog.requestPayload.carrierRequestId = dataItem.carrierId;
    this.activityAgentAssignDialog.requestPayload.userId = this.utilService.getUserId();
    this.activityAgentAssignDialog.requestPayload.systemId = this.utilService.getSystemId();
    this.activityAgentAssignDialog.requestPayload.correlationId = this.utilService.getCorrelationId();
    this.activityAgentAssignDialog.showDialog = true;
  }

  onAgentSubmit() {
    this.lsrActivityAgentAssignDialogService.assignAgent(this.activityAgentAssignDialog.requestPayload).subscribe((response: any) => {
      if (response.errorCode === 0) {
        this.successMessage = 'Assigned agent successfully updated.'
      } else {
        this.updateErrorMesg = response.errorMessage;
      }
      this.activityAgentAssignDialog.showDialog = false;
      this.activityAgentAssignDialog.requestPayload = new AssignAgentRequest();
      this.searchActivities();
    }, (error) => this.updateError = error);
  }

  updateReasonOnlyDialogSubmit(event) {
    this.updateReasonOnlyDialog.displaDialog = false;
    this.updateActivitySearch();
  }

  setCommentAndPerformAction() {
    this.displayCompletedActivitydialog = false;
    if (this.updateActionReason.code === 'Other') {
    } else {
      this.completedActionReason = this.updateActionReason.code;
    }

    this.updateActivitySearch();
  }



  updateActivitySearch(extraDetails?) {
    this.updateError = '';
    this.updateErrorMesg = '';
    this.successMessage = '';
    let exportData = [];
    if (this.filteredResults.length > 0) {
      this.isUpdating = true;
      exportData = this.selectedActivityIds;
      if (this.updateAction.type.code === 'all') {
        exportData = this.filteredResults.filter(item => {
          if (item.status !== 'Completed') {
            return true;
          } else {
            return false;
          }
        });
        if (exportData.length === 0) {
          this.isUpdating = false;
          this.updateError = 'Trying to Perform ' + this.updateAction.operation.name + ' Action on Completed Activities';
          return;
        }
      } else if (exportData.length === 0) {
        this.isUpdating = false;
        this.updateError = 'Please select atleast one record to perform action';
        return;
      }
      let count = 0;
      let hitApi = false;
      let activityIds = [];

      const dateTime = new Date();
      const dateTimeStr = 'SLDB-' + dateTime.getTime();


      const codeForAcvtivity = ['restartActivity', 'forceCompleteActivity'];

      if (codeForAcvtivity.indexOf(this.updateAction.operation.code) !== -1) {

        if (exportData.length > 0) {
          const list = exportData.map(b => b.orderActivityIdPK);
        }

        let errorResponse = false;
        let successfulResponse = false;
        const listOfResultIds = [];
        const listOfSuccessIds = [];
        for (let i = 0; i < exportData.length; i++) {
          if (activityIds.indexOf(exportData[i].orderActivityIdPK) === -1) {
            activityIds.push(exportData[i].orderActivityIdPK);
          }
          count++;
          if (i === exportData.length - 1) {
            hitApi = true;
          }
          if (count === 30 || hitApi) {
            const idList = activityIds;
            switch (this.updateAction.operation.code) {
              case 'restartActivity':
                this.lsrActivitySearchService.updateActivities(activityIds, this.updateAction.operation.code, dateTimeStr).subscribe((response) => {
                  response.forEach((obj, index) => {
                    if (obj.successful === true && !errorResponse) {
                      successfulResponse = true;
                      listOfResultIds.push(idList[index]);
                    } else if (obj.errorCode === 0) {
                      errorResponse = true;
                      listOfResultIds.push(idList[index]);
                    }
                  });

                  if (successfulResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.successMessage = 'Update Successful';
                    } else {
                      this.successMessage = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.updateAction.operation.code, dateTime, true);
                    }
                  } else if (errorResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.updateError = response[0].errorMessage;
                    } else {
                      this.updateError = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.updateAction.operation.code, dateTime);
                    }
                  }
                  this.searchActivities();
                }, (error) => {
                  console.log(error);
                });
                activityIds = [];
                count = 0;
                break;
              case 'forceCompleteActivity':
                // update comment in filtered list
                this.filteredResults.forEach(item => {
                  if (item.checked && item.checked[0] === 'true') {
                    item['comments'] = this.completedActionReason;
                  }
                });
                // this.searchActivities(this.activitySearch);
                this.lsrActivitySearchService.updateActivities(activityIds, this.updateAction.operation.code, dateTimeStr, this.completedActionReason).subscribe((response) => {
                  response.forEach((obj, index) => {
                    if (obj.successful === true && !errorResponse) {
                      successfulResponse = true;
                      listOfResultIds.push(idList[index]);
                    } else if (obj.errorCode === 0) {
                      errorResponse = true;
                      listOfResultIds.push(idList[index]);
                    }
                  });

                  if (successfulResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.successMessage = 'Update Successful';
                    } else {
                      this.successMessage = 'multiple';
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.updateAction.operation.code, dateTime, true);
                    }
                  } else if (errorResponse) {
                    this.isUpdating = false;
                    if (exportData.length === 1) {
                      this.updateError = response.errorMessage;
                    } else {
                      this.updateError = 'multiple';
                      this.isUpdating =false
                      this.storageService.setTransactionActivityIds(listOfResultIds, this.updateAction.operation.code, dateTime);
                    }
                  }
                  this.searchActivities();

                }, (error) => {
                  console.log(error);
                });
                activityIds = [];
                count = 0;
                break;
            }
          }
        }
      } else {
        this.isUpdating = false;
      }
    }
  }

  openTransactionDialog() {
    this.transactionDetailsDialog.loadErrorList();
    this.transactionDetailsDialog.displayDialog = true;
  }

  onCloseTransactionDialog() {
    this.transactionDetailsDialog.displayDialog = false;
  }

  openCompletedActivitydialog() {
    this.updateWithReasonDialog.reset();
    this.completedActionReason = '';
    this.updateWithReasonDialog.displaDialog = true;
  }

  updateWithReasonDialogSubmit(event) {
    this.completedActionReason = event.action;
    if (event.action === 'Other') {
      this.completedActionReason = event.errorMessage;
    }
    this.updateWithReasonDialog.displaDialog = false;
    this.updateActivitySearch();
  }
}


interface PanelFilter {
  lsrSearch: boolean;
  lsrAdvancedSearch: boolean;
}
