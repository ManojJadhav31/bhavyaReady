import { async, ComponentFixture, TestBed,tick } from '@angular/core/testing';
import { LsrActivitySearchComponent } from './lsr-activity-search.component';
import { SharedModule } from '../../../shared/shared.module';
import { ColumnPickListDialogModule } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog.module';
import { SearchPanelsModule } from '../../search-panels/search-panels.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { UpdateOrderDateDialogModule } from '../../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../../dialog/update-reason-dialog/update-reason-dialog.module';
import { ActivationLsrRoutingModule } from '../activation-lsr-routing.module';
import { ApiService } from '../../../shared/services/api.service';
import { StorageService } from '../../../services/storage.service';
import { LsrActivitySearchService } from '../services/lsr-activity-search.service';
import { UtilityService } from '../../../shared/services/utility.service';
import { LsrActivityDetailPageComponent } from '../lsr-activity-detail-page/lsr-activity-detail-page.component';
import { LsrActivityDeprovisionTnsPageComponent } from '../lsr-activity-deprovision-tns-page/lsr-activity-deprovision-tns-page.component';
import { of } from 'rxjs';
import { LsrActivityAgentAssignDialogComponent } from '../../dialog/lsr-activity-agent-assign-dialog/lsr-activity-agent-assign-dialog.component';
import { LsrActivitySearchResult } from '../../../../tests/mockdata/lsr-activity/lsr-activity-search-result';

describe('LsrActivitySearchComponent', () => {
  let component: LsrActivitySearchComponent;
  let fixture: ComponentFixture<LsrActivitySearchComponent>;
  let storageService: StorageService;
  let lsrActivitySearchService: LsrActivitySearchService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LsrActivitySearchComponent, LsrActivityDetailPageComponent, LsrActivityDeprovisionTnsPageComponent, LsrActivityAgentAssignDialogComponent ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        SearchPanelsModule,
        ActivationLsrRoutingModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        ApiService,
        StorageService,
        LsrActivitySearchService,
        UtilityService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LsrActivitySearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    lsrActivitySearchService = fixture.debugElement.injector.get(LsrActivitySearchService);
    storageService = fixture.debugElement.injector.get(StorageService);
    storageService.setModule('lsr-activity');
    // spyOn(tnActSearchService, 'searchActivities').and.returnValue(of(activationSearchResult));
    spyOn(storageService, 'getSelectedActivityIds').and.returnValue(of([]));

    component.filteredResults = LsrActivitySearchResult.lsrActivitySearchDTOs;

    component.panelFilter = {
     lsrSearch: false,
     lsrAdvancedSearch: false
    };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show hide column filter dialog', () => {
    component.showHideColumnFilterDialog();
    expect(component.columnPickListDialog.showDialog).toBe(true);
  });

  it('should show hide column filter dialog', () => {
    const list = [ {
      caption: 'LSR ID',
      value: 'carrierRequestId',
      visible: false,
      type: 'string',
      class: { 'r9': true }
    },
      {
        caption: '# Tn',
        value: 'tnCount',
        visible: false,
        type: 'string',
        class: { 'r6': true }
      } ];
    component.onPickListChange(list);
    expect(component.gridColumnList[0].value).toBe('carrierRequestId');
  });
  it('should expand search panels', () => {
    component.filterPanels('lsrAdvanceSearch', true);
    expect(component.panelFilter.lsrAdvancedSearch).toBe(true);
  });

  it('should search activities', () => {
    const activitySearch = {
     extOrderId:'547677',
    selectedDateType: 'All'
    };
    component.searchActivities(activitySearch);
    expect(component.searchResults.length).toBeGreaterThanOrEqual(0);
    expect(component.filteredResults.length).toBeGreaterThanOrEqual(0);
    expect(component.totalRecords).toBeGreaterThanOrEqual(0);
  });

  it('should navigate to detail screen', () => {
    const app = fixture.debugElement.componentInstance;
    const item = {
      extOrderId: 123124
    };
    spyOn(component, 'getOrderDetail').and.returnValue(true);
    const result = app.getOrderDetail(item); // trigger click on first inner
    expect(result).toBe(true);
  });

  it('should navigate to activity detail screen', () => {
    const app = fixture.debugElement.componentInstance;
    const item = {
      id: 123124
    };
    spyOn(component, 'getDeprovisionTn').and.returnValue(true);
    const result = app.getDeprovisionTn(item); // trigger click on first inner
    expect(result).toBe(true);
  });
  it('should be able to clear form', () => {
    component.clearForm();
    expect(component.activitySearch.carrierId).toBe(undefined);
  });
});
