import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { ApiService } from '../../../shared/services/api.service';
import { Observable } from 'rxjs';
import { MsFlowUpdateRequest } from '../support-tool-constants';



@Injectable({
  providedIn: 'root'
})
export class SupportToolService {

  constructor(private apiService: ApiService, private http: HttpClient) {

  }

  msFlag(request: MsFlowUpdateRequest) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/productool/msFlowUpdate';
    return this.http.post(url, request).pipe(
      catchError(error => this.apiService.handleException(error))
    )
  };
}
