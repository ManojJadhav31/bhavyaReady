import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FileUploadService } from './fileupload.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { SelectItem } from 'primeng/primeng';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderDetailService } from '../portout/services/orderdetail-portout.service';
import { OrderDetail } from '../portout/search-portout/orderdetail-portout/orderdetail-portout.component';
import { UtilityService } from '../../shared/services/utility.service';
import { StateValidator, ZipCodeValidator } from '../../shared/validators/fileUploadValidators';
import { StorageService } from '../../services/storage.service';


@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  providers: [FileUploadService]
})
export class FileUploadComponent implements OnInit {

  @ViewChild('file') filePicker: ElementRef;
  public maxFiles: Number = 5;
  public fileExt: String = 'xlsx, xls';
  public maxSize: Number = 20; // 20MB

  public error: string;
  public serviceErrors: any = [];
  public files: any;
  public isCreate = true;
  public supActionDisabled = false;
  public focDateDisabled = false;
  public fileUploadForm: FormGroup;
  public updateSuccessMsg = '';
  public requestTypeId: string;
  public orderDetail: OrderDetail;
  public isUpdatingOrder: boolean;
  public clicked = false;

  public ocnValues: SelectItem[] = [
    { label: 'LEVEL3 COMMUNICATIONS', value: 'LEVEL 3 COMMUNICATIONS' },
    { label: 'ICG', value: 'ICG' },
    { label: 'TELCOVE', value: 'TELCOVE' },
    { label: 'BROADWING', value: 'BROADWING' }
  ];

  constructor(private fileService: FileUploadService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private orderDetailService: OrderDetailService,
    private utilityService: UtilityService,
    private storageService: StorageService,
    private router: Router) {
    this.fileUploadForm = fb.group({
      pon: new FormControl(),
      ver: new FormControl(),
      focDate: new FormControl(),
      receivedDate: new FormControl(),
      nnsp: new FormControl(),
      authnm: new FormControl(),
      migrationFlag: new FormControl(),
      recordFlag: new FormControl(),
      oldCarrierName: new FormControl(),
      tns: new FormControl(),
      init: new FormControl(),
      telNo: new FormControl(),
      email: new FormControl(),
      portingLines: new FormControl(),
      name: new FormControl(),
      ban: new FormControl(),
      sano: new FormControl(),
      sasn: new FormControl(),
      city: new FormControl(),
      state: new FormControl('', [StateValidator]),
      zipCode: new FormControl('', [ZipCodeValidator]),
      carrierRequestId: new FormControl(),
      errorCode: new FormControl(),
      errorMessage: new FormControl(),
      authorizedBy: new FormControl()
    });
  }

  ngOnInit() {
    if (this.isCreate) {
      this.setFormInitialState();
    }
    this.route.params.subscribe(p => {
      if (p.requestTypeId) {
        this.isCreate = false;
        this.requestTypeId = p.requestTypeId;
        this.getOrderDetails();
        this.setFormInitialState();
      }
      if (p.supActionDisabled) {
        this.supActionDisabled = p.supActionDisabled;
      }
    });
  }

  setFormInitialState() {
    // Setting default values
    if (this.isCreate) {
      this.fileUploadForm.controls.ver.setValue('00');
      this.fileUploadForm.controls.oldCarrierName.disable();
      this.fileUploadForm.controls.oldCarrierName.setValue(this.ocnValues[0].value);
    }
    else {
      this.fileUploadForm.controls.pon.disable();
      this.fileUploadForm.controls.name.disable();
      this.fileUploadForm.controls.sasn.disable();
      this.fileUploadForm.controls.sano.disable();
      this.fileUploadForm.controls.city.disable();
      this.fileUploadForm.controls.state.disable();
      this.fileUploadForm.controls.zipCode.disable();
      this.fileUploadForm.controls.errorCode.disable();
      this.fileUploadForm.controls.authorizedBy.disable();
    }
  }

  ocnChecked(e) {
    // this.fileUploadForm.controls.oldCarrierName.setValue('LEVEL 3 COMMUNICATIONS');
    if (e.currentTarget.checked) {
      this.fileUploadForm.controls.oldCarrierName.enable();
    } else {
      this.fileUploadForm.controls.oldCarrierName.disable();
    }
  }

  getOrderDetails() {
    this.orderDetailService.getOrderDetails(this.requestTypeId).subscribe(data => {
      if (data[0]) {
        this.orderDetail = data[0];
        this.orderDetailService.setOrderDetailsData(this.orderDetail);
        if (this.orderDetail.focDate) {
          const focDate = this.utilityService.parseDate(this.orderDetail.focDate, 'mdy');
          this.fileUploadForm.controls.focDate.setValue(new Date(focDate));
        } else {
          this.focDateDisabled = true;
        }
        this.fileUploadForm.controls.ver.setValue(this.orderDetail.purchaseOrderVersion);
        this.fileUploadForm.controls.ban.setValue(this.orderDetail.billingAccountName);
        this.fileUploadForm.controls.zipCode.setValue(this.orderDetail.zipCode);
        this.fileUploadForm.controls.carrierRequestId.setValue(this.orderDetail.carrierRequestId);
        this.fileUploadForm.controls.pon.setValue(this.orderDetail.purchaseOrderNumber);
        this.fileUploadForm.controls.city.setValue(this.orderDetail.city);
        this.fileUploadForm.controls.sano.setValue(this.orderDetail.streetNumber);
        this.fileUploadForm.controls.sasn.setValue(this.orderDetail.streetName);
        this.fileUploadForm.controls.state.setValue(this.orderDetail.state);
        this.fileUploadForm.controls.name.setValue(this.orderDetail.endUserName);
        this.fileUploadForm.controls.authorizedBy.setValue(this.orderDetail.authorizedBy);
        this.fileUploadForm.controls.errorCode.setValue(this.orderDetail.errorCode);
      }
    }, error => {
      let errorbody = error;
      const errorMsg = error.split(':');
      if (errorMsg.length >= 3) {
        errorbody = errorMsg[1];
        if (errorMsg[2]) {
          errorbody += ' - ' + errorMsg[2];
        }
      }
      this.serviceErrors.push(errorbody);
    });
  }

  onFocDateChang(event) {
    if (this.orderDetail && this.orderDetail.focDate) {
      this.orderDetail.focDate = this.fileUploadForm.controls.focDate.value;
      this.orderDetailService.setOrderDetailsData(this.orderDetail);
    }
  }

  onFileChange(event) {
    this.files = event.target.files;
  }

  createUpdateOrder(orderDetail) {
    this.clearErrors();
    const formData: FormData = new FormData();
    // Create Order
    if (this.isCreate) {
      this.clicked = true;
      if (this.files) {
        if (this.files.length > 0 && (!this.isValidFiles(this.files))) {
          return;
        }
        if (this.files.length > 0) {
          for (let j = 0; j < this.files.length; j++) {
            formData.append('file', this.files[j], this.files[j].name);
          }
        }
      }
      this.isUpdatingOrder =true;
      formData.append('recordFlag', orderDetail.recordFlag);
      formData.append('migrationFlag', orderDetail.migrationFlag);
      formData.append('oldCarrierName', orderDetail.oldCarrierName);

      if (orderDetail.pon) {
        formData.append('pon', orderDetail.pon.trim());
      }
      formData.append('ver', orderDetail.ver);
      if (orderDetail.focDate) {
        const focDate = this.utilityService.parseDate(orderDetail.focDate, 'mdy');
        formData.append('focDate', focDate.trim());
      }
      if (orderDetail.receivedDate) {
        const receivedDate = this.utilityService.parseDate(orderDetail.receivedDate, 'mdy');
        formData.append('receivedDate', receivedDate.trim());
      }
      if (orderDetail.authnm) {
        formData.append('authnm', orderDetail.authnm.trim());
      }
      if (orderDetail.nnsp) {
        formData.append('nnsp', orderDetail.nnsp.trim());
      }
      if (orderDetail.init) {
        formData.append('init', orderDetail.init.trim());
      }
      if (orderDetail.name) {
        formData.append('name', orderDetail.name.trim());
      }
      if (orderDetail.sano) {
        formData.append('sano', orderDetail.sano.trim());
      }
      if (orderDetail.sasn) {
        formData.append('sasn', orderDetail.sasn.trim());
      }
      if (orderDetail.city) {
        formData.append('city', orderDetail.city.trim());
      }
      if (orderDetail.state) {
        formData.append('state', orderDetail.state);
      }
      if (orderDetail.zipCode) {
        formData.append('zipCode', orderDetail.zipCode);
      }
      if (orderDetail.telNo) {
        formData.append('telNo', orderDetail.telNo.trim());
      }
      if (orderDetail.portingLines) {
        formData.append('numberOfPortingLines', orderDetail.portingLines.trim());
      }
      if (orderDetail.email) {
        formData.append('email', orderDetail.email.trim());
      }

      this.fileService.uploadNew(formData)
        .subscribe((data: any) => {
          if (data) {
            this.updateSuccessMsg = 'RequestId - ' + data.CarrierRequestId;
            this.clearForm();
            this.clicked = false;
            this.isUpdatingOrder = false;
          }
        }, error => {
          let errorbody = error;
          const errorMsg = error.split(':');
          this.clicked= false;
          this.isUpdatingOrder = false;
          if (errorMsg.length >= 3) {
            errorbody = errorMsg[1];
            if (errorMsg[2]) {
              errorbody += ' - ' + errorMsg[2];
            }
          }
          this.serviceErrors.push(errorbody);
         
        });
    }
  }

  public isValidFiles(files) {
    // Check Number of files
    if (files.length > this.maxFiles) {
      this.error = 'At a time you can upload only ' + this.maxFiles + ' files';
      return;
    }
    this.isValidFileExtension(files);
    return this.error === '';
  }

  public isValidFileExtension(files) {
    // Make array of file extensions
    const extensions = (this.fileExt.split(','))
      .map(function (x) {
        return x.toLocaleUpperCase().trim();
      });
    for (let i = 0; i < files.length; i++) {
      // Get file extension
      const ext = files[i].name.toUpperCase().split('.').pop() || files[i].name;
      // Check the extension exists
      const exists = extensions.some(e => e === ext);
      if (!exists) {
        this.error = 'Error (Extension): ' + files[i].name;
      }
      // Check file size
      this.isValidFileSize(files[i]);
    }
  }

  public isValidFileSize(file) {
    const fileSizeinMB = file.size / (1024 * 1000);
    const size = Math.round(fileSizeinMB * 100) / 100; // convert upto 2 decimal place
    if (size > this.maxSize) {
      this.error = 'Error (File Size): ' + file.name + ': exceed file size limit of ' + this.maxSize + 'MB ( ' + size + 'MB )';
    }
  }

  clearForm() {
    this.files = null;
    this.isUpdatingOrder =false;
    this.clicked = false;
    if (this.filePicker) {
      this.filePicker.nativeElement.value = null;
    }
    this.fileUploadForm.reset();
  }

  clearErrors() {
    this.error = '';
    this.updateSuccessMsg = '';
    this.serviceErrors = [];
  }

  gotoPortoutSearch() {
    this.storageService.shouldFillSearchForm = true;
    this.router.navigate(['/portout/search']);
  }
}
