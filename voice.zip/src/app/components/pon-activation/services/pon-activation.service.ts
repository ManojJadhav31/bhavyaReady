import { Injectable } from '@angular/core';
import { ApiService } from '../../../shared/services/api.service';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';


@Injectable()
export class PonActivationService {

  constructor(private http: HttpClient,
              private apiService: ApiService) {
  }

  searchPon(pon) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/pon/search/activation/' + pon;
    return this.http.get(url).pipe(catchError(error => this.apiService.handleException(error)));
  }

  getTns(pon, activityId, tnCount) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/pon/search/activation/tn-details/' + pon + '/' + activityId + '/' + tnCount;
    return this.http.get(url).pipe(catchError(error => this.apiService.handleException(error)));
  }

  getPONByVoid(voiceOrderId) {
    const url = this.apiService.orderApiUrl + '/ServiceDelivery/v1/Voice/pon/search/void/' + voiceOrderId;
    return this.http.get(url).pipe(catchError(error => this.apiService.handleException(error)));
  }

}








































































































































