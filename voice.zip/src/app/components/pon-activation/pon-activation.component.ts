import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-pon-activation',
  templateUrl: 'pon-activation.component.html'
})

export class PonActivationComponent {
}
