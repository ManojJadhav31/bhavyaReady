import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {PonActivationComponent} from './pon-activation.component';
import {PonSearchComponent} from './pon-search/pon-search.component';

const routes: Routes = [
  {
    path: '', component: PonActivationComponent,
    data: {
      breadcrumb: 'Pon activation'
    },
    children: [
      {path: '', redirectTo: 'search', pathMatch: 'full'},
      {
        path: 'search', component: PonSearchComponent,
        data: {
          breadcrumb: 'Search'
        }
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PonActivationRoutingModule {
}

export const PonActivationComponents = [
  PonActivationComponent,
  PonSearchComponent
];
