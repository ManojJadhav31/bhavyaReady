import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ApiService} from '../../shared/services/api.service';
import {PortoutService} from '../portout/services/portout.service';
import {PonActivationComponent} from './pon-activation.component';
import {RouterTestingModule} from '@angular/router/testing';
import {TnActivitySearchService} from '../activation-service/services/tn-activity-search.service';
import {PonActivationRoutingModule} from './pon-activation-routing.module';
import {PonSearchComponent} from './pon-search/pon-search.component';
import {AppBreadcrumbModule} from '../../shared/app-breadcrumb/app-breadcrumb.module';
import {SharedModule} from '../../shared/shared.module';

class MockRouter {
  navigate (url) {
    return true;
  }
}

describe('PonActivationComponent', () => {
  let component: PonActivationComponent;
  let fixture: ComponentFixture<PonActivationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PonActivationComponent,
        PonSearchComponent
      ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        PonActivationRoutingModule,
        RouterTestingModule,
        AppBreadcrumbModule
      ],
      providers: [
        TnActivitySearchService,
        PortoutService,
        ApiService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PonActivationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to other screens', () => {
    const app = fixture.debugElement.componentInstance;
    const event = {
      index: 0
    };
    spyOn(component, 'onTabChange').and.returnValue(true);
    const result = app.onTabChange(event); // trigger click on first inner
    expect(result).toBe(true);
  });
});
