import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ActivityErrorDetailsRoutingModule } from './activity-error-details-routing.module';
import { ActivityErrorDetailsComponent } from './activity-error-details/activity-error-details.component';
import { SharedModule } from '../../shared/shared.module';
import { ActivityErrorDetailsService } from './activity-error-details.service';

@NgModule({
  declarations: [ActivityErrorDetailsComponent],
  imports: [SharedModule, ActivityErrorDetailsRoutingModule],
  providers: [ActivityErrorDetailsService]
})
export class ActivityErrorDetailsModule { }
