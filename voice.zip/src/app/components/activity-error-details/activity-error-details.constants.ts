enum ColumnType {
    string = 'string',
    number = 'number',
    date = 'date'
};

export interface GridColumnDetails {
    caption: string;
    value: string;
    visible: boolean;
    type: ColumnType;
    class: any
}



export const ActivityErrorGridColumns: GridColumnDetails[] = [
    {
        caption: 'TN Order ID',
        value: 'slOrderId',
        visible: true,
        type: ColumnType.string,
        class: { 'r11': true }
    },
    {
        caption: 'Activity ID',
        value: 'orderActivityPK',
        visible: true,
        type: ColumnType.string,
        class: { 'r11': true }
    },
    {
        caption: 'Error ID',
        value: 'errorId',
        visible: true,
        type: ColumnType.string,
        class: { 'r11': true }
    },
    {
        caption: 'Brief Message',
        value: 'briefMessage',
        visible: true,
        type: ColumnType.string,
        class: { 'briefMessage': true }
    },
    {
        caption: 'Error Message',
        value: 'errorMessage',
        visible: true,
        type: ColumnType.string,
        class: { 'errorMessage': true }
    },
    {
        caption: 'Error Status',
        value: 'errorStatus',
        visible: true,
        type: ColumnType.string,
        class: { 'r11': true }
    },
    {
        caption: 'Resolution Date',
        value: 'resolutionDate',
        visible: true,
        type: ColumnType.date,
        class: { 'r11': true }
    }
]


export interface ActivityErrorResponse {
    errorId: number;
    orderActivityPK: number;
    slOrderId: number;
    briefMessage: string;
    errorMessage: string;
    errorTypeId: number;
    errorStatus: string;
}