import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivityErrorDetailsService } from '../activity-error-details.service';
import { ActivityErrorResponse, ActivityErrorGridColumns, GridColumnDetails } from '../activity-error-details.constants';
import { MockActivityErrorResponse } from '../../../../tests/mockdata/activity-error-details/activity-error-details';
import { Location } from '@angular/common';

@Component({
  selector: 'app-activity-error-details',
  templateUrl: './activity-error-details.component.html',
  styleUrls: ['./activity-error-details.component.scss']
})
export class ActivityErrorDetailsComponent implements OnInit {

  public message: string;
  public activityId: string;
  public errorResult: ActivityErrorResponse[] = [];
  public gridColumns: GridColumnDetails[] = ActivityErrorGridColumns;

  constructor(private activatedRoute: ActivatedRoute, public activityErrorDetailsService: ActivityErrorDetailsService,
    public location: Location) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.params['id']
    console.log(id)
    if (id) {
      this.activityId = id;
      this.getErrorDetails();
    }
  }

  getErrorDetails() {
    this.activityErrorDetailsService.getOrderDetails(this.activityId).subscribe((response: ActivityErrorResponse[]) => {
      this.errorResult = response;
    }, error => this.message = error)
  }
}
