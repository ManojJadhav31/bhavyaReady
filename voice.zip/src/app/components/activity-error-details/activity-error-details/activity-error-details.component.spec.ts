import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivityErrorDetailsComponent } from './activity-error-details.component';

describe('ActivityErrorDetailsComponent', () => {
  let component: ActivityErrorDetailsComponent;
  let fixture: ComponentFixture<ActivityErrorDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivityErrorDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivityErrorDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
