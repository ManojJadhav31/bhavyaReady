import { Component, Input, OnInit } from '@angular/core';
import {
  VCSTResultDataInnerGrid,
  VoiceCompleteServiceTransferResult,
  VoiceCompleteServiceTransferResultInnerGrid
} from '../voice-complete-service-transfer-constants';

@Component({
  selector: 'app-voice-complete-service-transfer-location',
  templateUrl: './voice-complete-service-transfer-location.component.html',
  styleUrls: [ './voice-complete-service-transfer-location.component.css' ]
})
export class VoiceCompleteServiceTransferLocationComponent implements OnInit {

  @Input('rowData') rowData: VoiceCompleteServiceTransferResult;

  public voiceCompleteServiceTransferResultFiltered: VoiceCompleteServiceTransferResultInnerGrid[] = [];
  public selectedAllCheckbox: string[] = [];

  constructor() {
  }

  ngOnInit() {
    console.log(this.rowData);
    this.voiceCompleteServiceTransferResultFiltered = VCSTResultDataInnerGrid;
  }


  onSelectAllChange() {
    console.log(this.selectedAllCheckbox);
    if ( this.selectedAllCheckbox[0] ) {
      this.voiceCompleteServiceTransferResultFiltered.forEach((object) => {
        if ( !object.checked ) {
          object.checked = [];
        }
        if ( !object.checked[0] ) {
          object.checked = [ 'true' ];
        }
      });
    } else {
      this.voiceCompleteServiceTransferResultFiltered.forEach((object) => {
        object.checked = [];
      });
    }
  }

  onRowCheckboxChnage(event, row) {
    const selectedResult = this.voiceCompleteServiceTransferResultFiltered.filter(item => {
      if ( item.checked && item.checked[0] === 'true' ) {
        return true;
      } else {
        return false;
      }
    });
    if ( selectedResult.length > 0 && ( this.voiceCompleteServiceTransferResultFiltered.length === selectedResult.length ) ) {
      this.selectedAllCheckbox = [ 'true' ];
    } else {
      this.selectedAllCheckbox = [];
    }
  }
}
