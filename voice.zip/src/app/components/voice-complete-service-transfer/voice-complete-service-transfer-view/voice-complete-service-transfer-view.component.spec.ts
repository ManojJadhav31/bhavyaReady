import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { VoiceCompleteServiceTransferViewComponent } from './voice-complete-service-transfer-view.component';
import { SharedModule } from '../../../shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { VoiceCompleteServiceTransferLocationComponent } from '../voice-complete-service-transfer-location/voice-complete-service-transfer-location.component';

describe('VoiceCompleteServiceTransferViewComponent', () => {
  let component: VoiceCompleteServiceTransferViewComponent;
  let fixture: ComponentFixture<VoiceCompleteServiceTransferViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoiceCompleteServiceTransferViewComponent, VoiceCompleteServiceTransferLocationComponent ],
      imports: [ SharedModule, BrowserAnimationsModule ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoiceCompleteServiceTransferViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
