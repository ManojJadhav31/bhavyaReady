import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AssignAgentRequest } from './lsr-activity-agent-assign-dialog.constants';

@Component({
  selector: 'app-lsr-activity-agent-assign-dialog',
  templateUrl: './lsr-activity-agent-assign-dialog.component.html',
  styleUrls: ['./lsr-activity-agent-assign-dialog.component.scss']
})
export class LsrActivityAgentAssignDialogComponent implements OnInit {

  showDialog: boolean = false;
  assignType: string = 'Assign';
  @Output('onSubmit') onSubmit: EventEmitter<any> = new EventEmitter();
  requestPayload: AssignAgentRequest = new AssignAgentRequest();
  agentList = [
    { selected: 'selected', value: '', label: 'None' },
    { value: 'Angadi, Eswarappa', label: 'Angadi, Eswarappa' },
    { value: 'Bose, Deepak', label: 'Bose, Deepak' },
    { value: 'Chamaraju, Manu', label: 'Chamaraju, Manu' },
    { value: 'Nayak, Shrikantha', label: 'Nayak, Shrikantha' },
    { value: 'Pai, Rajavardhan', label: 'Pai, Rajavardhan' },
    { value: 'Tilley, Kenneth TILLEYK', label: 'Tilley, Kenneth TILLEYK' }
  ];

  assignValue = [
    { selected: 'selected', value: 'Assign', label: 'Assign' },
    { value: 'Re-assign', label: 'Re-assign' },
    { value: 'Unassign', label: 'Unassign' }
  ]
  constructor() {
  }

  ngOnInit() {
  }

  onClickSave() {
    let requestPayload = new AssignAgentRequest();
    requestPayload = this.requestPayload;
    requestPayload.agent = this.assignType && this.assignType !== 'Unassign' ? this.requestPayload.agent : null;
    this.onSubmit.emit(requestPayload);
  }
}
