import { TestBed } from '@angular/core/testing';

import { LsrActivityAgentAssignDialogService } from './lsr-activity-agent-assign-dialog.service';

describe('LsrActivityAgentAssignDialogService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LsrActivityAgentAssignDialogService = TestBed.get(LsrActivityAgentAssignDialogService);
    expect(service).toBeTruthy();
  });
});
