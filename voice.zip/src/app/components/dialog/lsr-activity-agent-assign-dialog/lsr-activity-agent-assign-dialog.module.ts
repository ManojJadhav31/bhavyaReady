import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../../shared/shared.module';
import { LsrActivityAgentAssignDialogComponent } from './lsr-activity-agent-assign-dialog.component';
import { LsrActivityAgentAssignDialogService } from './lsr-activity-agent-assign-dialog.service';

@NgModule({
  declarations: [LsrActivityAgentAssignDialogComponent],
  exports: [LsrActivityAgentAssignDialogComponent],
  providers: [LsrActivityAgentAssignDialogService],
  imports: [
    SharedModule
  ]
})
export class LsrActivityAgentAssignDialogModule { }
