import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ColumnPickListDialogComponent } from './column-pick-list-dialog.component';
import { SharedModule } from '../../../../shared/shared.module';
import { StorageService } from '../../../../services/storage.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TnSearchResultsGridColumns } from '../../../activation-service/tn-activity-search/tn-activity-search-results-grid-columns';

describe('ColumnPickListDialogComponent', () => {
  let component: ColumnPickListDialogComponent;
  let fixture: ComponentFixture<ColumnPickListDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ColumnPickListDialogComponent ],
      imports: [ BrowserAnimationsModule, SharedModule ],
      providers: [ StorageService ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ColumnPickListDialogComponent);
    component = fixture.componentInstance;
    component.storageService.setModule('testing');
    fixture.detectChanges();
    component.resultsGridColumns = JSON.parse(JSON.stringify(TnSearchResultsGridColumns));
    component.resultsGridColumns.forEach((item) => {
      if ( component.defaultGridColumns.indexOf(item.value) !== -1 ) {
        item.visible = true;
      }
    });
    component.defaultGridColumns = [ 'voiceOrderId', 'parentTransId', 'tn', 'lnpFocDate', 'customerRequestDate', 'lnpStatus', 'customerBizOrgName',
      'activityName', 'activityStatus', 'activityCreateDate', 'activityCompleteDate', 'activationDate' ];
    component.gridColumnList = component.resultsGridColumns.filter(item => item.visible);
    component.hiddenColumns = component.resultsGridColumns.filter(item => !item.visible);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reset pick list', () => {
    component.onResetPickList();
    expect(component).toBeTruthy();
  });
});
