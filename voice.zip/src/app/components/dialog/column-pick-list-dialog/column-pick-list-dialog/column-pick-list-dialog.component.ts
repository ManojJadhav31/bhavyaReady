import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { StorageService } from '../../../../services/storage.service';
import { sortList } from '../../../../core/utills';

interface GridColumns {
  caption: string;
  value: string;
  visible: boolean;
  type: 'string' | 'number' | 'date';
  class: Map<string, boolean>;
}

@Component({
  selector: 'app-column-pick-list-dialog',
  templateUrl: './column-pick-list-dialog.component.html',
  styleUrls: [ './column-pick-list-dialog.component.scss' ]
})

export class ColumnPickListDialogComponent implements OnInit {

  showDialog: boolean = false;
  public localGridColumn: GridColumns[] = [];
  /** inputs */
  @Input('hiddenColumns') hiddenColumns: GridColumns[] = [];
  @Input('gridColumnList') gridColumnList: GridColumns[] = [];
  @Input('defaultGridColumns') defaultGridColumns: string[] = [];
  @Input('resultsGridColumns') resultsGridColumns: GridColumns[] = [];

  /** outputs */
  @Output('onListChange') onListChange: EventEmitter<GridColumns[]> = new EventEmitter();

  constructor(private storageService: StorageService) {
  }

  ngOnInit() {
    this.hiddenColumns = sortList(this.hiddenColumns, 'caption');
    this.localGridColumn = this.gridColumnList;
  }

  pickListClick() {
    const pickList = {
      hiddenColumns: sortList(this.hiddenColumns, 'caption'),
      gridColumnList: this.localGridColumn
    };
    this.onListChange.emit(this.localGridColumn);
    this.storageService.storePickList(pickList);
  }

  onResetPickList() {
    const columnList = JSON.parse(JSON.stringify(this.resultsGridColumns));
    columnList.forEach((item) => {
      if ( this.defaultGridColumns.indexOf(item.value) !== -1 ) {
        item.visible = true;
      }
    });
    this.localGridColumn = columnList.filter(item => item.visible);
    this.hiddenColumns = columnList.filter(item => !item.visible);
    this.hiddenColumns = sortList(this.hiddenColumns, 'caption');
    const pickList = {
      hiddenColumns: this.hiddenColumns,
      gridColumnList: this.localGridColumn
    };
    this.onListChange.emit(this.localGridColumn);
    this.storageService.storePickList(pickList);
  }

}
