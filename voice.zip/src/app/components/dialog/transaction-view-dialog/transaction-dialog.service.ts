import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { ApiService } from '../../../shared/services/api.service';

@Injectable()
export class TransactionDialogService {

  constructor( private http: HttpClient,
               private apiService: ApiService ) {

  }

  getErrorMessage( data: string[] ) {
     // const ids = this.generateQueryParam(data);
    const time = new Date().valueOf();
    const url = this.apiService.orderApiUrl + `/ServiceDelivery/v1/Voice/Transaction/status?orderActivityPks=` + data.join(',');
    // const url = this.apiService.orderApiUrl + `/ServiceDelivery/v1/Voice/Transaction/timeStamp?${time}&status?` + ids;
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');

    return this.http.get(url, {
      headers: headers
    }).pipe(catchError(error => this.apiService.handleException(error)));
  }

  generateQueryParam( data: any[] ): string {
    const ret = [];
    for ( const d of data ) {
      ret.push(encodeURIComponent('orderActivityPks') + '=' + encodeURIComponent(d));
    }
    return ret.join('&');
  }
}
