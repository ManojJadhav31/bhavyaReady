import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TransactionViewDialogComponent } from './transaction-view-dialog.component';
import { TransactionDialogService } from '../transaction-dialog.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from '../../../../shared/shared.module';
import { ApiService } from '../../../../shared/services/api.service';
import { StorageService } from '../../../../services/storage.service';

describe('TransactionViewDialogComponent', () => {
  let component: TransactionViewDialogComponent;
  let fixture: ComponentFixture<TransactionViewDialogComponent>;
  let transactionDialogService: TransactionDialogService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ BrowserAnimationsModule, SharedModule ],
      providers: [
        TransactionDialogService,
        ApiService,
        StorageService
      ],
      declarations: [ TransactionViewDialogComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransactionViewDialogComponent);
    transactionDialogService = fixture.debugElement.injector.get(TransactionDialogService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
