import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateFocAndCrdDialogComponent } from './update-foc-and-crd-dialog.component';

describe('UpdateFocAndCrdDialogComponent', () => {
  let component: UpdateFocAndCrdDialogComponent;
  let fixture: ComponentFixture<UpdateFocAndCrdDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateFocAndCrdDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateFocAndCrdDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
