import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { UtilityService } from '../../../../shared/services/utility.service';

class UpdateRequest {
  date: string;
  comments: string;
}

@Component({
  selector: 'app-update-foc-and-crd-dialog',
  templateUrl: './update-foc-and-crd-dialog.component.html',
  styleUrls: ['./update-foc-and-crd-dialog.component.scss']
})
export class UpdateFocAndCrdDialogComponent implements OnInit {

  public displayDialog: boolean = false;
  @Output('onSubmit') onSubmit: EventEmitter<any> = new EventEmitter();
  updateRequest: UpdateRequest = new UpdateRequest();

  constructor(private utilityService: UtilityService) { }

  ngOnInit() {
  }
  
  setRequest() {
    this.updateRequest = new UpdateRequest()
  }

  onSubmitClick() {
    const request = JSON.parse(JSON.stringify(this.updateRequest));
    request.date = this.utilityService.getFormatedDate(request.date);
    this.onSubmit.emit(request);
  }
}
