import { NgModule } from '@angular/core';
import { OrderDetailService } from './services/orderdetail-portout.service';
import { PortoutComponents, PortoutRoutingModule } from './portout-routing.module';
import { PortoutService } from './services/portout.service';
import { SharedModule } from '../../shared/shared.module';
import { SearchPortoutService } from './services/search-portout.service';
import { VpDatePipe } from '../../shared/pipes/vpDate.pipe';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';
import { PortoutOrderStatusDetailsComponent } from './search-portout/portout-order-status-details/portout-order-status-details.component';
import { ColumnPickListDialogModule } from '../dialog/column-pick-list-dialog/column-pick-list-dialog.module';


@NgModule({
  imports: [ SharedModule, PortoutRoutingModule, UpdateReasonDialogModule, ColumnPickListDialogModule],
  declarations: [ PortoutComponents, VpDatePipe, PortoutOrderStatusDetailsComponent],
  providers: [ PortoutService, OrderDetailService, SearchPortoutService ],
})
export class PortoutModule {
}
