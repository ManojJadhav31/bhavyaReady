import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { OrderdetailPortoutComponent } from './orderdetail-portout.component';
import { PortoutService } from '../../services/portout.service';
import { UtilityService } from '../../../../shared/services/utility.service';
import { OrderDetailService } from '../../services/orderdetail-portout.service';
import {
  OrderDetail,
  OrderDetailServiceStub,
  tns
} from '../../../../../tests/mockdata/portout/orderdetail/orderdetail';
import { of } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedModule } from '../../../../shared/shared.module';
import { StorageService } from '../../../../services/storage.service';
import { ApiService } from '../../../../shared/services/api.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UpdateReasonDialogModule } from '../../../dialog/update-reason-dialog/update-reason-dialog.module';
import { RouterTestingModule } from '@angular/router/testing';

describe('OrderdetailPortoutComponent', () => {
  let component: OrderdetailPortoutComponent;
  let fixture: ComponentFixture<OrderdetailPortoutComponent>;
  let orderDetailService: OrderDetailService, utilityService: UtilityService;

  beforeEach(async(() => {
    const params = {
      requestTypeId: 1
    };
    TestBed.configureTestingModule({
      declarations: [ OrderdetailPortoutComponent ],
      imports: [ SharedModule,
        BrowserAnimationsModule,
        UpdateReasonDialogModule,
        RouterTestingModule
      ],
      providers: [
        ApiService,
        UtilityService,
        StorageService,
        PortoutService,
        { provide: OrderDetailService, useClass: OrderDetailServiceStub },
        {
          provide: Router, useValue: {}
        },
        {
          provide: ActivatedRoute, useValue: {
            params: of(params)
          }
        } ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderdetailPortoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    orderDetailService = fixture.debugElement.injector.get(OrderDetailService);
    utilityService = fixture.debugElement.injector.get(UtilityService);
    const response = [];
    response.push(OrderDetail);
    component.requestTypeId = 'dummy';
    component.storageService.setModule('search-portout');
    spyOn(orderDetailService, 'getOrderDetails').and.returnValue(of(OrderDetail));
    // spyOn(orderDetailService, 'updateOrderDetail' ).and.returnValue(of(true));
    spyOn(orderDetailService, 'getTns').and.returnValue(of(tns));
    spyOn(utilityService, 'parseDate').and.returnValue('2018-04-08');
    component.newTns = [ '9874561254', '7678905362', '4567561254', '9874562344' ];
  });

  it('should create', fakeAsync(() => {

    fixture.detectChanges();
    tick();
    fixture.detectChanges();
    expect(component).toBeTruthy();
  }));

  it('should get tns', fakeAsync(() => {
    component.getTns();
    expect(component.tns).toBeDefined();
  }));
  describe('Add/Remove Tns', () => {
    beforeEach(async(() => {
      // fixture = TestBed.createComponent(OrderdetailPortoutComponent);
      // component = fixture.componentInstance;
      component.newTns = [ '9874561254', '7678905362', '4567561254', '9874562344' ];

      component.filteredTns = [ { 'id': '9874561254', 'checked': true }, {
        'id': '7678905362',
        'checked': true
      }, { 'id': '4567561254', 'checked': true },
        { 'id': '9874562344', 'checked': true },
        { 'id': '4567561254', 'checked': true }, { 'id': '123456', 'checked': false } ];
      // fixture.detectChanges();
    }));

    it('should add value to newTns', () => {
      const event = {
        target: {
          checked: true
        }
      };
      expect(component.newTns.length).toBe(4);
      const tnObj = {
        checked: '123456',
      };
      component.selectTns(event, tnObj);
      expect(component.newTns.length).toBe(5);

    });
    it('should remove value to newRemoveTns', () => {
      component.newTns = [ '9874561254', '7678905362', '4567561254', '9874562344' ];

      component.filteredTns = [ { 'id': '9874561254', 'checked': true }, {
        'id': '7678905362',
        'checked': false
      }, { 'id': '4567561254', 'checked': false },
        { 'id': '9874562344', 'checked': true },
        { 'id': '4567561254', 'checked': true }, { 'id': '123456', 'checked': false } ];
      const event = {
        target: {
          checked: false
        }
      };
      expect(component.newTns.length).toBe(4);
      const tnObjfalse = {
        checked: '',
      };
      component.selectTns(event, tnObjfalse);
      expect(component.newTns.length).toBe(3);
    });
  });

  it('should add new tns', ( () => {
    fixture.whenStable().then(data => {
      spyOn(orderDetailService, 'addTns').and.returnValue(of(true));
      component.newTn = '9874561254';
      fixture.detectChanges();
      component.addTn();
      tick();
      expect(component.tns.length).toBeGreaterThan(0);
    });
  } ));

  it('should remove existing tns', fakeAsync(() => {
    spyOn(orderDetailService, 'removeTns').and.returnValue(of([]));
    // spyOn(orderDetailService, 'getTns').and.returnValue(of(OrderDetailTns));
    component.newRemoveTn = '9874561254';
    fixture.detectChanges();
    component.removeTns();
    tick(25000);
    expect(component.tns.length).toBeGreaterThan(0);
  }));
  // it('should update order details', () => {
  //   spyOn(orderDetailService, 'updateOrderDetail').and.returnValue(of(true));
  //   component.updateOrderDetail.emit();
  //   fixture.detectChanges();
  //   expect(component.updateSuccessMsg).toBeTruthy();
  // });
  it('should filter tns', () => {
    component.getTns();
    const event = {
      target: {
        value: '2564473218'
      }
    };
    component.filterTns(event);
  });


  it('should be able to disable ban', () => {
    component.getTns();
    expect(component.isBanDisabled).toBe(true);
  });

  it('should be able to perform carrier approval action', () => {
    component.orderDetail = <any>OrderDetail;
    fixture.detectChanges();
    component.carrierApprovalAction('Approved');
    expect(component.orderDetail.carrierRequestId).toBe('12344555');
  });
  it('should be able to perform carrier Continue action', () => {
    component.orderDetail = <any>OrderDetail;
    fixture.detectChanges();
    component.carrierApprovalAction('Continue');
    expect(component.orderDetail.carrierRequestId).toBe('12344555');
  });
  it('should be able to perform carrier Rejected action', () => {
    component.orderDetail = <any>OrderDetail;
    fixture.detectChanges();
    component.carrierApprovalAction('Rejected', 'rejected reason');
    expect(component.orderDetail.carrierRequestId).toBe('12344555');
  });

  it('should not allow to add remove update tns', () => {
    component.selectedSuppActions = null;
    fixture.detectChanges();
    component.addRemoveUpdateTns();
    expect(component.removeTnErrorMsg).toBe('Please select at least one action.');
  });

  it('should add remove update tns', fakeAsync(() => {
    component.addTnUpdateSuccessMsg = 'Successfully Completed.';
    component.orderDetail = <any>OrderDetail;
    component.selectedSuppActions = [ 'addTns', 'update', 'removeTns' ];
    fixture.detectChanges();
    component.addRemoveUpdateTns();
    tick(25000);
    expect(component).toBeTruthy();
  }));
});
