export const ColumnType: any = {
  string: 'string',
  number: 'number',
  date: 'date'
};

export const PortoutResultsGridColumns: any = [
  {
    caption: 'LSR ID',
    value: 'carrierRequestId',
    visible: false,
    type: 'string',
    class: { 'r10': true }
  },
  {
    caption: '# Tn',
    value: 'tnCount',
    visible: false,
    type: 'string',
    class: { 'r6': true }
  },
  {
    caption: 'FOC DATE',
    value: 'focDate',
    visible: false,
    type: 'date',
    class: { 'r10': true }
  },
  {
    caption: 'END USER NAME',
    value: 'endUserName',
    visible: false,
    type: 'string',
    class: { 'r12': true }
  },
  {
    caption: 'Ver',
    value: 'purchaseOrderVersion',
    visible: false,
    type: 'string',
    class: { 'r6': true }
  },
  {
    caption: 'Carrier PON',
    value: 'purchaseOrderNumber',
    visible: false,
    type: 'string',
    class: { 'r11': true }
  },
  {
    caption: 'LSR Status',
    value: 'status',
    visible: false,
    type: 'string',
    class: { 'r9': true }

  },
  {
    caption: 'Pon Status',
    value: 'ponStatus',
    visible: false,
    type: 'string',
    class: { 'r9': true }
  },
  {
    caption: 'SANO',
    value: 'streetNumber',
    visible: false,
    type: 'string',
    class: { 'r9': true }
  },
  {
    caption: 'SASN',
    value: 'streetName',
    visible: false,
    type: 'string',
    class: { 'r9': true }
  },
  {
    caption: 'CITY',
    value: 'city',
    visible: false,
    type: 'string',
    class: { 'r10': true }
  },
  {
    caption: 'ST',
    value: 'state',
    visible: false,
    type: 'string',
    class: { 'r6': true }
  },
  {
    caption: 'ZIP CODE',
    value: 'zipCode',
    visible: false,
    type: 'string',
    class: { 'r9': true }
  },
  {
    caption: 'ERROR CODE',
    value: 'errorCode',
    visible: false,
    type: 'string',
    class: { 'r15': true }
  },
  {
    caption: 'ERROR MESSAGE',
    value: 'errorMessage',
    visible: false,
    type: 'string',
    class: { 'r19': true }
  }, 
  {
   caption:'Create UserName',
   value: 'contactName',
   visible:false,
   type: 'string',
   class: {'r15': true}
  },
  {
    caption:'Last Updated UserName',
    value:'lastUpdatedUser',
    visible:false,
    type :'string',
    class:{'r21': true}
  }
];
