import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {PortoutComponent} from './portout.component';
import {FileUploadComponent} from '../file-upload/file-upload.component';
import {SearchPortoutComponent} from './search-portout/search-portout.component';
import {ReportsPortoutComponent} from './reports-portout/reports-portout.component';
import {OrderdetailPortoutComponent} from './search-portout/orderdetail-portout/orderdetail-portout.component';


const routes: Routes = [
  {
    path: '', component: PortoutComponent,
    data: {
      breadcrumb: 'Portout'
    },
    children: [
      {path: '', redirectTo: 'search', pathMatch: 'full'},
      {
        path: 'search', component: SearchPortoutComponent,
        data: {
          breadcrumb: 'Search'
        }
      },
      {
        path: 'upload', component: FileUploadComponent,
        data: {
          breadcrumb: 'File upload'
        }
      },
      {
        path: 'upload/:requestTypeId', component: FileUploadComponent,
        data: {
          breadcrumb: 'File upload'
        }
      },
      {
        path: 'upload/:requestTypeId/:supActionDisabled', component: FileUploadComponent,
        data: {
          breadcrumb: 'File upload'
        }
      },
      {
        path: 'report', component: ReportsPortoutComponent,
        data: {
          breadcrumb: 'Report'
        }
      },
      {
        path: 'search/orderdetail/:requestTypeId', component: OrderdetailPortoutComponent,
        data: {
          breadcrumb: 'search order details'
        }
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PortoutRoutingModule {
}

export const PortoutComponents = [
  PortoutComponent,
  FileUploadComponent,
  SearchPortoutComponent,
  ReportsPortoutComponent,
  OrderdetailPortoutComponent,
];
