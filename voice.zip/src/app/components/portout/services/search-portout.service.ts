import { Injectable } from '@angular/core';
import { PortoutService } from './portout.service';
import { HttpParams } from '@angular/common/http';
import { ApiService } from '../../../shared/services/api.service';
import { Observable } from 'rxjs';
import { CancelRequest } from '../search-portout/search-portout-result';

@Injectable()
export class SearchPortoutService {

  constructor(private service: PortoutService,
    private apiService: ApiService) {
  }

  searchOrders(carrierRequestId: string, pon: string, tn: string, orderstatus: string,
    startDate: string, endDate: string, ponStatus: string): Observable<any> {


    let paramlist = new HttpParams();
    if (carrierRequestId) {
      paramlist = paramlist.append('carrierRequesTypeId', carrierRequestId);
    }
    if (pon) {
      paramlist = paramlist.append('pon', pon);
    }
    if (tn) {
      paramlist = paramlist.append('tn', tn);
    }

    if (orderstatus) {
      paramlist = paramlist.append('status', orderstatus);
    }
    if (ponStatus) {
      paramlist = paramlist.append('ponStatus', ponStatus);
    }
    if (startDate) {
      paramlist = paramlist.append('createDateStart', startDate);
    }

    if (endDate) {
      paramlist = paramlist.append('createDateEnd', endDate);
    }
    const url = this.apiService.portoutToolApiUrl + '/ServiceDelivery/v1/Voice/portOut/search';
    return this.service.getRequest(url, paramlist);
  }

  cancelOrders(carrierRequestId: string): Observable<any> {
    const requestBody = new CancelRequest();
    requestBody.carrierRequestId = carrierRequestId;
    const url = this.apiService.portoutToolApiUrl + `/ServiceDelivery/v1/Voice/portOut/cancel`;
    return this.service.putRequest(url, requestBody);
  }

  getOrderStatusDetails(carrierRequestId: string): Observable<any> {
    const url = this.apiService.portoutToolApiUrl + `/ServiceDelivery/v1/Voice/portOut/${carrierRequestId}/pons`;
    return this.service.getRequest(url);
  }
}

