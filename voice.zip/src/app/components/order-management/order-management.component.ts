import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-order-management',
  templateUrl: './order-management.component.html',
  styleUrls: [ './order-management.component.scss' ]
})
export class OrderManagementComponent implements OnInit {

  public selectedTab = '';

  constructor( private router: Router,
               private route: ActivatedRoute ) {
  }

  ngOnInit() {
    this.route.url.subscribe(data => {
      const url = this.router.url;
      if ( url.search('order-mgmt-search') > 0 ) {
        this.selectedTab = 'orderMgmtSearch';
      }
    });
  }

  onTabChange( event ) {
    switch ( event.index ) {
      case 0:
        this.router.navigate([ '/order-management/order-mgmt-search' ]);
        break;
    }
  }


}
