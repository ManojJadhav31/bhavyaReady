import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { OrderManagementComponent } from './order-management.component';
import { SearchPanelsModule } from '../search-panels/search-panels.module';
import { OrderMgmtSearchService } from './services/order-mgmt-search.service';
import { SearchPanelsService } from '../search-panels/services/search-panels.service';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { OrderManagementRoutingModule } from './order-management-routing.module';
import { OrderMgmtSearchComponent } from './order-mgmt-search/order-mgmt-search.component';
import { OrderManagementOrderDetailPageComponent } from './order-management-order-detail-page/order-management-order-detail-page.component';
import { SharedModule } from '../../shared/shared.module';
import { PricingInformationComponent } from './pricing-information/pricing-information.component';
import { UpdateOrderDateDialogModule } from '../dialog/update-order-date-dialog/update-order-date-dialog.module';
import { TransactionViewDialogModule } from '../dialog/transaction-view-dialog/transaction-view-dialog.module';
import { UpdateReasonDialogModule } from '../dialog/update-reason-dialog/update-reason-dialog.module';
import { ColumnPickListDialogModule } from '../dialog/column-pick-list-dialog/column-pick-list-dialog.module'

describe('OrderManagementComponent', () => {
  let component: OrderManagementComponent;
  let fixture: ComponentFixture<OrderManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        OrderManagementComponent,
        OrderMgmtSearchComponent,
        OrderManagementOrderDetailPageComponent,
        PricingInformationComponent
      ],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        OrderManagementRoutingModule,
        SearchPanelsModule,
        RouterTestingModule,
        UpdateOrderDateDialogModule,
        TransactionViewDialogModule,
        UpdateReasonDialogModule,
        ColumnPickListDialogModule
      ],
      providers: [
        OrderMgmtSearchService,
        SearchPanelsService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Tab change method check', () => {
    expect(component.onTabChange(0)).toBeFalsy();
  });
});
