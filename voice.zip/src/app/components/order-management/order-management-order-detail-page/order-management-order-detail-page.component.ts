import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderMgmtSearchService } from '../services/order-mgmt-search.service';



@Component({
  selector: 'app-order-management-order-detail-page',
  templateUrl: './order-management-order-detail-page.component.html',
  styleUrls: [ './order-management-order-detail-page.component.scss' ],

})
export class OrderManagementOrderDetailPageComponent implements OnInit {

  public orderDetail: any = {};
  orderId: string = null;
  public changeSummaryTableData: any[] = [];
  public CommentsTableData: any[] = [];
  message: string;

  constructor( private route: ActivatedRoute,
               private router: Router,
               private orderMgmtSearchService: OrderMgmtSearchService ) {
  }

  ngOnInit() {
    this.route
      .params
      .subscribe(params => {
        this.orderId = params['orderId'];
        this.message = '';
        this.orderMgmtSearchService.getOrderDetail(this.orderId).subscribe(res => {
          if ( res[0] ) {
            this.orderDetail = res[0];
            this.setupDataForUI();
          }
        }, error => this.message = error);
      });
  }

  setupDataForUI() {
    if ( this.orderDetail['orderChange'] ) {
      this.changeSummaryTableData.push({ orderChange: this.orderDetail['orderChange'] });
    }

    if ( this.orderDetail['comments'] || this.orderDetail['customer'] || this.orderDetail['commentDate'] ) {
      this.CommentsTableData.push({
        comments: this.orderDetail['comments'],
        customer: this.orderDetail['customer'],
        commentDate: this.orderDetail['commentDate']
      });
    }
  }

  BackToOderDetailPage() {
    this.router.navigate([ './order-management/order-mgmt-search' ]);
  }

}
