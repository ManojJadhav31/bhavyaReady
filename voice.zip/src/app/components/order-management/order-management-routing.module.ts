import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OrderManagementComponent } from './order-management.component';
import { OrderMgmtSearchComponent } from './order-mgmt-search/order-mgmt-search.component';
import { OrderManagementOrderDetailPageComponent } from './order-management-order-detail-page/order-management-order-detail-page.component';
import { PricingInformationComponent } from './pricing-information/pricing-information.component';


const routes: Routes = [
  {
    path: '', component: OrderManagementComponent,
    data: {
      breadcrumb: 'Order Search'
    },
    children: [
      { path: '', redirectTo: 'order-mgmt-search', pathMatch: 'full' },
      {
        path: 'order-mgmt-search', component: OrderMgmtSearchComponent,
        data: {
          breadcrumb: 'Search'
        }
      },
      {
        path: 'order-mgmt-order-detail/:orderId', component: OrderManagementOrderDetailPageComponent,
        data: {
          breadcrumb: 'Order detail'
        }
      },
      {
        path: 'pricing-info/:orderId/:tn', component: PricingInformationComponent,
        data: {
          breadcrumb: 'Order pricing details'
        }
      }
    ]
  },
];

@NgModule({
  imports: [ RouterModule.forChild(routes) ],
  exports: [ RouterModule ],
})
export class OrderManagementRoutingModule {
}
