import { Component, OnInit, ViewChild } from '@angular/core';
import { OrderMgmtSearchService } from '../services/order-mgmt-search.service';
import * as dateFn from 'date-fns';
import * as XLSX from 'xlsx';
import { DataTable } from 'primeng/primeng';
import { SearchRequestObject } from '../../search-panels/search-panel-constants';
import { StorageService } from '../../../services/storage.service';
import { Router } from '@angular/router';
import { OrderSearchResultsGridColumns } from './order-mgmt-search-results-grid-columns';
import { forkJoin, Observable } from 'rxjs';
import { UpdateOrderDateDialogComponent } from '../../dialog/update-order-date-dialog/update-order-date-dialog.component';
import { TransactionViewDialogComponent } from '../../dialog/transaction-view-dialog/transaction-view-dialog/transaction-view-dialog.component';
import { UpdateReasonDialogComponent } from '../../dialog/update-reason-dialog/update-reason-dialog.component';
import { ColumnPickListDialogComponent } from '../../dialog/column-pick-list-dialog/column-pick-list-dialog/column-pick-list-dialog.component';
import { UtilityService } from '../../../shared/services/utility.service';

@Component({
  selector: 'app-order-mgmt-search',
  templateUrl: './order-mgmt-search.component.html',
  styleUrls: [ './order-mgmt-search.component.scss' ]
})
export class OrderMgmtSearchComponent implements OnInit {

  @ViewChild('searchResultGrid') searchResultGrid: DataTable;
  slOrderId: any;
  customerList: any = [];
  dateType: any = [];
  selectedDateType: any = 'All';
  selectedDateCategories: any = 'range';
  selectedDateRange: any;
  selectedDateTypeSecondary: any = 'All';
  selectedDateCategoriesSecondary: any = 'range';
  selectedDateRangeSecondary: any;
  gridColumnList: any = [];
  hiddenColumns: any = [];
  showColumnFilterDialog = false;
  isSearching = false;
  panelFilter: PanelFilter;
  filerPanelsCheckBox = {
    OrderSearch: [],
    LnpSearch: [],
    E911Search: [],
    EmeaSearch: []
  };
  panelFilterList: string[] = [];
  filteredResults: any[] = [];
  selectedActivityIds: any[] = [];
  orderSearch: SearchRequestObject = new SearchRequestObject();
  searchResults: any = [];

  pageNumber = 1;
  totalRecords = 0;
  skip = 0;
  pageSize = 100;
  firstPage = 0;
  isExporting = false;

  actionToPerform = { code: 'export' };
  updateAction = {
    type: { name: 'Selected Order', code: 'selectedOrder' },
    operation: { name: 'Selected Order', code: 'selectedOrder' }
  };
  exportType: any = {
    code: 'all'
  };
  actionDropdownOptions: any[] = [
    { name: 'export', code: 'export' }
  ];

  updateOptions: any = [
    { name: 'Selected Order', code: 'selectedOrder' }
  ];
  selectedOrderOperations: any = [
    { name: 'Select One', code: '' },
    { name: 'Update Order Date', code: 'orderDateUpdate' },
    { name: 'Update Order Comments', code: 'orderCommentUpdate' }
  ];
  exportOptions: any = [
    { name: 'All Result', code: 'all' },
    { name: 'Selected Result', code: 'selected' }
  ];

  resultType: any = {
    code: 'all'
  };
  resultOptions: any = [
    { name: 'Export Results', code: 'all' },
    { name: 'Export All', code: 'exportAll' },
    { name: 'Export TNS', code: 'tns' }

  ];
  message: string;
  searchPanelCollapsed = {
    mainSearch: false,
    OrderSearch: false,
    LnpSearch: false,
    E911Search: false,
    EmeaSearch: false
  };

  isUpdating = false;
  updateError = '';
  updateErrorShowTrunk = {
    length: 500,
    showMore: false
  };
  successMessage = '';
  @ViewChild('updateOrderDateDialog') updateOrderDateDialog: UpdateOrderDateDialogComponent;
  @ViewChild('transactionDetailsDialog') transactionDetailsDialog: TransactionViewDialogComponent;
  @ViewChild('updateReasonOnlyDialog') updateReasonOnlyDialog: UpdateReasonDialogComponent;

  updateErrorMesg;
  selectAllCheckBox = [ 'false' ];
  UserName: string;
  public defaultGridColumns: string[] = [ 'parentOrderId', 'slOrderId', 'jeopErrors', 'lnpOrderStatus' , 'lnpVendorMsg', 'tn','btn', 'custTypeInd','orderAction',
  'orderStatus','orderType','custBusOrgId','customerName','masterBusOrgId','desiredDueDate','productId','product','scid','esOption','rcAbbr','extOrderId','reasonCode',
  'reasonDecription','oldOcn','businessName','subscriberName','lnpYn','lnpWirelessYn','activationTime','internalPortYn','lnpOrderState','lnpLastUpdatedDate',
  'lnpFocDate','lnpGwFocDate','lnpProjectId','lnpLastEventName','lastOutboundError','lastOutboundMessage','lastInboundError',
  'lastInboundMessage','portTriggerDate','portUserId','lnpOption','country'];




  @ViewChild('columnPickListDialog') columnPickListDialog: ColumnPickListDialogComponent;
  public resultsGridColumns = OrderSearchResultsGridColumns;

  constructor(private orderMgmtSearchService: OrderMgmtSearchService,
              private storageService: StorageService,
              private utilService: UtilityService,
              private router: Router) {
    this.storageService.setModule('order-mgmt');
  }

  ngOnInit() {
    this.UserName = localStorage.getItem('UserName') !== 'undefined' ? localStorage.getItem('UserName') : undefined;
    if ( this.UserName ) {
      this.actionDropdownOptions.push({
        name: 'Update', code: 'update'
      });
    }
    this.panelFilter = {
      OrderSearch: false,
      LnpSearch: false,
      E911Search: false,
      EmeaSearch: false
    };

    this.orderSearch.selectedDateTypeSecondary = 'All';
    this.orderSearch.selectedDateType = 'All';
    this.searchResults = [];
    this.filteredResults = [];
    this.setPresetData();
  }

  setPresetData() {
    const columnList = JSON.parse(JSON.stringify(this.resultsGridColumns));
    columnList.forEach((item) => {
      if ( this.defaultGridColumns.indexOf(item.value) !== -1 ) {
        item.visible = true;
      }
    });
    this.gridColumnList = columnList.filter(item => item.visible);
    this.hiddenColumns = columnList.filter(item => !item.visible);

    const searchDetails = this.storageService.getSearchDetails();
    if ( searchDetails ) {
      if ( searchDetails.formData ) {
        Object.assign(this.orderSearch, searchDetails.formData);
      }
      if ( searchDetails.pageConfig ) {
        this.firstPage = searchDetails.pageConfig.firstPage;
        this.pageNumber = searchDetails.pageConfig.pageNumber;
        this.pageSize = searchDetails.pageConfig.pageSize;
      }

      if ( searchDetails.results && searchDetails.totalRecords ) {
        Object.assign(this.searchResults, searchDetails.results);
        Object.assign(this.filteredResults, searchDetails.results);
        this.totalRecords = searchDetails.totalRecords;
        this.searchPanelCollapsed['mainSearch'] = true;
        this.skip = 0;
      }
      if ( searchDetails.panelList ) {
        searchDetails.panelList.forEach((key) => {
          if ( searchDetails.results && searchDetails.totalRecords ) {
            this.searchPanelCollapsed[key] = true;
          }
          this.filerPanelsCheckBox[key] = [ 'true' ];
          this.filterPanels(key, true);
        });
      }

      const pickListDetails = this.storageService.getPickList();
      if ( pickListDetails ) {
        this.hiddenColumns = pickListDetails.hiddenColumns;
        this.gridColumnList = pickListDetails.gridColumnList;
      }
    }
  }

  filterPanels(key, event) {
    if ( key === 'OrderSearch' ) {
      this.panelFilter.OrderSearch = event;
    } else if ( key === 'LnpSearch' ) {
      this.panelFilter.LnpSearch = event;
    } else if ( key === 'E911Search' ) {
      this.panelFilter.E911Search = event;
    } else if ( key === 'EmeaSearch' ) {
      this.panelFilter.EmeaSearch = event;
    }
    if ( event ) {
      const index = this.panelFilterList.indexOf(key);
      if ( index === -1 ) {
        this.panelFilterList.push(key);
      }
    } else {
      const index = this.panelFilterList.indexOf(key);
      if ( index !== -1 ) {
        this.panelFilterList.splice(index, 1);
      }
    }
    this.storageService.storePanelSearchList(this.panelFilterList);
  }

  search(orderSearch) {
    this.updateError = '';
    this.updateErrorMesg = '';
    this.message = '';
    this.successMessage = '';
    this.pageNumber = 1;
    this.firstPage = 0;
    this.selectedActivityIds = [];
    this.storageService.storeSelectedActivityIds([], true);
    this.searchActivities(orderSearch);
  }

  checkNonRequiredField(activitySearch) {
    if ( activitySearch.masterBusOrgId || activitySearch.orderStatus || activitySearch.countryCode || activitySearch.selectedDateCategoriesSecondaryToDate || activitySearch.selectedDateCategoriesSecondaryFromDate ) {
      return true;
    }
    if ( this.filerPanelsCheckBox.LnpSearch[0] && this.filerPanelsCheckBox.LnpSearch[0] == 'true' ) {
      if ( activitySearch.lnpStatus || activitySearch.lnpOrderState || activitySearch.psid || activitySearch.lnpOption || activitySearch.lnpStateCode || activitySearch.scid || activitySearch.lnpOldLrn
        || activitySearch.newLrn || activitySearch.lnpOrderError || activitySearch.lnpWirelessYn || activitySearch.locationScid || activitySearch.lnpWirelessYn
        || activitySearch.btn || activitySearch.adoptYn || activitySearch.activationHour || activitySearch.activationMin || activitySearch.activationTimeZone || activitySearch.adoptYn ) {
        return true;
      }
    }
    if ( this.filerPanelsCheckBox.E911Search[0] && this.filerPanelsCheckBox.E911Search[0] == 'true' ) {
      if ( activitySearch.businessName || activitySearch.preDirectional || activitySearch.aliStatus || activitySearch.subscriberName || activitySearch.streetNum
        || activitySearch.fipsCode || activitySearch.city || activitySearch.streetName || activitySearch.stateProv || activitySearch.streetType
        || activitySearch.zip || activitySearch.postDirectional || activitySearch.esOption ) {
        return true;
      }
    }
    if ( this.filerPanelsCheckBox.EmeaSearch[0] && this.filerPanelsCheckBox.EmeaSearch[0] == 'true' ) {
      if ( activitySearch.country || activitySearch.cityEmea || activitySearch.tnAreaCode || activitySearch.contactLanguage || activitySearch.listingLanguage ) {
        return true;
      }
    }
    if ( this.filerPanelsCheckBox.OrderSearch[0] && this.filerPanelsCheckBox.OrderSearch[0] == 'true' ) {
      if ( activitySearch.orderType || activitySearch.customerList || activitySearch.product || activitySearch.switchType
        || activitySearch.lnpOrder || activitySearch.orderStatus || activitySearch.orderAction || activitySearch.servicePackage || activitySearch.orderSource
        || activitySearch.switchType || activitySearch.serviceTransferYn || activitySearch.routePlanName || activitySearch.requesterName || activitySearch.requesterEmail
        || activitySearch.accomments || activitySearch.jeopardyError || activitySearch.lastInboundError || activitySearch.lnpFeatureCode || activitySearch.rcAbbr
        || activitySearch.rcState || activitySearch.reasonCodeList || activitySearch.lastOutboundError || activitySearch.lnpOldOcn || activitySearch.newOcn
        || activitySearch.lata || activitySearch.market || activitySearch.extOrderIdList || activitySearch.usageBilling ) {//activitySearch.orderActiveYn ||
        return true;
      }

    }
    return false;
  }

  searchActivities(orderSearch) {
    this.message = '';
    const body: any = {};
    this.orderSearch.noData = {
      error: false
    };

    if ( orderSearch.tnOrderId || orderSearch.lnpProjectId || orderSearch.voiceOrderId || orderSearch.extOrderId || orderSearch.parentOrderId || orderSearch.tn || ( orderSearch.tn === null && orderSearch.tnList ) || orderSearch.voiceCompleteServiceId || orderSearch.selectedDateType !== 'All' || orderSearch.selectedDateTypeSecondary !== 'All' ) {
      orderSearch.requiredFieldsError = {
        error: false
      };
    } else {
      orderSearch.requiredFieldsError = {
        error: true,
        msg: 'Please enter at least one of the required fields: Tn Order ID, VoiceComplete ServiceId, LNP Project Id ,Voice Order Id ,Parent Order Id, Voice Complete ServiceID, External Order Id, or TN'
      };
      return;
    }
    if ( orderSearch.requiredFieldsError.error === false ) {
      if ( orderSearch.selectedDateType !== 'All' ) {
        this.fillDateTypePayload(orderSearch, orderSearch);
        let error = false;
        if ( orderSearch.tnOrderId || orderSearch.lnpProjectId || orderSearch.voiceOrderId || orderSearch.extOrderId || orderSearch.parentOrderId || orderSearch.tn || orderSearch.voiceCompleteServiceId ) {
          error = false;
        } else if ( orderSearch.selectedDateCategories === 'range' ) {
          if ( dateFn.differenceInCalendarDays(orderSearch.selectedDateToDate, orderSearch.selectedDateFromDate) >= 90 && this.checkNonRequiredField(orderSearch) ) {
            error = true;
          }
        } else if ( orderSearch.selectedDateCategories === 'relative' && orderSearch.selectedDateRange === 'past90Days' && this.checkNonRequiredField(orderSearch) ) {
          error = true;
        }
        if ( error ) {
          orderSearch.requiredFieldsError = {
            error: true,
            msg: 'You can not select date type past 90 days date'
          };
          return;
        }
      }
      if ( orderSearch.selectedDateTypeSecondary !== 'All' ) {
        this.fillDateTypeSecondaryPayload(orderSearch, orderSearch);
        let error = false;
        if ( orderSearch.tnOrderId || orderSearch.lnpProjectId || orderSearch.voiceOrderId || orderSearch.extOrderId || orderSearch.parentOrderId || orderSearch.tn || orderSearch.voiceCompleteServiceId ) {
          error = false;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'range' && this.checkNonRequiredField(orderSearch) ) {
          if ( dateFn.differenceInCalendarDays(orderSearch.selectedDateCategoriesSecondaryToDate, orderSearch.selectedDateCategoriesSecondaryFromDate) >= 90 ) {
            error = true;
          }
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' && orderSearch.selectedDateRangeSecondary === 'past90Days' && this.checkNonRequiredField(orderSearch) ) {
          error = true;
        }
        if ( error ) {
          orderSearch.requiredFieldsError = {
            error: true,
            msg: 'You can not select date type secondary past 90 days date'
          };
          return;
        }
      }
    }

    if ( orderSearch.selectedDateType !== 'All' && orderSearch.selectedDateType === orderSearch.selectedDateTypeSecondary ) {
      orderSearch.dateTypeError = {
        error: true,
        msg: 'Date Type & Date Type Secondary cannot be same. Please choose different values.'
      };
      return;
    } else {
      orderSearch.dateTypeError = {
        error: false
      };
    }

    this.createBodyForService(orderSearch).subscribe((returnBody) => {
      this.selectedActivityIds = [];
      this.searchResults = [];
      this.filteredResults = [];
      this.totalRecords = 0;
      this.isSearching = true;
      this.orderMgmtSearchService.searchActivities(returnBody, this.pageSize, this.pageNumber).subscribe(res => {
        this.isSearching = false;
        const data = ( res as any );
        if ( data.orderSearchDTOList && data.orderSearchDTOList.length > 0 ) {
          this.searchPanelCollapsed = {
            mainSearch: true,
            OrderSearch: true,
            LnpSearch: true,
            E911Search: true,
            EmeaSearch: true
          };
          this.searchResults = data.orderSearchDTOList.sort((a, b) => {
            const nameA = a.tnOrderId, nameB = b.tnOrderId;
            if ( nameA < nameB ) { // sort string ascending
              return -1;
            }
            if ( nameA > nameB ) {
              return 1;
            }
            return 0;
          });

          const activitySerchResult = JSON.parse(JSON.stringify(this.searchResults));
          activitySerchResult.forEach(activity => {
            const findObject = this.selectedActivityIds.find(obj => obj.parentOrderId === activity.parentOrderId);
            if ( findObject ) {
              activity.checked = 'true';
            }
          });
          this.filteredResults = activitySerchResult;
          this.totalRecords = data.totalElementsCount;
          this.skip = 0;
          this.storageService.storeSearchDetails(orderSearch, this.searchResults, this.totalRecords);
        } else {
          this.orderSearch.noData = {
            error: true
          };
        }
      }, error => {
        this.message = error;
        this.isSearching = false;
      });
    });
  }

  createBodyForService(orderSearch): Observable<any> {
    return new Observable((observer) => {
      const body: any = {};

      // ----------- Default Search Params -----------
      body.slOrderId = orderSearch.tnOrderId || undefined;
      body.vcServiceId = orderSearch.voiceCompleteServiceId || undefined;
      body.internalPortYn = orderSearch.internalPortOptions || undefined;
      body.lnpProjectId = orderSearch.lnpProjectId || undefined;
      body.extOrderIdList = orderSearch.extOrderId || undefined;
      body.voiceOrderId = orderSearch.voiceOrderId || undefined;
      body.parentTransIdList = orderSearch.parentOrderId || undefined;

      if ( orderSearch.showTnTextArea ) {
        body.tnList = this.utilService.createArrayFromTextArea(orderSearch.tnList);
        // const tns = orderSearch.tnList.split(',');
        // if (tns.length > 0) {
        //   body.tnList = tns;
        // } else {
        //   body.tnList = [orderSearch.tnList];
        // }
      } else {
        if ( orderSearch.tn ) {
          body.tnList = this.utilService.createArrayFromTextArea(orderSearch.tn);
          // const tn = orderSearch.tn.replace('-', '');
          // body.tnList = [tn];
        }
      }
      if ( orderSearch.parentOrderId ) {
        body.parentTransIdList = this.utilService.createArrayFromTextArea(orderSearch.parentOrderId);
        // const pons = orderSearch.parentOrderId.split(',');
        // if (pons.length > 0) {
        //   body.parentTransIdList = pons;
        // } else {
        //   body.parentTransIdList = [orderSearch.parentOrderId];
        // }
      }
      if ( orderSearch.extOrderId ) {
        body.extOrderIdList = this.utilService.createArrayFromTextArea(orderSearch.extOrderId);
        // const extOrder = orderSearch.extOrderId.split(',');
        // if (extOrder.length > 0) {
        //   body.extOrderIdList = extOrder;
        // } else {
        //   body.extOrderIdList = [orderSearch.extOrderId];
        // }
      }


      if ( orderSearch.selectedDateType !== 'All' ) {
        this.fillDateTypePayload(orderSearch, body);
      }
      if ( orderSearch.selectedDateTypeSecondary !== 'All' ) {
        this.fillDateTypeSecondaryPayload(orderSearch, body);
      }


      // ----------- Order Search Params -----------
      body.orderActiveYn = orderSearch.orderActiveYn || undefined;
      body.orderAction = orderSearch.orderAction || undefined;

      if ( orderSearch.orderStatus && orderSearch.orderStatus.length > 0 ) {
        body.orderStatusList = orderSearch.orderStatus;
      }
      // body.orderStatusList = orderSearch.orderStatus || undefined;
      body.orderType = orderSearch.orderType || undefined;
      body.switchType = orderSearch.switchType || undefined;
      body.rcAbbr = orderSearch.rcAbbr || undefined;

      if ( orderSearch.servicePackage && orderSearch.servicePackage.length > 0 ) {
        body.servicePackageList = orderSearch.servicePackage;
      }
      // body.servicePackageList = orderSearch.servicePackage || undefined;
      body.serviceTransferYn = orderSearch.serviceTransferYn || undefined;
      body.market = orderSearch.market || undefined;

      body.lastInboundError = orderSearch.lastInboundError || undefined;
      body.lastOutboundError = orderSearch.lastOutboundError || undefined;
      body.lnpYn = orderSearch.lnpOrder || undefined;
      body.customerList = orderSearch.customerList || undefined;
      body.productList = orderSearch.productList || undefined;
      body.firstUsageBilling = orderSearch.firstUsageBilling || undefined;
      body.jeopErrors = orderSearch.jeopardyErrors || undefined;
      body.featureCode = orderSearch.featureCode || undefined;
      body.psid = orderSearch.psid || undefined;

      if ( orderSearch.reasonCodeList && orderSearch.reasonCodeList.length > 0 ) {
        body.reasonCodeList = orderSearch.reasonCodeList;
      }
      // body.reasonCodeList = orderSearch.reasonCodeList || undefined;

      //  ----------- LNP Order Search -----------
      body.lnpOrderError = orderSearch.lnpOrderError || undefined;
      body.masterBusOrgId = orderSearch.masterBusOrgId || undefined;
      body.adoptOrder = orderSearch.adoptOrder || undefined;
      body.lnpStatus = orderSearch.lnpStatus || undefined;
      body.lnpVendorMessage = orderSearch.lnpVendorMessage || undefined;
      body.btn = orderSearch.btn || undefined;
      body.lnpOption = orderSearch.lnpOption || undefined;
      body.locationScid = orderSearch.locationScid || undefined;
      body.lnpWirelessYn = orderSearch.lnpWirelessYn || undefined;
      body.scid = orderSearch.scid || undefined;
      body.lnpOrderState = orderSearch.lnpOrderState || undefined;
      if ( orderSearch.activationHour && orderSearch.activationMin && orderSearch.activationTimeZone ) {
        body.activationDate = orderSearch.activationHour + ':' + orderSearch.activationMin + ' ' + orderSearch.activationTimeZone;
      }

      //  ----------- E911 Search -----------
      // body.owner = orderSearch.owner;
      // body.cityName = orderSearch.cityName;
      body.businessName = orderSearch.businessName || undefined;
      body.subscriberName = orderSearch.subscriberName || undefined;
      body.esOption = orderSearch.esOption || undefined;

      //  ----------- EMEA Search -----------
      body.countryName = orderSearch.countryName || undefined;
      // body.cityEmea = orderSearch.cityEmea;
      body.areaCode = orderSearch.areaCode || undefined;
      observer.next(body);
    });
  }

  loadSearchResults(event, filteredResults) {
    this.updateError = '';
    this.updateErrorMesg = '';
    const selectedActivityids: Array<string> = [];
    this.firstPage = event.first;
    this.pageNumber = ( event.first / event.rows ) + 1;
    this.pageSize = event.rows;
    filteredResults.forEach(item => {
      if ( item.checked && item.checked[0] === 'true' ) {
        selectedActivityids.push(item.id);
      }
    });
    if (this.totalRecords > 0) {    
    this.searchActivities(this.orderSearch);
  }
    this.storageService.storeSelectedActivityIds(selectedActivityids, false);
    this.storageService.storeSearchDetailsGridPage(this.pageNumber, this.pageSize, this.firstPage);
  }

  clearForm() {
    this.message = '';
    this.storageService.resetDetails();
    this.setPresetData();
    this.isSearching = false;
    this.orderSearch = new SearchRequestObject();
    this.orderSearch.selectedDateTypeSecondary = 'All';
    this.orderSearch.selectedDateType = 'All';
    this.searchResults = [];
    this.firstPage = 0;
    this.totalRecords = 0;
    this.filteredResults = [];
    // this.orderSearch.isDisplayable = 'Y';
    this.orderSearch.orderActiveYn = 'Y';
    this.successMessage = '';
    this.updateError = '';
    this.updateErrorMesg = '';
  }


  // Export Functionality

  exportExcelLocally(options, exportData) {
    if ( exportData.length > 0 ) {
      const xlsData = [];
      xlsData.push(options.headers);
      exportData.forEach(f => {
        const arr = [];
        Object.keys(f).forEach(key => {
          arr.push(f[key]);
        });
        xlsData.push(arr);
      });
      const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(xlsData);
      const wb: XLSX.WorkBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
      XLSX.writeFile(wb, 'OrderResults.csv');
    }
    this.isExporting = false;
  }

  exportExcelFromService(exportColumns?: string[]) {
    this.createBodyForService(this.orderSearch).subscribe((returnBody) => {
      if ( exportColumns ) {
        returnBody['exportColumns'] = exportColumns;
      }
      this.orderMgmtSearchService.getExportDetail(returnBody).subscribe((response) => {
        const url = window.URL.createObjectURL(response.data);
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.setAttribute('style', 'display:none');
        a.href = url;
        a.download = response.fileName;
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        // this.isExporting = false;
      }, error => {
        this.message = error;
        // this.isExporting = false;
      });
    });
  }

  exportOrderSearch() {
    let exportData = [];
    if ( this.filteredResults.length > 0 ) {
      this.isExporting = true;
      const options = {
        showLabels: true,
        headers: this.gridColumnList.map(col => {
          return col.caption;
        })
      };
      let selectedResult = this.filteredResults.filter(item => {
        if ( item.checked && item.checked[0] === 'true' ) {
          return true;
        } else {
          return false;
        }
      });
      if ( this.exportType.code === 'selected' ) {
        if ( this.resultType.code === 'tns' ) {
          options.headers = [ 'TN' ];
          exportData = selectedResult.map(row => {
            const data = {};
            data['tn'] = row['tn'];
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else if ( this.resultType.code === 'all' ) {
          exportData = selectedResult.map(row => {
            const data = {};
            this.gridColumnList.forEach(col => {
              data[col.value] = row[col.value] || '';
            });
            return data;
          });
          this.exportExcelLocally(options, exportData);
        }
      } else if ( this.exportType.code === 'all' ) {
        if ( this.resultType.code === 'tns' ) {
          this.exportExcelFromService([ 'tn' ]);
        } else if ( this.resultType.code === 'all' ) {
          selectedResult = this.filteredResults;
          exportData = selectedResult.map(row => {
            const data = {};
            this.gridColumnList.forEach(col => {
              data[col.value] = row[col.value] || '';
            });
            return data;
          });
          this.exportExcelLocally(options, exportData);
        } else if ( this.resultType.code === 'exportAll' ) {
          const exportColumns = this.gridColumnList.map(col => {
            return col.value;
          });
          this.exportExcelFromService(exportColumns);
        }
      }
    }
  }

  // END
  showHideColumnFilterDialog() {
    this.columnPickListDialog.showDialog = true;
  }

  checkAllRows(event) {
    this.filteredResults.forEach(row => {
      row.checked = event ? [ 'true' ] : [];
      if ( event ) {
        this.selectedActivityIds.push(row);
      }
    });
    if ( !event ) {
      this.selectedActivityIds = [];
    }
  }

  onRowCheckboxChnage(event, row) {
    const selectedResult = this.filteredResults.filter(item => {
      if ( item.checked && item.checked[0] === 'true' ) {
        return true;
      } else {
        return false;
      }
    });
    if ( this.filteredResults.length === selectedResult.length ) {
      this.selectAllCheckBox = [ 'true' ];
    } else {
      this.selectAllCheckBox = [];
    }

    if ( event ) {
      this.selectedActivityIds.push(row);
    } else {
      const index = this.selectedActivityIds.findIndex((obj) => {
        return obj.id === row.id;
      });
      if ( index !== -1 ) {
        this.selectedActivityIds.splice(index, 1);
      }
    }
  }

  onPickListChange(list: any[]) {
    this.gridColumnList = JSON.parse(JSON.stringify(list));
  }

  filterGridResults(value, filter) {
    const results = [];
    if ( value ) {
      this.gridColumnList.forEach(col => {
        // this.searchResultGrid.filter(value, row.value, filter);
        this.searchResults.forEach(item => {
          if ( item[col.value] ) {
            if ( item[col.value].toString().toLowerCase().indexOf(value.toLowerCase()) !== -1 ) {
              if ( results.indexOf(item) === -1 ) {
                results.push(item);
              }
            }
          }
        });
      });
      this.filteredResults = results;
    } else {
      this.filteredResults = this.searchResults;
    }
  }

  fillDateTypePayload(orderSearch, body) {
    switch ( orderSearch.selectedDateType ) {
      case 'BillStartDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.billStartDateFrom = orderSearch.selectedDateFromDate;
          body.billStartDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.billStartDateFrom = relativeDate.fromDate;
          body.billStartDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerCommitDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.commitDateFrom = orderSearch.selectedDateFromDate;
          body.commitDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.commitDateFrom = relativeDate.fromDate;
          body.commitDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerRequestDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.customerRequestDateFrom = orderSearch.selectedDateFromDate;
          body.customerRequestDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.customerRequestDateFrom = relativeDate.fromDate;
          body.customerRequestDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerAcceptanceDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.customerAcceptDateFrom = orderSearch.selectedDateFromDate;
          body.customerAcceptDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.customerAcceptDateFrom = relativeDate.fromDate;
          body.customerAcceptDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'FocDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.lnpFocDateFrom = orderSearch.selectedDateFromDate;
          body.lnpFocDateTo = orderSearch.selctedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.lnpFocDateFrom = relativeDate.fromDate;
          body.lnpFocDateTo = relativeDate.toDate;

        }
        break;
      }
      case 'InstallDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.installDateFrom = orderSearch.selectedDateFromDate;
          body.installDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.installDateFrom = relativeDate.fromDate;
          body.installDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'LastUpdatedDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.lnpLastUpdatedFrom = orderSearch.selectedDateFromDate;
          body.lnpLastUpdatedDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.lnpLastUpdatedDateFrom = relativeDate.fromDate;
          body.lnpLastUpdatedDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'OrderCompletionDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.orderCompleteDateFrom = orderSearch.selectedDateFromDate;
          body.orderCompleteDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.orderCompleteDateFrom = relativeDate.fromDate;
          body.orderCompleteDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'OrderDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.orderDateFrom = orderSearch.selectedDateFromDate;
          body.orderDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.orderDateFrom = relativeDate.fromDate;
          body.orderDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'PortRequestDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.portRequestedDateFrom = orderSearch.selectedDateFromDate;
          body.portRequestedDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.portRequestedDateFrom = relativeDate.fromDate;
          body.portRequestedDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'RevisedCommitDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.revisedCommitDateFrom = orderSearch.selectedDateFromDate;
          body.revisedCommitDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.revisedCommitDateFrom = relativeDate.fromDate;
          body.revisedCommitDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'DesiredDueDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.desiredDueDateFrom = orderSearch.selectedDateFromDate;
          body.desiredDueDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.desiredDueDateFrom = relativeDate.fromDate;
          body.desiredDueDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'PortTriggerDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.portTriggerDateFrom = orderSearch.selectedDateFromDate;
          body.portTriggerDateDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.portTriggerDateFrom = relativeDate.fromDate;
          body.portTriggerDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'lnpGwFocDate': {
        if ( orderSearch.selectedDateCategories === 'range' ) {
          body.lnpGwFocDateDateFrom = orderSearch.selectedDateFromDate;
          body.lnpGwFocDateDateTo = orderSearch.selectedDateToDate;
        } else if ( orderSearch.selectedDateCategories === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRange);
          body.lnpGwFocDateFrom = relativeDate.fromDate;
          body.lnpGwFocDateDateTo = relativeDate.toDate;
        }
        break;
      }
    }
  }

  fillDateTypeSecondaryPayload(orderSearch, body) {
    switch ( orderSearch.selectedDateTypeSecondary ) {
      case 'BillStartDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.billStartDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.billStartDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.billStartDateFrom = relativeDate.fromDate;
          body.billStartDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerCommitDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.commitDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.commitDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.commitDateFrom = relativeDate.fromDate;
          body.commitDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerRequestDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.customerRequestDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.customerRequestDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.customerRequestDateFrom = relativeDate.fromDate;
          body.customerRequestDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'CustomerAcceptanceDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.customerAcceptDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.customerAcceptDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.customerAcceptDateFrom = relativeDate.fromDate;
          body.customerAcceptDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'FocDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.lnpFocDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.lnpFocDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.lnpFocDateFrom = relativeDate.fromDate;
          body.lnpFocDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'InstallDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.installDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.installDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.installDateFrom = relativeDate.fromDate;
          body.installDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'LastUpdatedDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.lnpLastUpdatedDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.lnpLastUpdatedDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.lnpLastUpdatedDateFrom = relativeDate.fromDate;
          body.lnpLastUpdatedDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'OrderCompletionDate': {
        if ( orderSearch.orderComz === 'range' ) {
          body.orderCompleteDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.orderCompleteDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.orderCompleteDateFrom = relativeDate.fromDate;
          body.orderCompleteDateTo = relativeDate.toDate;
        }

        break;
      }
      case 'OrderDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.orderDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.orderDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.orderDateFrom = relativeDate.fromDate;
          body.orderDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'PortRequestDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.portRequestedDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.portRequestedDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.portRequestedDateFrom = relativeDate.fromDate;
          body.portRequestedDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'RevisedCommitDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.revisedCommitDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.revisedCommitDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.revisedCommitDateFrom = relativeDate.fromDate;
          body.revisedCommitDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'DesiredDueDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.desiredDueDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.desiredDueDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.desiredDueDateFrom = relativeDate.fromDate;
          body.desiredDueDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'PortTriggerDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.portTriggerDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.portTriggerDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.portTriggerDateFrom = relativeDate.fromDate;
          body.portTriggerDateTo = relativeDate.toDate;
        }
        break;
      }
      case 'lnpGwFocDate': {
        if ( orderSearch.selectedDateCategoriesSecondary === 'range' ) {
          body.lnpGwFocDateFrom = orderSearch.selectedDateCategoriesSecondaryFromDate;
          body.lnpGwFocDateTo = orderSearch.selectedDateCategoriesSecondaryToDate;
        } else if ( orderSearch.selectedDateCategoriesSecondary === 'relative' ) {
          const relativeDate = this.getRelativeDate(orderSearch.selectedDateRangeSecondary);
          body.lnpGwFocDateFrom = relativeDate.fromDate;
          body.lnpGwFocDateTo = relativeDate.toDate;
        }
        break;
      }
    }
  }
  getRelativeDate(relation) {
    const relativeDate = {
      fromDate: new Date(),
      toDate: new Date()
    };
    let today = new Date();
    switch (relation) {
      case 'tomorrow': {
        const date = dateFn.addDays(today, 1);
        relativeDate.fromDate = date;
        relativeDate.toDate = date;
        break;
      }
      case 'yesterday': {
        const date = dateFn.addDays(today, -1);
        relativeDate.fromDate = date;
        relativeDate.toDate = date;
        break;
      }
      case 'nextBusinessDay': {
        const date = this.getNextBusinessDay(dateFn.addDays(today, 1));
        relativeDate.fromDate = date;
        relativeDate.toDate = date;
        break;
      }
      case 'previousBusinessDay': {
        const date = this.getPreviousBusinessDay(dateFn.addDays(today, -1));
        relativeDate.fromDate = date;
        relativeDate.toDate = date;
        break;
      }
      case 'next2Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 2);
        break;
      }
      case 'past2Days': {
        relativeDate.fromDate = dateFn.addDays(today, -2);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next3Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 3);
        break;
      }
      case 'past3Days': {
        relativeDate.fromDate = dateFn.addDays(today, -3);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next5Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 5);
        break;
      }
      case 'past5Days': {
        relativeDate.fromDate = dateFn.addDays(today, -5);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next10Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 10);
        break;
      }
      case 'past10Days': {
        relativeDate.fromDate = dateFn.addDays(today, -10);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'past30Days': {
        relativeDate.fromDate = dateFn.addDays(today, -30);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next30Days': {
        relativeDate.fromDate = dateFn.addDays(today, 1);
        relativeDate.toDate = dateFn.addDays(today, 30);
        break;
      }
      case 'past60Days': {
        relativeDate.fromDate = dateFn.addDays(today, -60);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'past90Days': {
        relativeDate.fromDate = dateFn.addDays(today, -90);
        relativeDate.toDate = dateFn.addDays(today, -1);
        break;
      }
      case 'next5BusinessDays': {
        for (let i = 1; i <= 5; i++) {
          today = this.getNextBusinessDay(dateFn.addDays(today, 1));
          if (i === 1) {
            relativeDate.fromDate = today;
          } else if (i === 5) {
            relativeDate.toDate = today;
          }
        }
        break;
      }
      case 'past5BusinessDays': {
        for (let i = 1; i <= 5; i++) {
          today = this.getPreviousBusinessDay(dateFn.addDays(today, -1));
          if (i === 5) {
            relativeDate.fromDate = today;
          } else if (i === 1) {
            relativeDate.toDate = today;
          }
        }
        break;
      }
      case 'next10BusinessDays': {
        for (let i = 1; i <= 10; i++) {
          today = this.getNextBusinessDay(dateFn.addDays(today, 1));
          if (i === 1) {
            relativeDate.fromDate = today;
          } else if (i === 10) {
            relativeDate.toDate = today;
          }
        }
        break;
      }
      case 'past10BusinessDays': {
        for (let i = 1; i <= 10; i++) {
          today = this.getPreviousBusinessDay(dateFn.addDays(today, -1));
          if (i === 10) {
            relativeDate.fromDate = today;
          } else if (i === 1) {
            relativeDate.toDate = today;
          }
        }
        break;
      }
      case 'previous30DaysToNext60Days': {
        relativeDate.fromDate = dateFn.addDays(today, -30);
        relativeDate.toDate = dateFn.addDays(today, 60);
        break;
      }

      case 'today': {
        relativeDate.fromDate = today;
        relativeDate.toDate = today;
        break;
      }
    }
    return relativeDate;
  }

  getNextBusinessDay(date) {
    if (dateFn.getDay(date) === 6 || dateFn.getDay(date) === 0) {
      return this.getNextBusinessDay(dateFn.addDays(date, 1));
    } else {
      return date;
    }
  }

  getPreviousBusinessDay(date) {
    if (dateFn.getDay(date) === 6 || dateFn.getDay(date) === 0) {
      return this.getPreviousBusinessDay(dateFn.addDays(date, -1));
    } else {
      return date;
    }
  }

  goToOderDetail(item) {
    // window.location.href = "?page=activation-service/tn-activity-order-detail/" + item.slOrderId;
    // this.router.navigateByUrl('/activation-service/tn-activity-order-detail/' + item.slOrderId)
    this.router.navigate([ './order-management/order-mgmt-order-detail/' + item.slOrderId ]);
  }


  onChangeAction(event, action) {
    this.filteredResults.forEach(row => {
      if ( action.code == 'update' && row.orderStatus == 'Completed' ) {
        row.checked = [];
      }
    });
  }


  onSelectedOrderActionClick() {
    if ( this.updateAction.operation.code === 'orderDateUpdate' ) {
      this.openUpdateOrderDateDialog();
    } else if ( this.updateAction.operation.code === 'orderCommentUpdate' ) {
      let exportData = this.selectedActivityIds;
      if ( this.updateAction.type.code === 'all' ) {
        exportData = this.filteredResults.filter(item => {
          if ( item.activityStatus !== 'Completed' ) {
            return true;
          } else {
            return false;
          }
        });
      }
      if ( exportData.length > 1 ) {
        this.updateError = 'Only one order can be selected for Update Order Comments.';
        return;
      } else if ( exportData.length === 1 ) {
        this.updateReasonOnlyDialog.reset();
        this.updateReasonOnlyDialog.displaDialog = true;
      }
    }
  }

  updateReasonOnlyDialogSubmit(event) {
    this.updateReasonOnlyDialog.displaDialog = false;
    this.updateActivitySearch();
  }

  openUpdateOrderDateDialog() {
    this.updateOrderDateDialog.onReset();
    this.updateOrderDateDialog.displayDialog = true;
  }

  onUpdateOrderDate(event) {
    this.updateOrderDateDialog.displayDialog = false;
    this.updateActivitySearch(event);
  }

  updateActivitySearch(extraDetails?) {
    this.updateError = '';
    this.updateErrorMesg = '';
    this.successMessage = '';
    let exportData = [];

    if ( this.filteredResults.length > 0 ) {
      this.isUpdating = true;
      exportData = this.selectedActivityIds;
      if ( exportData.length === 0 ) {
        this.isUpdating = false;
        this.updateError = 'Please select atleast one record to perform action';
        return;
      }
      let count = 0;
      let hitApi = false;

      const dateTime = new Date();
      const dateTimeStr = 'SLDB-' + dateTime.getTime();
      const codeForPON = [ 'orderDateUpdate' ];
      const codeForSLOrderId = [ 'orderCommentUpdate' ];

      if ( codeForPON.indexOf(this.updateAction.operation.code) !== -1 ) {
        let filterParentId = exportData.map(
          object => object.parentOrderId
        );
        filterParentId = filterParentId.filter(function (item, pos) {
          return filterParentId.indexOf(item) == pos;
        });
        const responseArray: any[] = [];
        switch ( this.updateAction.operation.code ) {
          case 'orderDateUpdate':
            const requestArray = [];
            for ( let index = 0; index < filterParentId.length; index++ ) {
              requestArray.push(this.orderMgmtSearchService.updateActivitiesOrderDate(filterParentId[index], extraDetails, dateTimeStr));
            }
            forkJoin(requestArray).subscribe((result) => {
              console.log(result);
              result.forEach((response, index) => {
                if ( response.successful === false ) {
                  responseArray.push({
                    ponId: filterParentId[index],
                    error: response.errorMessage
                  });
                }
                if ( filterParentId.length - 1 === index ) {
                  this.isUpdating = false;
                  if ( responseArray.length > 0 ) {
                    this.successMessage = '';
                    if ( filterParentId.length === 1 ) {
                      this.updateError = response.errorMessage;
                    } else {
                      this.updateError = 'multiple';
                    }
                    this.storageService.setTransactionActivityIds(responseArray, this.updateAction.operation.code, dateTime);
                  } else {
                    this.updateError = '';
                    if ( filterParentId.length === 1 ) {
                      this.successMessage = 'Update Successful';
                    } else {
                      this.successMessage = 'multiple';
                      this.storageService.setTransactionActivityIds(result, this.updateAction.operation.code, dateTime, true);
                    }
                  }
                  this.searchActivities(this.orderSearch);
                }
              });
            }, () => {
              this.isUpdating = false;
            });
        }
      } else if ( codeForSLOrderId.indexOf(this.updateAction.operation.code) !== -1 ) {
        let filterSLOrderId = exportData.map(
          object => object.slOrderId
        );
        filterSLOrderId = filterSLOrderId.filter(function (item, pos) {
          return filterSLOrderId.indexOf(item) == pos;
        });
        if ( filterSLOrderId.length > 1 ) {
          this.updateError = 'Only one order can be selected for Update Order Comments.';
          return;
        } else {
          const responseArray: any[] = [];
          switch ( this.updateAction.operation.code ) {
            case 'orderCommentUpdate':
              const requestArray = [];
              for ( let index = 0; index < filterSLOrderId.length; index++ ) {
                requestArray.push(this.orderMgmtSearchService.updateActivitiesOrderComment(filterSLOrderId[index], this.updateReasonOnlyDialog.actionReason, dateTimeStr));
              }
              forkJoin(requestArray).subscribe((result) => {
                console.log(result);
                result.forEach((response, index) => {
                  if ( response.successful === false ) {
                    responseArray.push({
                      ponId: filterSLOrderId[index],
                      error: response.errorMessage
                    });
                  }
                  if ( filterSLOrderId.length - 1 === index ) {
                    this.isUpdating = false;
                    if ( responseArray.length > 0 ) {
                      this.successMessage = '';
                      if ( filterSLOrderId.length === 1 ) {
                        this.updateError = response.errorMessage;
                      } else {
                        this.updateError = 'multiple';
                      }
                      this.storageService.setTransactionActivityIds(responseArray, this.updateAction.operation.code, dateTime);
                    } else {
                      this.updateError = '';
                      if ( filterSLOrderId.length === 1 ) {
                        this.successMessage = 'Update Successful';
                      } else {
                        this.successMessage = 'multiple';
                        this.storageService.setTransactionActivityIds(result, this.updateAction.operation.code, dateTime, true);
                      }
                    }
                    this.searchActivities(this.orderSearch);
                  }
                });
              }, () => {
                this.isUpdating = false;
              });
          }
        }
      } else {
        this.isUpdating = false;
      }

    }
  }

  openTransactionDialog() {
    console.log('open');
    this.transactionDetailsDialog.loadErrorList();
    this.transactionDetailsDialog.displayDialog = true;
  }

  onCloseTransactionDialog() {
    this.transactionDetailsDialog.displayDialog = false;
  }
}


interface PanelFilter {
  OrderSearch: boolean;
  LnpSearch: boolean;
  E911Search: boolean;
  EmeaSearch: boolean;
}
