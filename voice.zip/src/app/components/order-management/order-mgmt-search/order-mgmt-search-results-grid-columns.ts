export const ColumnType: any = {
  string: 'string',
  number: 'number',
  date: 'date'
};

export const OrderSearchResultsGridColumns: any = [
  {
    caption: 'parent Order Id',
    value: 'parentOrderId',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'TN Order Id',
    value: 'slOrderId',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Jeopardy Errors',
    value: 'jeopErrors',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'LNP Order Status',
    value: 'lnpOrderStatus',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'LNP Vendor Message',
    value: 'lnpVendorMsg',
    visible: false,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'Adopt Order',
    value: 'adoptOrder',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'TN',
    value: 'tn',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'BTN',
    value: 'btn',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'CTI',
    value: 'custTypeInd',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Order  Action',
    value: 'orderAction',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Order Status',
    value: 'orderStatus',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Order Type',
    value: 'orderType',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Customer Bus Org Id',
    value: 'custBusOrgId',
    visible: false,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'Customer Name',
    value: 'customerName',
    visible: false,
    type: ColumnType.string,
    class: { 'r21': true }
  },
  {
    caption: 'Master Bus Org ID',
    value: 'masterBusOrgId',
    visible: false,
    type: ColumnType.string,
    class: { 'r21': true }
  },
  {
    caption: 'Bill Start Date',
    value: 'billStartDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r17': true }
  },
  {
    caption: 'Desired Due Date',
    value: 'desiredDueDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r17': true }
  },
  {
    caption: 'First Billing Usage?',
    value: 'firstUsageBilling',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Product ID',
    value: 'productId',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Product',
    value: 'product',
    visible: false,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'SCID',
    value: 'scid',
    visible: false,
    type: ColumnType.string,
    class: { 'r9': true }
  },
  {
    caption: 'Location SCID',
    value: 'locationScid',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Voice Complete Service ID',
    value: 'vcServiceId',
    visible: false,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'PSID',
    value: 'psid',
    visible: false,
    type: ColumnType.string,
    class: { 'r7': true }
  },
  {
    caption: 'Market',
    value: 'market',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Market Tier',
    value: 'marketTier',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'Service Package',
    value: 'servicePackage',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'ES Option',
    value: 'esOption',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'RC Abbr',
    value: 'rcAbbr',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Bill - Site ID',
    value: 'billToSiteId',
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'External Order Id',
    value: 'extOrderId',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Reason Code',
    value: 'reasonCode',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'Reason Decription',
    value: 'reasonDecription',
    visible: false,
    type: ColumnType.string,
    class: { 'r21': true },
  },
  {
    caption: 'Old OCN',
    value: 'oldOcn',
    visible: false,
    type: ColumnType.string,
    class: { 'r9': true }
  },
  {
    caption: 'Business Name',
    value: 'businessName',
    visible: false,
    type: ColumnType.string,
    class: { 'r16': true }
  },
  {
    caption: 'Subscriber Name',
    value: 'subscriberName',
    visible: false,
    type: ColumnType.string,
    class: { 'r16': true }
  },
  {
    caption: 'LNP Order',
    value: 'lnpYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'LNP Wireless',
    value: 'lnpWirelessYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Activation Time',
    value: 'activationTime',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'B2B API Version',
    value: 'b2bApiVersion',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Internal Port',
    value: 'internalPortYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Service Transfer',
    value: 'serviceTransferYn',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'LNP Order State',
    value: 'lnpOrderState',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: ' LNP Last Update Date ',
    value: 'lnpLastUpdatedDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r19': true }
  },
  {
    caption: 'LNP FOC Date',
    value: 'lnpFocDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r17': true }
  },
  {
    caption: 'LNP GW FOC Date',
    value: 'lnpGwFocDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r19': true }
  },

  {
    caption: 'LNP LEC Response Date',
    value: 'lnpLecResponseDate',
    visible: false,
    type: ColumnType.date,
    class: { 'r19': true }
  },
  {
    caption: 'LNP Project Id',
    value: 'lnpProjectId',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'LNP Last Event',
    value: 'lnpLastEventName',
    visible: false,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'Last OutBound Error',
    value: 'lastOutboundError',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Last OutBound Error Message',
    value: 'lastOutboundMessage',
    visible: false,
    type: ColumnType.string,
    class: { 'r21': true }
  },
  {
    caption: 'Last InBound Error',
    value: 'lastInboundError',
    visible: false,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Last InBound Error Message',
    value: 'lastInboundMessage',
    visible: false,
    type: ColumnType.string,
    class: { 'r21': true }
  },
  {
    caption: 'Port Trigger Date',
    value: 'portTriggerDate',
    visible: false,
    type: ColumnType.date,
    format: 'MM/dd/yyyy hh:mm:a',
    class: { 'r19': true }
  },
  {
    caption: 'Port User ID',
    value: 'portUserId',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Feature Code',
    value: 'featureCode',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'LCT Response',
    value: 'lctResponse',
    visible: false,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'LNP Option',
    value: 'lnpOption',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Switch Type',
    value: 'switchType',
    visible: false,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Country',
    value: 'country',
    visible: false,
    type: ColumnType.string,
    class: { 'r10': true }
  },
  {
    caption: 'City(Emea)',
    value: 'cityName',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Area Code',
    value: 'areaCode',
    visible: false,
    type: ColumnType.string,
    class: { 'r11': true }
  },
  {
    caption: 'Sales Channel',
    value: 'salesChannel',
    visible: false,
    type: ColumnType.string,
    class: { 'r15': true }
  },

];

export const OrderSearchPricingDetailsGridColumns: any = [
  {
    caption: 'Charge Description',
    value: 'description',
    visible: true,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Charge Level',
    value: 'charge_level',
    visible: true,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Frequency',
    value: 'frequency',
    visible: true,
    type: ColumnType.string,
    class: { 'r12': true }
  },
  {
    caption: 'Unit Price',
    value: 'formatted_unit_price',
    visible: true,
    type: ColumnType.string,
    class: { 'r13': true }
  },
  {
    caption: 'UOM',
    value: 'unit_of_measure',
    visible: true,
    type: ColumnType.string,
    class: { 'r14': true }
  },
  {
    caption: 'Qty.',
    value: 'quantity',
    visible: true,
    type: ColumnType.string,
    class: { 'r15': true }
  },
  {
    caption: 'Charge Amt',
    value: 'formatted_amount',
    visible: true,
    type: ColumnType.string,
    class: { 'r16': true }
  },
  {
    caption: 'Gross Chg Amt',
    value: 'formatted_gross',
    visible: true,
    type: ColumnType.string,
    class: { 'r19': true }
  },
  {
    caption: 'Net Chg Amt',
    value: 'formatted_net',
    visible: true,
    type: ColumnType.string,
    class: { 'r17': true }
  },
  {
    caption: 'Date Created',
    value: 'date_created',
    visible: true,
    type: ColumnType.string,
    class: { 'r20': true }
  },
  {
    caption: 'Last Update Date',
    value: 'lst_updated',
    visible: true,
    type: ColumnType.date,
    class: { 'r20': true }
  },
  {
    caption: 'Last Updated User',
    value: 'last_updated_user',
    visible: true,
    type: ColumnType.string,
    class: { 'r21': true }
  }
];
