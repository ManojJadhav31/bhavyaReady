import { ActivityErrorResponse } from "../../../app/components/activity-error-details/activity-error-details.constants";

export const MockActivityErrorResponse: ActivityErrorResponse[] = [
    {
        errorId: 1,
        orderActivityPK: 1,
        slOrderId: 1,
        briefMessage: 'briefMessage',
        errorMessage: 'errorMessage',
        errorTypeId: 1,
        errorStatus: 'errorStatus'
    },
    {
        errorId: 1,
        orderActivityPK: 1,
        slOrderId: 1,
        briefMessage: 'briefMessage',
        errorMessage: 'errorMessage',
        errorTypeId: 1,
        errorStatus: 'errorStatus'
    },
    {
        errorId: 1,
        orderActivityPK: 1,
        slOrderId: 1,
        briefMessage: 'briefMessage',
        errorMessage: 'errorMessage',
        errorTypeId: 1,
        errorStatus: 'errorStatus'
    },
    {
        errorId: 1,
        orderActivityPK: 1,
        slOrderId: 1,
        briefMessage: 'briefMessage',
        errorMessage: 'errorMessage',
        errorTypeId: 1,
        errorStatus: 'errorStatus'
    },
    {
        errorId: 1,
        orderActivityPK: 1,
        slOrderId: 1,
        briefMessage: 'briefMessage',
        errorMessage: 'errorMessage',
        errorTypeId: 1,
        errorStatus: 'errorStatus'
    },
    {
        errorId: 1,
        orderActivityPK: 1,
        slOrderId: 1,
        briefMessage: 'briefMessage',
        errorMessage: 'errorMessage',
        errorTypeId: 1,
        errorStatus: 'errorStatus'
    },
    {
        errorId: 1,
        orderActivityPK: 1,
        slOrderId: 1,
        briefMessage: 'briefMessage',
        errorMessage: 'errorMessage',
        errorTypeId: 1,
        errorStatus: 'errorStatus'
    },
    {
        errorId: 1,
        orderActivityPK: 1,
        slOrderId: 1,
        briefMessage: 'briefMessage',
        errorMessage: 'errorMessage',
        errorTypeId: 1,
        errorStatus: 'errorStatus'
    }
]