package com.level3.voice.workflow.utils;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * This payload is needed since it has some more 1S PIC Long distance fields.
 * 
 * @author <a href=
 *         "mailto:Keerthi.Selvaraj@centurylink.com">Keerthi.Selvaraj</a>
 *
 */
/**
 * @author AB37648
 *
 */
@XmlRootElement(name = "request")
@XmlAccessorType(XmlAccessType.FIELD)
public class LDEmpPayload implements LDEmpPayloadIF {

	private String serviceID;
	private String accountnumber;
	private String wtn;
	private Date effectiveDate;
	private Date disconnectDate;
	private String productofferingid;
	private String rateplanid;
	private String servicelocationid;
	private String cic;
	private String jurisdiction;
	private String scid;
	private String status;
	private String provisionDate;

	public String getServiceID() {
		return serviceID;
	}

	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}

	public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getWtn() {
		return wtn;
	}

	public void setWtn(String wtn) {
		this.wtn = wtn;
	}

	public String getProductofferingid() {
		return productofferingid;
	}

	public void setProductofferingid(String productofferingid) {
		this.productofferingid = productofferingid;
	}

	public String getRateplanid() {
		return rateplanid;
	}

	public void setRateplanid(String rateplanid) {
		this.rateplanid = rateplanid;
	}

	public String getServicelocationid() {
		return servicelocationid;
	}

	public void setServicelocationid(String servicelocationid) {
		this.servicelocationid = servicelocationid;
	}

	public String getCic() {
		return cic;
	}

	public void setCic(String cic) {
		this.cic = cic;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getScid() {
		return scid;
	}

	public void setScid(String scid) {
		this.scid = scid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProvisionDate() {
		return provisionDate;
	}

	public void setProvisionDate(String provisionDate) {
		this.provisionDate = provisionDate;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getDisconnectDate() {
		return disconnectDate;
	}

	public void setDisconnectDate(Date disconnectDate) {
		this.disconnectDate = disconnectDate;
	}
}
