package com.level3.voice.workflow.utils;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Arun2.kumar@level3.com
 *
 */
@XmlRootElement(name = "request")
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class NPALPayload implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String callbackURL;
	private String customerRoutingCode;
	private String priority;
	private String productId;

	private String telephoneNumbers;

	public String getCallbackURL() {
		return callbackURL;
	}

	public void setCallbackURL(String callbackURL) {
		this.callbackURL = callbackURL;
	}

	public String getCustomerRoutingCode() {
		return customerRoutingCode;
	}

	public void setCustomerRoutingCode(String customerRoutingCode) {
		this.customerRoutingCode = customerRoutingCode;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getTelephoneNumbers() {
		return telephoneNumbers;
	}

	public void setTelephoneNumbers(String telephoneNumbers) {
		this.telephoneNumbers = telephoneNumbers;
	}

}
