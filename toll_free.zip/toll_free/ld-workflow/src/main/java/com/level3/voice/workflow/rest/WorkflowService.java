package com.level3.voice.workflow.rest;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.ws.rs.core.Response;

import org.activiti.engine.ManagementService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.impl.cfg.ProcessEngineConfigurationImpl;
import org.activiti.engine.impl.interceptor.Command;
import org.activiti.engine.impl.interceptor.CommandConfig;
import org.activiti.engine.impl.interceptor.CommandContext;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.runtime.Execution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.centurylink.voice.workflow.common.utils.ActivitiUtils;
import com.centurylink.voice.workflow.common.utils.WorkflowUtils;
import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.DAOException;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.common.util.StringUtils;
import com.level3.voice.common.util.WebServicesResponseCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.ProcessFlowStatusDTO;
import com.level3.voice.persist.dto.ProcessFlowVersionDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.repository.ActivityRuleRepository;
import com.level3.voice.persist.repository.OrderActivityRepository;
import com.level3.voice.persist.repository.ProcessFlowStatusRepository;
import com.level3.voice.persist.repository.ProcessFlowVersionRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.SublCallQueueRepository;
import com.level3.voice.persist.repository.TnOrderRepository;
import com.level3.voice.tollfree.persist.dto.LECResponseDTO;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.dto.TcsiDTO;
import com.level3.voice.tollfree.persist.repository.LecResponseRepository;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TcsiRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderActivityRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeSlOrderRepository;
import com.level3.voice.workflow.constants.TollfreeWorkflowConstants;
import com.level3.voice.workflow.dto.LecProvisionerRequestDTO;
import com.level3.voice.workflow.dto.ProvisionerRequestDetailDTO;
import com.level3.voice.workflow.manager.WorkflowServiceManager;
import com.level3.voice.workflow.repository.LecProvisionerRequestRepository;
import com.level3.voice.workflow.repository.ProvisionerRequestDetailRepository;
import com.level3.voice.workflow.utils.OrderActionCodes;
import com.sun.jersey.api.client.ClientResponse.Status;

/**
 * Long Distance Workflow service to start or stop workflow
 * 
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/Voice/order")
public class WorkflowService {
	private static final int INSTALL_PROCESS_ID = 20000;

	private static final int DISCONNECT_PROCESS_ID = 20002;

	private static final int BLOCK_UNBLOCK_PROCESS_ID = 20001;

	private static final Logger LOG = Logger.getLogger(WorkflowService.class);

	@Value("${voice.workflow.tenant}")
	private String tentantId;

	@Autowired
	RuntimeService runtimeService;

	@Autowired
	ProcessFlowVersionRepository processFlowVersionRepository;
	@Autowired
	ProcessFlowStatusRepository processFlowStatusRepository;
	@Autowired
	OrderActivityRepository orderActivityRepository;
	@Autowired
	ActivityRuleRepository activityRuleRepository;
	@Autowired
	SlOrderRepository slOrderRepository;
	@Autowired
	SublCallQueueRepository sublCallQueueRepository;
	@Autowired
	TnOrderRepository tnOrderRepository;
	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;
	@Autowired
	TollfreeSlOrderRepository TollfreeSlOrderRepository;
	@Autowired
	WorkflowServiceManager workflowServiceManager;

	@Autowired
	ActivitiUtils activitiUtils;

	@Autowired
	RestartActivity restartActivity;

	@Autowired
	ProcessEngineConfigurationImpl processEngineConfiguration;

	@Autowired
	ManagementService managementService;

	@Autowired
	TollfreeOrderActivityRepository tollfreeOrderActivityRepository;

	@Autowired
	ProvisionerRequestDetailRepository provisionerRequestDetailRepository;

	@Autowired
	LecProvisionerRequestRepository lecProvisionerRequestRepository;

	@Autowired
	LecResponseRepository lecResponseRepository;

	@Autowired
	WorkflowUtils workflowUtils;
	
	@Autowired
	TcsiRepository tcsiRepository;

	@RequestMapping(value = "/start/pon/{pon}", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@Transactional
	public void submitOrderToWorkflow(@PathVariable(value = "pon") Long parentTransId) throws Exception {
		HashMap<String, Object> variables = new HashMap<String, Object>();
		variables.put("PON_FLOW", parentTransId);
		runtimeService.startProcessInstanceByKeyAndTenantId("PIC_LD_PON_FLOW", variables, tentantId);
	}

	/**
	 * Endpoint to trigger the workflow
	 * 
	 * @param slOrderId
	 */
	@RequestMapping(value = "/start/slOrder/{slOrderId}", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@Transactional
	public void startSLOrderWorkflow(@PathVariable(value = "slOrderId") Long slOrderId) {
		try {
			LOG.info("Sl Order Worflow flow triggered for sales order id: " + slOrderId);
			HashMap<String, Object> variables = new HashMap<String, Object>();
			SlOrderDTO slOrderDTO = slOrderRepository.findOne(slOrderId);
			if (slOrderDTO == null) {
				LOG.error("SL Order Cannot be null for sl Order id: " + slOrderId);
				return;
			}
			variables.put("SL_ORDER_ID", slOrderDTO.getSlOrderId());
			variables.put("PON", slOrderDTO.getParentTransId());

			if (slOrderDTO != null && slOrderDTO.getOrderActivities().size() > 1) {
				LOG.info("Workflow already started, so skip processing the start workflow for sl order id: "
						+ slOrderId);
				return;
			}

			Integer processFlowId = getProcessFlowId(slOrderDTO);

			ProcessFlowVersionDTO processFlowVersionDTO = processFlowVersionRepository
					.findProcessByFlowId(processFlowId);

			if (processFlowVersionDTO == null) {
				throw new SLDBException("No process flow version for process flow: " + processFlowId + " orderId: "
						+ slOrderDTO.getSlOrderId(), WebServicesResponseCodes.SYSTEM_ERROR);
			}

			variables.put("PROCESS_FLOW_VERSION", processFlowVersionDTO.getProcessFlowVersionId());
			variables.put("PROCESS_FLOW_ID", processFlowId);

			insertStartWorkflowActivity(slOrderDTO, processFlowId);

			runtimeService.startProcessInstanceByKeyAndTenantId(
					"WF_" + processFlowId + "_" + processFlowVersionDTO.getProcessFlowVersionId(), variables,
					tentantId);
		} catch (Exception e) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail(
					"Exception processing workflow submit for SL Order: " + slOrderId + ' ' + e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * Endpoint to trigger the workflow for all SL Orders on a given PON.
	 *
	 * @param pon
	 */
	@RequestMapping(value = "/start/pon/{pon}/orders", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@Transactional
	public void startSLOrderWorkflowByPON(@PathVariable(value = "pon") Long pon) {
		try {
			LOG.info("Starting all Sl Order Worflow flow triggered for PON=" + pon);
			List<Long> slOrders = tnOrderRepository.findActiveTNorderByParentTransId(pon);
			LOG.info("Starting all Sl Order Worflow flow triggered for PON=" + pon + " SL Order Count="
					+ slOrders.size());
			for (Long slOrderId : slOrders) {
				try {
					startOrderWorkflow(slOrderId);
				} catch (Exception ex) {
					LOG.error("Error starting workflow for SL_ORDER_ID=" + slOrderId + ", PON=" + pon, ex);
				}
			}

		} catch (Exception e) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("Exception processing workflow submit for PON: " + pon + ' ' + e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	private void startOrderWorkflow(Long slOrderId) throws Exception {
		HashMap<String, Object> variables = new HashMap<String, Object>();

		SlOrderDTO slOrderDTO = slOrderRepository.findOne(slOrderId);
		if (slOrderDTO == null) {
			LOG.error("SL Order Cannot be null for sl Order id: " + slOrderId);
			return;
		}
		variables.put("SL_ORDER_ID", slOrderDTO.getSlOrderId());
		variables.put("PON", slOrderDTO.getParentTransId());

		if (slOrderDTO != null && slOrderDTO.getOrderActivities().size() > 1) {
			LOG.info("Workflow already started, so skip processing the start workflow for sl order id: " + slOrderId);
			return;
		}

		Integer processFlowId = getProcessFlowId(slOrderDTO);

		ProcessFlowVersionDTO processFlowVersionDTO = processFlowVersionRepository.findProcessByFlowId(processFlowId);

		if (processFlowVersionDTO == null) {
			throw new SLDBException("No process flow version for process flow: " + processFlowId + " orderId: "
					+ slOrderDTO.getSlOrderId(), WebServicesResponseCodes.SYSTEM_ERROR);
		}

		variables.put("PROCESS_FLOW_VERSION", processFlowVersionDTO.getProcessFlowVersionId());
		variables.put("PROCESS_FLOW_ID", processFlowId);

		insertStartWorkflowActivity(slOrderDTO, processFlowId);

		runtimeService.startProcessInstanceByKeyAndTenantId(
				"WF_" + processFlowId + "_" + processFlowVersionDTO.getProcessFlowVersionId(), variables, tentantId);
	}

	/**
	 * Retrieve process flow based on the action type assigned to the sl order
	 * 
	 * @param slOrderDTO
	 * @return
	 */
	private Integer getProcessFlowId(SlOrderDTO slOrderDTO) {
		if (OrderActionCodes.BLOCK == slOrderDTO.getActionTypeId().intValue()
				|| OrderActionCodes.UNBLOCK == slOrderDTO.getActionTypeId().intValue()) {
			return BLOCK_UNBLOCK_PROCESS_ID;
		} else if (OrderActionCodes.DISCONNECT == slOrderDTO.getActionTypeId().intValue()) {
			return DISCONNECT_PROCESS_ID;
		}
		return INSTALL_PROCESS_ID;
	}

	/**
	 * Insert start workflow activity as the first step into order activity for the
	 * slorder
	 * 
	 * @param slOrderDTO
	 * @param processFlowId
	 * @throws DAOException
	 */
	public void insertStartWorkflowActivity(SlOrderDTO slOrderDTO, Integer processFlowId) throws DAOException {

		OrderActivityDTO orderActv = getWorkflowStartedActivity(slOrderDTO, processFlowId);
		ProcessFlowVersionDTO pfVersion = processFlowVersionRepository
				.findProcessByFlowId(new Integer(WorkflowConstants.START_WORKFLOW_ORDER_PROCESS_FLOW_ID));
		ProcessFlowStatusDTO pfsDTO = getWorkflowStartedPfs(pfVersion);

		pfsDTO = processFlowStatusRepository.saveAndFlush(pfsDTO);
		orderActv.setProcessFlowInstanceId(new Long(pfsDTO.getProcessFlowInstanceId().longValue()));
		orderActivityRepository.saveAndFlush(orderActv);

	}

	/**
	 * Get the existing/new startworflow activity DTO from DB
	 * 
	 * @param slOrderDTO
	 * @param processFlowId
	 * @return
	 * @throws DAOException
	 */
	private OrderActivityDTO getWorkflowStartedActivity(SlOrderDTO slOrderDTO, Integer processFlowId)
			throws DAOException {
		OrderActivityDTO startWk = new OrderActivityDTO();
		ActivityRuleDTO actvRule = activityRuleRepository.findStartWorkflowActivityRule();

		if (slOrderDTO.getOrderActivities().size() == 1) {
			startWk = slOrderDTO.getOrderActivities().iterator().next();
		} else {
			startWk.setSlOrder(slOrderDTO);
			slOrderDTO.getOrderActivities().add(startWk);
		}

		startWk.setActivityId(actvRule.getFlowActivitySeqno());
		startWk.setActivityTypeId(actvRule.getActivity().getActivityId());
		startWk.setActivityRule(actvRule);
		startWk.setParentTransId(slOrderDTO.getParentTransId());
		startWk.setIsParentTransCoord(new Integer(0));
		startWk.setProcessFlowId(processFlowId);
		startWk.setProcessFlowInstanceId(new Long(0));
		if (startWk.getStatus() == null)
			startWk.setStatus(new Integer(WorkflowConstants.ACTIVITY_COMPLETED_STATE));
		startWk.setExpediteInd("N");
		startWk.setMsFlow("Y");
		startWk.setManualCompleteFlag(false);
		startWk.setNumRetries(new Integer(1));
		startWk.setNumManualRetries(new Integer(0));
		startWk.setCreateDate(new Date());
		startWk.setLastUpdated(new Date());
		startWk.setLastUpdatedUser("UNKNOWN");
		startWk.setCompleteDate(new Date());
		startWk.setLastProcessingStart(new Date());
		startWk.setLastProcessingStop(new Date());
		startWk.setComments(TollfreeWorkflowConstants.ACTIVITY_COMMENTS);
		return startWk;
	}

	/**
	 * Create a processflowstatus record and set the status of the current
	 * processflowversion as active
	 * 
	 * @param pfVersion
	 * @return
	 * @throws DAOException
	 */
	private ProcessFlowStatusDTO getWorkflowStartedPfs(ProcessFlowVersionDTO pfVersion) throws DAOException {
		Long pfInstanceId = slOrderRepository.getGeneralNextval().longValue();
		ProcessFlowStatusDTO pfsDTO = new ProcessFlowStatusDTO();
		pfsDTO.setProcessFlowVersion(pfVersion);
		pfsDTO.setStatus(WorkflowConstants.WORKFLOW_ACTIVE_STATE);
		pfsDTO.setProcessFlowInstanceId(pfInstanceId);
		return pfsDTO;
	}

	@RequestMapping(value = "/emp/response/{correlationId}", method = RequestMethod.PUT, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE }, consumes = {
					MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@Audited
	public Response consumeEMPMessage(@PathVariable(value = "correlationId") String correlationId,
			@RequestParam(value = "eventName", required = false) String eventName,
			@RequestParam(value = "slOrderId", required = false) String slOrder,
			@RequestParam(value = "orderActivityPk", required = false) Long orderActivityPk1,
			@RequestParam(value = "sublCallQueueId", required = false) Long sublCallQueueId1) {
		LOG.info(" --->>> EMP Message trigger for correlation Id: " + correlationId + " event Name:" + eventName);
		if (StringUtils.isEmpty(correlationId)) {
			Response.status(400).build();
		}
		if (eventName == null) {
			eventName = "";
		}

		List<Object[]> resultMap = null;
		if (!StringUtils.isEmpty(slOrder) && orderActivityPk1 != null) {
			resultMap = processFlowStatusRepository.findWaitProcessInstanceByCorrelationIdSlorderId(slOrder);
		} else {
			resultMap = processFlowStatusRepository.findWaitProcessInstanceByCorrelationId(correlationId);
		}
		if (resultMap.size() == 0)
			return Response.status(404).build();

		String executionId = null;
		String eventId = null;
		String slOrderId = null;
		Long sublCallQueueId = null;
		Long orderActivityPk = null;
		Boolean eventFound = false;

		for (Object[] result : resultMap) {
			// to_char(subscr.execution_id_) as execId, event_name_ as eventName, scq.col10
			// as slOrderId, scq.subl_call_queue_id as queueId
			executionId = (String) result[0];
			eventId = (String) result[1];

			if (result.length > 2) {
				slOrderId = (String) result[2];
				sublCallQueueId = ((BigDecimal) result[3]).longValue();
				orderActivityPk = ((BigDecimal) result[4]).longValue();
			}

			if (eventId != null && eventId.toLowerCase().indexOf(eventName.toLowerCase()) > 0) {
				eventFound = true;
				break;
			}
		}

		if (!eventFound) {
			return Response.status(500).build();
		}

		if (sublCallQueueId == null)
			sublCallQueueId = sublCallQueueId1;
		if (orderActivityPk == null)
			orderActivityPk = orderActivityPk1;

		if (executionId != null && eventId != null) {
			try {
				LOG.info("--->> EMP Message Processing signal " + eventId + " for SL Order " + slOrderId
						+ " executionID: " + executionId + " Correlation ID:" + correlationId);
				runtimeService.signalEventReceived(eventId, String.class.cast(executionId));
			} catch (Exception ex) {
				LOG.error("--->> Error processing signal " + eventId + " for SL Order " + slOrderId + " executionID: "
						+ executionId + " Correlation ID:" + correlationId, ex);
				return Response.status(500).build();
			}

			try {
				if (orderActivityPk != null)
					tollfreeOrderActivityRepository.completeActivity(new Date(),
							TollfreeWorkflowConstants.ACTIVITY_COMMENTS, orderActivityPk);
				if (sublCallQueueId != null)
					sublCallQueueRepository.updateDequeueDate(sublCallQueueId);
			} catch (Exception ex) {
				LOG.error("--->> Error Updating Dequeue Date for signal " + eventId + " for SL Order " + slOrderId
						+ " executionID: " + executionId + " Correlation ID:" + correlationId + " SublcallQueue"
						+ sublCallQueueId, ex);
			}
		}

		return Response.ok().build();
	}

	@RequestMapping(value = "/forcecomplete", method = RequestMethod.PUT, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@Transactional
	@CrossOrigin
	public Response forceCompleteErrorActivity(@RequestParam(value = "jobId", required = false) String jobID,
			@RequestParam(value = "condition", required = false) String condition,
			@RequestParam(value = "orderActivityPk", required = false) Long orderActivityPK,
			@RequestParam(value = "username", required = false) String username,
			@RequestParam(value = "comments", required = false) String comments,
			@RequestParam(value = "tc", required = false) String tc,
			@RequestParam(value = "si", required = false) String si) {
		LOG.info("Force completing job id" + jobID + " on orderActivityPk=" + orderActivityPK);

		try {
			if(!StringUtils.isEmpty(tc) && !StringUtils.isEmpty(si)){
				List<TcsiDTO> selectedTcSiList = tcsiRepository.findByTcAndSi(tc, si);
				if(selectedTcSiList == null || selectedTcSiList.size()<1){
					return Response.status(Status.BAD_REQUEST).build();
				}
			}
			
			OrderActivityDTO orderActivity = orderActivityRepository.findOne(orderActivityPK);
			TollfreeSlOrderRepository.updateLastUpdatedUser(username, orderActivity.getSlOrder().getSlOrderId());
			activitiUtils.forceCompleteErrorActivity(jobID, condition, orderActivityPK, username, comments);
			if (orderActivityPK != null && tc != null && si != null) {
				ifLECActivityUpdateTCSI(orderActivityPK, tc, si, username, orderActivity);
			}
		} catch (Exception e) {
			LOG.error("Exception processing force complete for orderActivityPk: " + orderActivityPK, e);
			Level3Response l3Response = Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail("Exception processing force complete for orderActivityPk: " + orderActivityPK);
			throw new ServiceException(l3Response);
		}
		return Response.status(Status.OK).build();

	}

	private void ifLECActivityUpdateTCSI(Long orderActivityPK, String tc, String si, String username, OrderActivityDTO orderActivity) {
		if (orderActivity.getActivityTypeId().equals(916)) {
			if (orderActivity != null && orderActivity.getSlOrder() != null
					&& orderActivity.getSlOrder().getSlOrderId() != null) {
				OrderTollFreeFeatureDTO orderTollFreeFeatureDTO = orderTollFreeFeatureRepository
						.getOne(orderActivity.getSlOrder().getSlOrderId());
				LECResponseDTO lecResponseDTO = lecResponseRepository
						.getBySlOrderId(orderActivity.getSlOrder().getSlOrderId().toString());
				if (lecResponseDTO == null) {
					lecResponseDTO = new LECResponseDTO();
					updateLecResponseDTO(tc, si, orderActivity, orderTollFreeFeatureDTO, lecResponseDTO);
				} else {
					updateLecResponseDTO(tc, si, orderActivity, orderTollFreeFeatureDTO, lecResponseDTO);

					LecProvisionerRequestDTO lecProvisionerRequest = lecProvisionerRequestRepository
							.getBySlOrderId(orderActivity.getSlOrder().getSlOrderId().toString());
					lecProvisionerRequest.setStatus("PROCESSED");
					lecProvisionerRequestRepository.save(lecProvisionerRequest);

					ProvisionerRequestDetailDTO provisionerRequestDetail = provisionerRequestDetailRepository
							.getBySlOrderId(orderActivity.getSlOrder().getSlOrderId().toString());
					provisionerRequestDetail.setStatus("PROCESSED");
					provisionerRequestDetailRepository.save(provisionerRequestDetail);
				}

				orderActivity.setComments("Force Completed by user " + username);
				orderActivity.setLastProcessingStop(new Date());
				orderActivity.setStatus(WorkflowConstants.ACTIVITY_COMPLETED_STATE);
				orderActivityRepository.save(orderActivity);
			}
		}
	}

	private void updateLecResponseDTO(String tc, String si, OrderActivityDTO orderActivity,
			OrderTollFreeFeatureDTO orderTollFreeFeatureDTO, LECResponseDTO lecResponseDTO) {
		lecResponseDTO.setAcOrderNum(orderActivity.getSlOrder().getSlOrderId().toString());
		lecResponseDTO.setTc(tc);
		lecResponseDTO.setSi(si);
		lecResponseDTO.setWtnNew(orderTollFreeFeatureDTO.getTn());
		lecResponseDTO.setCreateDate(new Date());
		lecResponseRepository.save(lecResponseDTO);
	}

	@RequestMapping(value = "/restartactivity", method = RequestMethod.PUT, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@Transactional
	@CrossOrigin
	public boolean restartActivity(@RequestParam(value = "jobId", required = false) String jobId,
			@RequestParam(value = "orderActivityPk", required = false) Long orderActivityPK,
			@RequestParam(value = "userName", required = false) String userName) throws Exception {
		if (orderActivityPK != null) {
			OrderActivityDTO orderActivityDTO = orderActivityRepository.findOne(orderActivityPK);
			Long slOrderId = orderActivityDTO.getSlOrder().getSlOrderId();
			if(orderActivityDTO.getSlOrder()!=null && userName!=null) {
				orderActivityDTO.getSlOrder().setLastUpdatedUser(userName);	
			}
			workflowServiceManager.updateLastUpdatedUser(userName, slOrderId);
			List<Object[]> restartData = processFlowStatusRepository
					.getActivityExecutionByOrderActivityPk(orderActivityPK);
			if (restartData.size() > 0) {
				activitiUtils.restartActivity(restartData, orderActivityPK);
			} else {
				// no jobs found look for child activities ???
				restartActivity(orderActivityPK);
			}
		} else if (jobId != null) {
			managementService.moveDeadLetterJobToExecutableJob(jobId, 1);
		}
		return true;
	}

	@Transactional
	public void restartActivity(Long orderActivityPK) {
		OrderActivityDTO orderActivityDTO = orderActivityRepository.findOne(orderActivityPK);
		try {
			LOG.info("Restarting Order activity " + orderActivityDTO.getMsFlow() + " from workflow metadata");

			String processInstanceId = null;
			Long slOrderId = orderActivityDTO.getSlOrder().getSlOrderId();
			if (slOrderId != null) {
				processInstanceId = processFlowStatusRepository.getAtivityExecutionIdBySLOrder(slOrderId);
			}

			if (processInstanceId == null) {
				String message = "No Activity found to restart for SL_Order=" + orderActivityDTO.getSlOrder()
						+ " , OrderActivityPK=" + orderActivityDTO.getOrderActivityPk() + " ," + " Activity_Name="
						+ orderActivityDTO.getActivityTypeId();
				throw new Exception(message);
			}

			List<Execution> executions = runtimeService.createExecutionQuery().executionId(processInstanceId).list();
			ExecutionEntity entity = (ExecutionEntity) executions.get(0);// (ExecutionEntity)Context.getCommandContext().getExecutionEntityManager().findById(processInstanceId);
			String matchingActivityId = activitiUtils.getBPMNActivityId(orderActivityDTO, processInstanceId, entity);

			CommandConfig commandConfig = processEngineConfiguration.getCommandExecutor().getDefaultConfig()
					.transactionRequired();
			managementService.executeCommand(commandConfig, new Command<Object>() {

				@Override
				public Object execute(CommandContext commandContext) {
					try {
						restartActivity.execute((DelegateExecution) entity, orderActivityDTO,
								orderActivityDTO.getSlOrder(), orderActivityDTO.getActivityRule(), matchingActivityId);
					} catch (Exception ex) {
						String message = "Error restarting activity " + orderActivityDTO.getOrderActivityPk();
						LOG.error(message, ex);
						throw new ServiceException(ex);
					}
					return null;
				}
			});

		} catch (Exception ex) {
			LOG.error("Error restarting activity " + orderActivityPK, ex);
			Level3Response l3Response = Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(ex.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	@RequestMapping(value = "/resume/{orderActivityPk}/activation", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE }, consumes = {
					MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@Audited
	public Response resumeWorkflowOnActivateTN(@PathVariable(value = "orderActivityPk") Long orderActivityPK) {
		try {
			LOG.info("NPAL Response Processing for orderActivityPk= " + orderActivityPK);

			if (orderActivityPK == null || orderActivityPK < 0) {
				return Response.status(400).build();
			}
			OrderActivityDTO orderActivityDTO = orderActivityRepository.findOne(orderActivityPK);

			List<Object[]> results = orderActivityRepository.findTnOrderActiivtyByPONandActivityTypeId(
					orderActivityDTO.getParentTransId(), orderActivityDTO.getActivityTypeId());
			List<Long> orderActivityPKs = results.stream().map(l -> ((BigDecimal) l[0]).longValue())
					.collect(Collectors.toList());

			for (Long orderActivityPk : orderActivityPKs) {
				try {
					forceCompleteErrorActivity(null, WorkflowConstants.CONDITION_NONE, orderActivityPk,
							WorkflowConstants.WORKFLOW_USER, "Auto completed by EMP.", null, null);
				} catch (Exception e) {
					// ignore the exception as it is logged in force complete method itself.
				}
			}

		} catch (Exception ex) {
			// error parsing response look for the xml objects
			LOG.error("Error Processing Activation signal. ", ex);
			return Response.status(500).build();
		}

		return Response.ok().build();
	}

	/**
	 * This method is used to resume the workflow, so if there is a PON, SlOrderId
	 * has to be there then signal would be updated at PON level, Only slOrderid if
	 * passed will close the signal at slorderlevel
	 * 
	 * @param parentTransId
	 * @param slOrderId
	 * @param orderActivityPK
	 * @throws Exception
	 */
	@RequestMapping(value = "/resume/workflow/{pon}/{slOrderId}/{orderActivityPK}", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@Transactional
	public void resumeWorkFlow(@PathVariable(value = "pon") Long parentTransId,
			@PathVariable(value = "slOrderId") Long slOrderId,
			@PathVariable(value = "orderActivityPK") Long orderActivityPK) throws Exception {
		OrderActivityDTO orderActivityDTO = orderActivityRepository.findOne(orderActivityPK);
		String completeSignalName = getSignalName(orderActivityDTO);
		String completeSignalId = getSignalId(orderActivityDTO);
		BigDecimal count = slOrderRepository.getSLOrderCountByPON(parentTransId.longValue());

		if (parentTransId != null && parentTransId != 0) {
			if (count.intValue() == 1) {
				workflowUtils.completeWaitSignalByOrder(slOrderId, completeSignalName, completeSignalId);
			} else {
				workflowUtils.completeWaitSignalByPON(parentTransId, completeSignalName, completeSignalId);
			}
		} else {
			workflowUtils.completeWaitSignalByOrder(slOrderId, completeSignalName, completeSignalId);
		}
	}

	private String getSignalName(OrderActivityDTO orderActivityDTO) {
		return "WF_" + orderActivityDTO.getActivityTypeId() + "_" + orderActivityDTO.getActivityId()
				+ "_Activity_Complete";
	}

	private String getSignalId(OrderActivityDTO orderActivityDTO) {
		return "WF_" + orderActivityDTO.getActivityTypeId() + "_" + orderActivityDTO.getActivityId()
				+ "_Activity_Signal";
	}

}
