package com.level3.voice.workflow.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * This VO object had identical information as the TollfreeTNDTO
 * as this would be used as the input object for the NUMS client call
 * to persist in NUMS Tollfree_TN table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class TollFreeTnVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long tn;
	private String productPartNumber;
	private String productId;
	private String ldNetwork;
	private String consumptionStatus;
	private String picLdCustomerNumber;
	private String ban;
	private Date lastUpdated;
	private String lastUpdateUser;
	private String lastUpdateSystem;
	private String event;
	private String vcOrderId;
	
	public Long getTn() {
		return tn;
	}

	public void setTn(Long tn) {
		this.tn = tn;
	}

	public String getProductPartNumber() {
		return productPartNumber;
	}

	public void setProductPartNumber(String productPartNumber) {
		this.productPartNumber = productPartNumber;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getLdNetwork() {
		return ldNetwork;
	}

	public void setLdNetwork(String ldNetwork) {
		this.ldNetwork = ldNetwork;
	}

	public String getConsumptionStatus() {
		return consumptionStatus;
	}

	public void setConsumptionStatus(String consumptionStatus) {
		this.consumptionStatus = consumptionStatus;
	}

	public String getPicLdCustomerNumber() {
		return picLdCustomerNumber;
	}

	public void setPicLdCustomerNumber(String picLdCustomerNumber) {
		this.picLdCustomerNumber = picLdCustomerNumber;
	}

	public String getBan() {
		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getLastUpdateUser() {
		return lastUpdateUser;
	}

	public void setLastUpdateUser(String lastUpdateUser) {
		this.lastUpdateUser = lastUpdateUser;
	}

	public String getLastUpdateSystem() {
		return lastUpdateSystem;
	}

	public void setLastUpdateSystem(String lastUpdateSystem) {
		this.lastUpdateSystem = lastUpdateSystem;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	/**
	 * @return the vcOrderId
	 */
	public String getVcOrderId() {
		return vcOrderId;
	}

	/**
	 * @param vcOrderId the vcOrderId to set
	 */
	public void setVcOrderId(String vcOrderId) {
		this.vcOrderId = vcOrderId;
	}
}
