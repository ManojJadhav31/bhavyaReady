/**
 * @author arun2.kumar
 */
package com.level3.voice.workflow.tai.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author kumar.arun2
 *
 */
@Entity
@Table(name = "CARRIER")
public class CarrierDTO {
	
	/** identifier field */
    @Id
    @Column(name = "CARRIER_NAME")
    private String carrierName;
    
    @Column(name = "CIC")
    private String cic;
    
    @Column(name = "ACNA")
    private String acna;
    
    @Column(name = "TYPE")
    private String type;
    
    @Column(name = "Network_Type")
    private String networkType;
    
    @Column(name = "EFFECTIVE_BEGIN")
    private Date effectiveBegin;
    
    @Column(name = "EFFECTIVE_END")
    private Date effectiveEnd;
    
    @Column(name = "STATUS_IND")
    private String statusInd;

	public String getCarrierName() {
		return carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	public String getCic() {
		return cic;
	}

	public void setCic(String cic) {
		this.cic = cic;
	}

	public String getAcna() {
		return acna;
	}

	public void setAcna(String acna) {
		this.acna = acna;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public Date getEffectiveBegin() {
		return effectiveBegin;
	}

	public void setEffectiveBegin(Date effectiveBegin) {
		this.effectiveBegin = effectiveBegin;
	}

	public Date getEffectiveEnd() {
		return effectiveEnd;
	}

	public void setEffectiveEnd(Date effectiveEnd) {
		this.effectiveEnd = effectiveEnd;
	}

	public String getStatusInd() {
		return statusInd;
	}

	public void setStatusInd(String statusInd) {
		this.statusInd = statusInd;
	}  
    
    
}
