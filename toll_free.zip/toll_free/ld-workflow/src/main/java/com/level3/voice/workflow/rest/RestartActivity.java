package com.level3.voice.workflow.rest;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.centurylink.voice.workflow.common.activity.BaseActivity;
import com.centurylink.voice.workflow.common.activity.ParentTransCoordActivity;
import com.centurylink.voice.workflow.common.utils.WorkflowUtils;
import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.document.JsonDocument;
import com.couchbase.client.java.document.json.JsonObject;
import com.couchbase.client.java.error.DocumentAlreadyExistsException;
import com.couchbase.client.java.error.TemporaryLockFailureException;
import com.level3.voice.common.util.CacheConstants;
import com.level3.voice.common.util.OrderTypeCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.ErrorEntryDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.repository.OrderStatusRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.TnOrderRepository;
import com.level3.voice.tollfree.persist.dto.LECResponseDTO;
import com.level3.voice.tollfree.persist.repository.LecResponseRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderActivityRepository;
import com.level3.voice.workflow.activity.WorkflowBaseActivity;

/**
 * Created by dadi.sudhir on 10/2/2017.
 */
@Component("restartActivity")
public class RestartActivity  extends WorkflowBaseActivity{
    private static Log LOG = LogFactory.getLog(RestartActivity.class);

    private static final Map<String, String> parentCoordMap = initMap();

    private static Map<String, String> initMap() {
        HashMap<String, String> map = new  HashMap<String, String> ();

        // Toll Free restart parent co-ordinated list
        map.put("915_18", "activateTNonEFSActivity");
        map.put("921_9", "activateTNonEFSActivity");
        map.put("924_10", "activateTNonEFSActivity");

        map.put("914_16", "updateVoiceInventoryActivity");
        map.put("920_6", "updateVoiceInventoryActivity");
        map.put("923_9", "updateVoiceInventoryActivity");
        
        map.put("933_6", "createDisconnectOrderActivity");
        map.put("936_8", "custMoveANIRemoveProActivity");

        return map;
    }

    @Autowired
    SlOrderRepository slOrderRepository;

    @Autowired
    TnOrderRepository tnOrderRepository;

    @Autowired
    ApplicationContext applicationContext;

    @Autowired
    WorkflowUtils workflowUtils;
    
    @Autowired
    OrderStatusRepository orderStatusRepository;
    
    @Autowired
    LecResponseRepository lecResponseRepository;

    @Autowired
	TollfreeOrderActivityRepository tollfreeOrderActivityRepository;
    
    @Override
    public void execute(DelegateExecution delegateExecution) {
        // for restarts this is a dummy function.
    }

    //@Transactional(propagation = Propagation.REQUIRES_NEW)
    public void execute(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
                        SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO, String delegateExpression) throws Exception {
        String errorMessage = null;
        try {
            if(delegateExpression.indexOf("parent") != -1) {
                restartParentCoordAct(delegateExecution, orderActivityDTO, slOrderDTO, activityRuleDTO, delegateExpression);
                String comments = "Restarted Activity by user : " + slOrderDTO.getLastUpdatedUser() + " on : " + new Date();
                tollfreeOrderActivityRepository.updateActivityComments(comments, OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
    					orderActivityDTO.getActivityTypeId());
                clearLECResponseOnRestart(orderActivityDTO);
                return;
            }


           Object baseActivity = (Object) applicationContext.getBean(delegateExpression);

            if(baseActivity instanceof WorkflowBaseActivity) {
                WorkflowBaseActivity baseActivity1 = (WorkflowBaseActivity) baseActivity;
                baseActivity1.executeActivity(delegateExecution, orderActivityDTO, slOrderDTO, activityRuleDTO);
                clearLECResponseOnRestart(orderActivityDTO);
            } else if(baseActivity instanceof  BaseActivity) {
                BaseActivity baseActivity1 = (BaseActivity) baseActivity;
                baseActivity1.executeActivity(delegateExecution, orderActivityDTO, slOrderDTO, activityRuleDTO);
                clearLECResponseOnRestart(orderActivityDTO);
            }
            

            if (delegateExecution.getCurrentFlowElement().getName().indexOf("Delegate") != -1) {
                // do nothing - delegating it to 3flow..
            }
            // if it is artifical and complete activity dummy nodes, just mark it as a complete, this is required to make 3flow engine happy.
            else if (activityRuleDTO.getActivity().getActivityName().indexOf("Artificial") != -1) {
                completeActivity(orderActivityDTO, null);
            } else if (delegateExecution.getCurrentActivityId().endsWith("Complete")) {
                completeActivity(orderActivityDTO, null);
            } else if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CREATED_STATE) {
                // since no errors mark it as complete
                completeActivity(orderActivityDTO, null);
            } else {
            	orderActivityDTO.setComments("Restarted Activity by user : " + slOrderDTO.getLastUpdatedUser() + " on : " + new Date());
                orderActivityRepository.save(orderActivityDTO);
            }
        } catch (Exception ex) {
            LOG.error("Error restarting activity activityPk=" + orderActivityDTO.getOrderActivityPk() + ", sl_order=" + slOrderDTO.getSlOrderId()
                    + ", activity_name="+ activityRuleDTO.getActivity().getActivityName(), ex);
            errorMessage = ex.getMessage();
        } finally {
            if(errorMessage != null ) {
                final OrderActivityDTO orderActivityDTO1 = orderActivityDTO;
                final ErrorEntryDTO errorEntryDTO1 = new ErrorEntryDTO();
                final SlOrderDTO slOrderDTO1 = slOrderDTO;
                final String errorMessage1 = errorMessage;
                workflowUtils.handleWorkflowError(slOrderDTO1, orderActivityDTO1, errorEntryDTO1, errorMessage1);

            }
        }
    }

    /**
     * This method is to clear the LEC response details when a
     * restart is done for LEC
     * 
     * @param orderActivityDTO
     */
	private void clearLECResponseOnRestart(OrderActivityDTO orderActivityDTO) {
		if(916 == orderActivityDTO.getActivityTypeId()) {
			LECResponseDTO lecResponseDTO = lecResponseRepository.getBySlOrderId(orderActivityDTO.getSlOrder().getSlOrderId().toString());
			if(lecResponseDTO != null) {
				lecResponseRepository.delete(lecResponseDTO);
			}
		}
	}

	@Autowired
    Bucket bucket;

    // restart parent co-ordinated activity
    public void restartParentCoordAct(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
                        SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO, String delegateExpression) throws Exception {
        String targetBean = orderActivityDTO.getActivityTypeId()+"_"+ orderActivityDTO.getActivityId();
        String pon = String.valueOf(orderActivityDTO.getParentTransId());
        JsonDocument doc = null;
        String key =  ":PON_RESTART_" + pon + "_"+targetBean;
        // restart parent co-ordinated activities, only for once for all restart activities belong to same PON and activity id...
        try {
            JsonObject content = JsonObject.empty().put("PON_ID", key);
            // expire in 30 seconds
            doc = JsonDocument.create(CacheConstants.SERVICE_CACHE + key, 30, content);
            doc = bucket.insert(doc);
            // lock for 5 seconds
            bucket.getAndLock(doc, 5 * 1000);
        } catch (DocumentAlreadyExistsException existsException) {
            LOG.info(" Skipping pon submission due to active submission in couchbase "+key);
            return;
        } catch (TemporaryLockFailureException exception) {
            LOG.info(" Skipping pon submission due to active submission in couchbase "+key);
            return;
        } catch(Exception ex) {
            // ignore ..
        }

        if(parentCoordMap.get(targetBean) == null ) {
            LOG.info("Error finding parent co-ordinated activity in parent coord map for bean"+targetBean);
            return;
        }

        ParentTransCoordActivity baseActivity = (ParentTransCoordActivity) applicationContext.getBean(parentCoordMap.get(targetBean));
        if(baseActivity != null) {
            try {
                baseActivity.executeActivity(delegateExecution, orderActivityDTO, slOrderDTO, activityRuleDTO);
               /* if(baseActivity.isAsyncWait() != null && !baseActivity.isAsyncWait()){
                    // mark it as complete
                    slOrderRepository.updateOrderActivityCompleteStatusByPon(orderActivityDTO.getParentTransId(), WorkflowConstants.ACTIVITY_COMPLETED_STATE, orderActivityDTO.getActivityTypeId(),
                            orderActivityDTO.getActivityId(), "Completed by Microservices Activity.", 3);
                    // send signal
                    ParentTransCoordCompleteActivity parentTransCoordCompleteActivity =  (ParentTransCoordCompleteActivity) applicationContext.getBean(ParentTransCoordCompleteActivity.class);

                    parentTransCoordCompleteActivity.executeParentTransActivity(orderActivityDTO.getParentTransId(), delegateExecution, orderActivityDTO.getProcessFlowId(),
                            orderActivityDTO.getActivityTypeId(), orderActivityDTO.getActivityId());
                }*/
            } catch(BpmnError error) {
                LOG.error("BPMN Error restarting parent co-ordinated activityPk=" + orderActivityDTO.getOrderActivityPk() + ", sl_order=" + slOrderDTO.getSlOrderId()
                        + ", activity_name="+ activityRuleDTO.getActivity().getActivityName(), error);
            } catch(Exception ex) {
                LOG.error("Error restarting parent co-ordinated activityPk=" + orderActivityDTO.getOrderActivityPk() + ", sl_order=" + slOrderDTO.getSlOrderId()
                        + ", activity_name="+ activityRuleDTO.getActivity().getActivityName(), ex);
                throw ex;
            }
        }
    }

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}
}