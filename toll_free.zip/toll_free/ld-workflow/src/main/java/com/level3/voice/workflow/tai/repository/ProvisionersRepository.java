package com.level3.voice.workflow.tai.repository;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.level3.voice.workflow.tai.dto.ProvisionersDTO;

@Transactional
public interface ProvisionersRepository extends JpaRepository<ProvisionersDTO, Long> {


	@Query(value="from ProvisionersDTO "
            + " where provisioner_name = ?1 and status='A' ")
	public ProvisionersDTO findProvisionerByName(final String provisionerName);  


	@Query(value="from ProvisionersDTO where status='A' ")
	public List<ProvisionersDTO> findAllProvisioners();
	
}