/**
 * 
 */
package com.level3.voice.workflow.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;
import java.nio.file.Files;
import java.security.Security;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.optional.ssh.Scp;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.StringUtils;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.tollfree.persist.dto.LECManualDTO;
import com.level3.voice.tollfree.persist.dto.LECProvisionerDTO;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.LECManualRepository;
import com.level3.voice.tollfree.persist.repository.LECProvisionerRepository;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.XMasterSubOcnRepository;
import com.level3.voice.workflow.dto.LecProvisionerRequestDTO;
import com.level3.voice.workflow.dto.ProvisionerRequestDetailDTO;
import com.level3.voice.workflow.repository.LecProvisionerRequestRepository;
import com.level3.voice.workflow.repository.ProvisionerRequestDetailRepository;
import com.level3.voice.workflow.tai.dto.CarrierDTO;
import com.level3.voice.workflow.tai.dto.ProvisionersDTO;
import com.level3.voice.workflow.tai.repository.CarrierRepository;
import com.level3.voice.workflow.tai.repository.ProvisionersRepository;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;
import com.level3.voice.workflow.vo.ProvisionerRequestDetail;
import com.level3.voice.workflow.vo.ProvisionerRequestHeader;
import com.level3.voice.workflow.vo.ProvisionerRequestTrail;

/**
 * This class is for SendToLECActivity It creates the .wca request file and
 * places in the remote machine for actual provisioning to happen. Response is
 * being processed in the scheduler on every specified interval
 * 
 * @author ab68221 - D, Manjunatha
 *
 */
@Component("sendToLECActivity")
public class SendToLECActivity extends WorkflowBaseActivity {

	private static final String TEST_CUSTOMER = "00001157";

	private static Log LOG = LogFactory.getLog(SendToLECActivity.class);

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	CarrierRepository carrierRepository;

	@Autowired
	LECProvisionerRepository lecProvisionerRepository;

	@Autowired
	ProvisionersRepository provisionersRepository;

	@Autowired
	LecProvisionerRequestRepository lecProvisionerRequestRepository;

	@Autowired
	ProvisionerRequestDetailRepository provisionerRequestDetailRepository;

	@Autowired
	LECManualRepository lecManualRepository;

	@Autowired
	XMasterSubOcnRepository xMasterSubOcnRepository;

	@Value("${tollfree.lecProvisioner.sshRemoteHost}")
	private String sshRemoteHost;

	@Value("${tollfree.lecProvisioner.srcBasePath}")
	private String srcBasePath;

	@Value("${tollfree.lecProvisioner.sshUserName}")
	private String sshUserName;

	@Value("${tollfree.lecProvisioner.remoteDir}")
	private String remoteDir;

	@Value("${tollfree.lecProvisioner.service.url}")
	private String ocnServiceUrl;

	@Value("${tollfree.lecProvisioner.remoteDirPath}")
	private String remoteDirPath;

	@Value("${spring.profiles.active}")
	private String activeProfile;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		LOG.info("SendToLECActivity started for slOrderId:" + slOrderDTO.getSlOrderId() + "activityId:"
				+ orderActivityDTO.getOrderActivityPk());

		OrderTollFreeFeatureDTO featureDTO = null;
		List<OrderTollFreeFeatureDTO> featureDTOs = orderTollFreeFeatureRepository
				.getAllBySlOrderId(slOrderDTO.getSlOrderId());
		if (featureDTOs.size() > 0) {
			featureDTO = featureDTOs.get(0);
		}
		String ocn = featureDTO.getOcn();
		if (StringUtils.isEmpty(ocn)) {
			String comments = "OCN is not available for ANI: " + featureDTO.getTn();
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			return;
		}
		ocn = getMasterOCN(ocn);

		String provisionerName = null;
		CarrierDTO carrierDTO = null;
		LECProvisionerDTO lecProvisionerDTO = null;
		ProvisionersDTO provisionersDTO = null;
		provisionerName = featureDTO.getLecProvisionerName();

		LECManualDTO lecManualDTO = lecManualRepository.findOne(featureDTO.getOcn());
		if (lecManualDTO != null) {
			String comments = "Please perform manual LEC provisioning tasks for OCN: " + featureDTO.getOcn();
			orderActivityDTO.setComments(comments);
			orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE);
			return;
		} else if (StringUtils.isEmpty(provisionerName)) {
			String comments = "Unable to perform LEC provisioning Activity for OCN: " + featureDTO.getOcn();
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			return;
		}

		carrierDTO = carrierRepository.findCarrierByCic(featureDTO.getCic());
		if (carrierDTO == null) {
			String comments = "Active Carrier is not available for CIC: " + featureDTO.getCic();
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			return;
		}
		lecProvisionerDTO = lecProvisionerRepository.findLECProvisionerByProvisonerNameOCN(provisionerName, ocn);
		if (lecProvisionerDTO == null) {
			String comments = "Active Provisioner LEC details are not available for Provisioner Name: "
					+ provisionerName + " and OCN: " + ocn;
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			return;
		}

		provisionersDTO = provisionersRepository.findProvisionerByName(provisionerName);
		if (provisionersDTO == null) {
			String comments = "Active Provisioner Details are not available for Provisioner Name: " + provisionerName;
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			return;
		}

		String SWBTseq = fetchSWBTSequenceNumber();
		
		String reqFileName = createFileName(lecProvisionerDTO, orderActivityDTO,SWBTseq);
		try {
			generateRequestFile(slOrderDTO, orderActivityDTO, featureDTO, carrierDTO, lecProvisionerDTO,
					provisionersDTO, orderActivityDTO.getOrderActivityPk(), reqFileName,SWBTseq);
		} catch (Exception e) {
			String comments = "Unable to generate the file.";
			e.printStackTrace();
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			return;
		}

		boolean isSuccess = copyToRemoteLoc(orderActivityDTO, lecProvisionerDTO, reqFileName, slOrderDTO.getExternalCustomerId());

		if (isSuccess) {
			orderActivityDTO.setComments("Successfully placed LEC file for provisioner: " + provisionerName);
			orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE);
		} else {
			String comments = "Unable to copy file to remote location.";
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			return;
		}
		orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE);
	}

	private String getMasterOCN(String ocn) {
		return xMasterSubOcnRepository.getMasterOcn(ocn);
	}

	private String createFileName(LECProvisionerDTO lecProvisionerDTO, OrderActivityDTO orderActivityDTO, String seq) {
		String prefixProvisioner = "";

		if (lecProvisionerDTO.getProvisionerName().equals("USWEST")) {
			prefixProvisioner = "USW" + seq + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("AllTel")) {
			prefixProvisioner = "ALT" + seq + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("BellAtlan")) {
			prefixProvisioner = "WCA_" + orderActivityDTO.getSlOrder().getSlOrderId() + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("IowaNetSrv")) {
			prefixProvisioner = "ION" + seq + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("Onvoy")) {
			prefixProvisioner = "ONV_" + orderActivityDTO.getSlOrder().getSlOrderId();
		} else if (lecProvisionerDTO.getProvisionerName().equals("SWBT")) {
			prefixProvisioner = "SWB" + seq + ".wca"; // REQU_PATTERN="wca$|avu$"
		} else if (lecProvisionerDTO.getProvisionerName().equals("Century")) {
			prefixProvisioner = "CEN_" + orderActivityDTO.getSlOrder().getSlOrderId() + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("CitizensTC")) {
			prefixProvisioner = "CIT" + seq + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("Ameritech")) {
			prefixProvisioner = orderActivityDTO.getSlOrder().getSlOrderId() + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("CinBell")) {
			prefixProvisioner = orderActivityDTO.getSlOrder().getSlOrderId() + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("USWest")) {
			prefixProvisioner = "SSM_" + orderActivityDTO.getSlOrder().getSlOrderId() + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("Windstream")) {
			prefixProvisioner = orderActivityDTO.getSlOrder().getSlOrderId() + ".wca";
		} else if (lecProvisionerDTO.getProvisionerName().equals("VerizonNJ")) {
			prefixProvisioner = "BAL_" + orderActivityDTO.getSlOrder().getSlOrderId() + ".wca";
		} else {
			prefixProvisioner = orderActivityDTO.getSlOrder().getSlOrderId() + ".wca";
		}
		return prefixProvisioner;
	}

	/**
	 * This method is to SSH SCP to remote location
	 * 
	 * @param orderActivityDTO
	 * @param lecProvisionerDTO
	 * @param reqFileName
	 * @param customerId 
	 * @return
	 * @throws SocketException
	 * @throws IOException
	 */
	private boolean copyToRemoteLoc(OrderActivityDTO orderActivityDTO, LECProvisionerDTO lecProvisionerDTO,
			String reqFileName, String customerId) throws SocketException, IOException {
		String tempDir = System.getProperty("java.io.tmpdir");
		if (!tempDir.endsWith("/")) {
			tempDir = tempDir.concat("/");
		}
		extractShhKeyAndHost(tempDir);

		String localFile = tempDir + lecProvisionerDTO.getProvisionerName() + File.separator + reqFileName;

		boolean isSucess = false;
		String remoteDirectory = "";
		try {
			Scp scp = new Scp();
			int portSSH = 22;
			String targetFileIdRsa = tempDir + "ssh" + File.separator + "id_rsa";
			String targetKnownHosts = tempDir + "ssh" + File.separator + "known_hosts";
			if (activeProfile.equalsIgnoreCase("prod") || TEST_CUSTOMER.equalsIgnoreCase(customerId)) {
				remoteDirectory = remoteDir + "/" + lecProvisionerDTO.getProvisionerName() + "/" + "Export";
			} else {
				remoteDirectory = remoteDirPath;
			}
			scp.setPort(portSSH);
			scp.setLocalFile(localFile);
			scp.setKeyfile(targetFileIdRsa);
			scp.setKnownhosts(targetKnownHosts);
			scp.setTodir(sshUserName + "@" + sshRemoteHost + ":" + remoteDirectory);
			scp.setProject(new Project());
			scp.setTrust(true);
			Security.insertProviderAt(new BouncyCastleProvider(), 1);
			scp.setFileMode("777");
			scp.execute();
			LOG.info("The Object was succesfully written to a file in : " + sshUserName + "@" + sshRemoteHost + ":"
					+ remoteDirectory);
			isSucess = true;
		} catch (Exception e) {
			LOG.error("Error in copyToRemoteLoc of LECProcisioning for " + remoteDirectory);
			LOG.error(e.getStackTrace());
		}

		return isSucess;
	}

	/**
	 * To make a copy of id_rsa and known_hosts in java.io.tmpdir since the JSCH
	 * needs the absolute path to the files(inside jar path is not working)
	 * 
	 * @param tempDir
	 * @throws IOException
	 */
	private void extractShhKeyAndHost(String tempDir) throws IOException {
		// make a copy of id_rsa and known_hosts in java.io.tmpdir since the
		// JSCH needs the absolute path to the files(inside jar path is not
		// working)
		InputStream is = this.getClass().getResourceAsStream("/ssh/id_rsa");

		byte[] buffer = new byte[is.available()];
		is.read(buffer);
		String targetFileIdRsa = tempDir + "/ssh/id_rsa";
		OutputStream outStream = FileUtils.openOutputStream(new File(targetFileIdRsa));
		outStream.write(buffer);

		InputStream isKnownHosts = this.getClass().getResourceAsStream("/ssh/known_hosts");

		byte[] bufferKnownHosts = new byte[isKnownHosts.available()];
		isKnownHosts.read(buffer);
		String targetKnownHosts = tempDir + "/ssh/known_hosts";
		OutputStream outStreamKnownHosts = FileUtils.openOutputStream(new File(targetKnownHosts));
		outStreamKnownHosts.write(bufferKnownHosts);

	}

	/**
	 * This method is to generate the request footer object
	 * 
	 * @param slOrderDTO
	 * @param featureDTO
	 * @param carrierDTO
	 * @param lecProvisionerDTO
	 * @param provisionersDTO
	 * @param sWBTseq 
	 * @return
	 */
	private ProvisionerRequestTrail createReqTrail(SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO featureDTO,
			CarrierDTO carrierDTO, LECProvisionerDTO lecProvisionerDTO, ProvisionersDTO provisionersDTO, String sWBTseq) {
		ProvisionerRequestTrail trail = new ProvisionerRequestTrail();

		trail.setTc("99");
		trail.setSi("01");
		trail.setReserve1(StringUtils.appendCharToString(2, "", ' '));
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		trail.setCreateDate(StringUtils.appendCharToString(6, sdf.format(new Date()), ' '));
		trail.setSequenceNumber(StringUtils.appendCharToString(4, sWBTseq, ' '));

		trail.setApid(StringUtils.appendCharToString(4, lecProvisionerDTO.getApid(), ' '));
		trail.setAcna(StringUtils.appendCharToString(3, carrierDTO.getAcna(), ' '));
		trail.setRao(StringUtils.appendCharToString(3, lecProvisionerDTO.getRao(), ' '));
		trail.setSeqGroupId(StringUtils.appendCharToString(2, "", ' '));
		trail.setVersionNumber(StringUtils.appendCharToString(4, lecProvisionerDTO.getPicVersion(), ' '));
		trail.setCic(StringUtils.appendCharToString(4, featureDTO.getCic(), ' '));
		trail.setReserve2(StringUtils.appendCharToString(78, "", ' '));
		// TODO total number of lines in the file (for now its always 3 since
		// one TN is being processed)
		// Integer recordCount = 3;
		trail.setRecordCount(StringUtils.appendCharToString(7, "0000003", ' '));
		trail.setReserve3(StringUtils.appendCharToString(1378, "", ' '));
		return trail;
	}

	
	/** This method is to generate sequence number for SWBT provisioner. It generates the new sequence number for each call
	 * @return
	 */
	private String fetchSWBTSequenceNumber() {
		Long seq = orderTollFreeFeatureRepository.getSWBSeq();
		String SWBTseq=null;
		if(seq!=null) {
			long fDigit = seq % 1000;
			SWBTseq = String.format("%04d", fDigit);
		}
		return SWBTseq;
	}

	/**
	 * This method is to generate the request body object
	 * 
	 * @param slOrderDTO
	 * @param featureDTO
	 * @param carrierDTO
	 * @param lecProvisionerDTO
	 * @param provisionersDTO
	 * @param orderActivityIdPk
	 * @return
	 */
	private ProvisionerRequestDetail createReqDetail(SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO featureDTO,
			CarrierDTO carrierDTO, LECProvisionerDTO lecProvisionerDTO, ProvisionersDTO provisionersDTO,
			Long orderActivityIdPk) {
		ProvisionerRequestDetail detail = new ProvisionerRequestDetail();

		if ("SWBT".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName())) {
			detail.setTc("01");
			detail.setSi("01");
		} /*
			 * if terminal is associated. Need to check if we are capturing terminal else
			 * if("SWBT".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName() )) {
			 * detail.setTc("01"); detail.setSi("02"); }
			 */else if ("USWEST".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName())) {
			detail.setTc("01");
			detail.setSi("01");
		} else {
			detail.setTc("01");
			detail.setSi("05");
		}

		detail.setOldCIC(StringUtils.appendCharToString(3, "", ' '));
		detail.setReserve0(StringUtils.appendCharToString(10, "", ' '));
		detail.setCustomerCode(StringUtils.appendCharToString(3, "", ' '));
		detail.setWtn(StringUtils.appendCharToString(10, featureDTO.getTn(), ' '));
		detail.setHml(StringUtils.appendCharToString(4, "", ' '));
		detail.setTerminal(StringUtils.appendCharToString(4, "", ' '));
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		detail.setlOAorProcessDate(StringUtils.appendCharToString(6, sdf.format(new Date()), ' ')); // TODO
																									// need
																									// to
																									// check
																									// the
																									// table
																									// which
																									// is
		detail.setCustomerType(StringUtils.appendCharToString(1, "B", ' '));// TODO
																			// need
																			// to
																			// query
																			// service
																			// location
		detail.setReserve1(StringUtils.appendCharToString(3, "", ' '));

		// "SoutherNE-Z | PacBell -- Z | Ameritech--Y | All other LEC -- Blank"
		if ("SoutherNE".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName())
				|| "PacBell".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName())) {
			detail.setBillNameInd(StringUtils.appendCharToString(1, "Z", ' '));
		} else if ("Ameritech".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName())) {
			detail.setBillNameInd(StringUtils.appendCharToString(1, "Y", ' '));
		} else {
			detail.setBillNameInd(StringUtils.appendCharToString(1, "", ' '));
		}
		detail.setBillName1(StringUtils.appendCharToString(30, slOrderDTO.getExternalCustomerId(), ' ')); // CustomerId
		detail.setBillName2(StringUtils.appendCharToString(30, "", ' '));
		detail.setBillName3(StringUtils.appendCharToString(30, "", ' '));
		detail.setBillAddress1(StringUtils.appendCharToString(30, "", ' '));
		detail.setBillAddress2(StringUtils.appendCharToString(30, "", ' '));
		detail.setBillAddress3(StringUtils.appendCharToString(30, "", ' '));
		detail.setAddressFlag(StringUtils.appendCharToString(1, "", ' '));
		detail.setCity(StringUtils.appendCharToString(30, "", ' '));
		detail.setState(StringUtils.appendCharToString(25, "", ' '));
		detail.setZipCode(StringUtils.appendCharToString(9, "", ' '));
		detail.setReserve2(StringUtils.appendCharToString(48, "", ' '));
		detail.setiCRefNumber(StringUtils.appendCharToString(10, "", ' '));
		if (slOrderDTO.getSlOrderId() != null) {
			detail.setiCOrderNumber(StringUtils.appendCharToString(16, slOrderDTO.getSlOrderId().toString(), ' '));
		}

		detail.setlECOrderNumber(StringUtils.appendCharToString(18, "", ' '));
		detail.setLangInd(StringUtils.appendCharToString(1, "", ' '));
		detail.setOriginalTC(StringUtils.appendCharToString(2, "", ' '));
		detail.setOriginalSI(StringUtils.appendCharToString(2, "", ' '));
		detail.setReserve3(StringUtils.appendCharToString(8, "", ' '));
		detail.setPoliticalAcctInd(StringUtils.appendCharToString(1, "", ' '));
		detail.setReserve4(StringUtils.appendCharToString(2, "", ' '));
		detail.setJurisdiction(StringUtils.appendCharToString(1, featureDTO.getJurisdiction(), ' '));
		detail.setDialingInd(StringUtils.appendCharToString(1, "", ' '));
		if (featureDTO.getPicRequest() != null && featureDTO.getPicRequest().equalsIgnoreCase("ICPay")) {
			detail.setpICChargeInd(StringUtils.appendCharToString(1, "Y", ' '));
		} else {
			detail.setpICChargeInd(StringUtils.appendCharToString(1, "", ' '));
		}

		detail.setReserve5(StringUtils.appendCharToString(9, "", ' '));
		detail.setDesiredDueDate(StringUtils.appendCharToString(6, "", ' '));
		detail.setEarliestMsgDate(StringUtils.appendCharToString(6, "", ' '));
		detail.setLatestMsgDate(StringUtils.appendCharToString(6, "", ' '));
		detail.setCic(StringUtils.appendCharToString(4, featureDTO.getCic(), ' '));
		detail.setReserve6(StringUtils.appendCharToString(7, "", ' '));
		detail.setSwitchlessInd(StringUtils.appendCharToString(1, "", ' '));
		detail.setReserve7(StringUtils.appendCharToString(6, "", ' '));

		// "LEC's --- PacBell/Southern/SWBT -- N | All others Blank"
		if ("PacBell".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName())
				|| "Southern".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName())
				|| "SWBT".equalsIgnoreCase(lecProvisionerDTO.getProvisionerName())) {
			detail.setbTNEdit(StringUtils.appendCharToString(1, "N", ' '));
		} else {
			detail.setbTNEdit(StringUtils.appendCharToString(1, "", ' '));
		}

		detail.setReserve8(StringUtils.appendCharToString(304, "", ' '));
		detail.setMsgTypeInd(StringUtils.appendCharToString(1, "", ' '));
		detail.setPreviousCIC(StringUtils.appendCharToString(4, "", ' '));
		detail.setReserve9(StringUtils.appendCharToString(11, "", ' '));
		detail.setLocalServiceProvID(StringUtils.appendCharToString(4, lecProvisionerDTO.getOcn(), ' '));
		detail.setReserve10(StringUtils.appendCharToString(16, "", ' '));
		detail.setlECLineType(StringUtils.appendCharToString(1, "", ' '));
		detail.setlECLineDate(StringUtils.appendCharToString(8, "", ' '));
		detail.setReserve11(StringUtils.appendCharToString(699, "", ' '));

		return detail;

	}

	/**
	 * This is to generate the request header object
	 * 
	 * @param slOrderDTO
	 * @param featureDTO
	 * @param carrierDTO
	 * @param lecProvisionerDTO
	 * @param provisionersDTO
	 * @param sWBTseq 
	 * @return
	 */
	private ProvisionerRequestHeader createReqHeader(SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO featureDTO,
			CarrierDTO carrierDTO, LECProvisionerDTO lecProvisionerDTO, ProvisionersDTO provisionersDTO, String sWBTseq) {
		ProvisionerRequestHeader header = new ProvisionerRequestHeader();

		header.setTc("00");
		header.setSi("01");
		header.setReserve1(StringUtils.appendCharToString(2, "", ' '));
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		header.setCreateDate(StringUtils.appendCharToString(4, sdf.format(new Date()), ' '));
		header.setSequenceNumber(StringUtils.appendCharToString(4, sWBTseq, ' '));

		header.setApid(StringUtils.appendCharToString(4, lecProvisionerDTO.getApid(), ' '));
		header.setAcna(StringUtils.appendCharToString(3, carrierDTO.getAcna(), ' '));
		header.setRao(StringUtils.appendCharToString(3, lecProvisionerDTO.getRao(), ' '));
		header.setSeqGroupId(StringUtils.appendCharToString(2, "", ' '));
		header.setVersionNumber(StringUtils.appendCharToString(4, lecProvisionerDTO.getPicVersion(), ' '));
		header.setCic(StringUtils.appendCharToString(4, featureDTO.getCic(), ' '));
		header.setReserve2(StringUtils.appendCharToString(1463, "", ' '));

		return header;
	}

	/**
	 * This method is to generate the .wca file in local basepath specified
	 * 
	 * @param slOrderDTO
	 * @param orderActivityDTO
	 * @param featureDTO
	 * @param carrierDTO
	 * @param lecProvisionerDTO
	 * @param provisionersDTO
	 * @param orderActivityIdPk
	 * @param reqFileName
	 * @param sWBTseq 
	 * @throws IOException
	 */
	private void generateRequestFile(SlOrderDTO slOrderDTO, OrderActivityDTO orderActivityDTO,
			OrderTollFreeFeatureDTO featureDTO, CarrierDTO carrierDTO, LECProvisionerDTO lecProvisionerDTO,
			ProvisionersDTO provisionersDTO, Long orderActivityIdPk, String reqFileName, String swbtSeq) throws IOException {

		LecProvisionerRequestDTO lecProvisionerRequestDTO = lecProvisionerRequestRepository
				.getBySlOrderId(slOrderDTO.getSlOrderId().toString());
		if (lecProvisionerRequestDTO == null) {
			lecProvisionerRequestDTO = new LecProvisionerRequestDTO();
		}

		lecProvisionerRequestDTO.setStatus("REQUESTED");
		if (slOrderDTO.getVoiceOrderId() != null) {
			lecProvisionerRequestDTO.setVoId(slOrderDTO.getVoiceOrderId().toString());
		}
		lecProvisionerRequestDTO.setSlOrderId(slOrderDTO.getSlOrderId().toString());
		lecProvisionerRequestDTO.setOrderActivityId(orderActivityIdPk.toString());

		lecProvisionerRequestDTO.setCreatedDate(new Date());
		
		// Creating the required data for file with objects
		ProvisionerRequestHeader header = createReqHeader(slOrderDTO, featureDTO, carrierDTO, lecProvisionerDTO,
				provisionersDTO,swbtSeq);
		ProvisionerRequestDetail detail = createReqDetail(slOrderDTO, featureDTO, carrierDTO, lecProvisionerDTO,
				provisionersDTO, orderActivityIdPk);
		ProvisionerRequestTrail trail = createReqTrail(slOrderDTO, featureDTO, carrierDTO, lecProvisionerDTO,
				provisionersDTO,swbtSeq);
		String tempDir = System.getProperty("java.io.tmpdir");
		if (!tempDir.endsWith("/")) {
			tempDir = tempDir.concat("/");
		}
		String filePath = tempDir + lecProvisionerDTO.getProvisionerName() + File.separator + reqFileName;
		try {
			FileOutputStream fileOut = FileUtils.openOutputStream(new File(filePath));
			fileOut.write(header.toString().getBytes());
			fileOut.write(detail.toString().getBytes());
			fileOut.write(trail.toString().getBytes());
			fileOut.close();

			LOG.info("SendToLECActivity request file is created, name:" + filePath);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		byte[] lecFileData = Files.readAllBytes(new File(filePath).toPath());
		lecProvisionerRequestDTO.setFileData(lecFileData);
		lecProvisionerRequestDTO.setFileName(reqFileName);
		lecProvisionerRequestRepository.saveAndFlush(lecProvisionerRequestDTO);

		ProvisionerRequestDetailDTO detailDTO = provisionerRequestDetailRepository
				.getBySlOrderId(slOrderDTO.getSlOrderId().toString());
		if (detailDTO == null) {
			detailDTO = new ProvisionerRequestDetailDTO(detail);
		}
		detailDTO.setLecProvRequestId(lecProvisionerRequestDTO.getId());
		if (orderActivityDTO.getOrderActivityPk() != null) {
			detailDTO.setOrderActivityId(orderActivityDTO.getOrderActivityPk().toString());
		}
		if (slOrderDTO != null && slOrderDTO.getSlOrderId() != null) {
			detailDTO.setSlOrderId(slOrderDTO.getSlOrderId().toString());
		}
		detailDTO.setStatus("PENDING");
		provisionerRequestDetailRepository.saveAndFlush(detailDTO);
	}

}
