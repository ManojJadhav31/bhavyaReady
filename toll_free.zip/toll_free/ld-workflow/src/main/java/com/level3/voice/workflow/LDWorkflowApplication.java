package com.level3.voice.workflow;

import com.centurylink.microservice.hateoas.ConditionalEtagHeaderFilter;
import com.centurylink.microservice.springfox.EnableSwaggerDocumentation;
import com.level3.enterprise.common.connection.AuditExecutor;
import com.level3.voice.workflow.service.SwaggerDocumentationConfig;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import org.activiti.engine.RepositoryService;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.hateoas.UriTemplate;
import org.springframework.hateoas.hal.CurieProvider;
import org.springframework.hateoas.hal.DefaultCurieProvider;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import javax.annotation.PostConstruct;
import javax.servlet.Filter;


/**
 * Created by dadi.sudhir on 12/26/2017.
 */
@SpringBootApplication
@ComponentScan(basePackages= {"com.level3.voice"

        ,"com.centurylink",
        "com.level3.enterprise",
        "com.level3.voice.tollfree",
        "com.level3.voice.persist.repository",
        "com.level3.voice.workflow.tai",
        "com.level3.voice.workflow.tai.repository",
        "com.level3.voice.workflow.manager"
})
@EnableDiscoveryClient
@EnableAspectJAutoProxy
@EnableAsync
@EnableJpaAuditing
@EnableSwagger2
@EnableSwaggerDocumentation(apiTitle="Staged Orders",
apiDescription="Mangement of Staged Orders")
@Import({SwaggerDocumentationConfig.class})
public class LDWorkflowApplication {

    public static void main(String... args) {
        SpringApplication.run(LDWorkflowApplication.class, args);
    }

    @Value("${level3.voice.audit.executor.urls}")
    String auditExecutorUrls;

    @Value("${voice.workflow.tenant}")
    private String tentantId;


    @Autowired
    RepositoryService repositoryService;

    @Autowired
    SpringProcessEngineConfiguration springProcessEngineConfiguration;

    @Bean(destroyMethod="stop")
    public AuditExecutor auditExecutor() {
        AuditExecutor auditExecutor =
                new AuditExecutor(0, 0, auditExecutorUrls);
        auditExecutor.start();
        return auditExecutor;
    }


    /**
     * Creates a  default Curie Provider.
     * @return a HAL Curie provider  that maps the prefix "voice" to the
     * 	URL <code>http://level.com/rels/voice/{rel}</code>
     * @see "http://stateless.co/hal_specification.html"
     */
    @Bean
    public CurieProvider curieProvider() {
        return new DefaultCurieProvider("voice",
                new UriTemplate("http://www.level3.com/rels/voice/{rel}"));
    }

    @Bean
    public Filter eTagHeaderFilter() {
        return new ConditionalEtagHeaderFilter();
    }

    @Bean
    @Qualifier("workflowSignalExecutor")
    @Primary
    public TaskExecutor getSignalExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setMaxPoolSize(350);
        executor.setCorePoolSize(10);
        executor.setThreadNamePrefix("T-Workflow-Signal");
        executor.initialize();

        return executor;
    }


    @Value("${spring.cloud.stream.kafka.binder.brokers}")
    String binderKafka;

    @PostConstruct
    public void postSetup () {
        repositoryService.createDeployment()
        		.addClasspathResource("processes/WF_20000_9490344556.bpmn20.xml")
                .addClasspathResource("processes/WF_20001_9059997967.bpmn20.xml")
                .addClasspathResource("processes/WF_20002_9490345911.bpmn20.xml")
                .addClasspathResource("processes/PIC_LD_PON_FLOW.bpmn20.xml")
                .tenantId(tentantId).deploy() ;

        springProcessEngineConfiguration.getAsyncExecutor().shutdown();
    }
}