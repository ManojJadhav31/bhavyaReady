package com.level3.voice.workflow.utils;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.centurylink.voice.workflow.common.activity.BaseActivity;
import com.level3.voice.client.emp.dto.EMPResponseData;
import com.level3.voice.common.util.OrderConstants;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.repository.ErrorEntryRepository;
import com.level3.voice.persist.repository.OrderActivityRepository;
import com.level3.voice.persist.repository.OrderStatusRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;

@Component
public class TollfreeWorkflowUtils {

	private static Log LOG = LogFactory.getLog(TollfreeWorkflowUtils.class);

	@Autowired
	SlOrderRepository slOrderRepository;

	@Autowired
	ErrorEntryRepository errorEntryRepository;

	@Autowired
	OrderStatusRepository orderStatusRepository;

	@Autowired
	OrderActivityRepository orderActivityRepository;

	public boolean isEFSCallRequiredForChange(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {

		if (prevOrderTollfreeFeatures == null) {
			return false;
		} else if (checkValue(prevOrderTollfreeFeatures.getUnvalidatedAC(),
				currOrderTollfreeFeatures.getUnvalidatedAC())
				|| checkValue(prevOrderTollfreeFeatures.getValidatedAC(), currOrderTollfreeFeatures.getValidatedAC())) {
			return true;
		} else if ((prevOrderTollfreeFeatures.getValidatedAC()
				.equalsIgnoreCase(currOrderTollfreeFeatures.getValidatedAC())
				&& (checkAccountCodes(prevOrderTollfreeFeatures, currOrderTollfreeFeatures)))) {
			return true;
		}

		return false;
	}

	public boolean checkAccountCodes(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {
		if (checkValue(prevOrderTollfreeFeatures.getAcDigits(), currOrderTollfreeFeatures.getAcDigits())
				|| checkValue(prevOrderTollfreeFeatures.getAcTableName(), currOrderTollfreeFeatures.getAcTableName())) {
			return true;
		}
		return false;
	}

	public boolean checkValue(String value1, String value2) {
		if ((value1 == null && value2 != null) || (value1 == null && value2 != null)) {
			return true;
		} else if ((value1 != null && value2 == null) || (value1 != null && value2 == null)) {
			return true;
		} else {
			return (!value1.equalsIgnoreCase(value2)) || (!value1.equalsIgnoreCase(value2));
		}
	}

	public static boolean isOrderEnterprise(OrderTollFreeFeatureDTO orderTollFreeFeatureDTO, SlOrderDTO slOrderDTO) {
		// currently, only voice complete is enterprise
		String slOrderType = slOrderDTO.getSlOrderType();

		// if we aren't a "TN" or "CA" slOrderType, we can't currently be enterprise
		if (!OrderConstants.TN_ORDER_TYPE.equalsIgnoreCase(slOrderType)
				&& !OrderConstants.CARRIER_AUTOMATED_ORDER_TYPE.equalsIgnoreCase(slOrderType)) {
			return false;
		} else {
			// if we are a TN slOrderType, daoTnOrder lookup should work,
			// otherwise no
			return OrderConstants.VOICE_COMPLETE_ID_STRING
					.equals(orderTollFreeFeatureDTO.getProductOfferingID().toString());
		}
	}

	public void updateActivityErrorMessageNoTrans(SlOrderDTO slOrderDTO, OrderActivityDTO orderActivityDTO,
			String message) {
		try {

			if (message != null && message.length() > 500)
				message = message.substring(0, 500);

			if (orderActivityDTO != null)
				BaseActivity.raiseOrderActivityError(slOrderDTO, orderActivityDTO, message, message, "MF-WF", "MS-WF",
						false, true, errorEntryRepository);
			else
				BaseActivity.raiseError(slOrderDTO.getSlOrderId(), message, 1, errorEntryRepository);

		} catch (Exception ex) {
			LOG.error("Error Creating Error Entry record for SL order" + slOrderDTO.getSlOrderId() + " Message: "
					+ message, ex);
		}
	}
	
	public StringBuffer getDetailedErrorMessage(EMPResponseData empResponseData) {
		StringBuffer detailErrorMsg = new StringBuffer();
		detailErrorMsg.append(empResponseData.getResponseDetail());
		if (!StringUtils.isEmpty(empResponseData.getDetail())) {
			detailErrorMsg.append("-");
			detailErrorMsg.append(empResponseData.getDetail());
		}
		return detailErrorMsg;
	}

	@Transactional
	public void handleError(OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO, String comments) {
		orderActivityDTO.setComments(comments);
		orderActivityDTO.setLastProcessingStop(new Date());
		orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_ERROR_STATE);
	}

	@Transactional
	public void handleError(EMPResponseData empResponseData, String comments) {
		if (empResponseData.getOrderActivityPK() != null) {
			OrderActivityDTO orderActivityDTO = orderActivityRepository.findOne(empResponseData.getOrderActivityPK());
			orderActivityDTO.setComments(comments);
			orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_ERROR_STATE);
			orderActivityRepository.saveAndFlush(orderActivityDTO);
		}
	}

}
