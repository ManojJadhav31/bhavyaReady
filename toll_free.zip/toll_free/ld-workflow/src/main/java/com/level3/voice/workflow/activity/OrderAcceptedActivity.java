package com.level3.voice.workflow.activity;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.OrderStatusConstants;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.VoiceOrderDTO;
import com.level3.voice.persist.repository.OrderStatusRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.VoiceOrderRepository;
import com.level3.voice.util.DateCalculator;

/**
 * Created by dadi.sudhir on 10/2/2017.
 */
@Component("setOrderAccepted")
public class OrderAcceptedActivity extends WorkflowBaseActivity {
	private static Log LOG = LogFactory.getLog(OrderAcceptedActivity.class);

	@Autowired
	SlOrderRepository slOrderRepository;

	@Autowired
	DateCalculator dateCalculator;

	@Autowired
	VoiceOrderRepository voiceOrderRepository;

	@Autowired
	OrderStatusRepository orderStatusRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {
		if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CANCELLED_STATE) {
			LOG.error("@OrderAcceptedActivity: Cancelled skip processing the activity.");
			throw new BpmnError("Activity Cancelled, so stopped processing in Microservices.");
		}
		if (slOrderDTO.getOrderStatusId() == null
				|| slOrderDTO.getOrderStatusId() != OrderStatusConstants.ORDER_STATUS_ACCEPT) {
			slOrderDTO.setOrderStatusId(new Integer(OrderStatusConstants.ORDER_STATUS_ACCEPT));
			slOrderDTO = slOrderRepository.saveAndFlush(slOrderDTO);

			VoiceOrderDTO voiceOrderDTO = voiceOrderRepository.findOne(slOrderDTO.getVoiceOrderId());
			voiceOrderDTO.setOrderStatus(orderStatusRepository.findByName("In Progress"));
			voiceOrderDTO.setRequest("NA");
			voiceOrderRepository.saveAndFlush(voiceOrderDTO);
		}

		orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_COMPLETED_STATE);
		completeActivity(orderActivityDTO, null);
	}
}
