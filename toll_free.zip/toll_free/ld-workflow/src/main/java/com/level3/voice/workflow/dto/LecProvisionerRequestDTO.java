package com.level3.voice.workflow.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author ab68221 - D, Manjunatha
 *
 */
@Entity
@Table(name = "LEC_PROVISIONER_REQUEST", schema="SUBL_OWNER")
public class LecProvisionerRequestDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "lec_provisioner_request_seq")
    @SequenceGenerator(sequenceName = "LEC_PROVISIONER_REQUEST_SEQ", allocationSize = 1, name = "lec_provisioner_request_seq")
	@Column(name="ID")
	private Long id;
	@Column(name="VOID")
	private String voId;
	@Column(name="ORDER_ACTIVITY_ID")
	private String orderActivityId;
	@Column(name="SL_ORDER_ID")
	private String slOrderId;
	@Column(name="FILE_NAME")
	private String fileName;
	@Column(name="FILE_DATA")
	private byte[] fileData;
	@Column(name="STATUS")
	private String status;
	@Column(name="CREATED_DATE")
	private Date createdDate;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getVoId() {
		return voId;
	}
	public void setVoId(String voId) {
		this.voId = voId;
	}
	public String getOrderActivityId() {
		return orderActivityId;
	}
	public void setOrderActivityId(String orderActivityId) {
		this.orderActivityId = orderActivityId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public byte[] getFileData() {
		return fileData;
	}
	public void setFileData(byte[] fileData) {
		this.fileData = fileData;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getSlOrderId() {
		return slOrderId;
	}
	public void setSlOrderId(String slOrderId) {
		this.slOrderId = slOrderId;
	}

}
