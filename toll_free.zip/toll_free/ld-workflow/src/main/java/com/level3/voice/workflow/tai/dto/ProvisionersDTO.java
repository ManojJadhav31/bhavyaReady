/**
 * @author arun2.kumar
 */
package com.level3.voice.workflow.tai.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author kumar.arun2
 *
 */
@Entity
@Table(name = "PROVISIONERS")
public class ProvisionersDTO {
	
	/** identifier field */
    @Id
    @Column(name = "PROVISIONER_NAME")
    private String provisionersName;
    
    @Column(name = "DESCRIPTION")
    private String description;
    
    @Column(name = "TYPE")
    private String type;
    
    @Column(name = "STATUS")
    private String status;
    
    @Column(name = "DAILY_SENDs")
    private int dailySends;
    
    @Column(name = "DAILY_RECEIVES")
    private int dailyReceives;

	public String getProvisionersName() {
		return provisionersName;
	}

	public void setProvisionersName(String provisionersName) {
		this.provisionersName = provisionersName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getDailySends() {
		return dailySends;
	}

	public void setDailySends(int dailySends) {
		this.dailySends = dailySends;
	}

	public int getDailyReceives() {
		return dailyReceives;
	}

	public void setDailyReceives(int dailyReceives) {
		this.dailyReceives = dailyReceives;
	}
    
   }
