package com.level3.voice.workflow.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;
/**
 * Database config to scan JPA repository and DTO  
 * 
 * @author <a href="mailto:Keerthi.Selvaraj@centurylink.com">Keerthi selvaraj
 *         </a>
 *
 */
@Configuration
@EnableJpaRepositories(basePackages= {"com.level3.voice.tollfree.persist.repository","com.level3.voice.workflow.tai.repository","com.level3.voice.workflow.repository",
		"com.level3.voice.persist.repository"})
@EnableTransactionManagement
@EntityScan(basePackages= {"com.level3.voice.tollfree.persist.dto","com.level3.voice.workflow.tai.dto","com.level3.voice.workflow.dto","com.level3.voice.persist.dto",
		"com.level3.voice.persist.dto"})
public class WorkflowDBConfig {

}
