package com.level3.voice.workflow.manager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.repository.TollfreeSlOrderRepository;


@Component
public class WorkflowServiceManager {
	@Autowired
	TollfreeSlOrderRepository tollfreeSlOrderRepository;
	@Transactional
	public void  updateLastUpdatedUser(String userName, Long slOrderId) {
		tollfreeSlOrderRepository.updateLastUpdatedUser(userName, slOrderId);
	}
}
