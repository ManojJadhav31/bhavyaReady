package com.level3.voice.workflow.utils;

public interface LDEmpPayloadIF {

}
