package com.level3.voice.workflow.activity;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.centurylink.voice.workflow.common.activity.ParentTransCoordActivity;
import com.level3.voice.common.util.OrderConstants;
import com.level3.voice.common.util.OrderStatusConstants;
import com.level3.voice.common.util.OrderTypeCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.AddressDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.ProductDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.SubscriberDTO;
import com.level3.voice.persist.dto.TnOrderDTO;
import com.level3.voice.persist.repository.ActionTypeRepository;
import com.level3.voice.persist.repository.AddressRepository;
import com.level3.voice.persist.repository.ProductRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.SubscriberRepository;
import com.level3.voice.persist.repository.TnOrderRepository;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.dto.TollFreeSubsciberLineDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderActivityRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeTNOrderRepository;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;

/**
 * Create Disconnect Orders for the customer A in a customer A to customer B
 * scenario
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component("createDisconnectOrderActivity")
public class CreateDisconnectOrderActivity extends ParentTransCoordActivity {
	private static final String YES = "Yes";

	private static final String SONUS = "SONUS";

	private static final String Y = "Y";

	private static final String N = "N";

	private static final String _SYSTEM = "System";

	private static String WF_COMPLETE_CUST_MOVE_SIGNAL_NAME = "WF_933_6_Activity_Complete";
	private static String WF_COMPLETE_CUST_MOVE_SIGNAL_ID = "WF_933_6_Activity_Signal";

	private static Log LOG = LogFactory.getLog(CreateDisconnectOrderActivity.class);

	@Autowired
	SlOrderRepository slOrderRepository;

	@Autowired
	TnOrderRepository tnOrderRepository;

	@Autowired
	ActionTypeRepository actionTypeRepository;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	@Autowired
	SubscriberRepository subscriberRepository;

	@Autowired
	ProductRepository productRepository;

	@Autowired
	AddressRepository addressRepository;

	@Autowired
	TollfreeTNOrderRepository tollfreeTNOrderRepository;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Autowired
	TollfreeOrderActivityRepository tollfreeOrderActivityRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {
		if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CANCELLED_STATE) {
			LOG.error("@CreateDisconnectOrderActivity: Cancelled skip processing the activity.");
			throw new BpmnError("Activity Cancelled, so stopped processing in Microservices.");
		}

		Long pon = slOrderDTO.getParentTransId();
		List<SlOrderDTO> slOrderDTOs = slOrderRepository.findActiveSlOrdersByParentTransId(pon);

		try {
			createDisconnectOrders(slOrderDTOs, slOrderDTO.getOrderDate());
			BigDecimal count = slOrderRepository.getSLOrderCountByPON(pon);

			if (count.intValue() == 1) {
				workflowUtils.completeWaitSignalByOrder(slOrderDTO.getSlOrderId(), WF_COMPLETE_CUST_MOVE_SIGNAL_NAME,
						WF_COMPLETE_CUST_MOVE_SIGNAL_ID);
			} else {
				workflowUtils.completeWaitSignalByPON(pon, WF_COMPLETE_CUST_MOVE_SIGNAL_NAME,
						WF_COMPLETE_CUST_MOVE_SIGNAL_ID);
			}

			tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_COMPLETED_STATE, new Date(),
					"Completed by Microservices Activity.", OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(),
					orderActivityDTO.getActivityId(), orderActivityDTO.getActivityTypeId());
		} catch (Exception e) {
			LOG.error("Error from CreateDisconnectOrderActivity ", e);
			String comments = "Unable to create disconnect orders for customer move for pon: " + pon;
			tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_ERROR_STATE, new Date(),
					comments, OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
					orderActivityDTO.getActivityTypeId());
			return;
		}
	}

	@Transactional
	private void createDisconnectOrders(List<SlOrderDTO> slOrderDTOs, Date custBInstallOrderDate) {
		for (SlOrderDTO slOrderDTO : slOrderDTOs) {
			String tn = orderTollFreeFeatureRepository.getTn(slOrderDTO.getSlOrderId());
			OrderTollFreeFeatureDTO oldCustOrderTollfree = orderTollFreeFeatureRepository
					.getPrevCustActiveOrderTollFreeFeatures(tn);
			TnOrderDTO tnOrderDTO = tollfreeTNOrderRepository.getTnBySlorderId(oldCustOrderTollfree.getSlOrderId());
			SlOrderDTO oldCustSlOrder = slOrderRepository.findOne(oldCustOrderTollfree.getSlOrderId());
			TollFreeSubsciberLineDTO tollFreeSubsciberLineDTO = tollFreeSubsciberLineRepository
					.findOne(tnOrderDTO.getTollfreeSubscriberLineId());
			tollFreeSubsciberLineDTO.setActiveYn(N);
			tollFreeSubsciberLineRepository.save(tollFreeSubsciberLineDTO);
			Date sysdate = new Date();
			SubscriberDTO subscriberDTO = subscriberRepository.findOne(tollFreeSubsciberLineDTO.getSubscriberId());
			ProductDTO productDTO = productRepository.findOne(tollFreeSubsciberLineDTO.getProductId());
			AddressDTO addressDTO = addressRepository.findOne(tollFreeSubsciberLineDTO.getServiceAddressId());

			TnOrderDTO tnOrder = assembleTNOrder(sysdate, subscriberDTO, productDTO, tollFreeSubsciberLineDTO,
					addressDTO, slOrderDTO.getVoiceOrderId(), oldCustSlOrder, custBInstallOrderDate);
			updateSlOrderVersion(tnOrder.getSlOrder(), tn, oldCustSlOrder.getExternalCustomerId());
			populatePreviousOrderTollfreeFeature(sysdate, tnOrder.getSlOrder(), oldCustOrderTollfree);
		}
	}

	private void updateSlOrderVersion(SlOrderDTO slOrder, String tn, String customerID) {
		int currentVersionCount = orderTollFreeFeatureRepository.getVersionCount(tn, customerID);
		slOrder.setOrderVersion(currentVersionCount + 1);
	}

	/**
	 * Create TN order and persist the same with user selected data
	 * 
	 * @param orderVO
	 * @param sysdate
	 * @param ponInfo
	 * @param sub
	 * @param product
	 * @param tollFreeSubsciberLineDTO
	 * @param voiceOrderId
	 * @param custBInstallOrderDate
	 * @param gVO
	 * @return
	 */
	public TnOrderDTO assembleTNOrder(Date sysdate, SubscriberDTO sub, ProductDTO product,
			TollFreeSubsciberLineDTO tollFreeSubsciberLineDTO, AddressDTO address, Long voiceOrderId,
			SlOrderDTO oldCustSlOrder, Date custBInstallOrderDate) {
		TnOrderDTO tnOrderDTO = new TnOrderDTO();
		tnOrderDTO.setSlOrder(new SlOrderDTO());

		updatePrevSlOrder(oldCustSlOrder);

		assembleSlOrder(sysdate, tnOrderDTO, voiceOrderId, oldCustSlOrder, custBInstallOrderDate);

		tnOrderDTO.setTollfreeSubscriberLineId(tollFreeSubsciberLineDTO.getSubscriberLineId());
		tnOrderDTO.setInternalPortYn(N);
		tnOrderDTO.setServiceTransferYn(Y);
		tnOrderDTO.setSwitchType(SONUS);
		tnOrderDTO.setLnpLctDipYn(N);
		tnOrderDTO.setLsrServiceAddress(address);
		tnOrderDTO.setAddress(address);
		tnOrderDTO.setSubscriberSiteId(8059576860L);
		tnOrderDTO.setProduct(product);
		tnOrderDTO.setSubscriber(sub);
		tnOrderDTO.setMigrationYn(Y);
		tnOrderDTO.setLastUpdated(sysdate);
		tnOrderDTO = tnOrderRepository.save(tnOrderDTO);
		return tnOrderDTO;
	}

	private void updatePrevSlOrder(SlOrderDTO slOrderDTO) {
		slOrderDTO.setOrderActiveYn(N);
		slOrderRepository.saveAndFlush(slOrderDTO);
	}

	private SlOrderDTO assembleSlOrder(Date sysdate, TnOrderDTO tnOrderDTO, Long voiceOrderId,
			SlOrderDTO oldCustSlOrder, Date custBInstallOrderDate) {
		Long parentTransId = orderTollFreeFeatureRepository.getParentTxId();

		SlOrderDTO slOrder = tnOrderDTO.getSlOrder();
		slOrder.setExpediteYn(N);
		slOrder.setSlOrderType("AN");
		slOrder.setActionTypeId(3);
		slOrder.setOrderStatusId(new Integer(OrderStatusConstants.ORDER_STATUS_COMPLETE));
		slOrder.setOrderActiveYn(N);
		Calendar cal = Calendar.getInstance();
		cal.setTime(custBInstallOrderDate);
		cal.add(Calendar.MINUTE, -1);
		slOrder.setOrderDate(cal.getTime());
		slOrder.setCreateUser(_SYSTEM);
		slOrder.setLastUpdatedUser(_SYSTEM);
		slOrder.setLastUpdated(sysdate);
		slOrder.setDisconnectDate(sysdate);
		slOrder.setOrderCompleteDate(sysdate);
		slOrder.setCustomerBizOrgId(oldCustSlOrder.getCustomerBizOrgId());
		slOrder.setMasterBizOrgId(oldCustSlOrder.getMasterBizOrgId());
		slOrder.setCustomerBizOrgName(oldCustSlOrder.getCustomerBizOrgName());
		slOrder.setSuppAllowedFlag(OrderConstants.SUPP_ALLOWED_NONE);
		slOrder.setSaUrgentYn(N);
		slOrder.setOrderTypeId(1);
		slOrder.setOrderSourceId(18);

		slOrder.setParentTransId(parentTransId);
		slOrder.setExternalCustomerId(oldCustSlOrder.getExternalCustomerId());
		slOrder.setVoiceOrderId(voiceOrderId);
		slOrder.setDisconnectDate(sysdate);
		slOrderRepository.save(slOrder);
		return slOrder;
	}

	/**
	 * Retrieve previous latest Change or install features and use the same for the
	 * current unblock scenario
	 * 
	 * @param orderVO
	 * @param slOrder
	 * @param gVO
	 * @param sysdate
	 * @param oldCustOrderTollfree
	 * 
	 */
	private void populatePreviousOrderTollfreeFeature(Date sysdate, SlOrderDTO slOrder,
			OrderTollFreeFeatureDTO prevFeaturesDTO) {

		OrderTollFreeFeatureDTO orderTollFreeFeatureDTO = new OrderTollFreeFeatureDTO();
		orderTollFreeFeatureDTO.setTn(prevFeaturesDTO.getTn());
		orderTollFreeFeatureDTO.setBtn(prevFeaturesDTO.getBtn());
		orderTollFreeFeatureDTO.setCic(prevFeaturesDTO.getCic());
		orderTollFreeFeatureDTO.setForcedANI(prevFeaturesDTO.getForcedANI());
		orderTollFreeFeatureDTO.setJurisdiction(prevFeaturesDTO.getJurisdiction());
		orderTollFreeFeatureDTO.setPicRequest(prevFeaturesDTO.getPicRequest());
		orderTollFreeFeatureDTO.setStartDate(sysdate);
		orderTollFreeFeatureDTO.setSlOrderId(slOrder.getSlOrderId());
		orderTollFreeFeatureDTO.setLastUpdatedUser(_SYSTEM);
		orderTollFreeFeatureDTO.setLastUpdated(sysdate);
		orderTollFreeFeatureDTO.setAccountNumber(prevFeaturesDTO.getAccountNumber());
		orderTollFreeFeatureDTO.setControlGroupId(prevFeaturesDTO.getControlGroupId());
		orderTollFreeFeatureDTO.setServiceAddressId(prevFeaturesDTO.getServiceAddressId());
		orderTollFreeFeatureDTO.setRatePlan(prevFeaturesDTO.getRatePlan());
		orderTollFreeFeatureDTO.setScId(prevFeaturesDTO.getScId());
		orderTollFreeFeatureDTO.setBillingAccNum(prevFeaturesDTO.getBillingAccNum());
		orderTollFreeFeatureDTO.setCrc(prevFeaturesDTO.getCrc());
		orderTollFreeFeatureDTO.setProductOfferingID(prevFeaturesDTO.getProductOfferingID());
		orderTollFreeFeatureDTO.setJiLoad(YES);
		orderTollFreeFeatureDTO.setOcn(prevFeaturesDTO.getOcn());
		orderTollFreeFeatureDTO.setLecProvisionerName(prevFeaturesDTO.getLecProvisionerName());
		orderTollFreeFeatureDTO.setServiceID(prevFeaturesDTO.getServiceID());
		setOrderTollFreeFeatures(orderTollFreeFeatureDTO, prevFeaturesDTO);
		orderTollFreeFeatureRepository.saveAndFlush(orderTollFreeFeatureDTO);
	}

	/**
	 * Set feature information against the created order tollfree feature object
	 * which user has selected
	 * 
	 * @param gVO
	 * @param newOrderTollfreeFeatures
	 */
	private void setOrderTollFreeFeatures(OrderTollFreeFeatureDTO newOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO prevOrderTollfreeFeatures) {
		newOrderTollfreeFeatures.setUnvalidatedAC(prevOrderTollfreeFeatures.getUnvalidatedAC());
		newOrderTollfreeFeatures.setValidatedAC(prevOrderTollfreeFeatures.getValidatedAC());
		newOrderTollfreeFeatures.setBlockCaribInter(prevOrderTollfreeFeatures.getBlockCaribInter());
		newOrderTollfreeFeatures.setBlockFraudCaribInter(prevOrderTollfreeFeatures.getBlockFraudCaribInter());
		newOrderTollfreeFeatures.setBlockAll(prevOrderTollfreeFeatures.getBlockAll());
		newOrderTollfreeFeatures.setBlockFraudAll(prevOrderTollfreeFeatures.getBlockFraudAll());
		newOrderTollfreeFeatures.setAcTableName(prevOrderTollfreeFeatures.getAcTableName());
		newOrderTollfreeFeatures.setAcDigits(prevOrderTollfreeFeatures.getAcDigits());
		newOrderTollfreeFeatures.setAccountCodeEsf(prevOrderTollfreeFeatures.getAccountCodeEsf());
		newOrderTollfreeFeatures.setAcTableId(prevOrderTollfreeFeatures.getAcTableId());
	}

}
