package com.level3.voice.workflow.utils;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Arun2.kumar@level3.com
 *
 */
@XmlRootElement(name = "request")
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class EFSPayload implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ServiceOrder serviceOrder;
	/**
	 * @return the serviceOrder
	 */
	public ServiceOrder getServiceOrder() {
		return serviceOrder;
	}
	/**
	 * @param serviceOrder the serviceOrder to set
	 */
	public void setServiceOrder(ServiceOrder serviceOrder) {
		this.serviceOrder = serviceOrder;
	}
}
