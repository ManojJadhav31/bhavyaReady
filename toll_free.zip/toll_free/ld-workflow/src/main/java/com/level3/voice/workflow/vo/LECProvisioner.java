package com.level3.voice.workflow.vo;

import java.io.Serializable;

public class LECProvisioner implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ocnaBbr;
	private String picDetail;
	private String picHeader;
	private String picTrailer;
	private String crlfFlag;
	private String apid;
	private String picVersion;
	private String rao;
	public String getOcnaBbr() {
		return ocnaBbr;
	}
	public void setOcnaBbr(String ocnaBbr) {
		this.ocnaBbr = ocnaBbr;
	}
	public String getPicDetail() {
		return picDetail;
	}
	public void setPicDetail(String picDetail) {
		this.picDetail = picDetail;
	}
	public String getPicHeader() {
		return picHeader;
	}
	public void setPicHeader(String picHeader) {
		this.picHeader = picHeader;
	}
	public String getPicTrailer() {
		return picTrailer;
	}
	public void setPicTrailer(String picTrailer) {
		this.picTrailer = picTrailer;
	}
	public String getCrlfFlag() {
		return crlfFlag;
	}
	public void setCrlfFlag(String crlfFlag) {
		this.crlfFlag = crlfFlag;
	}
	public String getApid() {
		return apid;
	}
	public void setApid(String apid) {
		this.apid = apid;
	}
	public String getPicVersion() {
		return picVersion;
	}
	public void setPicVersion(String picVersion) {
		this.picVersion = picVersion;
	}
	public String getRao() {
		return rao;
	}
	public void setRao(String rao) {
		this.rao = rao;
	}
	
}
