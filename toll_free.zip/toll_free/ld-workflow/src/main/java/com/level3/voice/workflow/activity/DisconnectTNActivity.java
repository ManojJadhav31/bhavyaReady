package com.level3.voice.workflow.activity;

import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;

@Component("disconnectTNActivity")
public class DisconnectTNActivity extends WorkflowBaseActivity {

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {
		// TODO Auto-generated method stub
		orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_COMPLETED_STATE);
	}

}
