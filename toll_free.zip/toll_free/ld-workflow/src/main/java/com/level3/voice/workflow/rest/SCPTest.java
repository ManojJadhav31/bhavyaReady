package com.level3.voice.workflow.rest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Security;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.optional.ssh.Scp;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

@RestController
@RequestMapping("/ServiceDelivery/v1/Voice/order")
public class SCPTest {

	@RequestMapping(value = "/scpTest", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public String scpTest() {
		String localFile = "request.wca";
		String srvrSSH = "ndm1.prod.idc1.level3.com";
		String userSSH = "cduser";
		// String pswdSSH = new String ("password");
		String remoteDir = ".";

		String response = "";
		try {
			FileOutputStream fileOut = new FileOutputStream("request.wca");
			fileOut.write("Just a test file".getBytes());
			fileOut.close();

			response = "The Object was succesfully written to a file";

			Scp scp = new Scp();
			int portSSH = 22;

			scp.setPort(portSSH);
			scp.setLocalFile(localFile);
			scp.setKeyfile("/app/envuser/.ssh/id_rsa");
			//scp.setKeyfile("C:\\Users\\ab68221\\Desktop\\config\\config\\.ssh\\id_rsa");
			scp.setTodir(userSSH + "@" + srvrSSH + ":" + remoteDir);
			scp.setProject(new Project());
			scp.setTrust(true);
			Security.insertProviderAt(new BouncyCastleProvider(), 1);
			scp.execute();

		} catch (Exception ex) {
			ex.printStackTrace();
			response = response + ex.getStackTrace();
		}

		response = response + "File copied to " + userSSH + "@" + srvrSSH + ":" + remoteDir;
		return response;
	}

	@RequestMapping(value = "/scpTestJsch", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	public String scpTestJsch() {

		String response = "";
		try {
			FileOutputStream fileOut = new FileOutputStream("request.wca");
			fileOut.write("Just a test file".getBytes());
			fileOut.close();

			response = "The Object was succesfully written to a file";

			JSch jsch = new JSch();
			Session session = null;
			session = jsch.getSession("cduser", "ndm1.prod.idc1.level3.com", 22);
			jsch.addIdentity("/app/envuser/.ssh/id_rsa");
			//session.setPassword("password");
			Security.insertProviderAt(new BouncyCastleProvider(), 1);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setConfig(
				    "PreferredAuthentications", 
				    "publickey,keyboard-interactive,password");
			session.connect();
			ChannelSftp channel = null;
			channel = (ChannelSftp) session.openChannel("sftp");
			channel.connect();
			// File localFile = new File("response");
			// If you want you can change the directory using the following line.
			// channel.cd(RemoteDirectoryPath)
			try {
				channel.put(new FileInputStream("request.wca"), "response");
			} catch (FileNotFoundException | SftpException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				response = response + e.getStackTrace();
			}
			channel.disconnect();
			session.disconnect();
		} catch (JSchException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			response = response + e.getStackTrace();
		}

		response = response + "File (request.wca) copied to home dir";
		return response;

	}
}
