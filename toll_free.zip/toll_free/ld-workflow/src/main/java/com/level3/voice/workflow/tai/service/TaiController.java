package com.level3.voice.workflow.tai.service;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.persist.dto.LECProvisionerDTO;
import com.level3.voice.workflow.tai.dto.CarrierDTO;
import com.level3.voice.workflow.tai.dto.ProvisionersDTO;
import com.level3.voice.workflow.tai.manager.TaiDataManager;

/**
 * Rest service to retrieve Carrier/Provisioner details based on Name or CIC 
 * 
 * 
 * @author <Arun2.kumar@level3.com>
 *
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/Voice/tai")
public class TaiController {
	
	private static final Logger LOG = Logger.getLogger(TaiController.class);

	@Autowired
	private TaiDataManager taiManager;
	
	/**
	 * Method is to retrieve Carrier Data based on the CIC
	 * 
	 * @param cic
	 * @return
	 */
	
	@RequestMapping(path = "/carrier/{cic}", method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    @Audited
	public CarrierDTO getCarrierByCic(@PathVariable String cic) {
		CarrierDTO carrier = null;
		try {
			carrier = taiManager.getDetailsByCIC(cic); 
		} catch (Exception e) {
			LOG.error("Exception processing getCarrierByCic", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return carrier;
	}
	
	/**
	 * Method is to retrieve All Carrier Data 
	 * 
	 *
	 * @return
	 */
	
	@RequestMapping(path = "/carrier", method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    @Audited
	public List<CarrierDTO> findAllCarrier() {
		List<CarrierDTO> carrier = null;
		try {
			carrier = taiManager.getAllCIC(); 
		} catch (Exception e) {
			LOG.error("Exception processing findAllCarrier", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return carrier;
	}
	
	/**
	 * Method is to retrieve Provisioner Data based on the Name
	 * 
	 * @param Provisioner Name
	 * @return
	 */
	@RequestMapping(path = "/provisioners/{provisionerName}", method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    @Audited
	public ProvisionersDTO findProvisionerByName(@PathVariable String provisionerName) {
		ProvisionersDTO provisioner = null;
		try {
			provisioner = taiManager.getProvisionerByName(provisionerName); 
		} catch (Exception e) {
			LOG.error("Exception processing findProvisionerByName", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return provisioner;
	}
	
	/**
	 * Method is to retrieve All  Provisioner Data 
	 * 
	 *
	 * @return
	 */
	
	@RequestMapping(path = "/provisioners", method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    @Audited
	public List<ProvisionersDTO> findAllProvisioners() {
		List<ProvisionersDTO> provisioners = null;
		try {
			provisioners = taiManager.getAllProvisioners(); 
		} catch (Exception e) {
			LOG.error("Exception processing findAllProvisioners", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return provisioners;
	}
	
	/**
	 * Method is to retrieve All LEC Provisioner Data 
	 * 
	 *
	 * @return
	 */

	@RequestMapping(path = "/lecprovisioners", method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    @Audited
	public List<LECProvisionerDTO> findAllLecProvisioners() {
		List<LECProvisionerDTO> provisioners = null;
		try {
			provisioners = taiManager.getAllLecProvisioners(); 
		} catch (Exception e) {
			LOG.error("Exception processing findAllLecProvisioners", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return provisioners;
	}
	
	/**
	 * Method is to retrieve LEC Provisioner Data based on the Name and CIC
	 * 
	 * @param Provisioner Name and CIC
	 * @return
	 */
	@RequestMapping(path = "/lecprovisioners/{provisionerName}/{ocn}", method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    @Audited
	public LECProvisionerDTO findProvisionerByName(@PathVariable String provisionerName,
													@PathVariable String ocn) {
		LECProvisionerDTO provisioner = null;
		try {
			provisioner = taiManager.getLecProvisionerByLecOcn(provisionerName,ocn); 
		} catch (Exception e) {
			LOG.error("Exception processing findProvisionerByName", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return provisioner;
	}
}
