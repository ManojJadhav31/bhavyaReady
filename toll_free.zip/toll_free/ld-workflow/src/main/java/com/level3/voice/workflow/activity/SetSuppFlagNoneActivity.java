package com.level3.voice.workflow.activity;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.OrderConstants;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.repository.SlOrderRepository;

/**
 * Created by dadi.sudhir on 10/2/2017.
 */
@Component("setSuppFlagNoneActivity")
public class SetSuppFlagNoneActivity extends WorkflowBaseActivity {
	private static Logger LOG = Logger.getLogger(SetSuppFlagNoneActivity.class);

	@Autowired
	SlOrderRepository slOrderRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		LOG.info("Executing [" + SetSuppFlagNoneActivity.class.getName() + "] with PK="
				+ orderActivityDTO.getOrderActivityPk() + " slOrderID= " + slOrderDTO.getSlOrderId());
		if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CANCELLED_STATE) {
			// If cancelled then skip processing the activity.
			throw new BpmnError("Activity Cancelled, so stopped processing in Microservices.");
		}
		try {
			if (!OrderConstants.SUPP_ALLOWED_NONE.equalsIgnoreCase(slOrderDTO.getSuppAllowedFlag())) {
				slOrderDTO.setSuppAllowedFlag(OrderConstants.SUPP_ALLOWED_NONE);
				slOrderDTO = slOrderRepository.saveAndFlush(slOrderDTO);
			}

			completeActivity(orderActivityDTO, null);
		} catch (Exception ex) {
			throw new SLDBException("SetSuppFlagNoneActivity failed for order Id : " + slOrderDTO.getSlOrderId()
					+ " order activity pk = " + orderActivityDTO.getOrderActivityPk() + " error :" + ex.getMessage(),
					ex);
		}
	}

}
