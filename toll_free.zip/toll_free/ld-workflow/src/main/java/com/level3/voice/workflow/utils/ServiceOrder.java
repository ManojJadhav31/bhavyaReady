package com.level3.voice.workflow.utils;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "serviceOrder")
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class ServiceOrder {

	private String ani;
	private String attrNames;
	private String accountCodeSetType;
	private String accountCodeLength;
	/**
	 * @return the ani
	 */
	public String getAni() {
		return ani;
	}
	/**
	 * @param ani the ani to set
	 */
	public void setAni(String ani) {
		this.ani = ani;
	}
	/**
	 * @return the attrNames
	 */
	public String getAttrNames() {
		return attrNames;
	}
	/**
	 * @param attrNames the attrNames to set
	 */
	public void setAttrNames(String attrNames) {
		this.attrNames = attrNames;
	}
	/**
	 * @return the accountCodeSetType
	 */
	public String getAccountCodeSetType() {
		return accountCodeSetType;
	}
	/**
	 * @param accountCodeSetType the accountCodeSetType to set
	 */
	public void setAccountCodeSetType(String accountCodeSetType) {
		this.accountCodeSetType = accountCodeSetType;
	}
	/**
	 * @return the accountCodeLength
	 */
	public String getAccountCodeLength() {
		return accountCodeLength;
	}
	/**
	 * @param accountCodeLength the accountCodeLength to set
	 */
	public void setAccountCodeLength(String accountCodeLength) {
		this.accountCodeLength = accountCodeLength;
	}
}
