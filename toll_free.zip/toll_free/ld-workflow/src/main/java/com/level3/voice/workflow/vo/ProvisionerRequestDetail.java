/**
 * 
 */
package com.level3.voice.workflow.vo;

import java.io.Serializable;

import com.level3.voice.common.util.StringUtils;

/**The class is to write detail row in LEC request file. <b>DO NOT ALTER</b> unless there is a change in the request file template
 * @author ab68221 - D, Manjunatha
 *
 */
public class ProvisionerRequestDetail implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String tc;
	private String si;
	private String oldCIC;
	private String reserve0;
	private String customerCode;
	private String wtn;
	private String hml;
	private String terminal;
	private String lOAorProcessDate;
	private String customerType;
	private String reserve1;
	private String billNameInd;
	private String billName1;
	private String billName2;
	private String billName3;
	private String billAddress1;
	private String billAddress2;
	private String billAddress3;
	private String addressFlag;
	private String city;
	private String state;
	private String zipCode;
	private String reserve2;
	private String iCRefNumber;
	private String iCOrderNumber;
	private String lECOrderNumber;
	private String langInd;
	private String originalTC;
	private String originalSI;
	private String reserve3;
	private String politicalAcctInd;
	private String reserve4;
	private String jurisdiction;
	private String dialingInd;
	private String pICChargeInd;
	private String reserve5;
	private String desiredDueDate;
	private String earliestMsgDate;
	private String latestMsgDate;
	private String cic;
	private String reserve6;
	private String switchlessInd;
	private String reserve7;
	private String bTNEdit;
	private String reserve8;
	private String msgTypeInd;
	private String previousCIC;
	private String reserve9;
	private String localServiceProvID;
	private String reserve10;
	private String lECLineType;
	private String lECLineDate;
	private String reserve11;
	
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getOldCIC() {
		return oldCIC;
	}
	public void setOldCIC(String oldCIC) {
		this.oldCIC = oldCIC;
	}
	public String getReserve0() {
		return reserve0;
	}
	public void setReserve0(String reserve0) {
		this.reserve0 = reserve0;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getWtn() {
		return wtn;
	}
	public void setWtn(String wtn) {
		this.wtn = wtn;
	}
	public String getHml() {
		return hml;
	}
	public void setHml(String hml) {
		this.hml = hml;
	}
	public String getTerminal() {
		return terminal;
	}
	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}
	public String getlOAorProcessDate() {
		return lOAorProcessDate;
	}
	public void setlOAorProcessDate(String lOAorProcessDate) {
		this.lOAorProcessDate = lOAorProcessDate;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getReserve1() {
		return reserve1;
	}
	public void setReserve1(String reserve1) {
		this.reserve1 = reserve1;
	}
	public String getBillNameInd() {
		return billNameInd;
	}
	public void setBillNameInd(String billNameInd) {
		this.billNameInd = billNameInd;
	}
	public String getBillName1() {
		return billName1;
	}
	public void setBillName1(String billName1) {
		this.billName1 = billName1;
	}
	public String getBillName2() {
		return billName2;
	}
	public void setBillName2(String billName2) {
		this.billName2 = billName2;
	}
	public String getBillName3() {
		return billName3;
	}
	public void setBillName3(String billName3) {
		this.billName3 = billName3;
	}
	public String getBillAddress1() {
		return billAddress1;
	}
	public void setBillAddress1(String billAddress1) {
		this.billAddress1 = billAddress1;
	}
	public String getBillAddress2() {
		return billAddress2;
	}
	public void setBillAddress2(String billAddress2) {
		this.billAddress2 = billAddress2;
	}
	public String getBillAddress3() {
		return billAddress3;
	}
	public void setBillAddress3(String billAddress3) {
		this.billAddress3 = billAddress3;
	}
	public String getAddressFlag() {
		return addressFlag;
	}
	public void setAddressFlag(String addressFlag) {
		this.addressFlag = addressFlag;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getReserve2() {
		return reserve2;
	}
	public void setReserve2(String reserve2) {
		this.reserve2 = reserve2;
	}
	public String getiCRefNumber() {
		return iCRefNumber;
	}
	public void setiCRefNumber(String iCRefNumber) {
		this.iCRefNumber = iCRefNumber;
	}
	public String getiCOrderNumber() {
		return iCOrderNumber;
	}
	public void setiCOrderNumber(String iCOrderNumber) {
		this.iCOrderNumber = iCOrderNumber;
	}
	public String getlECOrderNumber() {
		return lECOrderNumber;
	}
	public void setlECOrderNumber(String lECOrderNumber) {
		this.lECOrderNumber = lECOrderNumber;
	}
	public String getLangInd() {
		return langInd;
	}
	public void setLangInd(String langInd) {
		this.langInd = langInd;
	}
	public String getOriginalTC() {
		return originalTC;
	}
	public void setOriginalTC(String originalTC) {
		this.originalTC = originalTC;
	}
	public String getOriginalSI() {
		return originalSI;
	}
	public void setOriginalSI(String originalSI) {
		this.originalSI = originalSI;
	}
	public String getReserve3() {
		return reserve3;
	}
	public void setReserve3(String reserve3) {
		this.reserve3 = reserve3;
	}
	public String getPoliticalAcctInd() {
		return politicalAcctInd;
	}
	public void setPoliticalAcctInd(String politicalAcctInd) {
		this.politicalAcctInd = politicalAcctInd;
	}
	public String getReserve4() {
		return reserve4;
	}
	public void setReserve4(String reserve4) {
		this.reserve4 = reserve4;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getDialingInd() {
		return dialingInd;
	}
	public void setDialingInd(String dialingInd) {
		this.dialingInd = dialingInd;
	}
	public String getpICChargeInd() {
		return pICChargeInd;
	}
	public void setpICChargeInd(String pICChargeInd) {
		this.pICChargeInd = pICChargeInd;
	}
	public String getReserve5() {
		return reserve5;
	}
	public void setReserve5(String reserve5) {
		this.reserve5 = reserve5;
	}
	public String getDesiredDueDate() {
		return desiredDueDate;
	}
	public void setDesiredDueDate(String desiredDueDate) {
		this.desiredDueDate = desiredDueDate;
	}
	public String getEarliestMsgDate() {
		return earliestMsgDate;
	}
	public void setEarliestMsgDate(String earliestMsgDate) {
		this.earliestMsgDate = earliestMsgDate;
	}
	public String getLatestMsgDate() {
		return latestMsgDate;
	}
	public void setLatestMsgDate(String latestMsgDate) {
		this.latestMsgDate = latestMsgDate;
	}
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public String getReserve6() {
		return reserve6;
	}
	public void setReserve6(String reserve6) {
		this.reserve6 = reserve6;
	}
	public String getSwitchlessInd() {
		return switchlessInd;
	}
	public void setSwitchlessInd(String switchlessInd) {
		this.switchlessInd = switchlessInd;
	}
	public String getReserve7() {
		return reserve7;
	}
	public void setReserve7(String reserve7) {
		this.reserve7 = reserve7;
	}
	public String getbTNEdit() {
		return bTNEdit;
	}
	public void setbTNEdit(String bTNEdit) {
		this.bTNEdit = bTNEdit;
	}
	public String getReserve8() {
		return reserve8;
	}
	public void setReserve8(String reserve8) {
		this.reserve8 = reserve8;
	}
	public String getMsgTypeInd() {
		return msgTypeInd;
	}
	public void setMsgTypeInd(String msgTypeInd) {
		this.msgTypeInd = msgTypeInd;
	}
	public String getPreviousCIC() {
		return previousCIC;
	}
	public void setPreviousCIC(String previousCIC) {
		this.previousCIC = previousCIC;
	}
	public String getReserve9() {
		return reserve9;
	}
	public void setReserve9(String reserve9) {
		this.reserve9 = reserve9;
	}
	public String getLocalServiceProvID() {
		return localServiceProvID;
	}
	public void setLocalServiceProvID(String localServiceProvID) {
		this.localServiceProvID = localServiceProvID;
	}
	public String getReserve10() {
		return reserve10;
	}
	public void setReserve10(String reserve10) {
		this.reserve10 = reserve10;
	}
	public String getlECLineType() {
		return lECLineType;
	}
	public void setlECLineType(String lECLineType) {
		this.lECLineType = lECLineType;
	}
	public String getlECLineDate() {
		return lECLineDate;
	}
	public void setlECLineDate(String lECLineDate) {
		this.lECLineDate = lECLineDate;
	}
	public String getReserve11() {
		return reserve11;
	}
	public void setReserve11(String reserve11) {
		this.reserve11 = reserve11;
	}

	@Override
	public String toString() {
		return  tc + si + oldCIC + reserve0
				+ customerCode + wtn + hml + terminal
				+ lOAorProcessDate + customerType + reserve1
				+ billNameInd + billName1 + billName2
				+ billName3 + billAddress1 + billAddress2
				+ billAddress3 + addressFlag + city 
				+ state + zipCode + reserve2 + iCRefNumber
				+ iCOrderNumber + lECOrderNumber + langInd
				+ originalTC + originalSI + reserve3
				+ politicalAcctInd + reserve4 + jurisdiction
				+ dialingInd + pICChargeInd + reserve5
				+ desiredDueDate + earliestMsgDate 
				+ latestMsgDate + cic + reserve6 + switchlessInd
				+ reserve7 + bTNEdit + reserve8
				+ msgTypeInd + previousCIC + reserve9 
				+ localServiceProvID + reserve10 + lECLineType 
				+ lECLineDate + reserve11 + "\n";
	}

	
}
