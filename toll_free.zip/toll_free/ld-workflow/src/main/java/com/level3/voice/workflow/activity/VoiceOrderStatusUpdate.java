/**
 * 
 */
package com.level3.voice.workflow.activity;

import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.OrderStatusConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.VoiceOrderDTO;
import com.level3.voice.persist.repository.OrderStatusRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.VoiceOrderRepository;


/**
 * This activity for updating the voice order status to completed if all activities are completed.
 * @author ab68221 - D, Manjunatha
 *
 */
@Component("voiceOrderStatusUpdate")
public class VoiceOrderStatusUpdate extends WorkflowBaseActivity {

	private static Log LOG = LogFactory.getLog(VoiceOrderStatusUpdate.class);
	
	@Autowired
	SlOrderRepository slOrderRepository;
	
	@Autowired
	VoiceOrderRepository voiceOrderRepository;
	
	@Autowired
	OrderStatusRepository orderStatusRepository;
	
	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {
		List<SlOrderDTO> slOrderList = slOrderRepository.findActiveSlOrdersByVoiceOrderId(slOrderDTO.getVoiceOrderId());
		
		boolean isAnyActivityNotCompleted = false;
		if(slOrderList.size() != 1) {
			for(SlOrderDTO slOrder : slOrderList) {
					if(!slOrder.getOrderStatusId().equals(OrderStatusConstants.ORDER_STATUS_COMPLETE)) {
						LOG.info("Found not completed activity :"+slOrder.getSlOrderId()+". Not updating the voice order status.");;
						isAnyActivityNotCompleted = true;
						break;
					}
					if(isAnyActivityNotCompleted) {
						break;
					}
				}
		}
		VoiceOrderDTO voiceOrderDTO = voiceOrderRepository.findOne(slOrderDTO.getVoiceOrderId());
		if(!isAnyActivityNotCompleted) {
			voiceOrderDTO.setOrderStatus(orderStatusRepository.findByName("Completed"));
		}
		voiceOrderDTO.setRequest("NA");
		voiceOrderRepository.saveAndFlush(voiceOrderDTO);
		completeActivity(orderActivityDTO, null);
	}

}
