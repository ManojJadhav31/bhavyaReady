package com.level3.voice.workflow.activity;

import java.sql.Timestamp;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.OrderStatusConstants;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.repository.SlOrderRepository;

/**
 * 
 */
@Component("orderCompleted")
public class OrderCompletedActivity extends WorkflowBaseActivity {

    private static Log LOG = LogFactory.getLog(OrderCompletedActivity.class);

    @Autowired
    SlOrderRepository slOrderRepository;

    @Override
    public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception{
    	if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CANCELLED_STATE) {
			// If cancelled then skip processing the activity.
			throw new BpmnError("Activity Cancelled, so stopped processing in Microservices.");
		}
        LOG.debug("Inside OrderCompletedActivity.act() ...");
        SlOrderDTO order =slOrderDTO;
        order.setOrderStatusId(new Integer(OrderStatusConstants.ORDER_STATUS_COMPLETE));
        order.setOrderCompleteDate(new Timestamp(System.currentTimeMillis()));
        slOrderDTO = slOrderRepository.saveAndFlush(slOrderDTO);
        LOG.debug("After Updating fields:SlOrder");

        orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_COMPLETED_STATE);
    }

}