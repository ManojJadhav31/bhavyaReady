package com.level3.voice.workflow.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.level3.voice.workflow.dto.LecProvisionerRequestDTO;

/**
 * This repository is for saving the all provisioner request files
 * @author ab68221 - D, Manjunatha
 *
 */
@Transactional
public interface LecProvisionerRequestRepository extends JpaRepository<LecProvisionerRequestDTO, Long> {

	@Query(value="from LecProvisionerRequestDTO where slOrderId=?")
	LecProvisionerRequestDTO getBySlOrderId(String slOrderId);

	
}