package com.level3.voice.workflow.activity;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.OrderActionCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;

/**
 * This activity is to check if there is a change in customer id for an ANI
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component("isCustomerChangeFlow")
public class IsCustomerChangeFlowActivity extends WorkflowBaseActivity {

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CANCELLED_STATE) {
			throw new BpmnError("Activity Cancelled, so stopped processing in Microservices.");
		}

		if (isCustomerMove(slOrderDTO.getSlOrderId(), slOrderDTO.getActionTypeId().intValue(),
				slOrderDTO.getExternalCustomerId())) {
			delegateExecution.setVariable(delegateExecution.getCurrentActivityId(), "T");
			orderActivityDTO.setConditionValue(WorkflowConstants.CONDITION_TRUE);
		} else {
			delegateExecution.setVariable(delegateExecution.getCurrentActivityId(), "F");
			orderActivityDTO.setConditionValue(WorkflowConstants.CONDITION_FALSE);
		}

		completeActivity(orderActivityDTO, null);
	}

	/**
	 * This method is to check for the customer move scenario
	 * 
	 * @param slOrderId
	 * @param actionType
	 * @param currentCustomerId
	 * @return
	 */
	private boolean isCustomerMove(Long slOrderId, int actionType, String currentCustomerId) {
		String tn = orderTollFreeFeatureRepository.getTn(slOrderId);
		String customerID = orderTollFreeFeatureRepository.getPrevCustActiveCustomerId(tn);

		return OrderActionCodes.INSTALL == actionType && !StringUtils.isEmpty(customerID)
				&& !customerID.equalsIgnoreCase(currentCustomerId);
	}
}