package com.level3.voice.workflow.configuration.consumer;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.level3.messaging.model.Message;
import com.level3.messaging.model.command.Command;
import com.level3.voice.client.emp.EmpMessageProcessor;
import com.level3.voice.client.emp.dto.EMPResponseData;
import com.level3.voice.common.util.OrderActionCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeTNOrderRepository;
import com.level3.voice.workflow.rest.WorkflowService;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;

/**
 * Response handler for the mediation call which takes care to complete or error
 * the activity based on the response returned for install, disco, change and
 * customer move
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class LDTriggerMediationResponseHandler extends LDWorkflowEMPResponseHandler implements EmpMessageProcessor {
	private static Log LOGGER = LogFactory.getLog(LDTriggerMediationResponseHandler.class);

	@Autowired
	protected WorkflowService workflowService;

	@Autowired
	protected TollfreeTNOrderRepository tollfreeTNOrderRepository;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;
	
	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;
	
	private static final String CUST_MOVE = "CUST-MOVE-";

	@Override
	public void processMessage(Message message) {
		Command responseVo = (Command) message;
		EMPResponseData empResponseData = null;
		try {

			empResponseData = preProcessResponseData((Command) message);
			extractResponseValues(message, empResponseData);
			LOGGER.info("Processing Trigger Mediation message " + ((Command) message).getCommandType() + " SL Order "
					+ empResponseData.getSlOrderId() + " " + message);
		} catch (Exception ex) {
			LOGGER.error("Error performing pre process", ex);
			String comments = "Error performing pre process " + ex.getMessage();
			tollfreeWorkflowUtils.handleError(empResponseData, comments);
		}

		if (isAcknowledged(responseVo, empResponseData)) {
			try {
				saveOrderCompletionDate(empResponseData.getSlOrderId(), responseVo.getCorrelationId());
				OrderActivityDTO orderActivityDTO = orderActivityRepository
						.findOne(empResponseData.getOrderActivityPK());
				workflowService.consumeEMPMessage(responseVo.getCorrelationId(),
						String.valueOf(orderActivityDTO.getActivityTypeId()), empResponseData.getSlOrderId(),
						empResponseData.getOrderActivityPK(), empResponseData.getSublCallQueueId());
			} catch (Exception e) {
				LOGGER.error("Error processing ACK on Correlation ID:" + responseVo.getCorrelationId()
						+ " SL Order:" + empResponseData.getSlOrderId(), e);
				String comments = "Error processing ACK on Correlation ID:" + responseVo.getCorrelationId()
						+ " SL Order:" + empResponseData.getSlOrderId() + " : Error Message : " + e.getMessage();
				tollfreeWorkflowUtils.handleError(empResponseData, comments);
			}
		} else {
			// Process the NACK
			try {
				processNonAcknowledgement(responseVo, empResponseData);
				StringBuffer detailErrorMsg = tollfreeWorkflowUtils.getDetailedErrorMessage(empResponseData);
				orderActivityRepository
				.updateOrderActivity(
						WorkflowConstants.ACTIVITY_ERROR_STATE, "Error processing request. "
								+ detailErrorMsg.toString() + ". Correlation ID: " + responseVo.getCorrelationId(),
						empResponseData.getOrderActivityPK());
			} catch (Exception e) {
				LOGGER.error("Error processing non ACK ", e);
				String comments = "Error processing non ACK " + e.getMessage();
				tollfreeWorkflowUtils.handleError(empResponseData, comments);
			}
		}
	}

	@Transactional
	private void saveOrderCompletionDate(String slOrderId, String correlationId) {
		SlOrderDTO slOrderDTO = slOrderRepository.findOne(Long.valueOf(slOrderId));
		if(correlationId.indexOf(CUST_MOVE) > -1) {
			String tn = orderTollFreeFeatureRepository.getTn(Long.valueOf(slOrderId));
			String discoSlOrderId = orderTollFreeFeatureRepository.getPrevDiscoSlOrderId(tn, String.valueOf(slOrderDTO.getVoiceOrderId()));
			slOrderDTO = slOrderRepository.findOne(Long.valueOf(discoSlOrderId));
		}
		
		Date sysDate = new Date();
		if (OrderActionCodes.DISCONNECT == slOrderDTO.getActionTypeId().intValue()) {
			tollfreeTNOrderRepository.updateSlOrderBillEndDate(slOrderDTO.getSlOrderId(), sysDate, sysDate);
		} else {
			tollfreeTNOrderRepository.updateSlOrderBillStartDate(slOrderDTO.getSlOrderId(), sysDate, sysDate);
		}
	}

	@Override
	public String getCommandType() {
		return "INSTALL_RESPONSE";
	}

}
