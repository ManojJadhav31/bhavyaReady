package com.level3.voice.workflow.activity;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.messaging.model.command.Command;
import com.level3.voice.client.emp.EmpPublishClient;
import com.level3.voice.client.emp.util.EmpUtil;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.OrderActionCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.repository.SublCallQueueRepository;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.workflow.emp.MessageType;
import com.level3.voice.workflow.rest.WorkflowService;
import com.level3.voice.workflow.utils.AccountCodeIndicator;
import com.level3.voice.workflow.utils.EFSPayload;
import com.level3.voice.workflow.utils.MessageUtils;
import com.level3.voice.workflow.utils.ServiceOrder;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;

@Component("provisionAccountCode")
public class ProvisionAccountCodeActivity extends WorkflowBaseActivity {

	private static Log LOG = LogFactory.getLog(ProvisionAccountCodeActivity.class);
	public static String PRODUCT_ID_BUSINESS_KEY_NAME = "partNumber";
	public static String COMMAND_TYPE_ADD = "ADD";
	public static String COMMAND_TYPE_MODIFY = "MODIFY";
	public static String COMMAND_TYPE_DELETE = "DELETE";
	public static String BUSINESS_KEY_ENTITY_PRODUCT = "Product";

	@Value("#{'${list.of.unvalidated.features}'.split(',')}")
	private List<String> unvalidatedFeatures;

	@Autowired
	EmpPublishClient empPublishClient;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	SublCallQueueRepository sublCallQueueRepository;

	@Autowired
	protected WorkflowService workflowService;

	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		OrderTollFreeFeatureDTO currOrderTollfreeFeatures = orderTollFreeFeatureRepository
				.findOne(slOrderDTO.getSlOrderId().longValue());

		OrderTollFreeFeatureDTO prevOrderTollfreeFeatures = orderTollFreeFeatureRepository
				.getPrevNonActiveOrderTollFreeFeatures(currOrderTollfreeFeatures.getTn(),
						slOrderDTO.getExternalCustomerId());

		Command empRequest = populateCommandRequest(MessageType.NPAL_EFS_LD_VOICE_ORDER_COMMAND,
				getCommandType(slOrderDTO, prevOrderTollfreeFeatures, currOrderTollfreeFeatures), slOrderDTO,
				orderActivityDTO, prevOrderTollfreeFeatures, currOrderTollfreeFeatures);

		publishToEFSEmp(slOrderDTO, orderActivityDTO, empRequest);
	}

	private String getCommandType(SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {

		if (isEFSCallRequiredForAdd(slOrderDTO, prevOrderTollfreeFeatures, currOrderTollfreeFeatures)) {
			return COMMAND_TYPE_ADD;
		} else if (OrderActionCodes.CHANGE == slOrderDTO.getActionTypeId().intValue()
				&& isEFSCallRequiredForChange(prevOrderTollfreeFeatures, currOrderTollfreeFeatures)) {
			return COMMAND_TYPE_MODIFY;
		} else if (OrderActionCodes.DISCONNECT == slOrderDTO.getActionTypeId().intValue()
				|| isEFSCallRequiredForRemoval(prevOrderTollfreeFeatures, currOrderTollfreeFeatures)) {
			return COMMAND_TYPE_DELETE;
		}
		return COMMAND_TYPE_ADD;
	}

	private boolean isEFSCallRequiredForAdd(SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {
		return (OrderActionCodes.INSTALL == slOrderDTO.getActionTypeId().intValue()
				&& ((currOrderTollfreeFeatures.getUnvalidatedAC() != null
						|| currOrderTollfreeFeatures.getValidatedAC() != null)))
				|| checkChange(prevOrderTollfreeFeatures, currOrderTollfreeFeatures);
	}

	private boolean checkChange(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {
		String prevUnVal = prevOrderTollfreeFeatures.getUnvalidatedAC();
		String curUnVal = currOrderTollfreeFeatures.getUnvalidatedAC();
		String prevVal = prevOrderTollfreeFeatures.getValidatedAC();
		String curVal = currOrderTollfreeFeatures.getValidatedAC();

		if (prevUnVal == null && prevVal == null && (curUnVal != null || curVal != null)) {
			return true;
		}

		return false;
	}

	private boolean isEFSCallRequiredForRemoval(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {

		if (prevOrderTollfreeFeatures == null) {
			return false;
		} else if (checkValueRemoved(prevOrderTollfreeFeatures.getUnvalidatedAC(),
				prevOrderTollfreeFeatures.getValidatedAC(), currOrderTollfreeFeatures.getUnvalidatedAC(),
				currOrderTollfreeFeatures.getValidatedAC())) {
			return true;
		}
		return false;
	}

	private boolean isEFSCallRequiredForChange(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {

		if (prevOrderTollfreeFeatures == null) {
			return false;
		} else if (checkValueChanged(prevOrderTollfreeFeatures.getUnvalidatedAC(),
				prevOrderTollfreeFeatures.getValidatedAC(), currOrderTollfreeFeatures.getUnvalidatedAC(),
				currOrderTollfreeFeatures.getValidatedAC())) {
			return true;
		} else if (checkMandatoryFlagChange(prevOrderTollfreeFeatures, currOrderTollfreeFeatures)) {
			return true;
		} else if ((prevOrderTollfreeFeatures.getValidatedAC() != null
				&& prevOrderTollfreeFeatures.getValidatedAC()
						.equalsIgnoreCase(currOrderTollfreeFeatures.getValidatedAC())
				&& (checkAccountCodes(prevOrderTollfreeFeatures, currOrderTollfreeFeatures)))) {
			return true;
		}

		return false;
	}

	private boolean checkMandatoryFlagChange(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {
		if (checkValueChanged(prevOrderTollfreeFeatures.getAccountCodeEsf(),
				currOrderTollfreeFeatures.getAccountCodeEsf())) {
			return true;
		}
		return false;
	}

	private boolean checkAccountCodes(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {
		if (checkValueChanged(prevOrderTollfreeFeatures.getAcDigits(), currOrderTollfreeFeatures.getAcDigits())
				|| checkValueChanged(prevOrderTollfreeFeatures.getAcTableName(),
						currOrderTollfreeFeatures.getAcTableName())) {
			return true;
		}
		return false;
	}

	private boolean checkValueRemoved(String value1, String value2, String value3, String value4) {
		if ((value1 != null || value2 != null) && (value3 == null && value4 == null)) {
			return true;
		}
		return false;
	}

	private boolean checkValueChanged(String value1, String value2, String value3, String value4) {

		if ((value1 != null && value2 == null) && (value3 == null && value4 != null)) {
			return true;
		} else if ((value1 == null && value2 != null) && (value3 != null && value4 == null)) {
			return true;
		}

		return checkValueChanged(value1, value3) || checkValueChanged(value2, value4);
	}

	private boolean checkValueChanged(String value1, String value2) {
		return value1 != null && value2 != null && (!value1.equalsIgnoreCase(value2));
	}

	/**
	 * Publish command request derived for the ANI to EMP
	 * 
	 * @param slOrderDTO
	 * @param orderActivityDTO
	 * @param empRequest
	 * @throws SLDBException
	 */
	private void publishToEFSEmp(SlOrderDTO slOrderDTO, OrderActivityDTO orderActivityDTO, Command empRequest)
			throws SLDBException {

		try {
			String correlationId = super.storeAsyncResponseMapping(EmpPublishClient.ASYNC_MSG_ACTION, orderActivityDTO,
					"EFS Provisioning");
			empRequest.setCorrelationId(correlationId);

			empPublishClient.publishMessage(correlationId, String.valueOf(slOrderDTO.getVoiceOrderId()), empRequest,
					orderActivityDTO.getOrderActivityPk());
			orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE);

		} catch (Exception e) {
			LOG.error("Error sending TN command to NPAL EMP from activateTNonEFSActivity ", e);

			String comments = "Error sending TN command to NPAL EMP from activateTNonEFSActivity " + e.getMessage();
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			throw new SLDBException(e);
		}
	}

	/**
	 * Method to create the command request for the usage processing call
	 * 
	 * @param messageType
	 * @param commandType
	 * @param slOrder
	 * @param orderActivityDTO
	 * @param orderTollFree
	 * @param currOrderTollfreeFeatures
	 * @param slOrderDTOs
	 * @return
	 * @throws Exception
	 */
	private Command populateCommandRequest(MessageType messageType, String commandType, SlOrderDTO slOrder,
			OrderActivityDTO orderActivityDTO, OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) throws Exception {
		Command command = new Command();

		EFSPayload efsPayLoad = new EFSPayload();

		String commandId = String.valueOf(orderActivityDTO.getOrderActivityPk().toString());
		command.setCommandId(commandId);
		command.setCommandType(commandType);
		command.setMessageType(messageType.getMessageTypeName());
		command.setMessageSource("3FLOW");
		command.setEventTimestamp(new Date());
		command.setBusinessKeys(new Command.BusinessKeys());

		OrderTollFreeFeatureDTO orderTollFree = getOrderTollFree(command.getCommandType(), prevOrderTollfreeFeatures,
				currOrderTollfreeFeatures);

		Command.BusinessKeys.BusinessKey businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.CUSTOMER_NAME_BUSINESS_KEY_NAME);
		businessKey.setValue(slOrder.getCustomerBizOrgName());
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.BUS_ORG_BUSINESS_KEY_NAME);
		businessKey.setValue(slOrder.getCustomerBizOrgId());
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.WRK_ORD_NM_BUSINESS_KEY_NAME);
		businessKey.setValue(String.valueOf(slOrder.getVoiceOrderId()));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.SRV_TYP_BUSINESS_KEY_NAME);
		businessKey.setValue("AC");
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.ACC_CDSETID_BUSINESS_KEY_NAME);
		businessKey.setValue(getTableId(orderTollFree));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		ServiceOrder serviceOrder = new ServiceOrder();
		serviceOrder.setAni(orderTollFree.getTn());
		serviceOrder.setAttrNames("ANI");

		if (orderTollFree.getValidatedAC() != null) {
			serviceOrder.setAccountCodeSetType(
					String.valueOf(AccountCodeIndicator.valueOf(orderTollFree.getAccountCodeEsf()).getValue()));
			serviceOrder.setAccountCodeLength(orderTollFree.getAcDigits());
		} else if (orderTollFree.getUnvalidatedAC() != null) {
			serviceOrder.setAccountCodeSetType(
					String.valueOf(AccountCodeIndicator.valueOf(orderTollFree.getAccountCodeEsf()).getValue()));
			serviceOrder.setAccountCodeLength(getAccountCodeDigit(orderTollFree.getUnvalidatedAC()));
		}
		efsPayLoad.setServiceOrder(serviceOrder);

		String payload = EmpUtil.objectToXmlString(efsPayLoad, EFSPayload.class);

		payload = payload.replaceAll("<request>", "");
		payload = payload.replaceAll("</request>", "");
		payload = payload.replaceAll("<request/>", "");

		command.setPayload(payload);

		return command;
	}

	private OrderTollFreeFeatureDTO getOrderTollFree(String commandType,
			OrderTollFreeFeatureDTO prevOrderTollfreeFeatures, OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {

		if (COMMAND_TYPE_DELETE.equalsIgnoreCase(commandType)) {
			return prevOrderTollfreeFeatures;
		}
		return currOrderTollfreeFeatures;
	}

	private String getAccountCodeDigit(String accountCodeId) throws SLDBException {
		String accountCode = getUnvalidatedFeatures().get(accountCodeId);

		if (!StringUtils.isEmpty(accountCode) && accountCode.indexOf("Unvalidated") > -1) {
			String accountDigit = accountCode.substring(accountCode.indexOf("(") + 1, accountCode.indexOf("digit"));
			return accountDigit.trim();
		} else {
			LOG.error("No valid unvalidated account code name available for account code id: " + accountCodeId);
			throw new SLDBException(
					"No valid unvalidated account code name available for account code id: " + accountCodeId);
		}
	}

	private String getTableId(OrderTollFreeFeatureDTO orderTollFree) {
		if (orderTollFree.getValidatedAC() != null) {
			return orderTollFree.getAcTableId();
		}
		return "SHARED_NV_AC_LIST";
	}

	private Map<String, String> getUnvalidatedFeatures() {
		Map<String, String> featureDetails = new HashMap<String, String>();

		for (String featureGroup : unvalidatedFeatures) {
			String[] features = featureGroup.split(":");
			featureDetails.put(features[0], features[1]);
		}

		return featureDetails;
	}
}
