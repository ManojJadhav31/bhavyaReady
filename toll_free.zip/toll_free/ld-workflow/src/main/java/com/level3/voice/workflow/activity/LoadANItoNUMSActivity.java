package com.level3.voice.workflow.activity;

import javax.annotation.PostConstruct;
import javax.ws.rs.core.MediaType;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.common.util.OrderActionCodes;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.TnOrderDTO;
import com.level3.voice.persist.repository.TnOrderRepository;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeTNOrderRepository;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;
import com.level3.voice.workflow.vo.TollFreeTnVO;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/**
 * This activity is to handle the NUMS interaction to persist the TN requested
 * in NUMS Tollfree_TN table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component("loadANItoNUMSActivity")
public class LoadANItoNUMSActivity extends WorkflowBaseActivity {
	private static final Logger LOGGER = Logger.getLogger(LoadANItoNUMSActivity.class);

	@Value("${tollfree.nums.client.url}#{'/events/v1/nums/'}")
	private String baseUrl;

	@Value("${tollfree.nums.client.connect.timeout.ms}")
	private Integer connectTimeoutMs;

	@Value("${tollfree.nums.client.read.timeout.ms}")
	private Integer readTimeoutMs;

	final String consumptionstatus = "ASSIGNED";
	final String ldNetwork = "Red NACS";

	ObjectMapper objectMapper;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	TnOrderRepository tnOrderRepository;

	@Autowired
	TollfreeTNOrderRepository tollfreeTNOrderRepository;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	com.sun.jersey.api.client.WebResource webResource;

	@PostConstruct
	public void init() throws Exception {
		Client client = Client.create();
		client.setReadTimeout(readTimeoutMs);
		client.setConnectTimeout(connectTimeoutMs);
		objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		webResource = client.resource(this.baseUrl);
	}

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {
		OrderTollFreeFeatureDTO orderTollFreeFeatureDTO = orderTollFreeFeatureRepository
				.findOne(slOrderDTO.getSlOrderId());
		TollFreeTnVO tollFreeTnVO = assembleNumsData(orderTollFreeFeatureDTO, slOrderDTO);
		sendNumsData(tollFreeTnVO, orderActivityDTO, slOrderDTO);
	}

	/**
	 * Assemble the NUMS request using the ANI information and create tollfreeTNVO
	 * which is exact match to the input TOLLFREETNDTO on the NUMS MS end
	 * 
	 * @param orderTollFreeFeatureDTO
	 * @param slOrderDTO
	 * @return
	 */
	public TollFreeTnVO assembleNumsData(OrderTollFreeFeatureDTO orderTollFreeFeatureDTO, SlOrderDTO slOrderDTO) {
		TollFreeTnVO tollFreeTnVO = new TollFreeTnVO();
		tollFreeTnVO.setBan(orderTollFreeFeatureDTO.getAccountNumber());
		tollFreeTnVO.setConsumptionStatus(this.consumptionstatus);
		tollFreeTnVO.setLastUpdated(slOrderDTO.getLastUpdated());
		tollFreeTnVO.setLastUpdateSystem("3FLOW");
		tollFreeTnVO.setLastUpdateUser(slOrderDTO.getLastUpdatedUser());
		tollFreeTnVO.setLdNetwork(this.ldNetwork);
		TnOrderDTO tnOrder = tollfreeTNOrderRepository.getTnBySlorderId(slOrderDTO.getSlOrderId());
		tollFreeTnVO.setProductId(tnOrder.getProduct().getProductId().toString());
		tollFreeTnVO.setProductPartNumber(tnOrder.getProduct().getExtProductId());
		tollFreeTnVO.setTn(Long.valueOf(orderTollFreeFeatureDTO.getTn()));
		tollFreeTnVO.setPicLdCustomerNumber(slOrderDTO.getExternalCustomerId());
		tollFreeTnVO.setEvent(getEvent(slOrderDTO));
		tollFreeTnVO.setVcOrderId(String.valueOf(slOrderDTO.getVoiceOrderId()));

		return tollFreeTnVO;
	}

	private String getEvent(SlOrderDTO slOrderDTO) {
		if (OrderActionCodes.DISCONNECT == slOrderDTO.getActionTypeId().intValue()) {
			return "DELETE";
		} else if (OrderActionCodes.DISCONNECT != slOrderDTO.getActionTypeId().intValue()
				&& OrderActionCodes.INSTALL != slOrderDTO.getActionTypeId().intValue()) {
			return "CHANGE";
		}
		return "CREATE";
	}

	/**
	 * Send the tollfreetnVO construcuted to NUMS and process the response to mark
	 * the activity with proper status and comments
	 * 
	 * @param tollFreeTnVO
	 * @param orderActivityDTO
	 * @param slOrderDTO
	 * @throws Exception
	 */
	public void sendNumsData(TollFreeTnVO tollFreeTnVO, OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO)
			throws Exception {
		String serviceUrl = "/createlnptn";

		WebResource.Builder builder = webResource.path(serviceUrl).type(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse response = builder.post(ClientResponse.class, marshalRequest(tollFreeTnVO));
		Level3Response l3Response = unmarshal(response.getEntity(String.class));

		orderActivityDTO.setComments(l3Response.getException().getDetail());
		if (l3Response.getHttpStatusCodeInt() == 200) {
			LOGGER.info("TN " + tollFreeTnVO.getTn() + " has been successfully saved in NUMS");
			completeActivity(orderActivityDTO, null);
		} else {
			LOGGER.info("TN " + tollFreeTnVO.getTn() + " either already exists or could be a failure in NUMS");
			String comments = "TN " + tollFreeTnVO.getTn() + " either already exists or could be a failure in NUMS";
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
			setNonCompleteActivity();
			//throw new SLDBException(comments);
		}
	}

	/**
	 * Marshal request to convert the vo to json
	 * 
	 * @param tnVO
	 * @return
	 */
	private String marshalRequest(TollFreeTnVO tnVO) {
		try {
			return objectMapper.writeValueAsString(tnVO);
		} catch (JsonProcessingException e) {
		}
		return "";
	}

	/**
	 * Unmarshall the request and form the level3response object
	 * 
	 * @param response
	 * @return
	 * @throws SLDBException
	 */
	private Level3Response unmarshal(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		Level3Response result = null;
		try {
			LOGGER.info("String response is.." + response);
			result = objectMapper.readValue(response, Level3Response.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}

	@SuppressWarnings("unused")
	private TollFreeTnVO stubData() {
		TollFreeTnVO tollFreeTnVO = new TollFreeTnVO();
		tollFreeTnVO.setTn(9886130569L);
		tollFreeTnVO.setProductPartNumber("34");
		tollFreeTnVO.setProductId("6789");
		tollFreeTnVO.setLdNetwork("343434");
		tollFreeTnVO.setConsumptionStatus("Active");
		tollFreeTnVO.setPicLdCustomerNumber("1157");
		tollFreeTnVO.setBan("1888");
		tollFreeTnVO.setEvent("CREATE");
		return tollFreeTnVO;
	}
}
