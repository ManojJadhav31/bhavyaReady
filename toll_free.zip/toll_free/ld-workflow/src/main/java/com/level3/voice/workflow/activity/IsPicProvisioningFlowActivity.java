package com.level3.voice.workflow.activity;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.LECProvisionerRepository;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.workflow.utils.OrderActionCodes;

/**
 * This activity is to identify if TN/slorder flow requires PIC provisioning
 * 
 * If Self PIC - NO PIC Provisioning is needed If CTL PIC - PIC Provisioning is
 * needed
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component("isPicProvisioningFlow")
public class IsPicProvisioningFlowActivity extends WorkflowBaseActivity {

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	LECProvisionerRepository lecProvisionerRepository;

	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CANCELLED_STATE) {
			throw new BpmnError("Activity Cancelled, so stopped processing in Microservices.");
		}

		OrderTollFreeFeatureDTO orderTollFreeFeatureDTO = orderTollFreeFeatureRepository
				.findOne(slOrderDTO.getSlOrderId());

		if (isPicProvNotNeeded(slOrderDTO, orderTollFreeFeatureDTO)) {
			delegateExecution.setVariable(delegateExecution.getCurrentActivityId(), "F");
			orderActivityDTO.setConditionValue(WorkflowConstants.CONDITION_FALSE);
		} else {
			delegateExecution.setVariable(delegateExecution.getCurrentActivityId(), "T");
			orderActivityDTO.setConditionValue(WorkflowConstants.CONDITION_TRUE);
		}

		completeActivity(orderActivityDTO, null);
	}

	/**
	 * Check to see if PIC provisioning is really needed.
	 * 
	 * @param slOrderDTO
	 * @param currentOrderTollFreeFeatureDTO
	 * @return
	 */
	private boolean isPicProvNotNeeded(SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO currentOrderTollFreeFeatureDTO) {
		if (StringUtils.isEmpty(currentOrderTollFreeFeatureDTO.getPicRequest())
				|| (!StringUtils.isEmpty(currentOrderTollFreeFeatureDTO.getPicRequest())
						&& "Self".equalsIgnoreCase(currentOrderTollFreeFeatureDTO.getPicRequest()))) {
			return true;
		}

		OrderTollFreeFeatureDTO currOrderTollfreeFeatures = orderTollFreeFeatureRepository
				.findOne(slOrderDTO.getSlOrderId().longValue());

		OrderTollFreeFeatureDTO prevOrderTollFreeFeatureDTO = orderTollFreeFeatureRepository
				.getPrevNonActiveOrderTollFreeFeatures(currOrderTollfreeFeatures.getTn(),
						slOrderDTO.getExternalCustomerId());

		if (OrderActionCodes.CHANGE == slOrderDTO.getActionTypeId().intValue()
				&& ("CTL".equalsIgnoreCase(currentOrderTollFreeFeatureDTO.getPicRequest())
						|| "ICPAY".equalsIgnoreCase(currentOrderTollFreeFeatureDTO.getPicRequest()))
				&& prevOrderTollFreeFeatureDTO != null && currentOrderTollFreeFeatureDTO.getPicRequest()
						.equalsIgnoreCase(prevOrderTollFreeFeatureDTO.getPicRequest())) {
			if (currentOrderTollFreeFeatureDTO.getJurisdiction()
					.equalsIgnoreCase(prevOrderTollFreeFeatureDTO.getJurisdiction())) {
				return true;
			}
		}
		return false;
	}

}