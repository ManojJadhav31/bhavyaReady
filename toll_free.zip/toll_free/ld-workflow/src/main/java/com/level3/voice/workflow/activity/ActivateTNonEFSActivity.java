package com.level3.voice.workflow.activity;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.centurylink.voice.workflow.common.activity.ParentTransCoordActivity;
import com.level3.messaging.model.command.Command;
import com.level3.voice.client.emp.EmpPublishClient;
import com.level3.voice.client.emp.util.EmpUtil;
import com.level3.voice.client.emp.util.MessageUtils;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.OrderActionCodes;
import com.level3.voice.common.util.OrderTypeCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.ProductDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.TnOrderDTO;
import com.level3.voice.persist.repository.SublCallQueueRepository;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderActivityRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeTNOrderRepository;
import com.level3.voice.workflow.emp.MessageType;
import com.level3.voice.workflow.rest.WorkflowService;
import com.level3.voice.workflow.utils.NPALPayload;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;

@Component("activateTNonEFSActivity")
public class ActivateTNonEFSActivity extends ParentTransCoordActivity {

	private static Log LOG = LogFactory.getLog(ActivateTNonEFSActivity.class);
	public static String PRODUCT_ID_BUSINESS_KEY_NAME = "partNumber";
	public static String COMMAND_TYPE_ADD_PICLD = "ADD_PICLD";
	public static String COMMAND_TYPE_DEACTIVATE_PICLD = "DEACTIVATE_PICLD";
	public static String BUSINESS_KEY_ENTITY_PRODUCT = "Product";

	@Value("${tollfree.npal.pro.callback.url}")
	private String baseUrl;

	@Autowired
	EmpPublishClient empPublishClient;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	SublCallQueueRepository sublCallQueueRepository;

	@Autowired
	protected WorkflowService workflowService;

	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	@Autowired
	TollfreeTNOrderRepository tollfreeTNOrderRepository;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Autowired
	TollfreeOrderActivityRepository tollfreeOrderActivityRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		Command empRequest = null;
		Long pon = (Long) delegateExecution.getVariable("PON_FLOW");
		if (pon == null) {
			pon = slOrderDTO.getParentTransId();
		}
		List<SlOrderDTO> slOrderDTOs = slOrderRepository.findActiveSlOrdersByParentTransId(pon);

		empRequest = populateCommandRequest(MessageType.NPAL_LD_VOICE_ORDER_COMMAND, getCommandType(slOrderDTO),
				slOrderDTO, orderActivityDTO, slOrderDTOs);

		publishToNPALEmpToAddTn(slOrderDTO, orderActivityDTO, empRequest);

	}

	/**
	 * 
	 * @param slOrderDTO
	 * @return
	 */
	private String getCommandType(SlOrderDTO slOrderDTO) {
		if (OrderActionCodes.DISCONNECT == slOrderDTO.getActionTypeId().intValue()) {
			return COMMAND_TYPE_DEACTIVATE_PICLD;
		}
		return COMMAND_TYPE_ADD_PICLD;
	}

	/**
	 * Publish command request derived for the ANI to EMP
	 * 
	 * @param slOrderDTO
	 * @param orderActivityDTO
	 * @param empRequest
	 * @throws SLDBException
	 */
	private void publishToNPALEmpToAddTn(SlOrderDTO slOrderDTO, OrderActivityDTO orderActivityDTO, Command empRequest)
			throws SLDBException {

		try {
			String comments = "";
			String correlationId = super.storeAsyncResponseMapping(EmpPublishClient.ASYNC_MSG_ACTION, orderActivityDTO,
					"NPAL Provisioning");
			empRequest.setCorrelationId(correlationId);

			empPublishClient.publishMessage(correlationId, String.valueOf(slOrderDTO.getVoiceOrderId()), empRequest,
					orderActivityDTO.getOrderActivityPk());
			orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE);
			tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE, 
					comments, OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
					orderActivityDTO.getActivityTypeId());
		} catch (Exception e) {
			LOG.error("Error sending TN command to NPAL EMP from activateTNonEFSActivity ", e);
			String comments = "Error sending TN command to NPAL EMP from activateTNonEFSActivity " + e.getMessage();
			tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_ERROR_STATE, new Date(),
					comments, OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
					orderActivityDTO.getActivityTypeId());
			throw new SLDBException(e);
		}
	}

	/**
	 * Method to create the command request for the usage processing call
	 * 
	 * @param messageType
	 * @param commandType
	 * @param slOrder
	 * @param orderActivityDTO
	 * @param slOrderDTOs
	 * @return
	 * @throws Exception
	 */
	private Command populateCommandRequest(MessageType messageType, String commandType, SlOrderDTO slOrder,
			OrderActivityDTO orderActivityDTO, List<SlOrderDTO> slOrderDTOs) throws Exception {
		Command command = new Command();

		OrderTollFreeFeatureDTO orderTollFree = orderTollFreeFeatureRepository.findOne(slOrder.getSlOrderId());

		NPALPayload npalPayload = new NPALPayload();

		String commandId = String.valueOf(orderActivityDTO.getOrderActivityPk().toString());
		TnOrderDTO tnOrder = tollfreeTNOrderRepository.getTnBySlorderId(slOrder.getSlOrderId());
		ProductDTO product = tnOrder.getProduct();
		command.setCommandId(commandId);
		command.setCommandType(commandType);
		command.setMessageType(messageType.getMessageTypeName());
		command.setMessageSource("3FLOW");
		command.setEventTimestamp(new Date());
		command.setBusinessKeys(new Command.BusinessKeys());

		Command.BusinessKeys.BusinessKey businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(BUSINESS_KEY_ENTITY_PRODUCT);
		businessKey.setName(PRODUCT_ID_BUSINESS_KEY_NAME);
		businessKey.setValue(String.valueOf(product.getExtProductId()));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.VOICE_ORDER_ID_BUSINESS_KEY_NAME);
		businessKey.setValue(String.valueOf(slOrder.getParentTransId()));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		if (OrderActionCodes.DISCONNECT != slOrder.getActionTypeId().intValue()) {
			npalPayload.setCallbackURL(baseUrl + "1" + String.valueOf(orderTollFree.getTn()));
		}
		npalPayload.setCustomerRoutingCode(orderTollFree.getCrc());
		npalPayload.setPriority("3");
		npalPayload.setProductId(product.getExtProductId());

		String tn = "";
		Iterator<SlOrderDTO> slOrderDTOItor = slOrderDTOs.iterator();
		while (slOrderDTOItor.hasNext()) {
			SlOrderDTO slOrdDTO = slOrderDTOItor.next();

			OrderTollFreeFeatureDTO currOrderTollfreeFeatures = orderTollFreeFeatureRepository
					.findOne(slOrdDTO.getSlOrderId().longValue());
			tn = tn + currOrderTollfreeFeatures.getTn() + ",";
		}

		tn = tn.substring(0, tn.lastIndexOf(","));
		npalPayload.setTelephoneNumbers(tn);

		command.setPayload(EmpUtil.objectToXmlString(npalPayload, NPALPayload.class));
		return command;
	}
}
