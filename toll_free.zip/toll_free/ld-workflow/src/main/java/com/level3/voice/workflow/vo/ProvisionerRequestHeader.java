/**
 * 
 */
package com.level3.voice.workflow.vo;

import java.io.Serializable;

import com.level3.voice.common.util.StringUtils;

/**The class is to write detail row header in LEC request file. <b>DO NOT ALTER</b> unless there is a change in the request file template
 * @author ab68221
 *
 */
public class ProvisionerRequestHeader  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String tc;
	private String si;
	private String reserve1;
	private String createDate;
	private String sequenceNumber;
	private String apid;
	private String acna;
	private String rao;
	private String seqGroupId;
	private String versionNumber;
	private String cic;
	private String reserve2;
	
	/*public ProvisionerRequestHeader(){
		this.tc="00";
		this.si="01";
		this.reserve1=StringUtils.appendCharToString(2, "", ' ');
		this.createDate=StringUtils.appendCharToString(4, "", ' ');
		this.sequenceNumber=StringUtils.appendCharToString(4, "", ' ');
		this.apid=StringUtils.appendCharToString(4, "", ' ');
		this.acna=StringUtils.appendCharToString(3, "", ' ');
		this.rao=StringUtils.appendCharToString(3, "", ' ');
		this.seqGroupId=StringUtils.appendCharToString(2, "", ' ');
		this.versionNumber=StringUtils.appendCharToString(4, "", ' ');
		this.cic=StringUtils.appendCharToString(4, "", ' ');
		this.reserve2=StringUtils.appendCharToString(1463, "", ' ');
	}*/
	
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getReserve1() {
		return reserve1;
	}
	public void setReserve1(String reserve1) {
		this.reserve1 = reserve1;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getApid() {
		return apid;
	}
	public void setApid(String apid) {
		this.apid = apid;
	}
	public String getAcna() {
		return acna;
	}
	public void setAcna(String acna) {
		this.acna = acna;
	}
	public String getRao() {
		return rao;
	}
	public void setRao(String rao) {
		this.rao = rao;
	}
	public String getSeqGroupId() {
		return seqGroupId;
	}
	public void setSeqGroupId(String seqGroupId) {
		this.seqGroupId = seqGroupId;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public String getReserve2() {
		return reserve2;
	}
	public void setReserve2(String reserve2) {
		this.reserve2 = reserve2;
	}
	@Override
	public String toString() {
		return  tc + si + reserve1
				+ createDate + sequenceNumber + apid + acna 
				+ rao + seqGroupId + versionNumber + cic
				+ reserve2 + "\n";
	}

	
}
