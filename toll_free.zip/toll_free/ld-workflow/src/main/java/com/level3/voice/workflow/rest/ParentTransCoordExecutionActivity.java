package com.level3.voice.workflow.rest;

import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import org.activiti.engine.delegate.DelegateExecution;

/**
 * Created by dadi.sudhir on 10/29/2018.
 */
public interface ParentTransCoordExecutionActivity {

    public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
                                SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception;

    public Boolean isAsyncWait();

}
