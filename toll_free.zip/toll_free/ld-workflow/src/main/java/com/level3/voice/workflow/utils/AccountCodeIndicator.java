package com.level3.voice.workflow.utils;

/**
 * Enum to capture all the account code indicator
 * with its code and value
 * 
 * @author <a href="mailto:Nnupur.Krishnaa@centurylink.com">Nnupur Krishnaa</a>
 *
 */
public enum AccountCodeIndicator {

	C("MAN_VAL"),
	U("MAN_NON-VAL"),
	Y("NON-MAN_VAL"),
	N("NON-MAN_NON-VAL");
	

	private String value;
	

	AccountCodeIndicator(String value){
		this.value = value;
		
	}

	public String getValue() {
		return value;
	}

	
}