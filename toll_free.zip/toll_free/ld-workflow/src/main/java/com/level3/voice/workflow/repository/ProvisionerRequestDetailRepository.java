package com.level3.voice.workflow.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.level3.voice.workflow.dto.LecProvisionerRequestDTO;
import com.level3.voice.workflow.dto.ProvisionerRequestDetailDTO;

/**
 * This repository is for saving the all provisioner request detail files
 * @author ab68221 - D, Manjunatha
 *
 */
@Transactional
public interface ProvisionerRequestDetailRepository extends JpaRepository<ProvisionerRequestDetailDTO, Long> {

	@Query(value="from ProvisionerRequestDetailDTO where slOrderId=?")
	public ProvisionerRequestDetailDTO getBySlOrderId(String slOrderId);

	
}