/**
 * 
 */
package com.level3.voice.workflow.activity;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.centurylink.voice.workflow.common.activity.ParentTransCoordActivity;
import com.level3.messaging.model.command.Command;
import com.level3.messaging.model.command.Command.SecurityHeader;
import com.level3.voice.client.emp.EmpPublishClient;
import com.level3.voice.client.emp.util.EmpUtil;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.OrderTypeCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.TnOrderDTO;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.SublCallQueueRepository;
import com.level3.voice.persist.repository.TnOrderRepository;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderActivityRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeTNOrderRepository;
import com.level3.voice.workflow.Payload;
import com.level3.voice.workflow.emp.MessageType;
import com.level3.voice.workflow.rest.WorkflowService;
import com.level3.voice.workflow.utils.MessageUtils;
import com.level3.voice.workflow.utils.OrderActionCodes;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;

/**
 * This activity is to handle the pro processing for TNCONFIG for 1S PIC Long
 * distance flows
 * 
 * @author <a href="mailto:Nnupur.Krishnaa@centurylink.com">Nnupur Krishnaa</a>
 *
 */
@Component("updateVoiceInventoryActivity")
public class UpdateVoiceInventoryActivity extends ParentTransCoordActivity {

	private static Log LOG = LogFactory.getLog(UpdateVoiceInventoryActivity.class);
	public static String PRODUCT_ID_BUSINESS_KEY_NAME = "productId";

	@Value("#{'${list.of.features}'.split(',')}")
	private List<String> featuresGroup;

	@Value("${sldb.3flow.application.key}")
	private String applicationKeyValue;

	@Autowired
	TnOrderRepository tnOrderRepository;

	@Autowired
	EmpPublishClient empPublishClient;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	SublCallQueueRepository sublCallQueueRepository;

	@Autowired
	protected WorkflowService workflowService;

	@Autowired
	SlOrderRepository slOrderRepository;

	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	@Autowired
	TollfreeTNOrderRepository tollfreeTNOrderRepository;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Autowired
	TollfreeOrderActivityRepository tollfreeOrderActivityRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		LOG.debug("Executing [" + UpdateVoiceInventoryActivity.class.getName() + "] with PK="
				+ orderActivityDTO.getOrderActivityPk());

		Long pon = (Long) delegateExecution.getVariable("PON_FLOW");
		if (pon == null) {
			pon = slOrderDTO.getParentTransId();
		}
		List<SlOrderDTO> slOrderDTOs = slOrderRepository.findActiveSlOrdersByParentTransId(pon);

		String internalPort = tnOrderRepository.isInternalPortOrder(slOrderDTO.getSlOrderId());
		Command empRequest = null;
		try {

			if (internalPort == null || internalPort.equalsIgnoreCase("N")) {
				OrderTollFreeFeatureDTO orderTollfreeDTO = orderTollFreeFeatureRepository
						.findOne(slOrderDTO.getSlOrderId());
				if (TollfreeWorkflowUtils.isOrderEnterprise(orderTollfreeDTO, slOrderDTO)) {
					empRequest = populateCommandRequest(MessageType.ENTERPRISE_INVENTORY_VOICE_TNCONFIG_COMMAND,
							getCommandType(slOrderDTO), slOrderDTOs, orderActivityDTO, slOrderDTO);
				} else {
					empRequest = populateCommandRequest(MessageType.ENTERPRISE_INVENTORY_VOICE_TNCONFIG_COMMAND,
							getCommandType(slOrderDTO), slOrderDTOs, orderActivityDTO, slOrderDTO);
				}
				publishToEmpToAddTn(slOrderDTO, orderActivityDTO, empRequest);
			}

		} catch (SLDBException e) {
			LOG.error("Update Voice Inventory " + orderActivityDTO.getActivityId() + " failed with exception: "
					+ e.getStackTrace());

			String comments = "Update Voice Inventory could be a failure in usage " + e.getMessage();
			tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_ERROR_STATE, new Date(),
					comments, OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
					orderActivityDTO.getActivityTypeId());
		}
	}

	private String getCommandType(SlOrderDTO slOrderDTO) {
		if (OrderActionCodes.DISCONNECT == slOrderDTO.getActionTypeId().intValue()) {
			return EmpPublishClient.DELETE;
		}
		return EmpPublishClient.INSERT;
	}

	/**
	 * Publish command request derived for the ANI to EMP
	 * 
	 * @param slOrderDTO
	 * @param orderActivityDTO
	 * @param empRequest
	 * @throws SLDBException
	 */
	private void publishToEmpToAddTn(SlOrderDTO slOrderDTO, OrderActivityDTO orderActivityDTO, Command empRequest)
			throws SLDBException {

		try {
			String comments = "";
			String correlationId = super.storeAsyncResponseMapping(EmpPublishClient.ASYNC_MSG_ACTION, orderActivityDTO,
					"Update Voice Inventory");
			empRequest.setCorrelationId(correlationId);
			LOG.info("Update Voice Inventory triggered for salesOrderId :" + slOrderDTO.getSlOrderId() + "Payload:"
					+ empRequest);
			empPublishClient.publishMessage(correlationId, String.valueOf(slOrderDTO.getVoiceOrderId()), empRequest,
					orderActivityDTO.getOrderActivityPk());
			orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE);
			tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE,
					comments, OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
					orderActivityDTO.getActivityTypeId());
		} catch (Exception e) {
			LOG.error("Error sending ADD_TN command to EMP from UpdateVoiceInventory ", e);
			throw new SLDBException(e);
		}
	}

	/**
	 * Method to create the command request for the usage processing call
	 * 
	 * @param messageType
	 * @param commandType
	 * @param slOrderDTOs
	 * @param orderActivityDTO
	 * @return
	 * @throws Exception
	 */
	private Command populateCommandRequest(MessageType messageType, String commandType, List<SlOrderDTO> slOrderDTOs,
			OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO) throws Exception {

		OrderTollFreeFeatureDTO orderTollFree = orderTollFreeFeatureRepository.findOne(slOrderDTO.getSlOrderId());

		Map<String, String> featureDetails = getFeatureDetails();

		String cic = orderTollFree.getCic();
		String customerid = getBizOrgId(slOrderDTO);

		Command command = new Command();
		Command.BusinessKeys.BusinessKey businessKey = new Command.BusinessKeys.BusinessKey();

		command.setMessageType(messageType.getMessageTypeName());
		command.setCommandType(commandType);
		command.setEventTimestamp(new Date());
		command.setSecurityHeader(new SecurityHeader());
		command.getSecurityHeader().setApplicationKey(applicationKeyValue);
		command.setMessageSource("3FLOW");
		command.setBusinessKeys(new Command.BusinessKeys());
		// setting business keys..
		businessKey.setEntity(MessageUtils.PRODUCT_KEY_ENTITY);
		businessKey.setName(MessageUtils.PRODUCT_PART_KEY_NAME);
		TnOrderDTO tnOrder = tollfreeTNOrderRepository.getTnBySlorderId(slOrderDTO.getSlOrderId());
		businessKey.setValue(tnOrder.getProduct().getExtProductId());
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.PRODUCT_KEY_ENTITY);
		businessKey.setName(MessageUtils.PRODUCT_SERVICE_KEY_NAME);
		businessKey.setValue(String.valueOf(orderTollFree.getProductOfferingID()));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.VOICE_ORDER_ID_BUSINESS_KEY_NAME);
		businessKey.setValue(String.valueOf(slOrderDTO.getVoiceOrderId()));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		// payload construction

		Payload newPayload = new Payload();
		Payload.Request.CustomerAccountCode customAcctCode = new Payload.Request.CustomerAccountCode();
		Payload.Request.Features.Feature feature = new Payload.Request.Features.Feature();

		newPayload.setRequest(new Payload.Request());
		newPayload.getRequest().setCic(cic);
		newPayload.getRequest().setCountryCode("1");
		newPayload.getRequest().setCreatedBy("3flow_user");
		newPayload.getRequest().setCustomerNumber(customerid);
		newPayload.getRequest().setFeatures(new Payload.Request.Features());
		newPayload.getRequest().setTelephoneNumbers(new Payload.Request.TelephoneNumbers());

		if (OrderActionCodes.DISCONNECT != slOrderDTO.getActionTypeId().intValue()) {
			setFeatures(orderTollFree, featureDetails, newPayload, customAcctCode, feature,
					slOrderDTO.getActionTypeId());
		}

		Iterator<SlOrderDTO> slOrderDTOItor = slOrderDTOs.iterator();
		while (slOrderDTOItor.hasNext()) {
			SlOrderDTO slOrdDTO = slOrderDTOItor.next();
			Payload.Request.TelephoneNumbers.TelephoneNumber teleNums = new Payload.Request.TelephoneNumbers.TelephoneNumber();

			OrderTollFreeFeatureDTO currOrderTollfreeFeatures = orderTollFreeFeatureRepository
					.findOne(slOrdDTO.getSlOrderId().longValue());

			teleNums.setNationalNumber(currOrderTollfreeFeatures.getTn());
			newPayload.getRequest().getTelephoneNumbers().getTelephoneNumber().add(teleNums);
		}

		newPayload.getRequest().setJurisdiction(orderTollFree.getJurisdiction());
		newPayload.getRequest().setServiceId(orderTollFree.getProductOfferingID());

		String payload = EmpUtil.objectToXmlString(newPayload, Payload.class);
		payload = payload.replaceAll("<payload>", "");
		payload = payload.replaceAll("</payload>", "");

		command.setPayload(payload);

		return command;

	}

	private String getBizOrgId(SlOrderDTO slOrderDTO) {
		if (slOrderDTO.getMasterBizOrgId() != null
				&& !slOrderDTO.getMasterBizOrgId().equalsIgnoreCase(slOrderDTO.getCustomerBizOrgId())) {
			return slOrderDTO.getMasterBizOrgId();
		}
		return slOrderDTO.getCustomerBizOrgId();
	}

	private void setFeatures(OrderTollFreeFeatureDTO orderTollFree, Map<String, String> featureDetails,
			Payload newPayload, Payload.Request.CustomerAccountCode customAcctCode,
			Payload.Request.Features.Feature feature, Integer actionTypeId) {
		String featureBlockAll = orderTollFree.getBlockAll();
		String featureBlockCaribInter = orderTollFree.getBlockCaribInter();
		String featureBlockFraudAll = orderTollFree.getBlockFraudAll();
		String featureBlockFraudCaribInter = orderTollFree.getBlockFraudCaribInter();
		String featureBlocking = orderTollFree.getBlocking();
		String featureUnvalidatedAC = orderTollFree.getUnvalidatedAC();
		String featureValidatedAC = orderTollFree.getValidatedAC();
		String featureForcedANI = orderTollFree.getForcedANI();
		String featurePositiveANI = orderTollFree.getPositiveANI();
		String featurePortedANI = orderTollFree.getPortedANI();

		// setting features..
		if (featureBlockAll != null) {
			feature = new Payload.Request.Features.Feature();
			feature.setFeatureName(featureDetails.get(featureBlockAll));
			newPayload.getRequest().getFeatures().getFeature().add(feature);
		}
		if (featureBlockCaribInter != null) {
			feature = new Payload.Request.Features.Feature();
			feature.setFeatureName(featureDetails.get(featureBlockCaribInter));
			newPayload.getRequest().getFeatures().getFeature().add(feature);
		}
		if (featureBlockFraudAll != null) {
			feature = new Payload.Request.Features.Feature();
			feature.setFeatureName(featureDetails.get(featureBlockFraudAll));
			newPayload.getRequest().getFeatures().getFeature().add(feature);
		}
		if (featureBlockFraudCaribInter != null) {
			feature = new Payload.Request.Features.Feature();
			feature.setFeatureName(featureDetails.get(featureBlockFraudCaribInter));
			newPayload.getRequest().getFeatures().getFeature().add(feature);
		}
		if (featureBlocking != null) {
			feature = new Payload.Request.Features.Feature();
			feature.setFeatureName(featureDetails.get(featureBlocking));
			newPayload.getRequest().getFeatures().getFeature().add(feature);
		}
		if (featureUnvalidatedAC != null) {
			customAcctCode.setAccountCodeType(featureDetails.get(featureUnvalidatedAC));
			newPayload.getRequest().setCustomerAccountCode(customAcctCode);

		}
		if (featureValidatedAC != null) {
			customAcctCode.setAccountCodeTableName(orderTollFree.getAcTableName());
			customAcctCode.setAccountCodeType("Validated Acct Code");
			newPayload.getRequest().setCustomerAccountCode(customAcctCode);
		}
		// If not block order
		if (actionTypeId != OrderActionCodes.BLOCK) {
			if (StringUtils.isNotEmpty(featureForcedANI) && !"NO".equalsIgnoreCase(featureForcedANI)) {
				feature = new Payload.Request.Features.Feature();
				feature.setFeatureName("Forced ANI Load");
				newPayload.getRequest().getFeatures().getFeature().add(feature);
			} else if (StringUtils.isNotEmpty(featurePortedANI)) {
				feature = new Payload.Request.Features.Feature();
				feature.setFeatureName("Forced ANI Load");
				newPayload.getRequest().getFeatures().getFeature().add(feature);
			}

			if (featurePositiveANI != null) {
				feature = new Payload.Request.Features.Feature();
				feature.setFeatureName(featureDetails.get(featurePositiveANI));
				newPayload.getRequest().getFeatures().getFeature().add(feature);
			}
		}
	}

	private Map<String, String> getFeatureDetails() {
		Map<String, String> featureDetails = new HashMap<String, String>();

		for (String featureGroup : featuresGroup) {
			String[] features = featureGroup.split(":");
			featureDetails.put(features[0], features[1]);
		}

		return featureDetails;
	}

}
