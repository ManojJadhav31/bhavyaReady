package com.level3.voice.workflow.configuration.consumer;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.centurylink.voice.workflow.common.utils.WorkflowUtils;
import com.level3.messaging.model.Message;
import com.level3.messaging.model.command.Command;
import com.level3.voice.client.emp.EmpMessageProcessor;
import com.level3.voice.client.emp.dto.EMPResponseData;
import com.level3.voice.common.util.OrderTypeCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.repository.OrderActivityRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderActivityRepository;
import com.level3.voice.workflow.rest.WorkflowService;
import com.level3.voice.workflow.utils.OrderActionCodes;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;

@Component
public class ActivateTNonEFSResponseHandler extends LDWorkflowEMPResponseHandler implements EmpMessageProcessor {
	private static Log LOGGER = LogFactory.getLog(ActivateTNonEFSResponseHandler.class);
	private static String WF_COMPLETE_INS_SIGNAL_NAME = "WF_915_18_Activity_Complete";
	private static String WF_COMPLETE_BLOCK_SIGNAL_NAME = "WF_921_9_Activity_Complete";
	private static String WF_COMPLETE_DISCO_SIGNAL_NAME = "WF_924_10_Activity_Complete";
	private static String WF_COMPLETE_INS_SIGNAL_ID = "WF_915_18_Activity_Signal";
	private static String WF_COMPLETE_BLOCK_SIGNAL_ID = "WF_921_9_Activity_Signal";
	private static String WF_COMPLETE_DISCO_SIGNAL_ID = "WF_924_10_Activity_Signal";
	public static String COMMAND_TYPE_ADD_PICLD = "ADD_PICLD_RESPONSE";
	public static String COMMAND_TYPE_DEACTIVATE_PICLD = "DEACTIVATE_PICLD_RESPONSE";

	@Autowired
	protected WorkflowService workflowService;

	@Autowired
	protected SlOrderRepository slOrderRepository;

	@Autowired
	protected OrderActivityRepository orderActivityRepository;

	@Autowired
	WorkflowUtils workflowUtils;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Autowired
	TollfreeOrderActivityRepository tollfreeOrderActivityRepository;

	@Override
	public void processMessage(Message message) {
		Command responseVo = (Command) message;
		EMPResponseData empResponseData = null;
		try {

			empResponseData = preProcessResponseData((Command) message);
			extractResponseValues(message, empResponseData);
			LOGGER.info("Processing NPAL message " + ((Command) message).getCommandType() + " SL Order "
					+ empResponseData.getSlOrderId() + " " + message);
		} catch (Exception ex) {
			LOGGER.error("Error performing NPAL process", ex);
			String comments = "Error performing NPAL process" + ex.getMessage();
			tollfreeWorkflowUtils.handleError(empResponseData, comments);
			return;
		}

		if (isInvalidCommandType(responseVo)) {
			return;
		}

		if (isAcknowledged(responseVo, empResponseData)) {
			OrderActivityDTO orderActivityDTO = orderActivityRepository.findOne(empResponseData.getOrderActivityPK());
			BigDecimal pon = slOrderRepository.findPonBySlOrderId(Long.parseLong(empResponseData.getSlOrderId()));
			try {
				SlOrderDTO slOrderDTO = slOrderRepository.findOne(Long.valueOf(empResponseData.getSlOrderId()));
				String completeSignalName = retrieveSignalName(slOrderDTO.getActionTypeId().intValue());
				String completeSignalId = retrieveSignalId(slOrderDTO.getActionTypeId().intValue());
				BigDecimal count = slOrderRepository.getSLOrderCountByPON(pon.longValue());

				if (count.intValue() == 1) {
					workflowUtils.completeWaitSignalByOrder(Long.valueOf(empResponseData.getSlOrderId()),
							completeSignalName, completeSignalId);
				} else {
					workflowUtils.completeWaitSignalByPON(pon.longValue(), completeSignalName, completeSignalId);
				}

				tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_COMPLETED_STATE,
						new Date(), "Completed by Microservices Activity.", OrderTypeCodes.CANCEL,
						slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
						orderActivityDTO.getActivityTypeId());

			} catch (Exception e) {
				LOGGER.error("Error processing ACK on Correlation ID:" + empResponseData.getSublCallQueueId()
						+ " SL Order:" + empResponseData.getSlOrderId(), e);
				String comments = "Error processing ACK on Correlation ID:" + empResponseData.getSublCallQueueId()
						+ " SL Order:" + empResponseData.getSlOrderId() + " : Error Message: " + e.getMessage();
				tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_ERROR_STATE,
						new Date(), comments, OrderTypeCodes.CANCEL, pon.longValue(), orderActivityDTO.getActivityId(),
						orderActivityDTO.getActivityTypeId());
			}
		} else {
			OrderActivityDTO orderActivityDTO = orderActivityRepository.findOne(empResponseData.getOrderActivityPK());
			BigDecimal pon = slOrderRepository.findPonBySlOrderId(Long.parseLong(empResponseData.getSlOrderId()));
			try {
				processNonAcknowledgement(responseVo, empResponseData);
				StringBuffer detailErrorMsg = tollfreeWorkflowUtils.getDetailedErrorMessage(empResponseData);
				tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_ERROR_STATE, new Date(),
						detailErrorMsg.toString(), OrderTypeCodes.CANCEL, pon.longValue(),
						orderActivityDTO.getActivityId(), orderActivityDTO.getActivityTypeId());
			} catch (Exception e) {
				LOGGER.error("Error processing non ACK ", e);
				String comments = "Error processing non ACK " + e.getMessage();
				tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_ERROR_STATE, new Date(),
						comments, OrderTypeCodes.CANCEL, pon.longValue(),
						orderActivityDTO.getActivityId(), orderActivityDTO.getActivityTypeId());
			}
		}
	}

	/**
	 * This method is to make sure we only process Tollfree command type and skip
	 * other non tollfree messages
	 * 
	 * @param responseVo
	 * @return
	 */
	private boolean isInvalidCommandType(Command responseVo) {
		return !COMMAND_TYPE_ADD_PICLD.equalsIgnoreCase(responseVo.getCommandType())
				&& !COMMAND_TYPE_DEACTIVATE_PICLD.equalsIgnoreCase(responseVo.getCommandType());
	}

	/**
	 * Method to send in proper signal id
	 * 
	 * @param action
	 * @return
	 */
	private String retrieveSignalId(int action) {
		if (OrderActionCodes.BLOCK == action || OrderActionCodes.UNBLOCK == action) {
			return WF_COMPLETE_BLOCK_SIGNAL_ID;
		} else if (OrderActionCodes.DISCONNECT == action) {
			return WF_COMPLETE_DISCO_SIGNAL_ID;
		}
		return WF_COMPLETE_INS_SIGNAL_ID;
	}

	/**
	 * Method to send in proper signal name
	 * 
	 * @param action
	 * @return
	 */
	private String retrieveSignalName(int action) {
		if (OrderActionCodes.BLOCK == action || OrderActionCodes.UNBLOCK == action) {
			return WF_COMPLETE_BLOCK_SIGNAL_NAME;
		} else if (OrderActionCodes.DISCONNECT == action) {
			return WF_COMPLETE_DISCO_SIGNAL_NAME;
		}
		return WF_COMPLETE_INS_SIGNAL_NAME;
	}

	@Override
	public String getCommandType() {
		return "ADD_PICLD_RESPONSE";
	}
}
