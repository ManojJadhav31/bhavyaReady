/**
 * 
 */
package com.level3.voice.workflow.activity;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.centurylink.voice.workflow.common.activity.ParentTransCoordActivity;
import com.level3.messaging.model.command.Command;
import com.level3.messaging.model.command.Command.SecurityHeader;
import com.level3.voice.client.emp.EmpPublishClient;
import com.level3.voice.client.emp.util.EmpUtil;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.OrderTypeCodes;
import com.level3.voice.common.util.VoiceThreadLocal;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.SublCallQueueDTO;
import com.level3.voice.persist.dto.TnOrderDTO;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.SublCallQueueRepository;
import com.level3.voice.persist.repository.TnOrderRepository;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderActivityRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeTNOrderRepository;
import com.level3.voice.workflow.Payload;
import com.level3.voice.workflow.emp.MessageType;
import com.level3.voice.workflow.rest.WorkflowService;
import com.level3.voice.workflow.utils.MessageUtils;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;

/**
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component("custMoveANIRemoveProActivity")
public class CustMoveANIRemoveProActivity extends ParentTransCoordActivity {

	private static final String CUST_MOVE = "CUST-MOVE-";
	private static Log LOG = LogFactory.getLog(CustMoveANIRemoveProActivity.class);
	public static String PRODUCT_ID_BUSINESS_KEY_NAME = "productId";

	@Value("${sldb.3flow.application.key}")
	private String applicationKeyValue;

	@Autowired
	TnOrderRepository tnOrderRepository;

	@Autowired
	EmpPublishClient empPublishClient;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	SublCallQueueRepository sublCallQueueRepository;

	@Autowired
	protected WorkflowService workflowService;

	@Autowired
	SlOrderRepository slOrderRepository;

	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	@Autowired
	TollfreeTNOrderRepository tollfreeTNOrderRepository;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Autowired
	TollfreeOrderActivityRepository tollfreeOrderActivityRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		LOG.debug("Executing [" + CustMoveANIRemoveProActivity.class.getName() + "] with PK="
				+ orderActivityDTO.getOrderActivityPk());

		Long pon = (Long) delegateExecution.getVariable("PON_FLOW");
		if (pon == null) {
			pon = slOrderDTO.getParentTransId();
		}
		List<SlOrderDTO> slOrderDTOs = slOrderRepository.findActiveSlOrdersByParentTransId(pon);

		Command empRequest = null;
		String tn = null;
		try {
			tn = orderTollFreeFeatureRepository.getTn(slOrderDTO.getSlOrderId());
			OrderTollFreeFeatureDTO oldCustOrderTollfree = orderTollFreeFeatureRepository
					.getPrevCustNonActiveOrderTollFreeFeatures(tn);
			SlOrderDTO oldCustSlOrder = slOrderRepository.findOne(oldCustOrderTollfree.getSlOrderId());
			empRequest = populateCommandRequest(MessageType.ENTERPRISE_INVENTORY_VOICE_TNCONFIG_COMMAND,
					EmpPublishClient.DELETE, slOrderDTOs, orderActivityDTO, oldCustSlOrder, oldCustOrderTollfree);
			publishToEmpToAddTn(slOrderDTO, orderActivityDTO, empRequest);

		} catch (SLDBException e) {
			LOG.error("Customer Move Remove ANI from PRO " + orderActivityDTO.getActivityId()
					+ " failed with exception: " + e.getStackTrace());

			String comments = "Customer Move Remove ANI from PRO " + orderActivityDTO.getActivityId()
					+ " could be a failure in usage " + e.getMessage();
			tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_ERROR_STATE, new Date(),
					comments, OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
					orderActivityDTO.getActivityTypeId());
		}
	}

	/**
	 * Publish command request derived for the ANI to EMP
	 * 
	 * @param slOrderDTO
	 * @param orderActivityDTO
	 * @param empRequest
	 * @throws SLDBException
	 */
	private void publishToEmpToAddTn(SlOrderDTO slOrderDTO, OrderActivityDTO orderActivityDTO, Command empRequest)
			throws SLDBException {

		try {
			String comments = "";
			String correlationId = storeAsyncResponseMapping(EmpPublishClient.ASYNC_MSG_ACTION, orderActivityDTO,
					"PRO Call");
			empRequest.setCorrelationId(correlationId);
			LOG.info("Customer Move Remove ANI from PRO triggered for salesOrderId :" + slOrderDTO.getSlOrderId()
					+ "Payload:" + empRequest);
			empPublishClient.publishMessage(correlationId, String.valueOf(slOrderDTO.getVoiceOrderId()), empRequest,
					orderActivityDTO.getOrderActivityPk());
			orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE);
			tollfreeOrderActivityRepository.updatePonActivity(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE,
					comments, OrderTypeCodes.CANCEL, slOrderDTO.getParentTransId(), orderActivityDTO.getActivityId(),
					orderActivityDTO.getActivityTypeId());
		} catch (Exception e) {
			LOG.error("Error sending ADD_TN command to EMP from UpdateVoiceInventory ", e);
			throw new SLDBException(e);
		}
	}

	public String storeAsyncResponseMapping(String action, OrderActivityDTO orderActivityDTO, String eventName)
			throws SLDBException {
		String id = MICRO_PREFIX + CUST_MOVE + slOrderRepository.getAuditNextval();
		VoiceThreadLocal.setAudit(id);
		String correlationId = id;

		if (!StringUtils.isEmpty(correlationId)) {
			SublCallQueueDTO dto = new SublCallQueueDTO();

			dto.setAction(action);
			dto.setCallerPk(orderActivityDTO.getOrderActivityPk());
			dto.setNumber(correlationId);
			dto.setIsRestartYn("N");
			dto.setCol10(String.valueOf(orderActivityDTO.getSlOrder().getSlOrderId()));
			dto.setCol8("Microservices");
			dto.setEnqueueDate(new Date());

			sublCallQueueRepository.saveAndFlush(dto);

		} else {
			throw new SLDBException("Correlation ID could not be determined");
		}
		return correlationId;
	}

	/**
	 * Method to create the command request for the usage processing call
	 * 
	 * @param messageType
	 * @param commandType
	 * @param slOrderDTOs
	 * @param orderActivityDTO
	 * @return
	 * @throws Exception
	 */
	private Command populateCommandRequest(MessageType messageType, String commandType, List<SlOrderDTO> slOrderDTOs,
			OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO orderTollFree)
			throws Exception {

		String cic = orderTollFree.getCic();
		String customerid = getBizOrgId(slOrderDTO);

		Command command = new Command();
		Command.BusinessKeys.BusinessKey businessKey = new Command.BusinessKeys.BusinessKey();

		command.setMessageType(messageType.getMessageTypeName());
		command.setCommandType(commandType);
		command.setEventTimestamp(new Date());
		command.setSecurityHeader(new SecurityHeader());
		command.getSecurityHeader().setApplicationKey(applicationKeyValue);
		command.setMessageSource("3FLOW");
		command.setBusinessKeys(new Command.BusinessKeys());

		businessKey.setEntity(MessageUtils.PRODUCT_KEY_ENTITY);
		businessKey.setName(MessageUtils.PRODUCT_PART_KEY_NAME);
		TnOrderDTO tnOrder = tollfreeTNOrderRepository.getTnBySlorderId(slOrderDTO.getSlOrderId());
		businessKey.setValue(tnOrder.getProduct().getExtProductId());
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.PRODUCT_KEY_ENTITY);
		businessKey.setName(MessageUtils.PRODUCT_SERVICE_KEY_NAME);
		businessKey.setValue(String.valueOf(orderTollFree.getProductOfferingID()));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.VOICE_ORDER_ID_BUSINESS_KEY_NAME);
		businessKey.setValue(String.valueOf(slOrderDTO.getVoiceOrderId()));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		Payload newPayload = new Payload();

		newPayload.setRequest(new Payload.Request());
		newPayload.getRequest().setCic(cic);
		newPayload.getRequest().setCountryCode("1");
		newPayload.getRequest().setCreatedBy("3flow_user");
		newPayload.getRequest().setCustomerNumber(customerid);
		newPayload.getRequest().setFeatures(new Payload.Request.Features());
		newPayload.getRequest().setTelephoneNumbers(new Payload.Request.TelephoneNumbers());

		Iterator<SlOrderDTO> slOrderDTOItor = slOrderDTOs.iterator();
		while (slOrderDTOItor.hasNext()) {
			SlOrderDTO slOrdDTO = slOrderDTOItor.next();
			Payload.Request.TelephoneNumbers.TelephoneNumber teleNums = new Payload.Request.TelephoneNumbers.TelephoneNumber();

			OrderTollFreeFeatureDTO currOrderTollfreeFeatures = orderTollFreeFeatureRepository
					.findOne(slOrdDTO.getSlOrderId().longValue());

			teleNums.setNationalNumber(currOrderTollfreeFeatures.getTn());
			newPayload.getRequest().getTelephoneNumbers().getTelephoneNumber().add(teleNums);
		}

		newPayload.getRequest().setJurisdiction(orderTollFree.getJurisdiction());
		newPayload.getRequest().setServiceId(orderTollFree.getProductOfferingID());

		String payload = EmpUtil.objectToXmlString(newPayload, Payload.class);
		payload = payload.replaceAll("<payload>", "");
		payload = payload.replaceAll("</payload>", "");

		command.setPayload(payload);

		return command;
	}

	private String getBizOrgId(SlOrderDTO slOrderDTO) {
		if (slOrderDTO.getMasterBizOrgId() != null
				&& !slOrderDTO.getMasterBizOrgId().equalsIgnoreCase(slOrderDTO.getCustomerBizOrgId())) {
			return slOrderDTO.getMasterBizOrgId();
		}
		return slOrderDTO.getCustomerBizOrgId();
	}
}
