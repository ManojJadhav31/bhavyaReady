package com.level3.voice.workflow.tai.repository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.level3.voice.workflow.tai.dto.CarrierDTO;

@Transactional
public interface CarrierRepository extends JpaRepository<CarrierDTO, Long> {


	@Query(value="from CarrierDTO  where cic = ? and statusInd='A' ")
    public CarrierDTO findCarrierByCic( String cic);  


	@Query(value="from CarrierDTO where statusInd='A' ")
	public List<CarrierDTO> findAllCarrier();
	
}