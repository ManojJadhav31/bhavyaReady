package com.level3.voice.workflow.activity;

import com.centurylink.voice.workflow.common.activity.VoiceBaseActivity;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import org.activiti.engine.delegate.DelegateExecution;

/**
 * Abstract Base activity class for all LD workflows
 */
public abstract class WorkflowBaseActivity extends VoiceBaseActivity {

    @Override
    public void doPostOrderActivityCreate(OrderActivityDTO orderActivityDTO) {

    }

    @Override
    public void doPreOrderActivityExecute(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) {

    }

    @Override
    public void doPostOrderActivityExecute(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) {

    }

    @Override
    public void doPostOrderActivityComplete(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) {

    }

    @Override
    public void handleActivityExecutionError(Exception ex, DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO, SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) {

    }

    @Override
    public abstract void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
                                SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception;
}
