package com.level3.voice.workflow.vo;

import org.springframework.stereotype.Component;

@Component
public class EmpClient {
	public static final String ADD_COMMAND_TYPE = "ADD";
	public static final String MODIFY_COMMAND_TYPE = "MODIFY";
}
