package com.level3.voice.workflow.tai.manager;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.level3.voice.tollfree.persist.dto.LECProvisionerDTO;
import com.level3.voice.tollfree.persist.repository.LECProvisionerRepository;
import com.level3.voice.workflow.tai.dto.CarrierDTO;
import com.level3.voice.workflow.tai.dto.ProvisionersDTO;
import com.level3.voice.workflow.tai.repository.CarrierRepository;
import com.level3.voice.workflow.tai.repository.ProvisionersRepository;


/**
 * 
 * @author <arun2.kumar@level3.com>
 *
 */
@Component
public class TaiDataManager {
	private static final Logger LOGGER = Logger.getLogger(TaiDataManager.class);

	@Autowired
	CarrierRepository carrierRepository;

	@Autowired
	LECProvisionerRepository lecProvisionerRepository;
	
	@Autowired
	ProvisionersRepository provisionersRepository;

	/**
	 * Method is to retrieve carrier details from carrier table using CIC.
	 * 
	 * @return
	 */
	//@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":orderDetailPage")
	public CarrierDTO getDetailsByCIC(String cic) {
		LOGGER.info("@getDetailsByCIC - retrieving getDetailsByCIC");
		return carrierRepository.findCarrierByCic(cic);
	}
	/**
	 * Method is to retrieve all carriers from the carrier table.
	 * 
	 * @return
	 */
	public List<CarrierDTO> getAllCIC() {
		LOGGER.info("@getAllCIC - retrieving getAllCIC");
		return carrierRepository.findAllCarrier();
	}
	
	/**
	 * Method is to retrieve lecprovisioner details from 
	 * 	lec_provisioner table using name and CIC.
	 * 
	 * @return
	 */
	public LECProvisionerDTO getLecProvisionerByLecOcn(String provisionerName,String ocn) {
		LOGGER.info("@getLecProvisionerByLecOcn - retrieving getLecProvisionerByLecOcn");
		return lecProvisionerRepository.findLECProvisionerByProvisonerNameOCN(provisionerName, ocn);
	}
	/**
	 * Method is to retrieve all LecProvisioners from the Lec_Provisioner table.
	 * 
	 * @return
	 */
	public List<LECProvisionerDTO> getAllLecProvisioners() {
		LOGGER.info("@getAllLecProvisioners - retrieving getAllLecProvisioners");
		return lecProvisionerRepository.findAllLECProvisioners();
	}
	/**
	 * Method is to retrieve provisioner details from provisioner table using name.
	 * 
	 * @return
	 */
	public ProvisionersDTO getProvisionerByName(String provisionerName) {
		LOGGER.info("@getProvisionerByName - retrieving findProvisionerByName");
		return provisionersRepository.findProvisionerByName(provisionerName);
	}
	/**
	 * Method is to retrieve all Provisioners from the Provisioners table.
	 * 
	 * @return
	 */
	public List<ProvisionersDTO> getAllProvisioners() {
		LOGGER.info("@getAllProvisioners - retrieving getAllProvisioners");
		return provisionersRepository.findAllProvisioners();
	}
		
}
