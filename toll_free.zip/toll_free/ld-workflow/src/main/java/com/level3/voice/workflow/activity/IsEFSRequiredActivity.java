package com.level3.voice.workflow.activity;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.OrderActionCodes;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;

@Component("isEFSRequired")
public class IsEFSRequiredActivity extends WorkflowBaseActivity {

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CANCELLED_STATE) {
			// If cancelled then skip processing the activity.
			throw new BpmnError("Activity Cancelled, so stopped processing in Microservices.");
		}

		OrderTollFreeFeatureDTO currOrderTollfreeFeatures = orderTollFreeFeatureRepository
				.findOne(slOrderDTO.getSlOrderId().longValue());

		OrderTollFreeFeatureDTO prevOrderTollfreeFeatures = orderTollFreeFeatureRepository
				.getPrevNonActiveOrderTollFreeFeatures(currOrderTollfreeFeatures.getTn(),
						slOrderDTO.getExternalCustomerId());

		if (!isEFSCallRequired(slOrderDTO, prevOrderTollfreeFeatures, currOrderTollfreeFeatures)) {
			delegateExecution.setVariable(delegateExecution.getCurrentActivityId(), "F");
			orderActivityDTO.setConditionValue(WorkflowConstants.CONDITION_FALSE);
		} else {
			delegateExecution.setVariable(delegateExecution.getCurrentActivityId(), "T");
			orderActivityDTO.setConditionValue(WorkflowConstants.CONDITION_TRUE);
		}
		completeActivity(orderActivityDTO, null);
	}

	private boolean isEFSCallRequired(SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {

		if (OrderActionCodes.INSTALL == slOrderDTO.getActionTypeId().intValue()
				|| OrderActionCodes.DISCONNECT == slOrderDTO.getActionTypeId().intValue()) {
			return (currOrderTollfreeFeatures.getUnvalidatedAC() != null
					|| currOrderTollfreeFeatures.getValidatedAC() != null);
		} else if (OrderActionCodes.CHANGE == slOrderDTO.getActionTypeId().intValue()) {
			return isEFSCallRequiredForChange(prevOrderTollfreeFeatures, currOrderTollfreeFeatures);
		}

		return false;
	}

	public boolean isEFSCallRequiredForChange(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {

		if (prevOrderTollfreeFeatures == null) {
			return false;
		} else if (checkValue(prevOrderTollfreeFeatures.getUnvalidatedAC(), prevOrderTollfreeFeatures.getValidatedAC(),
				currOrderTollfreeFeatures.getUnvalidatedAC(), currOrderTollfreeFeatures.getValidatedAC())) {
			return true;
		} else if (checkMandatoryFlagChange(prevOrderTollfreeFeatures, currOrderTollfreeFeatures)) {
			return true;
		} else if (prevOrderTollfreeFeatures.getValidatedAC() != null
				&& prevOrderTollfreeFeatures.getValidatedAC()
						.equalsIgnoreCase(currOrderTollfreeFeatures.getValidatedAC())
				&& (checkAccountCodes(prevOrderTollfreeFeatures, currOrderTollfreeFeatures))) {
			return true;
		}

		return false;
	}

	private boolean checkMandatoryFlagChange(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {
		if (checkValue(prevOrderTollfreeFeatures.getAccountCodeEsf(), currOrderTollfreeFeatures.getAccountCodeEsf())) {
			return true;
		}
		return false;
	}

	public boolean checkAccountCodes(OrderTollFreeFeatureDTO prevOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO currOrderTollfreeFeatures) {
		if (checkValue(prevOrderTollfreeFeatures.getAcDigits(), currOrderTollfreeFeatures.getAcDigits())
				|| checkValue(prevOrderTollfreeFeatures.getAcTableName(), currOrderTollfreeFeatures.getAcTableName())) {
			return true;
		}
		return false;
	}

	public boolean checkValue(String value1, String value2, String value3, String value4) {
		if ((value1 != null && value2 == null) && (value3 == null && value4 != null)) {
			return true;
		} else if ((value1 == null && value2 != null) && (value3 != null && value4 == null)) {
			return true;
		}

		return checkValue(value1, value3) || checkValue(value2, value4);
	}

	public boolean checkValue(String value1, String value2) {
		Boolean isChanged = false;
		if (value1 == null && value2 == null) {
			isChanged = false;
		} else if ((value1 == null && value2 != null) || (value2 == null && value1 != null)) {
			isChanged = true;
		} else if (value1.equalsIgnoreCase(value2)) {
			isChanged = false;
		} else if (!value1.equalsIgnoreCase(value2)) {
			isChanged = true;
		}
		return isChanged;
	}

}
