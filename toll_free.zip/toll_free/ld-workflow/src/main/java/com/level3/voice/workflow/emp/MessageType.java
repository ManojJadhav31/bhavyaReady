package com.level3.voice.workflow.emp;

public enum MessageType {

	ENTERPRISE_MEDIATION_MEDIATION_LD_VOICE_ORDER_COMMAND("E.BillingAndRating.Rating.UP.LongDistanceVoiceOrder.Mediate.Command", false,true, false, false, false, 100), 
	ENTERPRISE_MEDIATION_3FLOW_LD_VOICE_ORDER_COMMAND("E.ServiceDelivery.Voice.3Flow.LongDistanceVoiceOrder.MediateResponse.Command", false, true, false, true, false, 70),
	ENTERPRISE_INVENTORY_VOICE_TNCONFIG_COMMAND("E.Inventory.Voice.LongDistanceVoiceOrder.TNConfig.Command",false,true,false,false,false,100),
	ENTERPRISE_INVENTORY_3FLOW_VOICE_ORDER_COMMAND("E.ServiceDelivery.Voice.LongDistanceVoiceOrder.TNConfigResponse.Command", false, true, false, true, false, 70),
	NPAL_VOICE_ORDER_COMMAND("E.ServiceDelivery.Provisioning.NPAL.VoiceOrder.Provision.Command", false,true, false, false, false, 100),
	ENTERPRISE_PROVISION_3FLOW_VOICE_ORDER_COMMAND("E.ServiceDelivery.Voice.3Flow.VoiceOrder.Provision.Command", false, true, false, true, false, 70),
	NPAL_LD_VOICE_ORDER_COMMAND("E.ServiceDelivery.Provisioning.NPAL.LongDistanceVoiceOrder.Provision.Command", false,true, false, false, false, 100),
	ENTERPRISE_PROVISION_3FLOW_NEW_VOICE_ORDER_COMMAND("E.ServiceDelivery.Voice.3Flow.LongDistanceVoiceOrder.Provision.Command", false, true, false, true, false, 70),
	NPAL_EFS_LD_VOICE_ORDER_COMMAND("E.ServiceDelivery.Provisioning.NPAL.VoiceEFSOrder.Provision.Command", false,true, false, false, false, 100),
	ENTERPRISE_PROVISION_3FLOW_EFS_VOICE_ORDER_COMMAND("E.ServiceDelivery.Provisioning.VoiceEFSOrder.ProvisionResponse.Command", false, true, false, true, false, 70);

	private String messageTypeName;
	private boolean eventMessage;
	private boolean commandMessage;
	private boolean documentMessage;
	private boolean consumedMessage;
	private boolean privateMessage;
	private int priority;

	private MessageType(String messageTypeName, boolean eventMessage, boolean commandMessage, boolean documentMessage,
			boolean consumedMessage, boolean privateMessage, int priority) {
		this.messageTypeName = messageTypeName;
		this.eventMessage = eventMessage;
		this.commandMessage = commandMessage;
		this.documentMessage = documentMessage;
		this.consumedMessage = consumedMessage;
		this.privateMessage = privateMessage;
		this.priority = priority;
	}

	public String getMessageTypeName() {
		return messageTypeName;
	}

	public boolean isEventMessage() {
		return eventMessage;
	}

	public boolean isCommandMessage() {
		return commandMessage;
	}

	public boolean isDocumentMessage() {
		return documentMessage;
	}

	public boolean isConsumedMessage() {
		return consumedMessage;
	}

	public boolean isPrivateMessage() {
		return privateMessage;
	}

	public int getPriority() {
		return priority;
	}
}
