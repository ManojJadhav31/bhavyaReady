package com.level3.voice.workflow.activity;

import static com.level3.voice.client.emp.EmpPublishClient.INSTALL_COMMAND_TYPE;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.activiti.engine.delegate.DelegateExecution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.messaging.model.command.Command;
import com.level3.voice.client.emp.EmpPublishClient;
import com.level3.voice.client.emp.util.EmpUtil;
import com.level3.voice.client.emp.util.MessageUtils;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.StringUtils;
import com.level3.voice.common.util.VoiceThreadLocal;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.ProductDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.SublCallQueueDTO;
import com.level3.voice.persist.dto.TnOrderDTO;
import com.level3.voice.persist.repository.MediationServiceCallBufferRepository;
import com.level3.voice.persist.repository.SublCallQueueRepository;
import com.level3.voice.persist.repository.TnOrderRepository;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeTNOrderRepository;
import com.level3.voice.workflow.emp.MessageType;
import com.level3.voice.workflow.utils.LDEmpPayload;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;
import com.level3.voice.workflow.vo.EmpClient;

/**
 * This activity is to handle the usage processing for ANI for 1S PIC Long
 * distance flows
 * 
 * @author <a href=
 *         "mailto:Keerthi.Selvaraj@centurylink.com">Keerthi.Selvaraj</a>
 *
 */
@Component("custMoveANIRemoveMediationActivity")
public class CustMoveANIRemoveMediationActivity extends WorkflowBaseActivity {

	private static Log LOG = LogFactory.getLog(CustMoveANIRemoveMediationActivity.class);
	private static final String CUST_MOVE = "CUST-MOVE-";
	public static String PRODUCT_ID_BUSINESS_KEY_NAME = "productId";
	public static String DISCO = "DISCO";
	public static String ADD = "ADD";
	public static String MODIFY = "MODIFY";

	@Value("#{'${list.of.wholesale}'.split(',')}")
	private List<String> wholesaleFields;

	@Value("#{'${list.of.enterprise}'.split(',')}")
	private List<String> enterpriseFields;

	@Value("${ban.change.activity}")
	private String banChangeActivity;

	@Autowired
	TnOrderRepository tnOrderRepository;

	@Autowired
	EmpPublishClient empPublishClient;

	@Autowired
	EmpClient empClient;

	@Autowired
	MediationServiceCallBufferRepository mediationServiceCallBufferRepository;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	TollfreeTNOrderRepository tollfreeTNOrderRepository;

	@Autowired
	SublCallQueueRepository sublCallQueueRepository;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {

		Command empRequest = null;
		String tn = null;
		try {
			tn = orderTollFreeFeatureRepository.getTn(slOrderDTO.getSlOrderId());
			OrderTollFreeFeatureDTO oldCustOrderTollfree = orderTollFreeFeatureRepository
					.getPrevCustNonActiveOrderTollFreeFeatures(tn);
			SlOrderDTO oldCustSlOrder = slOrderRepository.findOne(oldCustOrderTollfree.getSlOrderId());
			empRequest = populateCommandRequest(MessageType.ENTERPRISE_MEDIATION_MEDIATION_LD_VOICE_ORDER_COMMAND,
					DISCO, oldCustSlOrder, orderActivityDTO, oldCustOrderTollfree);
			publishToEmpToAddTn(oldCustSlOrder, orderActivityDTO, empRequest);
		} catch (SLDBException e) {
			LOG.info("Usage Processing " + orderActivityDTO.getActivityId() + " could be a failure in usage"
					+ e.getStackTrace());
			String comments = "Issue in sending event to usage processing message: " + e.getMessage() + " for TN: "
					+ tn;
			tollfreeWorkflowUtils.handleError(orderActivityDTO, slOrderDTO, comments);
		}

	}

	/**
	 * Publish command request derived for the ANI to EMP
	 * 
	 * @param slOrderDTO
	 * @param orderActivityDTO
	 * @param empRequest
	 * @throws SLDBException
	 */
	private void publishToEmpToAddTn(SlOrderDTO slOrderDTO, OrderActivityDTO orderActivityDTO, Command empRequest)
			throws SLDBException {

		try {
			String correlationId = storeAsyncResponseMapping(EmpPublishClient.ASYNC_MSG_ACTION, orderActivityDTO,
					"Trigger Mediation");
			empRequest.setCorrelationId(correlationId);
			LOG.info("Usage Processing triggered for salesOrderId :" + slOrderDTO.getSlOrderId() + "Payload:"
					+ empRequest);
			empPublishClient.publishMessage(correlationId, String.valueOf(slOrderDTO.getVoiceOrderId()), empRequest,
					orderActivityDTO.getOrderActivityPk());
			orderActivityDTO.setStatus(WorkflowConstants.ACTIVITY_SYSTEM_WAIT_STATE);
		} catch (Exception e) {
			LOG.error("Error sending ADD_TN command to EMP from TriggerMediationActivity ", e);
			throw new SLDBException(e);
		}
	}

	public String storeAsyncResponseMapping(String action, OrderActivityDTO orderActivityDTO, String eventName)
			throws SLDBException {
		String id = MICRO_PREFIX + CUST_MOVE + slOrderRepository.getAuditNextval();
		if (banChangeActivity != null
				&& orderActivityDTO.getActivityTypeId().intValue() == Integer.valueOf(banChangeActivity).intValue()) {
			id = MICRO_PREFIX + slOrderRepository.getAuditNextval();
		}
		VoiceThreadLocal.setAudit(id);
		String correlationId = id;

		if (!StringUtils.isEmpty(correlationId)) {
			SublCallQueueDTO dto = new SublCallQueueDTO();

			dto.setAction(action);
			dto.setCallerPk(orderActivityDTO.getOrderActivityPk());
			dto.setNumber(correlationId);
			dto.setIsRestartYn("N");
			dto.setCol10(String.valueOf(orderActivityDTO.getSlOrder().getSlOrderId()));
			dto.setCol8("Microservices");
			dto.setEnqueueDate(new Date());

			sublCallQueueRepository.saveAndFlush(dto);

		} else {
			throw new SLDBException("Correlation ID could not be determined");
		}
		return correlationId;
	}

	/**
	 * Method to create the command request for the usage processing call
	 * 
	 * @param messageType
	 * @param commandType
	 * @param slOrder
	 * @param orderActivityDTO
	 * @return
	 * @throws Exception
	 */
	private Command populateCommandRequest(MessageType messageType, String commandType, SlOrderDTO slOrder,
			OrderActivityDTO orderActivityDTO, OrderTollFreeFeatureDTO orderTollFree) throws Exception {
		Command command = new Command();
		TnOrderDTO tnOrder = tollfreeTNOrderRepository.getTnBySlorderId(slOrder.getSlOrderId());
		ProductDTO product = tnOrder.getProduct();

		String commandId = String.valueOf(orderActivityDTO.getOrderActivityPk().toString());

		String serviceID = orderTollFree.getServiceID();
		if (StringUtils.isEmpty(serviceID)) {
			serviceID = String.valueOf(tnOrder.getTollfreeSubscriberLineId());
		}
		String provisionDate = formatDate(slOrder.getProvisioningDate());
		String billingaccnum = orderTollFree.getBillingAccNum();

		String wtn = orderTollFree.getTn();

		String productofferingid = orderTollFree.getProductOfferingID();
		String rateplanid = orderTollFree.getRatePlan();
		String servicelocationid = orderTollFree.getServiceAddressId();
		String cic = orderTollFree.getCic();
		String jurisdiction = orderTollFree.getJurisdiction();
		String scid = orderTollFree.getScId();
		if (scid != null) {
			scid = serviceID;
		}
		command.setCommandId(commandId);
		command.setCommandType(commandType);
		command.setMessageType(messageType.getMessageTypeName());
		command.setMessageSource("3FLOW");
		command.setEventTimestamp(new Date());
		command.setBusinessKeys(new Command.BusinessKeys());

		Command.BusinessKeys.BusinessKey businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.TELEPHONE_NUM_BUSINESS_KEY_NAME);
		businessKey.setValue((String.valueOf(orderTollFree.getTn())));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(MessageUtils.VOICE_ORDER_ID_BUSINESS_KEY_NAME);
		businessKey.setValue(String.valueOf(slOrder.getVoiceOrderId()));
		command.getBusinessKeys().getBusinessKey().add(businessKey);

		businessKey = new Command.BusinessKeys.BusinessKey();
		businessKey.setEntity(MessageUtils.BUSINESS_KEY_ENTITY);
		businessKey.setName(PRODUCT_ID_BUSINESS_KEY_NAME);
		command.getBusinessKeys().getBusinessKey().add(businessKey);
		LDEmpPayload ldempPayload = new LDEmpPayload();

		if (!StringUtils.isEmpty(scid)) {
			businessKey.setValue(String.valueOf(product.getExtProductId()));
			ldempPayload.setWtn(wtn);
			setDateEnterpriseFlow(slOrder, ldempPayload);
			ldempPayload.setServiceID(scid);
			createEmptyFieldTags(ldempPayload, enterpriseFields);
		} else {
			businessKey.setValue(String.valueOf(product.getExtProductId() + "_WholeSale"));
			ldempPayload.setServiceID(serviceID);
			ldempPayload.setAccountnumber(billingaccnum);
			ldempPayload.setWtn(wtn);
			setDateWholesaleFlow(slOrder, ldempPayload);
			ldempPayload.setProductofferingid(productofferingid);
			ldempPayload.setRateplanid(rateplanid);
			ldempPayload.setServicelocationid(servicelocationid);
			ldempPayload.setCic(cic);
			ldempPayload.setJurisdiction(jurisdiction);
			ldempPayload.setScid(scid);
			ldempPayload.setStatus(getStatus(slOrder));

			createEmptyFieldTags(ldempPayload, wholesaleFields);
		}

		if (INSTALL_COMMAND_TYPE.equals(commandType)) {
			ldempPayload.setProvisionDate(provisionDate);
		}

		String payload = EmpUtil.objectToXmlString(ldempPayload, LDEmpPayload.class);
		payload = payload.replaceAll("<request>", "");
		payload = payload.replaceAll("</request>", "");
		payload = payload.concat("<effectiveDate>NULL</effectiveDate>");
		command.setPayload(payload);

		return command;

	}

	/**
	 * Set Date during the Enterprise flow for disconnect and other action types
	 * 
	 * @param slOrder
	 * @param ldempPayload
	 */
	private void setDateEnterpriseFlow(SlOrderDTO slOrder, LDEmpPayload ldempPayload) {
		ldempPayload.setDisconnectDate(new Date());
	}

	/**
	 * Set Date during the Wholesale flow for disconnect and other action types
	 * 
	 * @param slOrder
	 * @param ldempPayload
	 */
	private void setDateWholesaleFlow(SlOrderDTO slOrder, LDEmpPayload ldempPayload) {
		ldempPayload.setDisconnectDate(new Date());
	}

	/**
	 * Get Status based on the order action type for wholesale scenario
	 * 
	 * @param slOrder
	 * @return
	 */
	private String getStatus(SlOrderDTO slOrder) {
		return "D";
	}

	/**
	 * Method to create empty tags, id there is no/null value been passed in the
	 * fields
	 * 
	 * @param ldempPayload
	 * @param includedFields
	 * @throws IllegalAccessException
	 * @throws JAXBException
	 */
	private void createEmptyFieldTags(LDEmpPayload ldempPayload, List<String> includedFields)
			throws IllegalAccessException, JAXBException {
		Field[] fields = LDEmpPayload.class.getDeclaredFields();
		for (Field f : fields) {
			if (includedFields.contains(f.getName())) {
				f.setAccessible(true);
				String type = f.getGenericType().toString();
				if (f.get(ldempPayload) == null && (type.equals("class java.lang.String"))) {
					f.set(ldempPayload, "");
				}
			}
		}
	}
}
