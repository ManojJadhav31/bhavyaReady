package com.level3.voice.workflow.configuration.consumer;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.level3.messaging.model.command.Command;
import com.level3.voice.client.emp.EMPRestClient;
import com.level3.voice.client.emp.EmpMessageConsumer;
import com.level3.voice.client.emp.EmpMessageProcessor;
import com.level3.voice.workflow.emp.MessageType;

@Component
public class EFSResponseConsumer extends EmpMessageConsumer {

	private final static String TRANSPORT_NAME = "Default";

	@Value("${sldb.emp.service.url}")
	private String empURL;

	@Value("${sldb.3flow.application.key}")
	private String empApplicationKey;

	@Value("${sldb.3flow.application.secret}")
	private String empApplicationSecretKey;

	@Autowired
	protected ApplicationContext context;

	@Override
	@Scheduled(fixedRateString = "10000")
	public void scheduler() {
		processMessage(Command.class,
				MessageType.ENTERPRISE_PROVISION_3FLOW_EFS_VOICE_ORDER_COMMAND.getMessageTypeName(), TRANSPORT_NAME,
				empApplicationKey, empApplicationSecretKey, "100");
	}

	@PostConstruct
	private void initialize() throws Exception {
		intializeConsumer(empURL, context);
	}

	@Override
	public void intializeConsumer(String empURL, ApplicationContext context) throws Exception {

		empRestClient = new EMPRestClient();
		empRestClient.setUri(empURL);
		empRestClient.afterPropertiesSet();

		Map<String, EmpMessageProcessor> messageProcessors = context.getBeansOfType(EmpMessageProcessor.class);
		for (String key : messageProcessors.keySet()) {
			EmpMessageProcessor msgProcessor = messageProcessors.get(key);
			empMessageProcessors.put(msgProcessor.getCommandType(), msgProcessor);
		}
		empMessageProcessors.put("ALL", context.getBean(EFSResponseHandler.class));
	} 

}
