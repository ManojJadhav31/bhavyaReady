package com.level3.voice.workflow.utils;

import com.level3.messaging.model.command.Command;
import com.level3.messaging.model.event.Event;

import java.util.HashMap;
import java.util.Map;

public class MessageUtils {

	public static String BUSINESS_KEY_ENTITY = "VoiceOrder";
	public static String CUSTOMER_BUSINESS_KEY_NAME = "networkCustomerId";
	public static String PRIORITY_VERSION_BUSINESS_KEY_NAME = "priority";
	public static String VOICE_ORDER_ID_BUSINESS_KEY_NAME = "voiceOrderId";
	public static String PON_BUSINESS_KEY_NAME = "pon";
	public static String TELEPHONE_NUM_BUSINESS_KEY_NAME = "telephoneNumber";
	public static String PRODUCT_KEY_ENTITY = "Product";
	public static String PRODUCT_PART_KEY_NAME = "partNumber";
	public static String PRODUCT_SERVICE_KEY_NAME = "serviceId";
	public static String BUSINESS_ORDER_KEY_ENTITY = "Order";
	public static String CUSTOMER_NAME_BUSINESS_KEY_NAME = "customerName";
	public static String BUS_ORG_BUSINESS_KEY_NAME = "busOrg";
	public static String WRK_ORD_NM_BUSINESS_KEY_NAME = "workOrderName";
	public static String SRV_TYP_BUSINESS_KEY_NAME = "serviceType";
	public static String ACC_CDSETID_BUSINESS_KEY_NAME = "accountCodeSetId";

	/**
	 * Util methods that returns HashMap of all the business keys
	 * 
	 * @param keys
	 * @return
	 */
	public static Map<String, Command.BusinessKeys.BusinessKey> getBusinessKeys(Command.BusinessKeys keys) {

		Map<String, Command.BusinessKeys.BusinessKey> businessKeys = new HashMap<String, Command.BusinessKeys.BusinessKey>();

		if (keys != null) {
			for (Command.BusinessKeys.BusinessKey businessKey : keys.getBusinessKey()) {
				businessKeys.put(
						businessKey.getEntity() + "$" + businessKey.getName(),
						businessKey);
			}
		}

		return businessKeys;
	}

	/**
	 * Util methods that returns value of business key
	 * 
	 * @param keys, name
	 * @return
	 */
	public static String getBusinessKeyValue(Command.BusinessKeys keys, String entity ) {

		if ( keys == null || entity == null )
			return null;
		
		for( Command.BusinessKeys.BusinessKey bk : keys.getBusinessKey() ) {
			if( entity.equalsIgnoreCase( bk.getEntity() ) ) 
				return bk.getValue();
		}

		return null;
	}
		
	/**
	 * Util methods that returns HashMap of all the event business keys
	 * 
	 * @param keys
	 * @return
	 */
	public static Map<String, com.level3.messaging.model.event.Event.BusinessKeys.BusinessKey> getEventBusinessKeys(com.level3.messaging.model.event.Event.BusinessKeys keys) {

		Map<String, com.level3.messaging.model.event.Event.BusinessKeys.BusinessKey> businessKeys = new HashMap<String, com.level3.messaging.model.event.Event.BusinessKeys.BusinessKey>();

		if (keys != null) {
			for (com.level3.messaging.model.event.Event.BusinessKeys.BusinessKey businessKey : keys.getBusinessKey()) {
				businessKeys.put(
						businessKey.getEntity() + "$" + businessKey.getName(),
						businessKey);
			}
		}

		return businessKeys;
	}
	
	/**
	 * Util methods that returns value of event business key
	 * 
	 * @param keys, name
	 * @return
	 */
	public static String getEventBusinessKeyValue( com.level3.messaging.model.event.Event.BusinessKeys keys, String entity ) {
		if ( keys == null || entity == null )
			return null;
		
		for( com.level3.messaging.model.event.Event.BusinessKeys.BusinessKey bk : keys.getBusinessKey() ) {
			if( entity.equalsIgnoreCase( bk.getEntity() ) ) 
				return bk.getValue();
		}

		return null;
	}
	
	public static String getEventBusinessKeyValue( com.level3.messaging.model.event.Event.BusinessKeys keys, String entity, String name ) {
		if ( keys == null || entity == null )
			return null;
		
		for( com.level3.messaging.model.event.Event.BusinessKeys.BusinessKey bk : keys.getBusinessKey() ) {
			if( entity.equalsIgnoreCase( bk.getEntity() ) && name.equalsIgnoreCase(bk.getName())) 
				return bk.getValue();
		}

		return null;
	}
	
	public static String getCommandBusinessKeyValue(Command.BusinessKeys keys, String entity, String name ) {
		if ( keys == null || entity == null )
			return null;
		
		for( Command.BusinessKeys.BusinessKey bk : keys.getBusinessKey() ) {
			if( entity.equalsIgnoreCase( bk.getEntity() ) && name.equalsIgnoreCase(bk.getName())) 
				return bk.getValue();	
		}

		return null;
	}
	
	/**
	 * Util method that returns the value of an attribute.
	 * 
	 * @param attributes
	 * @param name
	 * @return
	 */
	public static String getEventAttributeValue(Event.Attributes attributes, String name) {
		if ( attributes == null || name == null )
			return null;
		
		for( Event.Attributes.Attribute attribute : attributes.getAttribute() ) {
			if( name.equalsIgnoreCase( attribute.getName() ) ) 
				return attribute.getValue();
		}

		return null;
	}
	
	/**
	 * Add the following business key to the specified command.
	 * @param command
	 * @param entity
	 * @param name
	 * @param value
	 */
	public static void addBusinessKey( Command command, String entity, String name, String value ) {
		com.level3.messaging.model.command.Command.BusinessKeys busKeys = command.getBusinessKeys();
		if( busKeys == null ) {
			busKeys = new com.level3.messaging.model.command.Command.BusinessKeys();
			command.setBusinessKeys( busKeys );
		}

		com.level3.messaging.model.command.Command.BusinessKeys.BusinessKey busKey = new com.level3.messaging.model.command.Command.BusinessKeys.BusinessKey();
		busKey.setEntity( entity );
		busKey.setName( name );
		busKey.setValue( value );

		busKeys.getBusinessKey().add( busKey );
	}

	/**
	 * Add the following business key to the specified event.
	 * @param event
	 * @param entity
	 * @param name
	 * @param value
	 */
	public static void addBusinessKey( Event event, String entity, String name, String value ) {
		com.level3.messaging.model.event.Event.BusinessKeys busKeys = event.getBusinessKeys();
		if( busKeys == null ) {
			busKeys = new com.level3.messaging.model.event.Event.BusinessKeys();
			event.setBusinessKeys( busKeys );
		}

		com.level3.messaging.model.event.Event.BusinessKeys.BusinessKey busKey = new com.level3.messaging.model.event.Event.BusinessKeys.BusinessKey();
		busKey.setEntity( entity );
		busKey.setName( name );
		busKey.setValue( value );

		busKeys.getBusinessKey().add( busKey );
	}

	/**
	 * Add the following attribute to the specified event.
	 * @param event
	 * @param name
	 * @param value
	 */
	public static void addAttribute( Event event, String name, String value ) {
		Event.Attributes attrs = event.getAttributes();
		if( attrs == null ) {
			attrs = new Event.Attributes();
			event.setAttributes( attrs );
		}

		Event.Attributes.Attribute attr1 = new Event.Attributes.Attribute();
		attr1.setName( name );
		attr1.setValue( value );

		attrs.getAttribute().add( attr1 );
	}

}
