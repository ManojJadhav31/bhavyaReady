package com.level3.voice.workflow.constants;
/**
 * Constants for TollFree-Workflow MS
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class TollfreeWorkflowConstants {

	public static final String ACTIVITY_COMMENTS = "Completed by Microservices Activity.";
}
