package com.level3.voice.workflow.activity;

import org.activiti.engine.delegate.BpmnError;
import org.activiti.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.StringUtils;
import com.level3.voice.common.util.WorkflowConstants;
import com.level3.voice.persist.dto.ActivityRuleDTO;
import com.level3.voice.persist.dto.OrderActivityDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.workflow.utils.OrderActionCodes;

/**
 * Created by dadi.sudhir on 10/2/2017.
 */
@Component("isMediationRequired")
public class IsMediationRequiredActivity extends WorkflowBaseActivity {

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	@Override
	public void executeActivity(DelegateExecution delegateExecution, OrderActivityDTO orderActivityDTO,
			SlOrderDTO slOrderDTO, ActivityRuleDTO activityRuleDTO) throws Exception {
		slOrderDTO = slOrderRepository.findOne(slOrderDTO.getSlOrderId());
		if (orderActivityDTO.getStatus() == WorkflowConstants.ACTIVITY_CANCELLED_STATE) {
			// If cancelled then skip processing the activity.
			throw new BpmnError("Activity Cancelled, so stopped processing in Microservices.");
		}

		OrderTollFreeFeatureDTO currOrderTollfreeFeatures = orderTollFreeFeatureRepository
				.findOne(slOrderDTO.getSlOrderId().longValue());

		OrderTollFreeFeatureDTO prevOrderTollfreeFeatures = orderTollFreeFeatureRepository
				.getPrevNonActiveOrderTollFreeFeatures(currOrderTollfreeFeatures.getTn(),
						slOrderDTO.getExternalCustomerId());

		if (isBANPoChange(slOrderDTO, currOrderTollfreeFeatures, prevOrderTollfreeFeatures)
				|| (StringUtils.isEmpty(currOrderTollfreeFeatures.getRatePlan())
						&& StringUtils.isEmpty(currOrderTollfreeFeatures.getScId()))) {
			delegateExecution.setVariable(delegateExecution.getCurrentActivityId(), "F");
			orderActivityDTO.setConditionValue(WorkflowConstants.CONDITION_FALSE);
		} else {
			delegateExecution.setVariable(delegateExecution.getCurrentActivityId(), "T");
			orderActivityDTO.setConditionValue(WorkflowConstants.CONDITION_TRUE);
		}
		completeActivity(orderActivityDTO, null);
	}

	private boolean isBANPoChange(SlOrderDTO slOrderDTO, OrderTollFreeFeatureDTO currOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO prevOrderTollfreeFeatures) {
		return (prevOrderTollfreeFeatures != null) && OrderActionCodes.CHANGE == slOrderDTO.getActionTypeId().intValue()
				&& currOrderTollfreeFeatures.getAccountNumber()
						.equalsIgnoreCase(prevOrderTollfreeFeatures.getAccountNumber())
				&& currOrderTollfreeFeatures.getProductOfferingID()
						.equalsIgnoreCase(prevOrderTollfreeFeatures.getProductOfferingID());
	}
}