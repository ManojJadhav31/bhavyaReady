package com.level3.voice.workflow.configuration.consumer;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.centurylink.voice.workflow.common.utils.WorkflowUtils;
import com.level3.messaging.model.Message;
import com.level3.messaging.model.command.Command;
import com.level3.messaging.model.event.Event;
import com.level3.voice.client.emp.dto.EMPResponseData;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.SublCallQueueDTO;
import com.level3.voice.persist.repository.OrderActivityRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.SublCallQueueRepository;
import com.level3.voice.workflow.utils.TollfreeWorkflowUtils;

@Component
public class LDWorkflowEMPResponseHandler {
	private static Log LOG = LogFactory.getLog(LDWorkflowEMPResponseHandler.class);
	private static final String RESPONSE_STATUS_KEY_NAME = "responseStatus";
	private static final String RESPONSE_CODE_KEY_NAME = "responseCode";
	private static final String RESPONSE_DETAIL_KEY_NAME = "responseDetail";
	private static final String DETAIL_KEY_NAME = "detail";
	private static final String RESPONSE_STATUS_START_NODE = "<responseStatus>";
	private static final String RESPONSE_STATUS_END_NODE = "</responseStatus>";
	private static final String RESPONSE_CODE_START_NODE = "<responseCode>";
	private static final String RESPONSE_CODE_END_NODE = "</responseCode>";
	private static final String RESPONSE_DETAIL_START_NODE = "<responseDetail>";
	private static final String RESPONSE_DETAIL_END_NODE = "</responseDetail>";
	protected static final String RESPONSE_STATUS_SUCCESS = "200";
	private static final String RESPONSE_STATUS_404 = "404";
	private static final String RESPONSE_TYPE_DISCO_TN_RESPONSE = "DISCO_TN_RESPONSE";
	public static final String VOICE_ORDER_ID_BK_NAME = "voiceOrderId";

	@Autowired
	SublCallQueueRepository sublCallQueueRepository;

	@Autowired
	WorkflowUtils workflowUtils;

	@Autowired
	TollfreeWorkflowUtils tollfreeWorkflowUtils;

	@Autowired
	OrderActivityRepository orderActivityRepository;

	@Autowired
	SlOrderRepository slOrderRepository;

	protected EMPResponseData preProcessResponseData(Command responseVo) throws Exception {
		EMPResponseData empResponseData = new EMPResponseData();
		validateCorrelationId(responseVo);
		String correlationId = responseVo.getCorrelationId();
		List<SublCallQueueDTO> callQueueDTOs = sublCallQueueRepository.findByCorrelationId(correlationId);

		if (callQueueDTOs == null || callQueueDTOs.size() == 0) {
			LOG.error("EMP response received but could not read Subl Call Queue by Correlation ID: " + correlationId
					+ " :: responseVo: " + responseVo.toString());
			empResponseData.setDetail("EMP response received but could not read Subl Call Queue by Correlation ID: "
					+ correlationId + " :: responseVo: " + responseVo.toString());
			return empResponseData;
		}
		SublCallQueueDTO callQueueDTO = callQueueDTOs.get(0);

		Long orderActivityPK = callQueueDTO.getCallerPk();

		String isRestartYn = callQueueDTO.getIsRestartYn();
		empResponseData.setIsRestartYn(isRestartYn);
		empResponseData.setSlOrderId(callQueueDTO.getCol10());
		empResponseData.setSublCallQueueId(callQueueDTO.getSublCallQueueId());
		empResponseData.setOrderActivityPK(orderActivityPK);
		extractResponseValues(responseVo, empResponseData);

		sublCallQueueRepository.updateDequeueDate(callQueueDTO.getSublCallQueueId());

		if (StringUtils.isBlank(empResponseData.getResponseStatus())) {
			LOG.error("Error parsing EMP command response for response status. Correlation ID: " + correlationId
					+ ". We received a response of: " + responseVo.toString() + " SL Order ID: "
					+ empResponseData.getSlOrderId());

			raiseOrderActivityErrorAndRetry(orderActivityPK, empResponseData.getSlOrderId(),
					"EMP response was in wrong format. Could not determine response status. Correlation ID: "
							+ correlationId);
			return empResponseData;
		}

		return empResponseData;
	}

	protected void extractResponseValues(Message responseVo, EMPResponseData empResponseData) throws Exception {
		String payload = (String) ((Command) responseVo).getPayload();
		if (!StringUtils.isBlank(payload)) {
			empResponseData.setResponseStatus(getResponseStatusFromPayload(payload));
			empResponseData.setResponseCode(getResponseCodeFromPayload(payload));
			empResponseData.setResponseDetail(getResponseDetailFromPayload(payload));
		}

		// check attributes for responseStatus
		if (responseVo instanceof Event && StringUtils.isBlank(empResponseData.getResponseCode())
				&& ((Event) responseVo).getAttributes() != null) {
			Event.Attributes responseAttributeMap = ((Event) responseVo).getAttributes();
			if (responseAttributeMap.getAttribute() != null) {
				for (Event.Attributes.Attribute attribute : responseAttributeMap.getAttribute()) {

					if (attribute.getName().equals(RESPONSE_STATUS_KEY_NAME)) {
						empResponseData.setResponseStatus(attribute.getValue());
					}
					if (attribute.getName().equals(RESPONSE_CODE_KEY_NAME)) {
						empResponseData.setResponseCode(attribute.getValue());
					}
					if (attribute.getName().equals(RESPONSE_DETAIL_KEY_NAME)) {
						empResponseData.setResponseDetail(attribute.getValue());
					}
					if (attribute.getName().equals(DETAIL_KEY_NAME)) {
						empResponseData.setDetail(attribute.getValue());
					}
				}
			}
		}

		// check business keys for responseStatus
		if (responseVo instanceof Command && StringUtils.isBlank(empResponseData.getResponseCode())
				&& ((Command) responseVo).getBusinessKeys() != null
				&& ((Command) responseVo).getBusinessKeys().getBusinessKey() != null) {
			// See if response info is defined in business keys
			for (Command.BusinessKeys.BusinessKey bk : ((Command) responseVo).getBusinessKeys().getBusinessKey()) {
				if (RESPONSE_STATUS_KEY_NAME.equalsIgnoreCase(bk.getName())) {
					empResponseData.setResponseStatus(bk.getValue());
				} else if (RESPONSE_CODE_KEY_NAME.equalsIgnoreCase(bk.getName())) {
					empResponseData.setResponseCode(bk.getValue());
				} else if (RESPONSE_DETAIL_KEY_NAME.equalsIgnoreCase(bk.getName())) {
					empResponseData.setResponseDetail(bk.getValue());
				} else if (DETAIL_KEY_NAME.equalsIgnoreCase(bk.getName())) {
					empResponseData.setDetail(bk.getValue());
				}
			}
		}
	}

	protected String getResponseStatusFromPayload(String payload) {
		// SHOULD contain: <responseStatus>200</responseStatus>
		String responseStatus = "";
		int startPos = payload.indexOf(RESPONSE_STATUS_START_NODE);
		int endPos = payload.indexOf(RESPONSE_STATUS_END_NODE);
		if (startPos > -1 && endPos > (startPos + 16)) {
			responseStatus = payload.substring(startPos, endPos).replace(RESPONSE_STATUS_START_NODE, "");
		}
		return responseStatus;
	}

	protected String getResponseCodeFromPayload(String payload) {
		// MAY contain: <responseCode>400005</responseCode>
		String responseCode = "";
		int startPos = payload.indexOf(RESPONSE_CODE_START_NODE);
		int endPos = payload.indexOf(RESPONSE_CODE_END_NODE);
		if (startPos > -1 && endPos > startPos) {
			responseCode = payload.substring(startPos, endPos).replace(RESPONSE_CODE_START_NODE, "");
		}
		return responseCode;
	}

	protected String getResponseDetailFromPayload(String payload) {
		// MAY contain: <responseDetail>A message here</responseDetail>
		String responseDetail = "";
		int startPos = payload.indexOf(RESPONSE_DETAIL_START_NODE);
		int endPos = payload.indexOf(RESPONSE_DETAIL_END_NODE);
		if (startPos > -1 && endPos > startPos) {
			responseDetail = payload.substring(startPos, endPos).replace(RESPONSE_DETAIL_START_NODE, "");
		}
		return responseDetail;
	}

	protected boolean isAcknowledged(Command message, EMPResponseData empResponseData) {
		String responseStatus = empResponseData.getResponseStatus();
		boolean isAcknowledged = RESPONSE_STATUS_SUCCESS.equals(responseStatus);
		if (!isAcknowledged) {
			if (RESPONSE_STATUS_404.equals(responseStatus)
					&& RESPONSE_TYPE_DISCO_TN_RESPONSE.equalsIgnoreCase(message.getCommandType())) {
				isAcknowledged = true;
			}
		}
		return isAcknowledged;
	}

	protected void processNonAcknowledgement(Command message, EMPResponseData empResponseData) throws Exception {
		LOG.error("NACK received processing EMP response. SL OrderID: " + empResponseData.getSlOrderId()
				+ "  Correlation ID: " + message.getCorrelationId() + "  responseStatus: "
				+ empResponseData.getResponseStatus() + "  responseCode: " + empResponseData.getResponseCode()
				+ "  responseDetail: " + empResponseData.getResponseDetail() + "  detail: "
				+ empResponseData.getDetail() + " :: responseVo: " + message.toString());
		StringBuffer detailErrorMsg = tollfreeWorkflowUtils.getDetailedErrorMessage(empResponseData);

		if (!StringUtils.isEmpty(empResponseData.getResponseDetail())
				&& !empResponseData.getResponseDetail().contains("Invalid data")) {
			raiseOrderActivityErrorAndRetry(empResponseData.getOrderActivityPK(), empResponseData.getSlOrderId(),
					"Error processing request. " + detailErrorMsg.toString() + ". Correlation ID: "
							+ message.getCorrelationId());
		} else {
			raiseOrderActivityErrorAndRetry(empResponseData.getOrderActivityPK(), empResponseData.getSlOrderId(),
					"Error processing request. " + detailErrorMsg.toString() + ". Correlation ID: "
							+ message.getCorrelationId());
		}
		
	}

	protected void validateCorrelationId(Command responseVo) throws SLDBException {
		if (StringUtils.isBlank(responseVo.getCorrelationId())) {
			LOG.error("No correlationId found in EMP response message.");
			throw new SLDBException("No correlationId found in EMP response message: " + responseVo.toString());
		}
	}

	private void raiseOrderActivityErrorAndRetry(Long orderActivityPK, String slOrderId, String message)
			throws Exception {
		SlOrderDTO slOrderDTO = null;
		if (!com.level3.voice.common.util.StringUtils.isEmpty(slOrderId)) {
			try {
				slOrderDTO = slOrderRepository.findOne(Long.parseLong(slOrderId));
			} catch (Exception ex) {
			}
		} else {
			slOrderDTO = new SlOrderDTO(0l, 0, "");
		}

		tollfreeWorkflowUtils.updateActivityErrorMessageNoTrans(slOrderDTO,
				orderActivityRepository.findOne(orderActivityPK), message);
	}
}
