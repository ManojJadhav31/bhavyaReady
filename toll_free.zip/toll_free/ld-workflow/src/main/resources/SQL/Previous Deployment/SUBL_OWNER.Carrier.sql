-- Adding table LECProvisioner in SUBL_OWNER schema along with Primary Key 

CREATE TABLE SUBL_OWNER.Carrier (
    Carrier_Name    VARCHAR2 (30)     NOT NULL,
    CIC            VARCHAR2 (4)      NOT NULL,
    ACNA           VARCHAR2 (3)      NOT NULL,
    Type           VARCHAR2 (1)      NOT NULL,
    Network_Type    VARCHAR2 (1)      NOT NULL,
    Effective_Begin DATE 	NOT NULL,
    Effective_End   DATE 	,
    Status_Ind      VARCHAR2 (1) 
   
);

CREATE INDEX SUBL_OWNER.Carrier_IDX01 ON SUBL_OWNER.Carrier(CIC);

ALTER TABLE SUBL_OWNER.Carrier ADD (
 CONSTRAINT Carrier_PKX
  PRIMARY KEY (CIC)
  USING INDEX SUBL_OWNER.Carrier_IDX01 
  ENABLE VALIDATE);
  
GRANT SELECT ON SUBL_OWNER.Carrier TO SUBL_SELECT;

GRANT DELETE, INSERT, SELECT, UPDATE ON SUBL_OWNER.Carrier TO SUBL_UPDATE;

GRANT DELETE, INSERT, SELECT, UPDATE ON SUBL_OWNER.Carrier TO SUBL_USER;

CREATE PUBLIC SYNONYM Carrier  FOR SUBL_OWNER.Carrier;
