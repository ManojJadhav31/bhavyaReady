
-- Adding table LECProvisioner in SUBL_OWNER schema along with Primary Key 

CREATE TABLE SUBL_OWNER.LEC_Provisioner (
    Provisioner_Name VARCHAR2 (10)  NOT NULL,
    OCN             VARCHAR2 (4)   NOT NULL,
    OCNAbbr         VARCHAR2 (3)   NOT NULL,
    Description     VARCHAR2 (100) NOT NULL,
    Status          VARCHAR2 (1)   NOT NULL,
    On_CIC_Flag       VARCHAR2 (1)   NOT NULL,
    CRLF_Flag        VARCHAR2 (1)   NOT NULL,
    APID            VARCHAR2 (4)   NOT NULL,
    PIC_Version      VARCHAR2 (4)   NOT NULL,
    RAO             VARCHAR2 (3)   NOT NULL,
    Method          VARCHAR2 (6)   NOT NULL
);

CREATE INDEX SUBL_OWNER.LECProvisioner_IDX01 ON SUBL_OWNER.LEC_Provisioner(Provisioner_Name);

ALTER TABLE SUBL_OWNER.LEC_Provisioner ADD (
 CONSTRAINT LECProvisioner_PKX
  PRIMARY KEY (Provisioner_Name,ocn)
  ENABLE VALIDATE);

  
GRANT SELECT ON SUBL_OWNER.LEC_Provisioner TO SUBL_SELECT;

GRANT DELETE, INSERT, SELECT, UPDATE ON SUBL_OWNER.LEC_Provisioner TO SUBL_UPDATE;

GRANT DELETE, INSERT, SELECT, UPDATE ON SUBL_OWNER.LEC_Provisioner TO SUBL_USER;

CREATE PUBLIC SYNONYM LEC_Provisioner  FOR SUBL_OWNER.LEC_Provisioner;


