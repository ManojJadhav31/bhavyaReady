-- Adding table Provisioners in SUBL_OWNER schema along with Primary Key 

CREATE TABLE SUBL_OWNER.Provisioners (
    Provisioner_Name VARCHAR2 (10)  NOT NULL,
    Description     VARCHAR2 (100) NOT NULL,
    Type            VARCHAR2 (8)   NOT NULL,
    Status          VARCHAR2 (1)   NOT NULL,
    Daily_Sends      NUMBER   NOT NULL,
    Daily_Receives   NUMBER   NOT NULL
);
CREATE INDEX SUBL_OWNER.Provisioners_IDX01 ON SUBL_OWNER.Provisioners(Provisioner_Name);


ALTER TABLE SUBL_OWNER.Provisioners ADD (
 CONSTRAINT Provisioners_PKX
  PRIMARY KEY (Provisioner_Name)
  USING INDEX SUBL_OWNER.Provisioners_IDX01 
  ENABLE VALIDATE);
  

  GRANT SELECT ON SUBL_OWNER.Provisioners TO SUBL_SELECT;

GRANT DELETE, INSERT, SELECT, UPDATE ON SUBL_OWNER.Provisioners TO SUBL_UPDATE;

GRANT DELETE, INSERT, SELECT, UPDATE ON SUBL_OWNER.Provisioners TO SUBL_USER;

CREATE PUBLIC SYNONYM Provisioners  FOR SUBL_OWNER.Provisioners;
  

