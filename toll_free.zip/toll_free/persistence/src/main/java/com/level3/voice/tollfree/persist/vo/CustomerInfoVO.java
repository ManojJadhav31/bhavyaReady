package com.level3.voice.tollfree.persist.vo;

import java.io.Serializable;
import java.util.Date;

public class CustomerInfoVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String customerId;
	private String status;
	private String customerName;
	private String organizationId;
	private String customerBizOrgId;
	private String ratePlanId;
	private String intraLata;
	private String customerCode;
	private String customerType;
	private String controlGroupId;
	private String busOrg;
	private String CustomerBegin;
	private String CustomerEnd;
	

	/** default constructor */
	public CustomerInfoVO() {

	}



	public CustomerInfoVO(String customerId, String status, String customerName, String organizationId,
			String customerBizOrgId, String ratePlanId, String intraLata) {
		super();
		this.customerId = customerId;
		this.status = status;
		this.customerName = customerName;
		this.organizationId = organizationId;
		this.customerBizOrgId = customerBizOrgId;
		this.ratePlanId = ratePlanId;
		this.intraLata = intraLata;
		
		
	}



	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public String getCustomerBizOrgId() {
		return customerBizOrgId;
	}

	public void setCustomerBizOrgId(String customerBizOrgId) {
		this.customerBizOrgId = customerBizOrgId;
	}

	public String getRatePlanId() {
		return ratePlanId;
	}

	public void setRatePlanId(String ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public String getIntraLata() {
		return intraLata;
	}

	public void setIntraLata(String intraLata) {
		this.intraLata = intraLata;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getControlGroupId() {
		return controlGroupId;
	}

	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}

	public String getBusOrg() {
		return busOrg;
	}

	public void setBusOrg(String busOrg) {
		this.busOrg = busOrg;
	}

	public String getCustomerBegin() {
		return CustomerBegin;
	}

	public void setCustomerBegin(String customerBegin) {
		CustomerBegin = customerBegin;
	}

	public String getCustomerEnd() {
		return CustomerEnd;
	}

	public void setCustomerEnd(String customerEnd) {
		CustomerEnd = customerEnd;
	}
	
}
