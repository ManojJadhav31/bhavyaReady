package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**

 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */
@Entity(name = "aniDataView")
@Table(name = "GET_ANIDATA_VIEW", schema = "SUBL_OWNER")

public class AniDataDTO {
	
	
	@Id
	@Column(name ="SL_ORDER_ID")
	private Long slOrderId;    
	@Column(name ="TN")
	private String tn;
	@Column(name ="CUSTOMER_ID")
	private String customerId;
	@Column(name ="CUSTOMER_NAME")
	private String customerName;
	@Column(name ="LAST_UPDATED_USER")
	private String lastUpdatedUser;
	@Column(name ="LAST_UPDATED")
	private String lastUpdated;  
	@Column(name ="BTN")
	private String btn;  
	@Column(name ="ORDER_DATE")
	private Date orderDate;
	@Column(name ="DISCONNECT_DATE")
	private String disconnectDate;
	@Column(name ="PRODUCT_OFFERING_ID")
	private String productOfferingId;  
	@Column(name ="RATE_PLAN")
	private String ratePlan;
	@Column(name ="CIC")
	private String cic; 
	@Column(name ="POSITIVE_ANI")
	private String positiveAni; 
	@Column(name ="BLOCK_809")
	private String block809;
	@Column(name ="BLOCKING")
	private String blocking;
	@Column(name ="BLOCK_ALL")
	private String blockAll;
	@Column(name ="BLOCK_CARIB_INTER")
	private String blockCaribInter; 
	@Column(name ="BLOCK_FRAUD_ALL")
	private String blockFraudAll;
	@Column(name ="BLOCK_FRAUD_CARIB_INTER")
	private String blockFraudCaribInter; 
	@Column(name ="FORCED_ANI")
	private String forcedAni;
	@Column(name ="PIC_ICPAY")
	private String picIcpay;
	@Column(name ="PIC_REQUEST")
	private String picRequest;
	@Column(name ="JI_LOAD")               
	private String jiLoad;
	@Column(name ="SPECIAL_ROUTING")
	private String specialRouting; 
	@Column(name ="SERVICE_FEES_700")
	private String serviceFees700;
	@Column(name ="VPN")
	private String vpn; 
	@Column(name ="JURISDICTION")
	private String jurisdiction; 
	@Column(name ="VALIDATED_AC")
	private String validatedAc;
	@Column(name ="UNVALIDATED_AC")
	private String unvalidatedAc; 
	@Column(name ="AC_DIGITS")
	private String acDigits;
	@Column(name ="AC_TABLE_NAME")
	private String acTableName;
	@Column(name ="AC_MAN_NONMAN")
	private String acManNonman;
	@Column(name ="SCID")
	private String scid;
	@Column(name ="CONTROL_GROUP_ID")
	private String controlGroupId;
	@Column(name ="ACCOUNT_NUMBER")
	private String accountNumber;
	@Column(name ="SERVICE_ADDRESS_ID")
	private String serviceAddressId; 
	@Column(name ="BILLING_ACC_NUM")
	private String billingAccNum; 
	@Column(name ="CRC")
	private String crc; 
	@Column(name ="OCN")
	private String ocn;
	@Column(name ="LEC_PROVISIONER_NAME")
	private String lecProvisionerName; 
	@Column(name ="ORDER_COMPLETE_DATE")
	private String orderCompleteDate; 
	@Column(name ="SERVICE_ID")
	private String serviceId; 
	@Column(name ="SUBSCRIBER_LINE_ID")
	private Long subscriberLineId;
	@Column(name ="NAME")
	private String name; 
	@Column(name ="STATUS")
	private String status; 
	@Column(name ="VOICE_ORDER_ID")
	private Long voiceOrderId;
	@Column(name ="ORDER_ACTIVE_YN")
	private String orderActiveYn; 
	@Column(name ="TC")
	private String tc; 
	@Column(name ="SI")
	private String si; 
	@Column(name ="DESCRIPTION")
	private String description;
	@Column(name ="SOURCESYSTEM")
	private String sourceSystem; 
	@Column(name ="INTRALATA_FIRST_USAGE_DATE")
	private String intralataFirstUsageDate; 
	@Column(name ="INTRALATA_LAST_USAGE_DATE")
	private String intralataLastUsageDate;
	@Column(name ="INTERLATA_FIRST_USAGE_DATE")
	private String interlataFirstUsageDate;
	@Column(name ="INTERLATA_LAST_USAGE_DATE")
	private String interlataLastUsageDate;
	
	
	
	
	public Long getSlOrderId() {
		return slOrderId;
	}
	public void setSlOrderId(Long slOrderId) {
		this.slOrderId = slOrderId;
	}
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}
	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public String getDisconnectDate() {
		return disconnectDate;
	}
	public void setDisconnectDate(String disconnectDate) {
		this.disconnectDate = disconnectDate;
	}
	public String getProductOfferingId() {
		return productOfferingId;
	}
	public void setProductOfferingId(String productOfferingId) {
		this.productOfferingId = productOfferingId;
	}
	public String getRatePlan() {
		return ratePlan;
	}
	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public String getPositiveAni() {
		return positiveAni;
	}
	public void setPositiveAni(String positiveAni) {
		this.positiveAni = positiveAni;
	}
	public String getBlock809() {
		return block809;
	}
	public void setBlock809(String block809) {
		this.block809 = block809;
	}
	public String getBlocking() {
		return blocking;
	}
	public void setBlocking(String blocking) {
		this.blocking = blocking;
	}
	public String getBlockAll() {
		return blockAll;
	}
	public void setBlockAll(String blockAll) {
		this.blockAll = blockAll;
	}
	public String getBlockCaribInter() {
		return blockCaribInter;
	}
	public void setBlockCaribInter(String blockCaribInter) {
		this.blockCaribInter = blockCaribInter;
	}
	public String getBlockFraudAll() {
		return blockFraudAll;
	}
	public void setBlockFraudAll(String blockFraudAll) {
		this.blockFraudAll = blockFraudAll;
	}
	public String getBlockFraudCaribInter() {
		return blockFraudCaribInter;
	}
	public void setBlockFraudCaribInter(String blockFraudCaribInter) {
		this.blockFraudCaribInter = blockFraudCaribInter;
	}
	public String getForcedAni() {
		return forcedAni;
	}
	public void setForcedAni(String forcedAni) {
		this.forcedAni = forcedAni;
	}
	public String getPicIcpay() {
		return picIcpay;
	}
	public void setPicIcpay(String picIcpay) {
		this.picIcpay = picIcpay;
	}
	public String getPicRequest() {
		return picRequest;
	}
	public void setPicRequest(String picRequest) {
		this.picRequest = picRequest;
	}
	public String getJiLoad() {
		return jiLoad;
	}
	public void setJiLoad(String jiLoad) {
		this.jiLoad = jiLoad;
	}
	public String getSpecialRouting() {
		return specialRouting;
	}
	public void setSpecialRouting(String specialRouting) {
		this.specialRouting = specialRouting;
	}
	public String getServiceFees700() {
		return serviceFees700;
	}
	public void setServiceFees700(String serviceFees700) {
		this.serviceFees700 = serviceFees700;
	}
	public String getVpn() {
		return vpn;
	}
	public void setVpn(String vpn) {
		this.vpn = vpn;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getValidatedAc() {
		return validatedAc;
	}
	public void setValidatedAc(String validatedAc) {
		this.validatedAc = validatedAc;
	}
	public String getUnvalidatedAc() {
		return unvalidatedAc;
	}
	public void setUnvalidatedAc(String unvalidatedAc) {
		this.unvalidatedAc = unvalidatedAc;
	}
	public String getAcDigits() {
		return acDigits;
	}
	public void setAcDigits(String acDigits) {
		this.acDigits = acDigits;
	}
	public String getAcTableName() {
		return acTableName;
	}
	public void setAcTableName(String acTableName) {
		this.acTableName = acTableName;
	}
	public String getAcManNonman() {
		return acManNonman;
	}
	public void setAcManNonman(String acManNonman) {
		this.acManNonman = acManNonman;
	}
	public String getScid() {
		return scid;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	public String getControlGroupId() {
		return controlGroupId;
	}
	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getServiceAddressId() {
		return serviceAddressId;
	}
	public void setServiceAddressId(String serviceAddressId) {
		this.serviceAddressId = serviceAddressId;
	}
	public String getBillingAccNum() {
		return billingAccNum;
	}
	public void setBillingAccNum(String billingAccNum) {
		this.billingAccNum = billingAccNum;
	}
	public String getCrc() {
		return crc;
	}
	public void setCrc(String crc) {
		this.crc = crc;
	}
	public String getOcn() {
		return ocn;
	}
	public void setOcn(String ocn) {
		this.ocn = ocn;
	}
	public String getLecProvisionerName() {
		return lecProvisionerName;
	}
	public void setLecProvisionerName(String lecProvisionerName) {
		this.lecProvisionerName = lecProvisionerName;
	}
	public String getOrderCompleteDate() {
		return orderCompleteDate;
	}
	public void setOrderCompleteDate(String orderCompleteDate) {
		this.orderCompleteDate = orderCompleteDate;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public Long getSubscriberLineId() {
		return subscriberLineId;
	}
	public void setSubscriberLineId(Long subscriberLineId) {
		this.subscriberLineId = subscriberLineId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getVoiceOrderId() {
		return voiceOrderId;
	}
	public void setVoiceOrderId(Long voiceOrderId) {
		this.voiceOrderId = voiceOrderId;
	}
	public String getOrderActiveYn() {
		return orderActiveYn;
	}
	public void setOrderActiveYn(String orderActiveYn) {
		this.orderActiveYn = orderActiveYn;
	}
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	public String getIntralataFirstUsageDate() {
		return intralataFirstUsageDate;
	}
	public void setIntralataFirstUsageDate(String intralataFirstUsageDate) {
		this.intralataFirstUsageDate = intralataFirstUsageDate;
	}
	public String getIntralataLastUsageDate() {
		return intralataLastUsageDate;
	}
	public void setIntralataLastUsageDate(String intralataLastUsageDate) {
		this.intralataLastUsageDate = intralataLastUsageDate;
	}
	public String getInterlataFirstUsageDate() {
		return interlataFirstUsageDate;
	}
	public void setInterlataFirstUsageDate(String interlataFirstUsageDate) {
		this.interlataFirstUsageDate = interlataFirstUsageDate;
	}
	public String getInterlataLastUsageDate() {
		return interlataLastUsageDate;
	}
	public void setInterlataLastUsageDate(String interlataLastUsageDate) {
		this.interlataLastUsageDate = interlataLastUsageDate;
	}	
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acDigits == null) ? 0 : acDigits.hashCode());
		result = prime * result + ((acManNonman == null) ? 0 : acManNonman.hashCode());
		result = prime * result + ((acTableName == null) ? 0 : acTableName.hashCode());
		result = prime * result + ((accountNumber == null) ? 0 : accountNumber.hashCode());
		result = prime * result + ((billingAccNum == null) ? 0 : billingAccNum.hashCode());
		result = prime * result + ((block809 == null) ? 0 : block809.hashCode());
		result = prime * result + ((blockAll == null) ? 0 : blockAll.hashCode());
		result = prime * result + ((blockCaribInter == null) ? 0 : blockCaribInter.hashCode());
		result = prime * result + ((blockFraudAll == null) ? 0 : blockFraudAll.hashCode());
		result = prime * result + ((blockFraudCaribInter == null) ? 0 : blockFraudCaribInter.hashCode());
		result = prime * result + ((blocking == null) ? 0 : blocking.hashCode());
		result = prime * result + ((btn == null) ? 0 : btn.hashCode());
		result = prime * result + ((cic == null) ? 0 : cic.hashCode());
		result = prime * result + ((controlGroupId == null) ? 0 : controlGroupId.hashCode());
		result = prime * result + ((crc == null) ? 0 : crc.hashCode());
		result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((disconnectDate == null) ? 0 : disconnectDate.hashCode());
		result = prime * result + ((forcedAni == null) ? 0 : forcedAni.hashCode());
		result = prime * result + ((interlataFirstUsageDate == null) ? 0 : interlataFirstUsageDate.hashCode());
		result = prime * result + ((interlataLastUsageDate == null) ? 0 : interlataLastUsageDate.hashCode());
		result = prime * result + ((intralataFirstUsageDate == null) ? 0 : intralataFirstUsageDate.hashCode());
		result = prime * result + ((intralataLastUsageDate == null) ? 0 : intralataLastUsageDate.hashCode());
		result = prime * result + ((jiLoad == null) ? 0 : jiLoad.hashCode());
		result = prime * result + ((jurisdiction == null) ? 0 : jurisdiction.hashCode());
		result = prime * result + ((lastUpdated == null) ? 0 : lastUpdated.hashCode());
		result = prime * result + ((lastUpdatedUser == null) ? 0 : lastUpdatedUser.hashCode());
		result = prime * result + ((lecProvisionerName == null) ? 0 : lecProvisionerName.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((ocn == null) ? 0 : ocn.hashCode());
		result = prime * result + ((orderActiveYn == null) ? 0 : orderActiveYn.hashCode());
		result = prime * result + ((orderCompleteDate == null) ? 0 : orderCompleteDate.hashCode());
		result = prime * result + ((orderDate == null) ? 0 : orderDate.hashCode());
		result = prime * result + ((picIcpay == null) ? 0 : picIcpay.hashCode());
		result = prime * result + ((picRequest == null) ? 0 : picRequest.hashCode());
		result = prime * result + ((positiveAni == null) ? 0 : positiveAni.hashCode());
		result = prime * result + ((productOfferingId == null) ? 0 : productOfferingId.hashCode());
		result = prime * result + ((ratePlan == null) ? 0 : ratePlan.hashCode());
		result = prime * result + ((scid == null) ? 0 : scid.hashCode());
		result = prime * result + ((serviceAddressId == null) ? 0 : serviceAddressId.hashCode());
		result = prime * result + ((serviceFees700 == null) ? 0 : serviceFees700.hashCode());
		result = prime * result + ((serviceId == null) ? 0 : serviceId.hashCode());
		result = prime * result + ((si == null) ? 0 : si.hashCode());
		result = prime * result + ((slOrderId == null) ? 0 : slOrderId.hashCode());
		result = prime * result + ((sourceSystem == null) ? 0 : sourceSystem.hashCode());
		result = prime * result + ((specialRouting == null) ? 0 : specialRouting.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((subscriberLineId == null) ? 0 : subscriberLineId.hashCode());
		result = prime * result + ((tc == null) ? 0 : tc.hashCode());
		result = prime * result + ((tn == null) ? 0 : tn.hashCode());
		result = prime * result + ((unvalidatedAc == null) ? 0 : unvalidatedAc.hashCode());
		result = prime * result + ((validatedAc == null) ? 0 : validatedAc.hashCode());
		result = prime * result + ((voiceOrderId == null) ? 0 : voiceOrderId.hashCode());
		result = prime * result + ((vpn == null) ? 0 : vpn.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AniDataDTO other = (AniDataDTO) obj;
		if (acDigits == null) {
			if (other.acDigits != null)
				return false;
		} else if (!acDigits.equals(other.acDigits))
			return false;
		if (acManNonman == null) {
			if (other.acManNonman != null)
				return false;
		} else if (!acManNonman.equals(other.acManNonman))
			return false;
		if (acTableName == null) {
			if (other.acTableName != null)
				return false;
		} else if (!acTableName.equals(other.acTableName))
			return false;
		if (accountNumber == null) {
			if (other.accountNumber != null)
				return false;
		} else if (!accountNumber.equals(other.accountNumber))
			return false;
		if (billingAccNum == null) {
			if (other.billingAccNum != null)
				return false;
		} else if (!billingAccNum.equals(other.billingAccNum))
			return false;
		if (block809 == null) {
			if (other.block809 != null)
				return false;
		} else if (!block809.equals(other.block809))
			return false;
		if (blockAll == null) {
			if (other.blockAll != null)
				return false;
		} else if (!blockAll.equals(other.blockAll))
			return false;
		if (blockCaribInter == null) {
			if (other.blockCaribInter != null)
				return false;
		} else if (!blockCaribInter.equals(other.blockCaribInter))
			return false;
		if (blockFraudAll == null) {
			if (other.blockFraudAll != null)
				return false;
		} else if (!blockFraudAll.equals(other.blockFraudAll))
			return false;
		if (blockFraudCaribInter == null) {
			if (other.blockFraudCaribInter != null)
				return false;
		} else if (!blockFraudCaribInter.equals(other.blockFraudCaribInter))
			return false;
		if (blocking == null) {
			if (other.blocking != null)
				return false;
		} else if (!blocking.equals(other.blocking))
			return false;
		if (btn == null) {
			if (other.btn != null)
				return false;
		} else if (!btn.equals(other.btn))
			return false;
		if (cic == null) {
			if (other.cic != null)
				return false;
		} else if (!cic.equals(other.cic))
			return false;
		if (controlGroupId == null) {
			if (other.controlGroupId != null)
				return false;
		} else if (!controlGroupId.equals(other.controlGroupId))
			return false;
		if (crc == null) {
			if (other.crc != null)
				return false;
		} else if (!crc.equals(other.crc))
			return false;
		if (customerId == null) {
			if (other.customerId != null)
				return false;
		} else if (!customerId.equals(other.customerId))
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (disconnectDate == null) {
			if (other.disconnectDate != null)
				return false;
		} else if (!disconnectDate.equals(other.disconnectDate))
			return false;
		if (forcedAni == null) {
			if (other.forcedAni != null)
				return false;
		} else if (!forcedAni.equals(other.forcedAni))
			return false;
		if (interlataFirstUsageDate == null) {
			if (other.interlataFirstUsageDate != null)
				return false;
		} else if (!interlataFirstUsageDate.equals(other.interlataFirstUsageDate))
			return false;
		if (interlataLastUsageDate == null) {
			if (other.interlataLastUsageDate != null)
				return false;
		} else if (!interlataLastUsageDate.equals(other.interlataLastUsageDate))
			return false;
		if (intralataFirstUsageDate == null) {
			if (other.intralataFirstUsageDate != null)
				return false;
		} else if (!intralataFirstUsageDate.equals(other.intralataFirstUsageDate))
			return false;
		if (intralataLastUsageDate == null) {
			if (other.intralataLastUsageDate != null)
				return false;
		} else if (!intralataLastUsageDate.equals(other.intralataLastUsageDate))
			return false;
		if (jiLoad == null) {
			if (other.jiLoad != null)
				return false;
		} else if (!jiLoad.equals(other.jiLoad))
			return false;
		if (jurisdiction == null) {
			if (other.jurisdiction != null)
				return false;
		} else if (!jurisdiction.equals(other.jurisdiction))
			return false;
		if (lastUpdated == null) {
			if (other.lastUpdated != null)
				return false;
		} else if (!lastUpdated.equals(other.lastUpdated))
			return false;
		if (lastUpdatedUser == null) {
			if (other.lastUpdatedUser != null)
				return false;
		} else if (!lastUpdatedUser.equals(other.lastUpdatedUser))
			return false;
		if (lecProvisionerName == null) {
			if (other.lecProvisionerName != null)
				return false;
		} else if (!lecProvisionerName.equals(other.lecProvisionerName))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (ocn == null) {
			if (other.ocn != null)
				return false;
		} else if (!ocn.equals(other.ocn))
			return false;
		if (orderActiveYn == null) {
			if (other.orderActiveYn != null)
				return false;
		} else if (!orderActiveYn.equals(other.orderActiveYn))
			return false;
		if (orderCompleteDate == null) {
			if (other.orderCompleteDate != null)
				return false;
		} else if (!orderCompleteDate.equals(other.orderCompleteDate))
			return false;
		if (orderDate == null) {
			if (other.orderDate != null)
				return false;
		} else if (!orderDate.equals(other.orderDate))
			return false;
		if (picIcpay == null) {
			if (other.picIcpay != null)
				return false;
		} else if (!picIcpay.equals(other.picIcpay))
			return false;
		if (picRequest == null) {
			if (other.picRequest != null)
				return false;
		} else if (!picRequest.equals(other.picRequest))
			return false;
		if (positiveAni == null) {
			if (other.positiveAni != null)
				return false;
		} else if (!positiveAni.equals(other.positiveAni))
			return false;
		if (productOfferingId == null) {
			if (other.productOfferingId != null)
				return false;
		} else if (!productOfferingId.equals(other.productOfferingId))
			return false;
		if (ratePlan == null) {
			if (other.ratePlan != null)
				return false;
		} else if (!ratePlan.equals(other.ratePlan))
			return false;
		if (scid == null) {
			if (other.scid != null)
				return false;
		} else if (!scid.equals(other.scid))
			return false;
		if (serviceAddressId == null) {
			if (other.serviceAddressId != null)
				return false;
		} else if (!serviceAddressId.equals(other.serviceAddressId))
			return false;
		if (serviceFees700 == null) {
			if (other.serviceFees700 != null)
				return false;
		} else if (!serviceFees700.equals(other.serviceFees700))
			return false;
		if (serviceId == null) {
			if (other.serviceId != null)
				return false;
		} else if (!serviceId.equals(other.serviceId))
			return false;
		if (si == null) {
			if (other.si != null)
				return false;
		} else if (!si.equals(other.si))
			return false;
		if (slOrderId == null) {
			if (other.slOrderId != null)
				return false;
		} else if (!slOrderId.equals(other.slOrderId))
			return false;
		if (sourceSystem == null) {
			if (other.sourceSystem != null)
				return false;
		} else if (!sourceSystem.equals(other.sourceSystem))
			return false;
		if (specialRouting == null) {
			if (other.specialRouting != null)
				return false;
		} else if (!specialRouting.equals(other.specialRouting))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (subscriberLineId == null) {
			if (other.subscriberLineId != null)
				return false;
		} else if (!subscriberLineId.equals(other.subscriberLineId))
			return false;
		if (tc == null) {
			if (other.tc != null)
				return false;
		} else if (!tc.equals(other.tc))
			return false;
		if (tn == null) {
			if (other.tn != null)
				return false;
		} else if (!tn.equals(other.tn))
			return false;
		if (unvalidatedAc == null) {
			if (other.unvalidatedAc != null)
				return false;
		} else if (!unvalidatedAc.equals(other.unvalidatedAc))
			return false;
		if (validatedAc == null) {
			if (other.validatedAc != null)
				return false;
		} else if (!validatedAc.equals(other.validatedAc))
			return false;
		if (voiceOrderId == null) {
			if (other.voiceOrderId != null)
				return false;
		} else if (!voiceOrderId.equals(other.voiceOrderId))
			return false;
		if (vpn == null) {
			if (other.vpn != null)
				return false;
		} else if (!vpn.equals(other.vpn))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AniDataDTO [slOrderId=" + slOrderId + ", tn=" + tn + ", customerId=" + customerId + ", customerName="
				+ customerName + ", lastUpdatedUser=" + lastUpdatedUser + ", lastUpdated=" + lastUpdated + ", btn="
				+ btn + ", orderDate=" + orderDate + ", disconnectDate=" + disconnectDate + ", productOfferingId="
				+ productOfferingId + ", ratePlan=" + ratePlan + ", cic=" + cic + ", positiveAni=" + positiveAni
				+ ", block809=" + block809 + ", blocking=" + blocking + ", blockAll=" + blockAll + ", blockCaribInter="
				+ blockCaribInter + ", blockFraudAll=" + blockFraudAll + ", blockFraudCaribInter="
				+ blockFraudCaribInter + ", forcedAni=" + forcedAni + ", picIcpay=" + picIcpay + ", picRequest="
				+ picRequest + ", jiLoad=" + jiLoad + ", specialRouting=" + specialRouting + ", serviceFees700="
				+ serviceFees700 + ", vpn=" + vpn + ", jurisdiction=" + jurisdiction + ", validatedAc=" + validatedAc
				+ ", unvalidatedAc=" + unvalidatedAc + ", acDigits=" + acDigits + ", acTableName=" + acTableName
				+ ", acManNonman=" + acManNonman + ", scid=" + scid + ", controlGroupId=" + controlGroupId
				+ ", accountNumber=" + accountNumber + ", serviceAddressId=" + serviceAddressId + ", billingAccNum="
				+ billingAccNum + ", crc=" + crc + ", ocn=" + ocn + ", lecProvisionerName=" + lecProvisionerName
				+ ", orderCompleteDate=" + orderCompleteDate + ", serviceId=" + serviceId + ", subscriberLineId="
				+ subscriberLineId + ", name=" + name + ", status=" + status + ", voiceOrderId=" + voiceOrderId
				+ ", orderActiveYn=" + orderActiveYn + ", tc=" + tc + ", si=" + si + ", description=" + description
				+ ", sourceSystem=" + sourceSystem + ", intralataFirstUsageDate=" + intralataFirstUsageDate
				+ ", intralataLastUsageDate=" + intralataLastUsageDate + ", interlataFirstUsageDate="
				+ interlataFirstUsageDate + ", interlataLastUsageDate=" + interlataLastUsageDate + "]";
	}
	
	
}
