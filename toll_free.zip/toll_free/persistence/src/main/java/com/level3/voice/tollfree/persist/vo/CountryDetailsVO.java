package com.level3.voice.tollfree.persist.vo;

public class CountryDetailsVO {
	private Long countryId;
	private String countryName;
	private Long addressFormat;
	
	public CountryDetailsVO(Long countryId, String countryName, Long addressFormat) {
		super();
		this.countryId = countryId;
		this.countryName = countryName;
		this.addressFormat = addressFormat;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Long getAddressFormat() {
		return addressFormat;
	}

	public void setAddressFormat(Long addressFormat) {
		this.addressFormat = addressFormat;
	}
	
	
	
	
	
	
	

}

