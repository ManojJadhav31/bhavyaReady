package com.level3.voice.tollfree.persist.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@SuppressWarnings("unchecked")
public class TollfreeOrderReportsRepository {

	@Autowired
	EntityManager entityManager;

	public List<Object> getUnAuthorizedPicDisputes(Date startDate, Date endDate) {
		return entityManager.createNativeQuery(
				"select  slo.customer_biz_org_name as customer_Name, slo.external_customer_id as cutomer_Id, oc.oc_name as lec,\r\n"
						+ "lr.bill_name1 as end_user,\r\n"
						+ "lr.tc, lr.si, otf.btn,lr.wtn_new as wtn,lr.create_date as lec_Date,lr.date1 as loa_Date,lr.ji \r\n"
						+ "				 				from lec_response lr   \r\n"
						+ "				 				inner join order_tollfree_features otf on lr.ac_order_num =otf.sl_order_id    \r\n"
						+ "				 				inner join sl_order slo on slo.sl_order_id = lr.ac_order_num\r\n"
						+ "                left outer join npa_nxx_combined_all@NUMS.LEVEL3.COM oc on oc.ocn_no = otf.ocn and oc.NPA = SUBSTR(otf.tn,1,3) and oc.nxx = SUBSTR(otf.tn,4,3) and oc.from_no<=SUBSTR(otf.tn,7,4) and oc.to_no >= SUBSTR(otf.tn,7,4)  \r\n"
						+ "				         WHERE \r\n"
						+ "                  lr.tc ='22' and lr.si in ('17','18','19')    \r\n"
						+ "				       and lr.create_date between :startDate and :endDate")
				.setParameter("endDate", endDate).setParameter("startDate", startDate).getResultList();
	}

}
