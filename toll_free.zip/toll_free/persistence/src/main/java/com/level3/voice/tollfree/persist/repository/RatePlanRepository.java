package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.RatePlanDTO;

/**
 * This repository is to retrieve the rate plan details for
 * the selected organization id
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public interface RatePlanRepository extends JpaRepository<RatePlanDTO, Long> {

	@Query(value="from RatePlanDTO where organizationId = ? ")
	List<RatePlanDTO> retrieveRatePlans(String orgId);

	@Query(value="from RatePlanDTO where ratePlanId = ? ")
	RatePlanDTO getDescriptionForRatePlanId(Long ratePlanId);
		
	
}
