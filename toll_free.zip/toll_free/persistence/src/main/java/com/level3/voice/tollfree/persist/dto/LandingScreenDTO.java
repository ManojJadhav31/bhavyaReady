package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity(name = "GET_VOICEDATA_VIEW")
@Table(name = "GET_VOICEDATA_VIEW", schema = "SUBL_OWNER")
public class LandingScreenDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	/** default constructor */
	public LandingScreenDTO() {

	}

	@Id
	@Column(name = "VOICE_ORDER_ID")
	private Long voiceOrderId;
	/** persistent field */
	@Column(name = "CUSTOMER_NUMBER", nullable = true)
	private String customerNumber;
	/** persistent field */
	@Column(name = "CUSTOMER_REQUEST_DATE", nullable = true)
	private String customerRequestDate;
	/** persistent field */
	@Column(name = "ORDER_TYPE", nullable = true)
	private String orderType;
	/** persistent field */
	@Column(name = "ORDER_STATUS", nullable = true)
	private String orderStatus;

	public Long getVoiceOrderId() {
		return voiceOrderId;
	}
	public void setVoiceOrderId(Long voiceOrderId) {
		this.voiceOrderId = voiceOrderId;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getCustomerRequestDate() {
		return customerRequestDate;
	}
	public void setCustomerRequestDate(String customerRequestDate) {
		this.customerRequestDate = customerRequestDate;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customerNumber == null) ? 0 : customerNumber.hashCode());
		result = prime * result + ((customerRequestDate == null) ? 0 : customerRequestDate.hashCode());
		result = prime * result + ((orderStatus == null) ? 0 : orderStatus.hashCode());
		result = prime * result + ((orderType == null) ? 0 : orderType.hashCode());
		result = prime * result + ((voiceOrderId == null) ? 0 : voiceOrderId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LandingScreenDTO other = (LandingScreenDTO) obj;
		if (customerNumber == null) {
			if (other.customerNumber != null)
				return false;
		} else if (!customerNumber.equals(other.customerNumber))
			return false;
		if (customerRequestDate == null) {
			if (other.customerRequestDate != null)
				return false;
		} else if (!customerRequestDate.equals(other.customerRequestDate))
			return false;
		if (orderStatus == null) {
			if (other.orderStatus != null)
				return false;
		} else if (!orderStatus.equals(other.orderStatus))
			return false;
		if (orderType == null) {
			if (other.orderType != null)
				return false;
		} else if (!orderType.equals(other.orderType))
			return false;
		if (voiceOrderId == null) {
			if (other.voiceOrderId != null)
				return false;
		} else if (!voiceOrderId.equals(other.voiceOrderId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "LandingScreenDTO [voiceOrderId=" + voiceOrderId + ", customerNumber=" + customerNumber
				+ ", customerRequestDate=" + customerRequestDate + ", orderType=" + orderType + ", orderStatus="
				+ orderStatus + "]";
	}
	public LandingScreenDTO(Long voiceOrderId, String customerNumber, String customerRequestDate, String orderType,
			String orderStatus) {
		super();
		this.voiceOrderId = voiceOrderId;
		this.customerNumber = customerNumber;
		this.customerRequestDate = customerRequestDate;
		this.orderType = orderType;
		this.orderStatus = orderStatus;
	}
	

	
}
