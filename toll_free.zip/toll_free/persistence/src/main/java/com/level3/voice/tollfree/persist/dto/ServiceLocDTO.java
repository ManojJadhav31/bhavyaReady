package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "uv_serviceLocation4")
public class ServiceLocDTO {
	
	private static final long serialVersionUID = 1L;
	
	@Column(name ="OrganizationId")
	private String organizationId;
	
	@Column(name ="CustomerId")
	private String customerId;
	@Id
	@Column(name ="ServiceLocationId")
	private String serviceLocationId;

	@Column(name ="Status")
	private String serviceLocationStatus;
	
	@Column(name ="ServiceLocationType")
	private String serviceLocationType;
	
	@Column(name ="ServiceLocationName")
	private String serviceLocationName;
	
	@Column(name ="AccountNumber")
	private String accountNumber;
	
	@Column(name ="PIID")
	private String piid;
	
	@Column(name ="BillingAccountNumber")
	private String billingAccountNumber;
	
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getServiceLocationId() {
		return serviceLocationId;
	}
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}
	public String getServiceLocationStatus() {
		return serviceLocationStatus;
	}
	public void setServiceLocationStatus(String serviceLocationStatus) {
		this.serviceLocationStatus = serviceLocationStatus;
	}
	public String getServiceLocationType() {
		return serviceLocationType;
	}
	public void setServiceLocationType(String serviceLocationType) {
		this.serviceLocationType = serviceLocationType;
	}
	public String getServiceLocationName() {
		return serviceLocationName;
	}
	public void setServiceLocationName(String serviceLocationName) {
		this.serviceLocationName = serviceLocationName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getPiid() {
		return piid;
	}
	public void setPiid(String piid) {
		this.piid = piid;
	}
	public String getBillingAccountNumber() {
		return billingAccountNumber;
	}
	public void setBillingAccountNumber(String billingAccountNumber) {
		this.billingAccountNumber = billingAccountNumber;
	}
	
	
	

}
