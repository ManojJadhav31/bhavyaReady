package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.level3.voice.tollfree.persist.dto.ServiceLocDTO;

public interface ServiceLocRepository  extends JpaRepository<ServiceLocDTO, Long> {

	@Query(value="from ServiceLocDTO where OrganizationId = ? and CustomerId=?")
	public List<ServiceLocDTO> findServLocByCustomerId(String organizationId,String customerId);
}
