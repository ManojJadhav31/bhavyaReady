package com.level3.voice.tollfree.persist.repository;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.level3.voice.tollfree.persist.dto.TcsiDTO;


@Transactional
public interface TcsiRepository extends JpaRepository<TcsiDTO, Long> {

	@Query(value="from TcsiDTO Where tc=?1 and si=?2 ")
	public  List<TcsiDTO> findByTcAndSi(String tc, String si);
	
}