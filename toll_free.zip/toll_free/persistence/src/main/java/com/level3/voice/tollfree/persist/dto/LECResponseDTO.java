package com.level3.voice.tollfree.persist.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
* @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
*
*/
@Entity
@Table(name = "LEC_RESPONSE")
public class LECResponseDTO {


	@Column(name ="TC")
	private String tc;
	@Column(name ="SI")
	private String si;
	@Column(name ="BTN_NEW")
	private String btnNew;
	@Column(name ="CUST_CODE_NEW")
	private String custCodeNew;
	@Column(name ="WTN_NEW")
	private String wtnNew;
	@Column(name ="HML_GROUP_NUM")
	private String hmlGroupNum;
	@Column(name ="TNC_NEW")
	private String tncNew;
	@Column(name ="DATE1")
	private String date1;
	@Column(name ="CTI_NEW")
	private String ctiNew;
	@Column(name ="NON_LIST_IND")
	private String nonListInd;
	@Column(name ="WIRELESS_LINE_IND")
	private String wirelessLineInd;
	@Column(name ="CTI_OLD")
	private String ctiOld;
	@Column(name ="BNA_IND")
	private String bnaInd;
	@Column(name ="BILL_NAME1")
	private String billName1;
	@Column(name ="BILL_NAME2")
	private String billName2;
	@Column(name ="BILL_NAME3")
	private String billName3;
	@Column(name ="BILL_ADDR1")
	private String billAddr1;
	@Column(name ="BILL_ADDR2")
	private String billAddr2;
	@Column(name ="BILL_ADDR3")
	private String billAddr3;
	@Column(name ="CSZ_IND")
	private String cszInd;
	@Column(name ="CITY")
	private String city;
	@Column(name ="STATE_AND_COUNTRY")
	private String stateAndCountry;
	@Column(name ="ZIP_CODE")
	private String zipCode;
	@Column(name ="BTN_OLD")
	private String btnOld;
	@Column(name ="CUST_CODE_OLD")
	private String custCodeOld;
	@Column(name ="WTN_OLD")
	private String wtnOld;
	@Column(name ="TERMINAL_NUM_OLD")
	private String terminalNumOld;
	@Column(name ="AC_REFERENCE_NUM")
	private String acReferenceNum;
	@Id
	@Column(name ="AC_ORDER_NUM")
	private String acOrderNum;
	@Column(name ="SERVICE_ORDER_TYPE")
	private String serviceOrderType;
	@Column(name ="SERVICE_ORDER_NUM")
	private String serviceOrderNum;
	@Column(name ="LANGUAGE_IND")
	private String languageInd;
	@Column(name ="ORIG_TC")
	private String origTC;
	@Column(name ="ORIG_SI")
	private String origSI;
	@Column(name ="JOINT_LOCAL_EXCH_IND")
	private String jointLocalExchInd;
	@Column(name ="TOLL_CAP_IND")
	private String tollCapInd;
	@Column(name ="PTN_ACTIVITY_IND")
	private String pntActivityInd;
	@Column(name ="SIC_CODE")
	private String sicCode;
	@Column(name ="CAMPAIGN_ACCT_IND")
	private String campaignAcctInd;
	@Column(name ="NEW_RESP_PARTY_IND")
	private String newRespPartyInd;
	@Column(name ="JI")
	private String ji;
	@Column(name ="DIALING_IND")
	private String dialingInd;
	@Column(name ="PIC_CHANGE_CHARGE_IND")
	private String pICChangeChargeInd;
	@Column(name ="OCSC")
	private String ocsc;
	@Column(name ="OCSCM")
	private String ocscm;
	@Column(name ="DESIRED_DUE_DATE")
	private String desiredDueDate;
	@Column(name ="CIC")
	private String cic;
	@Column(name ="PIC_ACTIVE_DEACTIV_DATE")
	private String picActiveDeactivDate;
	@Column(name ="SD_IND")
	private String sdInd;
	@Column(name ="TR_IND")
	private String trInd;
	@Column(name ="SUBSCRIBED_CIC")
	private String subscribedCIC;
	@Column(name ="RESTRICTED_PIC_IND")
	private String restrictedPICInd;
	@Column(name ="DATA_ELEM_CHANGE_IND")
	private String dataElemChangeInd;
	@Column(name ="AGG_ACCOUNT_CODE")
	private String aggAccountCode;
	@Column(name ="SNA_Ind")
	private String snaInd;
	@Column(name ="SERVICE_NAME1")
	private String serviceName1;
	@Column(name ="SERVICE_NAME2")
	private String serviceName2;
	@Column(name ="SERVICE_ADDRESS1")
	private String serviceAddress1;
	@Column(name ="SERVICE_ADDRESS2")
	private String serviceAddress2;
	@Column(name ="SERVICE_CSZ_IND")
	private String serviceCSZInd;
	@Column(name ="SERVICE_CITY")
	private String serviceCity;
	@Column(name ="SERVICE_STATE")
	private String serviceState;
	@Column(name ="SERVICE_ZIP")
	private String serviceZip;
	@Column(name ="UNIQUE_IDENTIFIER")
	private String uniqueIdentifier;
	@Column(name ="PICACTIVE_DEACTIVTIME")
	private String picActiveDeactivTime;
	@Column(name ="LISTING_SERVICESIND")
	private String listingServicesInd;
	@Column(name ="DEPOSIT_IND")
	private String depositInd;
	@Column(name ="TOLLBLOCKEDSS_IND")
	private String tollBlockedSSInd;
	@Column(name ="ACPIC_MEDIUM_IND")
	private String acPicMediumInd;
	@Column(name ="ISDN_IND")
	private String isdnInd;
	@Column(name ="MESSAGE_TYPE_IND")
	private String messageTypeInd;
	@Column(name ="SPECIAL_SERVICES_IND")
	private String specialServicesInd;
	@Column(name ="SL_INDENTIFIER")
	private String slindentifier;
	@Column(name ="PTN")
	private String ptn;
	@Column(name ="LSPID_CODE")
	private String lsPidCode;
	@Column(name ="BILL_PERIOD")
	private String billPeriod;
	@Column(name ="CBT_NUM")
	private String cbtNum;
	@Column(name ="WL_IND_OLD")
	private String wlIndOld;
	@Column(name ="NAME_EDIT_BY_PASS_IND_OLD")
	private String nameEditByPassIndOld;
	@Column(name ="NPI")
	private String npi;
	@Column(name ="DATE_USE_IND")
	private String dateUseInd;
	@Column(name ="PICC_LINE_IND")
	private String piccLineInd;
	@Column(name ="PTN_OLD")
	private String ptnOld;
	@Column(name ="PICC_END_USER_NOTIF_DATE")
	private String piccEndUserNotifDate;
	@Column(name ="PICC_TERMIN_REAS_IND")
	private String piccTerminReasInd;
	@Column(name ="RESERVED1")
	private String reserved1;
	@Column(name ="RESERVED2")
	private String reserved2;
	@Column(name ="RESERVED3")
	private String reserved3;
	@Column(name ="RESERVED4")
	private String reserved4;
	@Column(name ="RESERVED5")
	private String reserved5;
	@Column(name ="RESERVED6")
	private String reserved6;
	@Column(name ="RESERVED7")
	private String reserved7;
	@Column(name ="RESERVED8")
	private String reserved8;
	@Column(name ="RESERVED9")
	private String reserved9;
	@Column(name ="RESERVED10")
	private String reserved10;
	@Column(name ="CREATE_DATE")
	private Date createDate;
	
	@Transient
	private String customerName;
	@Transient
	private String customerId;
	@Transient
	private String lec;
	@Transient
	private String endUser;
	@Transient
	private String lecDate;
	
	
	public String getLecDate() {
		return lecDate;
	}
	public void setLecDate(String lecDate) {
		this.lecDate = lecDate;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getLec() {
		return lec;
	}
	public void setLec(String lec) {
		this.lec = lec;
	}
	public String getEndUser() {
		return endUser;
	}
	public void setEndUser(String endUser) {
		this.endUser = endUser;
	}
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getBtnNew() {
		return btnNew;
	}
	public void setBtnNew(String btnNew) {
		this.btnNew = btnNew;
	}
	public String getCustCodeNew() {
		return custCodeNew;
	}
	public void setCustCodeNew(String custCodeNew) {
		this.custCodeNew = custCodeNew;
	}
	public String getWtnNew() {
		return wtnNew;
	}
	public void setWtnNew(String wtnNew) {
		this.wtnNew = wtnNew;
	}
	public String getHmlGroupNum() {
		return hmlGroupNum;
	}
	public void setHmlGroupNum(String hmlGroupNum) {
		this.hmlGroupNum = hmlGroupNum;
	}
	public String getTncNew() {
		return tncNew;
	}
	public void setTncNew(String tncNew) {
		this.tncNew = tncNew;
	}
	public String getDate1() {
		return date1;
	}
	public void setDate1(String date1) {
		this.date1 = date1;
	}
	public String getCtiNew() {
		return ctiNew;
	}
	public void setCtiNew(String ctiNew) {
		this.ctiNew = ctiNew;
	}
	public String getNonListInd() {
		return nonListInd;
	}
	public void setNonListInd(String nonListInd) {
		this.nonListInd = nonListInd;
	}
	public String getWirelessLineInd() {
		return wirelessLineInd;
	}
	public void setWirelessLineInd(String wirelessLineInd) {
		this.wirelessLineInd = wirelessLineInd;
	}
	public String getCtiOld() {
		return ctiOld;
	}
	public void setCtiOld(String ctiOld) {
		this.ctiOld = ctiOld;
	}
	public String getBnaInd() {
		return bnaInd;
	}
	public void setBnaInd(String bnaInd) {
		this.bnaInd = bnaInd;
	}
	public String getBillName1() {
		return billName1;
	}
	public void setBillName1(String billName1) {
		this.billName1 = billName1;
	}
	public String getBillName2() {
		return billName2;
	}
	public void setBillName2(String billName2) {
		this.billName2 = billName2;
	}
	public String getBillName3() {
		return billName3;
	}
	public void setBillName3(String billName3) {
		this.billName3 = billName3;
	}
	public String getBillAddr1() {
		return billAddr1;
	}
	public void setBillAddr1(String billAddr1) {
		this.billAddr1 = billAddr1;
	}
	public String getBillAddr2() {
		return billAddr2;
	}
	public void setBillAddr2(String billAddr2) {
		this.billAddr2 = billAddr2;
	}
	public String getBillAddr3() {
		return billAddr3;
	}
	public void setBillAddr3(String billAddr3) {
		this.billAddr3 = billAddr3;
	}
	public String getCszInd() {
		return cszInd;
	}
	public void setCszInd(String cszInd) {
		this.cszInd = cszInd;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStateAndCountry() {
		return stateAndCountry;
	}
	public void setStateAndCountry(String stateAndCountry) {
		this.stateAndCountry = stateAndCountry;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getBtnOld() {
		return btnOld;
	}
	public void setBtnOld(String btnOld) {
		this.btnOld = btnOld;
	}
	public String getCustCodeOld() {
		return custCodeOld;
	}
	public void setCustCodeOld(String custCodeOld) {
		this.custCodeOld = custCodeOld;
	}
	public String getWtnOld() {
		return wtnOld;
	}
	public void setWtnOld(String wtnOld) {
		this.wtnOld = wtnOld;
	}
	public String getTerminalNumOld() {
		return terminalNumOld;
	}
	public void setTerminalNumOld(String terminalNumOld) {
		this.terminalNumOld = terminalNumOld;
	}
	public String getAcReferenceNum() {
		return acReferenceNum;
	}
	public void setAcReferenceNum(String acReferenceNum) {
		this.acReferenceNum = acReferenceNum;
	}
	public String getAcOrderNum() {
		return acOrderNum;
	}
	public void setAcOrderNum(String acOrderNum) {
		this.acOrderNum = acOrderNum;
	}
	public String getServiceOrderType() {
		return serviceOrderType;
	}
	public void setServiceOrderType(String serviceOrderType) {
		this.serviceOrderType = serviceOrderType;
	}
	public String getServiceOrderNum() {
		return serviceOrderNum;
	}
	public void setServiceOrderNum(String serviceOrderNum) {
		this.serviceOrderNum = serviceOrderNum;
	}
	public String getLanguageInd() {
		return languageInd;
	}
	public void setLanguageInd(String languageInd) {
		this.languageInd = languageInd;
	}
	public String getOrigTC() {
		return origTC;
	}
	public void setOrigTC(String origTC) {
		this.origTC = origTC;
	}
	public String getOrigSI() {
		return origSI;
	}
	public void setOrigSI(String origSI) {
		this.origSI = origSI;
	}
	public String getJointLocalExchInd() {
		return jointLocalExchInd;
	}
	public void setJointLocalExchInd(String jointLocalExchInd) {
		this.jointLocalExchInd = jointLocalExchInd;
	}
	public String getTollCapInd() {
		return tollCapInd;
	}
	public void setTollCapInd(String tollCapInd) {
		this.tollCapInd = tollCapInd;
	}
	public String getPntActivityInd() {
		return pntActivityInd;
	}
	public void setPntActivityInd(String pntActivityInd) {
		this.pntActivityInd = pntActivityInd;
	}
	public String getSicCode() {
		return sicCode;
	}
	public void setSicCode(String sicCode) {
		this.sicCode = sicCode;
	}
	public String getCampaignAcctInd() {
		return campaignAcctInd;
	}
	public void setCampaignAcctInd(String campaignAcctInd) {
		this.campaignAcctInd = campaignAcctInd;
	}
	public String getNewRespPartyInd() {
		return newRespPartyInd;
	}
	public void setNewRespPartyInd(String newRespPartyInd) {
		this.newRespPartyInd = newRespPartyInd;
	}
	public String getJi() {
		return ji;
	}
	public void setJi(String ji) {
		this.ji = ji;
	}
	public String getDialingInd() {
		return dialingInd;
	}
	public void setDialingInd(String dialingInd) {
		this.dialingInd = dialingInd;
	}
	public String getpICChangeChargeInd() {
		return pICChangeChargeInd;
	}
	public void setpICChangeChargeInd(String pICChangeChargeInd) {
		this.pICChangeChargeInd = pICChangeChargeInd;
	}
	public String getOcsc() {
		return ocsc;
	}
	public void setOcsc(String ocsc) {
		this.ocsc = ocsc;
	}
	public String getOcscm() {
		return ocscm;
	}
	public void setOcscm(String ocscm) {
		this.ocscm = ocscm;
	}
	public String getDesiredDueDate() {
		return desiredDueDate;
	}
	public void setDesiredDueDate(String desiredDueDate) {
		this.desiredDueDate = desiredDueDate;
	}
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}	
	public String getPicActiveDeactivDate() {
		return picActiveDeactivDate;
	}
	public void setPicActiveDeactivDate(String picActiveDeactivDate) {
		this.picActiveDeactivDate = picActiveDeactivDate;
	}
	public String getSdInd() {
		return sdInd;
	}
	public void setSdInd(String sdInd) {
		this.sdInd = sdInd;
	}
	public String getTrInd() {
		return trInd;
	}
	public void setTrInd(String trInd) {
		this.trInd = trInd;
	}
	public String getSubscribedCIC() {
		return subscribedCIC;
	}
	public void setSubscribedCIC(String subscribedCIC) {
		this.subscribedCIC = subscribedCIC;
	}
	public String getRestrictedPICInd() {
		return restrictedPICInd;
	}
	public void setRestrictedPICInd(String restrictedPICInd) {
		this.restrictedPICInd = restrictedPICInd;
	}
	public String getDataElemChangeInd() {
		return dataElemChangeInd;
	}
	public void setDataElemChangeInd(String dataElemChangeInd) {
		this.dataElemChangeInd = dataElemChangeInd;
	}
	public String getAggAccountCode() {
		return aggAccountCode;
	}
	public void setAggAccountCode(String aggAccountCode) {
		this.aggAccountCode = aggAccountCode;
	}
	public String getSnaInd() {
		return snaInd;
	}
	public void setSnaInd(String snaInd) {
		this.snaInd = snaInd;
	}
	public String getServiceName1() {
		return serviceName1;
	}
	public void setServiceName1(String serviceName1) {
		this.serviceName1 = serviceName1;
	}
	public String getServiceName2() {
		return serviceName2;
	}
	public void setServiceName2(String serviceName2) {
		this.serviceName2 = serviceName2;
	}
	public String getServiceAddress1() {
		return serviceAddress1;
	}
	public void setServiceAddress1(String serviceAddress1) {
		this.serviceAddress1 = serviceAddress1;
	}
	public String getServiceAddress2() {
		return serviceAddress2;
	}
	public void setServiceAddress2(String serviceAddress2) {
		this.serviceAddress2 = serviceAddress2;
	}
	public String getServiceCSZInd() {
		return serviceCSZInd;
	}
	public void setServiceCSZInd(String serviceCSZInd) {
		this.serviceCSZInd = serviceCSZInd;
	}
	public String getServiceCity() {
		return serviceCity;
	}
	public void setServiceCity(String serviceCity) {
		this.serviceCity = serviceCity;
	}
	public String getServiceState() {
		return serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getServiceZip() {
		return serviceZip;
	}
	public void setServiceZip(String serviceZip) {
		this.serviceZip = serviceZip;
	}
	public String getUniqueIdentifier() {
		return uniqueIdentifier;
	}
	public void setUniqueIdentifier(String uniqueIdentifier) {
		this.uniqueIdentifier = uniqueIdentifier;
	}
	public String getPicActiveDeactivTime() {
		return picActiveDeactivTime;
	}
	public void setPicActiveDeactivTime(String picActiveDeactivTime) {
		this.picActiveDeactivTime = picActiveDeactivTime;
	}
	public String getListingServicesInd() {
		return listingServicesInd;
	}
	public void setListingServicesInd(String listingServicesInd) {
		this.listingServicesInd = listingServicesInd;
	}
	public String getDepositInd() {
		return depositInd;
	}
	public void setDepositInd(String depositInd) {
		this.depositInd = depositInd;
	}
	public String getTollBlockedSSInd() {
		return tollBlockedSSInd;
	}
	public void setTollBlockedSSInd(String tollBlockedSSInd) {
		this.tollBlockedSSInd = tollBlockedSSInd;
	}
	public String getAcPicMediumInd() {
		return acPicMediumInd;
	}
	public void setAcPicMediumInd(String acPicMediumInd) {
		this.acPicMediumInd = acPicMediumInd;
	}
	public String getIsdnInd() {
		return isdnInd;
	}
	public void setIsdnInd(String isdnInd) {
		this.isdnInd = isdnInd;
	}
	public String getMessageTypeInd() {
		return messageTypeInd;
	}
	public void setMessageTypeInd(String messageTypeInd) {
		this.messageTypeInd = messageTypeInd;
	}
	public String getSpecialServicesInd() {
		return specialServicesInd;
	}
	public void setSpecialServicesInd(String specialServicesInd) {
		this.specialServicesInd = specialServicesInd;
	}
	public String getSlindentifier() {
		return slindentifier;
	}
	public void setSlindentifier(String slindentifier) {
		this.slindentifier = slindentifier;
	}
	public String getPtn() {
		return ptn;
	}
	public void setPtn(String ptn) {
		this.ptn = ptn;
	}
	public String getLsPidCode() {
		return lsPidCode;
	}
	public void setLsPidCode(String lsPidCode) {
		this.lsPidCode = lsPidCode;
	}
	public String getBillPeriod() {
		return billPeriod;
	}
	public void setBillPeriod(String billPeriod) {
		this.billPeriod = billPeriod;
	}
	public String getCbtNum() {
		return cbtNum;
	}
	public void setCbtNum(String cbtNum) {
		this.cbtNum = cbtNum;
	}
	public String getWlIndOld() {
		return wlIndOld;
	}
	public void setWlIndOld(String wlIndOld) {
		this.wlIndOld = wlIndOld;
	}
	public String getNameEditByPassIndOld() {
		return nameEditByPassIndOld;
	}
	public void setNameEditByPassIndOld(String nameEditByPassIndOld) {
		this.nameEditByPassIndOld = nameEditByPassIndOld;
	}
	public String getNpi() {
		return npi;
	}
	public void setNpi(String npi) {
		this.npi = npi;
	}
	public String getDateUseInd() {
		return dateUseInd;
	}
	public void setDateUseInd(String dateUseInd) {
		this.dateUseInd = dateUseInd;
	}
	public String getPiccLineInd() {
		return piccLineInd;
	}
	public void setPiccLineInd(String piccLineInd) {
		this.piccLineInd = piccLineInd;
	}
	public String getPtnOld() {
		return ptnOld;
	}
	public void setPtnOld(String ptnOld) {
		this.ptnOld = ptnOld;
	}
	public String getPiccEndUserNotifDate() {
		return piccEndUserNotifDate;
	}
	public void setPiccEndUserNotifDate(String piccEndUserNotifDate) {
		this.piccEndUserNotifDate = piccEndUserNotifDate;
	}
	public String getPiccTerminReasInd() {
		return piccTerminReasInd;
	}
	public void setPiccTerminReasInd(String piccTerminReasInd) {
		this.piccTerminReasInd = piccTerminReasInd;
	}
	public String getReserved1() {
		return reserved1;
	}
	public void setReserved1(String reserved1) {
		this.reserved1 = reserved1;
	}
	public String getReserved2() {
		return reserved2;
	}
	public void setReserved2(String reserved2) {
		this.reserved2 = reserved2;
	}
	public String getReserved3() {
		return reserved3;
	}
	public void setReserved3(String reserved3) {
		this.reserved3 = reserved3;
	}
	public String getReserved4() {
		return reserved4;
	}
	public void setReserved4(String reserved4) {
		this.reserved4 = reserved4;
	}
	public String getReserved5() {
		return reserved5;
	}
	public void setReserved5(String reserved5) {
		this.reserved5 = reserved5;
	}
	public String getReserved6() {
		return reserved6;
	}
	public void setReserved6(String reserved6) {
		this.reserved6 = reserved6;
	}
	public String getReserved7() {
		return reserved7;
	}
	public void setReserved7(String reserved7) {
		this.reserved7 = reserved7;
	}
	public String getReserved8() {
		return reserved8;
	}
	public void setReserved8(String reserved8) {
		this.reserved8 = reserved8;
	}
	public String getReserved9() {
		return reserved9;
	}
	public void setReserved9(String reserved9) {
		this.reserved9 = reserved9;
	}
	public String getReserved10() {
		return reserved10;
	}
	public void setReserved10(String reserved10) {
		this.reserved10 = reserved10;
	}

	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
}
