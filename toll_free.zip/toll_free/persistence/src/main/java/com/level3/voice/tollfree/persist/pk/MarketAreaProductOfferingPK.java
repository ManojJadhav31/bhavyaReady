package com.level3.voice.tollfree.persist.pk;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * This class is to represent the composite
 * key created with the mentioned columns [productOfferingId, marketAreaId] against
 * MarketAreaProductOffering
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Embeddable
public class MarketAreaProductOfferingPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "ProductOfferingId")
	private Long productOfferingId;
	@Column(name = "MarketAreaId")
	private Long marketAreaId;
	
	public Long getProductOfferingId() {
		return productOfferingId;
	}
	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}
	public Long getMarketAreaId() {
		return marketAreaId;
	}
	public void setMarketAreaId(Long marketAreaId) {
		this.marketAreaId = marketAreaId;
	}
}
