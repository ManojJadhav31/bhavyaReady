package com.level3.voice.tollfree.persist.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ServiceLocationDTO;

/**
* This respository is to retrieve/persist the Service Location details in ServiceLocation
* 
* @author <a href="mailto:nnupur.krishnaa@centurylink.com">Nnupur.Krishnaa</a>
*/

@Component
public interface ServiceLocationRepository extends JpaRepository<ServiceLocationDTO, Long> {

	@Query(value="from ServiceLocationDTO where organizationId = ?1 and customerId = ?2 and serviceLocationId = ?3")
	public ServiceLocationDTO getServiceLocationDetails(String organizationId,String customerId, String serviceLocationId);

}



