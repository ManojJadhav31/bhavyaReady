package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Business Unit Charge table used for product offering charge screen
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "BusinessUnitCharge")
public class BusinessUnitChargeDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Id	
	@Column(name = "ChargeId")
	private Long chargeId;
	@Column(name = "BusinessUnit")
	private String businessUnit;
	@Column(name = "ChargeDepartment")
	private String chargeDepartment;
	@Column(name = "Affiliate")
	private String affiliate;
	@Column(name = "CostCode")
	private String costCode;
	@Column(name = "ProfitCenter")
	private String profitCenter;
	@Column(name = "Currency")
	private String currency;

//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "ChargeId")
//	@MapsId
//	private ChargeDTO charge;

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public Long getChargeId() {
		return chargeId;
	}

	public void setChargeId(Long chargeId) {
		this.chargeId = chargeId;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public String getChargeDepartment() {
		return chargeDepartment;
	}

	public void setChargeDepartment(String chargeDepartment) {
		this.chargeDepartment = chargeDepartment;
	}

	public String getAffiliate() {
		return affiliate;
	}

	public void setAffiliate(String affiliate) {
		this.affiliate = affiliate;
	}

	public String getCostCode() {
		return costCode;
	}

	public void setCostCode(String costCode) {
		this.costCode = costCode;
	}

	public String getProfitCenter() {
		return profitCenter;
	}

	public void setProfitCenter(String profitCenter) {
		this.profitCenter = profitCenter;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

}
