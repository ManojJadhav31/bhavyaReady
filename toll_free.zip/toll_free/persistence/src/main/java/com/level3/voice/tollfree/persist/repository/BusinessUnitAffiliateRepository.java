package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.BusinessUnitAffiliateDTO;

/**
 * This repository is to retreive all the business unit affiliate rows based 
 * on the organization id
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public interface BusinessUnitAffiliateRepository extends JpaRepository<BusinessUnitAffiliateDTO, String> {

	@Query(value="from BusinessUnitAffiliateDTO where organizationId = ? ")
	public List<BusinessUnitAffiliateDTO> retrieveProfitCenters(String orgId);
}
