package com.level3.voice.tollfree.persist.pk;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * This class represents the composite key for the ProductWithSpecialEndPoint
 * table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Embeddable
public class ProductWithSpecialEndPointPK implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "ProductOfferingId")
	private Long productOfferingId;
	@Column(name = "SpecialEndPointTypeCode")
	private String specialEndPointTypeCode;

	public Long getProductOfferingId() {
		return productOfferingId;
	}

	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}

	public String getSpecialEndPointTypeCode() {
		return specialEndPointTypeCode;
	}

	public void setSpecialEndPointTypeCode(String specialEndPointTypeCode) {
		this.specialEndPointTypeCode = specialEndPointTypeCode;
	}
}
