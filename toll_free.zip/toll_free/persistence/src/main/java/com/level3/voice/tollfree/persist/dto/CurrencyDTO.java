package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import com.level3.voice.tollfree.persist.vo.ProductDiscPlanVo;

/**
 * The currency data is used to populate
 * the currency dropdown on the product offering
 * charge screen
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "Currency")
@SqlResultSetMapping(
	    name="productDiscountVoResult",  
	    classes={
	      @ConstructorResult(
	        targetClass=ProductDiscPlanVo.class,
	        columns={
	          @ColumnResult(name="discountPlanId", type=Long.class),
	          @ColumnResult(name="discountPlanType", type=String.class)
	          })
	      }
)
public class CurrencyDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "Currency")
	private String currency;
	@Column(name = "CurrencyDesc")
	private String currencyDesc;

	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCurrencyDesc() {
		return currencyDesc;
	}
	public void setCurrencyDesc(String currencyDesc) {
		this.currencyDesc = currencyDesc;
	}
}
