package com.level3.voice.tollfree.persist.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.level3.voice.tollfree.persist.vo.BillingAccountNumberVO;
import com.level3.voice.tollfree.persist.vo.ContactsVO;
import com.level3.voice.tollfree.persist.vo.CountryDetailsVO;
import com.level3.voice.tollfree.persist.vo.CustomerInfoVO;
import com.level3.voice.tollfree.persist.vo.ProductDiscPlanVo;
import com.level3.voice.tollfree.persist.vo.VolumeDiscPlanVO;

/**
 * Repository to connect to network Strategies Existing Stored procedures
 * 
 * @author <a href="mailto:Keerthi.Selvaraj@centurylink.com">Keerthi
 *         selvaraj</a>
 *
 */
@Component
public class TollFreeDataRepository {

	@Autowired
	EntityManager entityManager;

	private static final Logger log = Logger.getLogger(TollFreeDataRepository.class);

	/**
	 * @param organizationId
	 * @param customerId
	 * @return accountInfoList
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getAccountInfo(String organizationId, String customerId) {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("uspw_GetAccounts")
				.registerStoredProcedureParameter("organizationId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("customerId", String.class, ParameterMode.IN)
				.setParameter("organizationId", organizationId).setParameter("customerId", customerId);

		List<Object> accountInfoList = query.getResultList();

		log.info("accountInfoList size: " + accountInfoList.size());
		return accountInfoList;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @return accountInfoList
	 */
	@SuppressWarnings("rawtypes")
	public List getBANServLocInfo(String organizationId, String customerId, String detailType) {
		long startTime = System.currentTimeMillis();
		log.info("@TollFreeDataServiceRepo @getBANServLocInfo Repo took " + startTime);
		List accountInfoList = entityManager.createNativeQuery(
				" SELECT DISTINCT ac.accountnumber,sl.ServiceLocationId,sls.serviceLocationName,sls.controlGroupId FROM  "
						+ " uv_ServiceLocProductOffering sl (NOLOCK) inner join AccountComposition ac on sl.customerid = ac.customerid "
						+ "AND sl.OrganizationId = ac.OrganizationId AND sl.ServiceLocationId = ac.ServiceLocationId inner join ServiceLocation sls on  ac.ServiceLocationId = sls.ServiceLocationId and sls.status = 'A' "
						+ "WHERE sl.OrganizationId = :organizationid AND sl.CustomerId = :customerid AND sl.DetailType in (:detailType) AND sl.Status = 'A'")
				.setParameter("organizationid", organizationId).setParameter("customerid", customerId)
				.setParameter("detailType", detailType).getResultList();

		log.info("accountInfoList size: " + accountInfoList.size());
		long endTime = System.currentTimeMillis();
		log.info("@repo outside @getBANServLocInfo Repo took " + (endTime - startTime));
		return accountInfoList;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @param servLocId
	 * @return customerCICList
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getCustomerCIC(String organizationId, String customerId, String servLocId) {
		List<Object> customerCICList;
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("usp_GetCustomerCIC")
				.registerStoredProcedureParameter("OrgId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("CustId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("ServLocId", String.class, ParameterMode.IN)
				.setParameter("OrgId", organizationId).setParameter("CustId", customerId)
				.setParameter("ServLocId", servLocId);
		customerCICList = query.getResultList();

		log.info("customerCICList size: " + customerCICList.size());
		return customerCICList;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @return serviceLocationList
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getServiceLocation(String organizationId, String customerId) {
		List<Object> serviceLocationList = entityManager.createNativeQuery(
				"select serviceLocationId,serviceLocationName,ControlGroupId from servicelocation where organizationid = :organizationid and customerid = :customerid and status = 'A'")
				.setParameter("organizationid", organizationId).setParameter("customerid", customerId).getResultList();

		log.info("accountInfoList size: " + serviceLocationList.size());
		return serviceLocationList;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @param servLocId
	 * @param detailType
	 * @return productInfoList
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getProductInfo(String organizationId, String customerId, String servLocId, String detailType) {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("usp_NSWeb_GetProducts")
				.registerStoredProcedureParameter("organizationId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("customerId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("serviceLocationId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("detailType", String.class, ParameterMode.IN)
				.setParameter("organizationId", organizationId).setParameter("customerId", customerId)
				.setParameter("serviceLocationId", servLocId).setParameter("detailType", detailType);

		List<Object> productInfoList = query.getResultList();

		log.info("productInfoList size: " + productInfoList.size());
		return productInfoList;

	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @return getCodeTableInfoList
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getCodeTable(String organizationId, String customerId) {
		List<Object> getCodeTableInfoList = entityManager.createNativeQuery(
				"select tableid,tablename,codedigits,NonMandatoryInd  from CustomACTable where OrganizationId=:organizationId and CustomerId= :customerId")
				.setParameter("organizationId", organizationId).setParameter("customerId", customerId).getResultList();

		log.info("getCodeTableInfoList size: " + getCodeTableInfoList.size());
		return getCodeTableInfoList;
	}

	/**
	 * @param productOfferingId
	 * @param organizationId
	 * @param status
	 * @return ratePlan
	 */
	public int getRatePlanInfo(String productOfferingId, String organizationId, String status) {
		int ratePlan = (int) entityManager.createNativeQuery("select RatePlanId from ProductOfferingRatePlan "
				+ "where ProductOfferingId=:productOfferingId  and OrganizationId=:organizationId and Status=:status")
				.setParameter("productOfferingId", productOfferingId).setParameter("organizationId", organizationId)
				.setParameter("status", status).getSingleResult();

		return ratePlan;
	}

	/**
	 * @param productOfferingId
	 * @param organizationId
	 * @return
	 */
	public String getSCIDInfo(String productOfferingId, String organizationId) {
		String scid = (String) entityManager
				.createNativeQuery("select SCID from productoffering "
						+ "where ProductOfferingId=:productOfferingId  and OrganizationId=:organizationId")
				.setParameter("productOfferingId", productOfferingId).setParameter("organizationId", organizationId)
				.getSingleResult();

		return scid;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @return CustomerInfo Object
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getCustomers(String organizationId, String custId) {
		List<Object> custInfo = entityManager
				.createNativeQuery("SELECT CustomerId, CustomerName, OrganizationId,BusOrg " + " FROM Customer "
						+ " WHERE OrganizationId	 =:organizationId  and CustomerId=:custId")
				.setParameter("organizationId", organizationId).setParameter("custId", custId).getResultList();
		return custInfo;
	}

	/**
	 * @param npa
	 * @param nxx
	 * @return npanxx list
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getNPANXX(String npa, String nxx) {
		List<Object> npanxxList = entityManager
				.createNativeQuery("SELECT npa, nxx FROM NPANXX " + " WHERE NPA =:npa  and NXX=:nxx")
				.setParameter("npa", npa).setParameter("nxx", nxx).getResultList();
		return npanxxList;
	}

	/**
	 * @param busOrg
	 * @return busOrgInfo Object
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getBusOrg(String busOrg) {
		List<Object> busOrgInfo = entityManager
				.createNativeQuery(
						"SELECT CustomerId, CustomerName,OrganizationId FROM Customer " + " WHERE BusOrg =:busOrg")
				.setParameter("busOrg", busOrg).getResultList();
		return busOrgInfo;
	}

	/**
	 * 
	 * @param organizationId
	 * @param controlGroupId
	 * @param productOfferingId
	 * @param isFromOneStop
	 * @param oneStopFeatureInd
	 * @return prodfeatures
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getProdFeatures(String organizationId, String customerId, String serviceLocationId,
			String productOfferingId, Boolean isFromOneStop) {
		List<Object> prodfeatures = entityManager
				.createNativeQuery("SELECT FeatureOfferingId, RTRIM (Description) "
						+ " FROM uv_ServiceLocationFeature (NOLOCK) "
						+ " where OrganizationId =:organizationId  and CustomerId =:customerId "
						+ " and ServiceLocationId=:serviceLocationId and ProductOfferingId =:productOfferingId "
						+ " and (ProductType = 'SF' OR ProductType = 'PB')" + appendOneStopIndcheck(isFromOneStop))
				.setParameter("organizationId", organizationId).setParameter("customerId", customerId)
				.setParameter("serviceLocationId", serviceLocationId)
				.setParameter("productOfferingId", productOfferingId).getResultList();
		return prodfeatures;
	}

	private String appendOneStopIndcheck(Boolean isFromOneStop) {
		return isFromOneStop ? " and OneStopFeatureInd='N'" : "";
	}

	/**
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param locationId
	 * @return
	 */
	public Object getServiceLocation(String organizationId, String customerId, String locationId) {
		Object serviceLocation = entityManager.createNativeQuery(
				"select ad.*, cc.CountryTelcrdCode, cc.ECOCountryName from address ad inner join servicelocation sl on sl.AddressId = ad.AddressId and sl.status = 'A' inner join CountryCode cc on cc.countryId = ad.countryId\r\n"
						+ "where ad.OrganizationId = :organizationid and ad.CustomerId = :customerid and sl.ServiceLocationId= :serviceLocationId")
				.setParameter("organizationid", organizationId).setParameter("customerid", customerId)
				.setParameter("serviceLocationId", locationId).getSingleResult();

		return serviceLocation;
	}

	/**
	 * 
	 * @param accoutNumber
	 * @param serviceLocationId
	 * @return
	 */
	public String getBillingAccountNumber(String accoutNumber, String serviceLocationId) {
		String billingAccountNumber = (String) entityManager.createNativeQuery(
				"select a.billingaccountnumber from accountcomposition ac join account a on a.accountnumber = ac.accountnumber and a.OrganizationId = ac.OrganizationId "
						+ "where a.accountnumber = :accountnumber and ac.serviceLocationid = :serviceLocationid")
				.setParameter("accountnumber", accoutNumber).setParameter("serviceLocationid", serviceLocationId)
				.getSingleResult();

		billingAccountNumber = billingAccountNumber == null ? "" : billingAccountNumber.trim();

		return billingAccountNumber;
	}

	/**
	 * 
	 * @param organizationId
	 * @param cutomerId
	 * @param cic
	 * @return
	 */
	public String getCRC(String organizationId, String customerId, String cic) {
		String crc = (String) entityManager
				.createNativeQuery("select customerRoutingCode from customerroutingpreference "
						+ "where organizationid = :organizationid and customerId = :customerId and cic = :cic")
				.setParameter("organizationid", organizationId).setParameter("customerId", customerId)
				.setParameter("cic", cic).getSingleResult();

		crc = crc == null ? "" : crc.trim();

		return crc;
	}

	/**
	 * 
	 * @param custName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getCustomerName(String custName) {
		// TODO Auto-generated method stub
		List<Object> custNameInfo = entityManager
				.createNativeQuery("SELECT CustomerId, CustomerName, OrganizationId,BusOrg " + " FROM Customer "
						+ " WHERE CustomerName LIKE CONCAT('%',:custName,'%')")
				.setParameter("custName", custName).getResultList();
		return custNameInfo;
	}

	/**
	 * @param serviceLocationId
	 * @return String
	 */
	public String getAccountDetails(String serviceLocationId) {
		String accountNumber = (String) entityManager
				.createNativeQuery(
						"select accountnumber from accountcomposition where servicelocationid = :serviceLocationId ")
				.setParameter("serviceLocationId", serviceLocationId).getSingleResult();

		accountNumber = accountNumber == null ? "" : accountNumber.trim();
		log.info("accountNumber @getAccountInfo: " + accountNumber);
		return accountNumber;
	}

	/**
	 * @param productOfferingId
	 * @return
	 */
	public String getProductGroupCode(String productOfferingId) {
		String productGroupCode = (String) entityManager
				.createNativeQuery(
						"select productGroupCode from productoffering where productOfferingId = :productOfferingId ")
				.setParameter("productOfferingId", productOfferingId).getSingleResult();

		productGroupCode = productGroupCode == null ? "" : productGroupCode.trim();
		log.info("accountNumber @getProductGroupCode: " + productGroupCode);
		return productGroupCode;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getServLocInfoForBAN(String organizationId, String customerId, String ban) {
		List<Object> accountInfoList = entityManager.createNativeQuery(
				"SELECT ac.accountNumber, ac.serviceLocationId, sl.serviceLocationName ,sl.ControlGroupId \r\n"
						+ "      FROM AccountComposition ac INNER JOIN ServiceLocation sl on  ac.ServiceLocationId = sl.ServiceLocationId and sl.status = 'A' \r\n"
						+ "      where ac.organizationid = :organizationid and ac.customerid = :customerid and ac.accountNumber=:ban")
				.setParameter("organizationid", organizationId).setParameter("customerid", customerId)
				.setParameter("ban", ban).getResultList();

		return accountInfoList;
	}

	/**
	 * Get billing account number for service location id
	 * 
	 * @param serviceLocationId
	 * @return
	 */
	public String getBillingAccountNumber(String serviceLocationId) {
		String billingAccountNumber = (String) entityManager.createNativeQuery(
				"select a.billingaccountnumber from account a inner join accountcomposition acom on acom.AccountNumber = a.AccountNumber "
						+ "			where acom.ServiceLocationId =:serviceLocationid")
				.setParameter("serviceLocationid", serviceLocationId).getSingleResult();

		billingAccountNumber = billingAccountNumber == null ? "" : billingAccountNumber.trim();

		return billingAccountNumber;
	}

	/**
	 * Get charge code based on the order id from feature extract table
	 * 
	 * @param orderId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getChargeCode(String orderId) {
		List<Object> chargeCodes = entityManager.createNativeQuery(
				"select Charge_Code from FeatureOrderExtract where charge_code is not null and order_id =:orderId")
				.setParameter("orderId", orderId).getResultList();

		return chargeCodes;
	}

	/**
	 * Get the order details [Order date and Service Location id] from the orders
	 * table for the order id
	 * 
	 * @param orderId
	 * @return
	 */
	public Object getOrderDetails(String orderId) {
		Object orderDetails = entityManager
				.createNativeQuery("select OrderDate, serviceLocationId from Orders where OrderNumber =:orderId")
				.setParameter("orderId", orderId).getSingleResult();

		return orderDetails;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getTNInventoryServiceId(String servLocId) {

		List<Object> voiceServiceList = entityManager.createNativeQuery("select top 1 with ties \r\n"
				+ "order_id, BillStartDate, BillEndDate, Installed_Date, scid, Component_Type, soe.BTN, o.ServiceLocationId, o.OrderDate, Service_ID \r\n"
				+ "from serviceorderextract soe inner join service s on serviceid=soe.service_id inner join orders o on o.OrderNumber = soe.Order_ID \r\n"
				+ "where soe.service_scid = :servLocId and s.status='A' \r\n"
				+ "order by row_number() over (partition by soe.scid order by soe.order_id desc) \r\n")
				.setParameter("servLocId", servLocId).getResultList();

		log.info("voiceServiceList size: " + voiceServiceList.size());
		return voiceServiceList;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getTNInventoryFeature(String orderId) {

		List<Object> voiceFeatureList = entityManager
				.createNativeQuery("SELECT distinct charge_code,feature_type_id from FeatureOrderExtract  \r\n"
						+ "  Where  order_id = :orderid and charge_code is not null ")
				.setParameter("orderid", orderId).getResultList();

		log.info("getTNInventoryFeature size: " + voiceFeatureList.size());
		return voiceFeatureList;
	}

	public List<Object> getdefaultProdFeatures(String organizationId, String productOfferingId, String controlGroupId) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Object> defaultprodfeatures = entityManager
				.createNativeQuery("SELECT FeatureOfferingId" + " FROM Offeringfeaturedefault"
						+ " where OrganizationId =:organizationId and ProductOfferingId =:productOfferingId and "
						+ "ControlGroupId=:controlGroupId")
				.setParameter("organizationId", organizationId).setParameter("productOfferingId", productOfferingId)
				.setParameter("controlGroupId", controlGroupId).getResultList();
		return defaultprodfeatures;
	}

	@SuppressWarnings("unchecked")
	public List<CustomerInfoVO> getCustomerInfo(String organizationId) {
		List<CustomerInfoVO> CustomerInfoList = new ArrayList<>();

		List<Object[]> customers = entityManager
				.createNativeQuery("SELECT CustomerId, Status, CustomerName,CustomerCode,CustomerType,ControlGroupId,"
						+ "BusOrg,CustomerBegin,CustomerEnd FROM Customer WHERE OrganizationId =:organizationId")
				.setParameter("organizationId", organizationId).getResultList();

		for (int i = 0; i < customers.size(); i++) {
			CustomerInfoVO newVO = new CustomerInfoVO();
			Object[] tempObject = customers.get(i);
			if (tempObject[0] != null) {
				newVO.setCustomerId(tempObject[0].toString());
			} else {
				newVO.setCustomerId(null);
			}
			if (tempObject[1] != null) {
				newVO.setStatus(tempObject[1].toString());
			} else {
				newVO.setStatus(null);
			}
			if (tempObject[2] != null) {
				newVO.setCustomerName(tempObject[2].toString());
			} else {
				newVO.setCustomerName(null);
			}
			if (tempObject[3] != null) {
				newVO.setCustomerCode(tempObject[3].toString());
			} else {
				newVO.setCustomerCode(null);
			}
			if (tempObject[4] != null) {
				newVO.setCustomerType(tempObject[4].toString());
			} else {
				newVO.setCustomerType(null);
			}
			if (tempObject[5] != null) {
				newVO.setControlGroupId(tempObject[5].toString());
			} else {
				newVO.setControlGroupId(null);
			}
			if (tempObject[6] != null) {
				newVO.setBusOrg(tempObject[6].toString());
			} else {
				newVO.setBusOrg(null);
			}
			if (tempObject[7] != null) {
				newVO.setCustomerBegin(tempObject[7].toString());
			} else {
				newVO.setCustomerBegin(null);
			}
			if (tempObject[8] != null) {
				newVO.setCustomerEnd(tempObject[8].toString());
			} else {
				newVO.setCustomerEnd(null);
			}
			CustomerInfoList.add(newVO);
		}
		return CustomerInfoList;
	}

	@SuppressWarnings("unchecked")
	public List<BillingAccountNumberVO> getAccountDetails(String customerid, String servicelocationid) {
		// TODO Auto-generated method stub
		List<BillingAccountNumberVO> accountdetails = entityManager.createNativeQuery(
				"select CONVERT(VARCHAR, AccountNumber) + CHAR(32) + CHAR(45) + CHAR(32) + RTrim(AccountName) as acc_num_name"
						+ " from uv_IAccountForCustomer where customerid=:customerid and accountnumber= (select accountnumber "
						+ "from accountcomposition where servicelocationid=:servicelocationid)")
				.setParameter("customerid", customerid).setParameter("servicelocationid", servicelocationid)
				.getResultList();

		return accountdetails;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getStatus(String accountNumber) {
		// TODO Auto-generated method stub

		List<Object> status = entityManager
				.createNativeQuery(
						"SELECT AccountStatusCodeDesc  FROM Account a (NOLOCK)  INNER JOIN AccountStatus acs (NOLOCK)"
								+ " ON a.Status = acs.AccountStatusCode WHERE AccountNumber = :accountNumber")
				.setParameter("accountNumber", accountNumber).getResultList();
		return status;
	}

	@SuppressWarnings("unchecked")
	public List<ContactsVO> getContacts(String organizationId, String customerid, String servicelocationid,
			String contactType) {
		// TODO Auto-generated method stub
		List<ContactsVO> ContactsList = new ArrayList<>();

		List<Object[]> contacts = entityManager.createNativeQuery(
				"SELECT a.peopleId, b.firstName, b.lastName, b.company, b.title, b.workPhone, b.workPhoneExt "
						+ "FROM SandStone..ServiceLocationContact a (NOLOCK), SandStone..People b (NOLOCK)WHERE a.peopleId = b.peopleId AND a.OrganizationId  = :organizationId  "
						+ " AND CustomerId =:customerid  AND ServiceLocationId =:servicelocationid   AND ContactType = :contactType")
				.setParameter("organizationId", organizationId).setParameter("customerid", customerid)
				.setParameter("servicelocationid", servicelocationid).setParameter("contactType", contactType)
				.getResultList();
		for (int i = 0; i < contacts.size(); i++) {
			ContactsVO newVO = new ContactsVO();
			Object[] tempObject = contacts.get(i);
			if (tempObject[1] != null) {
				newVO.setFirstName(tempObject[1].toString().trim() + " " + tempObject[2].toString().trim());
			} else {
				newVO.setFirstName(null);
			}
			if (tempObject[5] != null) {
				newVO.setWorkPhone(tempObject[5].toString());
			} else {
				newVO.setWorkPhone(null);
			}
			if (tempObject[4] != null) {
				newVO.setTitle(tempObject[4].toString());
			} else {
				newVO.setTitle(null);
			}
			ContactsList.add(newVO);
		}
		return ContactsList;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getCustomerDetails(String customerId, String serviceLocationId) {
		List<Object> object = entityManager.createNativeQuery(
				"select sl.ServiceLocationName, sl.ServiceLocationId, sl.Status,sl.serviceLocationType , sl.controlGroupId, sl.marketAreaId, sl.PayPhoneDeclarationCode from ServiceLocation sl where serviceLocationId=:serviceLocationId and CustomerId=:customerId and sl.status = 'A' ")
				.setParameter("serviceLocationId", serviceLocationId).setParameter("customerId", customerId)
				.getResultList();

		return object;
	}

	public Object[] getAddressDetails(String customerId, String servicelocationId) {
		Object[] object = (Object[]) entityManager.createNativeQuery(
				"select a.address1 ,a.address2, a.address3 as city,a.address4 as state, a.address5 as postal_code, cp.countryname, a.countyname from address a inner join uv_ICountryPostal cp on cp.countryid = a.countryid where addressId = (select addressId from ServiceLocation where CustomerId =:customerId and servicelocationId =:servicelocationId and status = 'A')")
				.setParameter("servicelocationId", servicelocationId).setParameter("customerId", customerId)
				.getSingleResult();

		return object;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @param serviceLocationId
	 * @return productSumamryList
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getProductSumamry(String organizationId, String customerId, String serviceLocationId) {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("usp_ProductSummaryLocation")
				.registerStoredProcedureParameter("organizationId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("customerId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("serviceLocationId", String.class, ParameterMode.IN)
				.setParameter("organizationId", organizationId).setParameter("customerId", customerId)
				.setParameter("serviceLocationId", serviceLocationId);

		List<Object> productSumamryList = query.getResultList();

		log.info("accountInfoList size: " + productSumamryList.size());
		return productSumamryList;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getPayPhoneBillingData() {
		List<Object> object = entityManager
				.createNativeQuery(
						"select * from CodeMaster  WHERE ContextId = 'PayphoneDeclarationCode' ORDER BY SortPriority")
				.getResultList();
		return object;

	}

	@SuppressWarnings("unchecked")
	public List<Object> getMarketArea() {
		List<Object> object = entityManager.createNativeQuery("select * from uv_IMarketArea where status='A'")
				.getResultList();
		return object;
	}

	public Object[] getControlGroupId(String customerid) {
		long startTime = System.currentTimeMillis();
		Object[] object = (Object[]) entityManager
				.createNativeQuery(" select * from customer where customerid =:customerid and organizationId='WCG'")
				.setParameter("customerid", customerid).getSingleResult();
		long endTime = System.currentTimeMillis();
		log.info("@TollFreeDataServiceManager outside @getControlGroupId took " + (endTime - startTime));
		return object;
	}

	public Object[] getCustAddress(String customerId) {
		// TODO Auto-generated method stub
		Object[] address = (Object[]) entityManager
				.createNativeQuery(
						"select a.Address1, a.Address2, a.Address3, a.Address4, a.Address5,cp.countryid,cp.countryname"
								+ " from address a inner join uv_ICountryPostal cp on cp.countryid = a.countryid where "
								+ "addressid in (select addressid from customer where customerId=:customerId)")
				.setParameter("customerId", customerId).getSingleResult();
		return address;
	}

	@SuppressWarnings("unchecked")
	public List<ContactsVO> getCustContacts(String organizationId, String customerid, String category) {
		// TODO Auto-generated method stub
		List<ContactsVO> ContactsList = new ArrayList<>();

		List<Object[]> contacts = entityManager.createNativeQuery(
				" SELECT a.PeopleId, b.FirstName, b.LastName, b.Company, b.Title, b.WorkPhone, b.WorkPhoneExt "
						+ "FROM SandStone..CustomerContact a (NOLOCK), SandStone..People b (NOLOCK)WHERE a.PeopleId = b.PeopleId  "
						+ "AND a.OrganizationId = :organizationId  AND CustomerId = :customerid AND "
						+ "b.RoleId IN ( SELECT RoleId FROM SandStone..RoleMaster (NOLOCK) WHERE Category = :category )")
				.setParameter("organizationId", organizationId).setParameter("customerid", customerid)
				.setParameter("category", category).getResultList();
		for (int i = 0; i < contacts.size(); i++) {
			ContactsVO newVO = new ContactsVO();
			Object[] tempObject = contacts.get(i);
			if (tempObject[1] != null) {
				newVO.setFirstName(tempObject[1].toString().trim() + " " + tempObject[2].toString().trim());
			} else {
				newVO.setFirstName(null);
			}
			if (tempObject[5] != null) {
				newVO.setWorkPhone(tempObject[5].toString());
			} else {
				newVO.setWorkPhone(null);
			}
			if (tempObject[4] != null) {
				newVO.setTitle(tempObject[4].toString());
			} else {
				newVO.setTitle(null);
			}
			ContactsList.add(newVO);
		}
		return ContactsList;
	}

	public List<ContactsVO> getSalesRepDetails(String organizationId, String customerid, String category) {
		List<ContactsVO> salesRepList = new ArrayList<>();

		@SuppressWarnings("unchecked")
		List<Object[]> salesRep = entityManager.createNativeQuery(
				" SELECT a.PeopleId, b.FirstName, b.LastName, b.Company, b.Title, b.WorkPhone, b.WorkPhoneExt,a.ContactType "
						+ " FROM SandStone..CustomerContact a (NOLOCK), SandStone..People b (NOLOCK)"
						+ " WHERE a.PeopleId = b.PeopleId AND a.OrganizationId = :organizationId AND CustomerId = :customerid "
						+ "AND a.ContactType IN ( SELECT RoleId FROM SandStone..RoleMaster (NOLOCK) WHERE Category = :category )")
				.setParameter("organizationId", organizationId).setParameter("customerid", customerid)
				.setParameter("category", category).getResultList();
		for (int i = 0; i < salesRep.size(); i++) {
			ContactsVO newVO = new ContactsVO();
			Object[] tempObject = salesRep.get(i);
			if (tempObject[1] != null) {
				newVO.setFirstName(tempObject[1].toString().trim() + " " + tempObject[2].toString().trim());
			} else {
				newVO.setFirstName(null);
			}
			if (tempObject[5] != null) {
				newVO.setWorkPhone(tempObject[5].toString());
			} else {
				newVO.setWorkPhone(null);
			}
			if (tempObject[4] != null) {
				newVO.setTitle(tempObject[4].toString());
			} else {
				newVO.setTitle(null);
			}
			salesRepList.add(newVO);
		}
		return salesRepList;

	}

	public List<String> getIntraLataDetails(String customerid, String organizationId) {
		{
			@SuppressWarnings("unchecked")
			List<String> intraLata = (List<String>) entityManager.createNativeQuery(
					" SELECT PreferenceValue  FROM CustomerPreference (NOLOCK)  WHERE  CustomerId = :customerid  AND PreferenceName= 'IntraLataEnabled' AND OrganizationId = :organizationId")
					.setParameter("customerid", customerid).setParameter("organizationId", organizationId)
					.getResultList();
			return intraLata;
		}
	}

	@SuppressWarnings("unchecked")
	public List<ProductDiscPlanVo> getProductDiscPLan(String customerid, String organizationId) {
		List<ProductDiscPlanVo> productDiscPLan = (List<ProductDiscPlanVo>) entityManager.createNativeQuery(
				" SELECT DiscountPlanId, DiscountPlanType FROM SandStone..CustomerDiscountPlan(NOLOCK) "
						+ "Where OrganizationId = :organizationId  AND CustomerId = :customerid  and discountplantype='P'",
				"productDiscountVoResult").setParameter("customerid", customerid)
				.setParameter("organizationId", organizationId).getResultList();

		return productDiscPLan;
	}

	@SuppressWarnings("unchecked")
	public List<VolumeDiscPlanVO> getVolumeDiscPLan(String customerid, String organizationId) {
		List<VolumeDiscPlanVO> volumeDiscountPlanList = new ArrayList<>();

		List<Object[]> volumeDiscPLan = (List<Object[]>) entityManager.createNativeQuery(
				" SELECT cdp.DiscountPlanId, cdp.DiscountPlanType, vdp.description FROM SandStone..CustomerDiscountPlan(NOLOCK) cdp"
						+ " inner join  uv_IVolumeDiscountPlan vdp on cdp.discountplanId=vdp.DiscountPlanId where cdp.OrganizationId = :organizationId "
						+ " AND cdp.CustomerId = :customerid  and cdp.discountplantype='V'")
				.setParameter("customerid", customerid).setParameter("organizationId", organizationId).getResultList();
		for (int i = 0; i < volumeDiscPLan.size(); i++) {
			VolumeDiscPlanVO newVO = new VolumeDiscPlanVO();
			Object[] tempObject = volumeDiscPLan.get(i);
			if (tempObject[0] != null) {
				newVO.setDiscountPlanId(tempObject[0].toString().trim());
			} else {
				newVO.setDiscountPlanId(null);
			}
			if (tempObject[1] != null) {
				newVO.setDiscountPlanType(tempObject[1].toString());
			} else {
				newVO.setDiscountPlanType(null);
			}
			if (tempObject[2] != null) {
				newVO.setDescription(tempObject[2].toString());
			} else {
				newVO.setDescription(null);
			}
			volumeDiscountPlanList.add(newVO);
		}
		return volumeDiscountPlanList;
	}

	public CountryDetailsVO getCountryDetails(String countryid) {
		// TODO Auto-generated method stub
		CountryDetailsVO countryInfo = (CountryDetailsVO) entityManager
				.createNativeQuery("select * from uv_ICountryPostal where countryid=:countryid", "countryDetailsResult")
				.setParameter("countryid", countryid).getSingleResult();
		// String countryInfor = countryInfo == null ? "" :
		// countryInfo[0].toString().trim();
		return countryInfo;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getCustAccInfo(String customerid, String organizationId) {
		log.debug("parameter into the repo:" + customerid + "and :" + organizationId);
		List<Object> accountdetails = entityManager.createNativeQuery(
				" select ac.accountnumber,uac.accountname   FROM SandStone..AccountComposition ac (NOLOCK) inner join uv_IAccountForCustomer uac on ac.accountnumber=uac.accountnumber WHERE"
						+ " ac.OrganizationId = :organizationId AND ac.CustomerId = :customerid AND "
						+ "ac.begindate = (select min(begindate) from accountcomposition where  OrganizationId = :organizationId AND CustomerId= :custId)")
				.setParameter("customerid", customerid).setParameter("organizationId", organizationId)
				.setParameter("custId", customerid).getResultList();

		return accountdetails;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getProductOfferingInfo(String organizationId, String productOfferingId) {
		// TODO Auto-generated method stub
		List<Object> prodOffInfo = (List<Object>) entityManager.createNativeQuery(
				"select * from productOffering where organizationId=:organizationId and productOfferingId=:productOfferingId")
				.setParameter("organizationId", organizationId).setParameter("productOfferingId", productOfferingId)
				.getResultList();
		return prodOffInfo;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @param servLocId
	 * @return customerCICList
	 */
	@SuppressWarnings("unchecked")
	public String getDefaultCIC(String organizationId, String customerId, String servLocId) {
		List<Object> defaultCIC;
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("usp_Validate1SCIC")
				.registerStoredProcedureParameter("OrgId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("CustId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("ServLocId", String.class, ParameterMode.IN)
				.registerStoredProcedureParameter("CIC", String.class, ParameterMode.IN)
				.setParameter("OrgId", organizationId).setParameter("CustId", customerId)
				.setParameter("ServLocId", servLocId).setParameter("CIC", "");
		defaultCIC = query.getResultList();

		log.info("customer default CIC: " + defaultCIC.size());
		return (defaultCIC.size() > 0) ? defaultCIC.get(0).toString() : null;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getBanServLoc(String organizationId, String customerId, String detailType) {
		List<Object> banList = entityManager.createNativeQuery(
				"select * from uv_GetBanServLocation where customerId=:customerId and detailType in (:detailType)")
				.setParameter("customerId", customerId).setParameter("detailType", detailType).getResultList();
		return banList;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @return CustomerInfo Object
	 */
	public Object getBizOrgForInHouseAcc(String organizationId, String custId) {
		Object custInfo = entityManager
				.createNativeQuery("SELECT EmailAddress " + " FROM Customer "
						+ " WHERE OrganizationId =:organizationId  and CustomerId=:custId")
				.setParameter("organizationId", organizationId).setParameter("custId", custId).getSingleResult();
		return custInfo;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getProductOffering(List<Integer> prodOfferingIds) {
		// TODO Auto-generated method stub
		List<Object> prodOffInfo = (List<Object>) entityManager.createNativeQuery(
				"select productOfferingId,Description from productOffering where organizationId='WCG' and productOfferingId in (:productOfferingIds)")
				.setParameter("productOfferingIds", prodOfferingIds).getResultList();
		return prodOffInfo;
	}

	@Modifying
	@Transactional
	public void completeBatchDropStatus(String fileName, String customerId) {
		entityManager.createNativeQuery(
				"Update NSTickets..BatchDrop  SET status='C' WHERE customerId =:customerId and fileName =:fileName ")
				.setParameter("fileName", fileName).setParameter("customerId", customerId).executeUpdate();
	}

	@Modifying
	@Transactional
	public int getBatchDropStatus(String fileName, String customerId) {
		int count = (int) entityManager
				.createNativeQuery("select count(*) from NSTickets..BatchDrop "
						+ "where fileName = :fileName and customerId = :customerId and status='I'")
				.setParameter("fileName", fileName).setParameter("customerId", customerId).getSingleResult();
		return count;
	}

	/**
	 * Method used to identified if the diff ban is enabled
	 * for tollfree BANs
	 * 
	 * @param ban
	 * @return
	 */
	public String isDifferentBanEnabled(String ban) {
		String preferenceValue = null;
		try {
			preferenceValue = (String) entityManager.createNativeQuery(
					"select cp.PreferenceValue from AccountComposition ac join CustomerPreference cp on cp.CustomerId = ac.CustomerId and PreferenceName = 'Diff BAN' "
					+ "where ac.serviceLocationid <> 'Null' and ac.Status = 'A' and ac.AccountNumber = :ban")
					.setParameter("ban", ban).getSingleResult();
		} catch (Exception e) {
			log.error("@isDifferentBanEnabled: failed to retrieve data" + e);
		}

		log.info("preferenceValue @isDifferentBanEnabled: " + preferenceValue);
		return (!StringUtils.isEmpty(preferenceValue) && preferenceValue.equalsIgnoreCase("Y")) ? Boolean.TRUE.toString() : Boolean.FALSE.toString();
	}

	/**
	 * Retrieve all bans for the selected ban
	 * 
	 * @param ban
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getCustomerBans(String ban) {
		List<Object> banList = null;
		try {
			banList = entityManager.createNativeQuery(
					"select distinct uvg.accountnumber from uv_GetBanServLocation uvg join AccountComposition ac on ac.CustomerId = uvg.CustomerId and detailType in ('8S','8D') "
					+ "where ac.AccountNumber = :ban and ac.Status = 'A'")
					.setParameter("ban", ban).getResultList();
		} catch (Exception e) {
			log.error("@getCustomerBans: failed to retrieve data" + e);
		}
		return banList;
	}
}
