package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

public class CdrServiceComposite implements Serializable {
	private Long account;
	private String serviceType;

}
