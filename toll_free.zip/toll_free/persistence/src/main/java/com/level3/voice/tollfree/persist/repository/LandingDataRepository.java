
package com.level3.voice.tollfree.persist.repository;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.LandingScreenDTO;
import com.level3.voice.tollfree.persist.vo.FeaturesVO;
import com.level3.voice.tollfree.persist.vo.LandingScreenSearchVO;
import com.level3.voice.tollfree.persist.vo.SearchScreenInputVO;

@Component

public class LandingDataRepository {

	@Autowired
	EntityManager entityManager;

	@Autowired
	TNSearchRepository tnDearchRepository;

	@Value("#{'${list.of.features}'.split(',')}")
	private List<String> featuresGroup;

	public List<LandingScreenDTO> getVoiceData(SearchScreenInputVO landingScreenReqParams) throws ParseException {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();

		CriteriaQuery<LandingScreenDTO> query = cb.createQuery(LandingScreenDTO.class);
		Root<LandingScreenDTO> landingScreenDTO = query.from(LandingScreenDTO.class);

		List<Predicate> predicates = new ArrayList<Predicate>();

		if (landingScreenReqParams.getVoiceOrderId() != null
				&& landingScreenReqParams.getVoiceOrderId().toString().trim().length() > 0) {
			predicates.add(cb.equal(landingScreenDTO.get("voiceOrderId"), landingScreenReqParams.getVoiceOrderId()));
		}
		if (landingScreenReqParams.getOrderType() != null
				&& landingScreenReqParams.getOrderType().toString().trim().length() > 0) {
			predicates.add(cb.equal(landingScreenDTO.get("orderType"), landingScreenReqParams.getOrderType()));
		}

		query.select(landingScreenDTO).where(predicates.toArray(new Predicate[] {}));
		List<LandingScreenDTO> landingScreenDTOs = entityManager.createQuery(query).getResultList();
		return landingScreenDTOs;

	}

	@SuppressWarnings("unchecked")
	public List<LandingScreenSearchVO> getDataForSearch(SearchScreenInputVO landingScreenReqParams)
			throws ParseException {

		List<Object[]> landingScreenDTOs = new ArrayList<>();

		List<LandingScreenSearchVO> landingScreenSearchlist = new ArrayList<>();

		Map<String, String> featureDetails = getFeatureDetails();

		String voiceDataQuery = "SELECT sl.ORDER_COMPLETE_DATE, ot.SERVICE_ID as serv_id, tno.TOLLFREE_SUBSCRIBER_LINE_ID,at.name,os.name as status,  \r\n"
				+ "				 sl.VOICE_ORDER_ID,sl.order_active_yn,tcs.description,oso.name as sourceSystem,  \r\n"
				+ "				 lprd.si,lprd.tc,sl.external_customer_id,sl.order_date,sl.create_user, \r\n"
				+ "				 osv.status as order_status,  \r\n"
				+ "				 ssv.status as service_status, ot.*, \r\n"
				+ "				(select oa.order_activity_pk from order_activity oa  \r\n"
				+ "				          WHERE ot.sl_order_id = oa.sl_order_id and oa.activity_type_id=916 and oa.status!=3) as err_lec_order_activity_pk, sl.last_updated_user as slo_last_updated_user \r\n"
				+ "				 FROM ORDER_TOLLFREE_FEATURES ot INNER JOIN SL_ORDER sl ON sl.SL_ORDER_ID=ot.SL_ORDER_ID   \r\n"
				+ "				 INNER JOIN tn_order tno ON tno.sl_order_id = sl.sl_order_id   \r\n"
				+ "				 INNER JOIN action_type at ON at.action_type_id = sl.action_type_id   \r\n"
				+ "				 INNER JOIN ORDER_STATUS os on os.ORDER_STATUS_ID = sl.ORDER_STATUS_ID  \r\n"
				+ "				 INNER JOIN ORDER_SOURCE oso on oso.ORDER_SOURCE_ID = sl.ORDER_SOURCE_ID \r\n"
				+ "				 left outer JOIN lec_response lprd on lprd.AC_ORDER_NUM = sl.sl_order_id  \r\n"
				+ "				 left outer JOIN TCSI tcs on tcs.tc = lprd.tc and tcs.si = lprd.si  \r\n"
				+ "				 left outer JOIN SUBL_OWNER.GET_ORDER_STATUS_VIEW osv on osv.sl_order_id = sl.SL_ORDER_ID   \r\n"
				+ "				 left outer JOIN SUBL_OWNER.GET_SERVICE_STATUS_VIEW ssv on ssv.sl_order_id = sl.sl_order_id\r\n"
				+ getWhereData(landingScreenReqParams);

		landingScreenDTOs = entityManager.createNativeQuery(voiceDataQuery).getResultList();
		for (int i = 0; i < landingScreenDTOs.size(); i++) {
			LandingScreenSearchVO newVO = new LandingScreenSearchVO();
			FeaturesVO featuredto = new FeaturesVO();
			List<FeaturesVO> featureVO = new ArrayList<>();

			Object[] tempObject = (Object[]) landingScreenDTOs.get(i);
			if (tempObject[17] != null) {
				newVO.setTn(tempObject[17].toString());
			} else {
				newVO.setTn(null);
			}
			if (tempObject[20] != null) {
				newVO.setBtn(tempObject[20].toString());
			} else {
				newVO.setBtn(null);
			}
			if (tempObject[22] != null) {
				newVO.setProductOfferingId(tempObject[22].toString());
			}
			if (tempObject[24] != null) {
				newVO.setCic(tempObject[24].toString());
			} else {
				newVO.setCic(null);
			}
			if (tempObject[36] != null && (tempObject[36].toString()).equals("B")) {
				newVO.setJurisdiction("Inter & Intra LATA");
			} else if (tempObject[36] != null && (tempObject[36].toString()).equals("E")) {
				newVO.setJurisdiction("Inter LATA");
			} else {
				newVO.setJurisdiction(null);
			}
			if (tempObject[33] != null) {
				newVO.setPicRequest(tempObject[33].toString());
			}
			if (tempObject[31] != null) {
				newVO.setForcedANI(tempObject[31].toString());
			} else {
				newVO.setForcedANI(null);
			}
			if (tempObject[41] != null) {
				newVO.setScid(tempObject[41].toString());
			} else {
				newVO.setScid(null);
			}
			if (tempObject[1] != null) {
				newVO.setServiceId(tempObject[1].toString());
			} else {
				newVO.setServiceId(null);
			}
			if (tempObject[5] != null) {
				newVO.setVoiceOrderId(tempObject[5].toString());
			} else {
				newVO.setVoiceOrderId(null);
			}
			if (tempObject[45] != null) {
				newVO.setBan(tempObject[45].toString());
			} else {
				newVO.setBan(null);
			}
			if (tempObject[48] != null) {
				newVO.setOcn(tempObject[48].toString());

			} else {
				newVO.setOcn(null);
			}
			if (tempObject[49] != null) {
				newVO.setLec(tempObject[49].toString());

			} else {
				newVO.setLec(null);
			}

			if (tempObject[7] != null) {
				newVO.setTcsiDesc(tempObject[7].toString());
			} else {
				newVO.setTcsiDesc(null);
			}
			if (tempObject[44] != null && tempObject[43] != null) {
				newVO.setServiceLocationId(tempObject[44].toString() + "/" + tempObject[43].toString());
			} else {
				newVO.setServiceLocationId(null);
			}
			if (tempObject[3] != null) {
				newVO.setOrderType(tempObject[3].toString());
			} else {
				newVO.setOrderType(null);
			}
			/*
			 * if(tempObject[40] != null){ newVO.setOrderStatus(tempObject[40].toString());
			 * }else{ newVO.setOrderStatus(null); }
			 */
			if (tempObject[0] != null) {
				newVO.setOrderCompleteDate(tempObject[0].toString());
			} else {
				newVO.setOrderCompleteDate(null);
			}
			if (tempObject[6] != null) {
				newVO.setOrderActive(tempObject[6].toString());
			} else {
				newVO.setOrderActive(null);
			}
			if (tempObject[8] != null) {
				newVO.setSourceSystem(tempObject[8].toString());
			} else {
				newVO.setSourceSystem(null);
			}
			if (tempObject[10] != null) {
				newVO.setTc(tempObject[10].toString());
			} else {
				newVO.setTc(null);
			}
			if (tempObject[9] != null) {
				newVO.setSi(tempObject[9].toString());
			} else {
				newVO.setSi(null);
			}
			if (tempObject[11] != null) {
				newVO.setCustomerId(tempObject[11].toString());
			} else {
				newVO.setCustomerId(null);
			}
			if (tempObject[12] != null) {
				newVO.setOrderDate(tempObject[12].toString());
			}
			if (tempObject[14] != null) {
				newVO.setOrderStatus(tempObject[14].toString());
			}

			if (tempObject[15] != null) {
				newVO.setServiceStatus(tempObject[15].toString());
			}

			// features....
			if (tempObject[25] != null) {
				featuredto = new FeaturesVO();
				featuredto.setFeatureDescription(featureDetails.get(tempObject[25]));
				featuredto.setFeatureOfferingId(tempObject[25].toString());
				featureVO.add(featuredto);
			}
			if (tempObject[26] != null) {
				featuredto = new FeaturesVO();
				featuredto.setFeatureDescription(featureDetails.get(tempObject[26]));
				featuredto.setFeatureOfferingId(tempObject[26].toString());
				featureVO.add(featuredto);
			}
			if (tempObject[27] != null) {
				featuredto = new FeaturesVO();
				featuredto.setFeatureDescription(featureDetails.get(tempObject[27]));
				featuredto.setFeatureOfferingId(tempObject[27].toString());
				featureVO.add(featuredto);
			}
			if (tempObject[28] != null) {
				featuredto = new FeaturesVO();
				featuredto.setFeatureDescription(featureDetails.get(tempObject[28]));
				featuredto.setFeatureOfferingId(tempObject[28].toString());
				featureVO.add(featuredto);
			}
			if (tempObject[29] != null) {
				featuredto = new FeaturesVO();
				featuredto.setFeatureDescription(featureDetails.get(tempObject[29]));
				featuredto.setFeatureOfferingId(tempObject[29].toString());
				featureVO.add(featuredto);
			}
			if (tempObject[30] != null) {
				featuredto = new FeaturesVO();
				featuredto.setFeatureDescription(featureDetails.get(tempObject[30]));
				featuredto.setFeatureOfferingId(tempObject[30].toString());
				featureVO.add(featuredto);
			}

			if (tempObject[37] != null) {
				featuredto = new FeaturesVO();
				String featDesc = null;
				String isMandatory=null;
				
				if(tempObject[40] != null && tempObject[50] != null) {
					if(tempObject[50].toString().equalsIgnoreCase("C")) {
						isMandatory="M";
					}
					else if(tempObject[50].toString().equalsIgnoreCase("Y")) {
						isMandatory="N";
					}				
					
					featDesc = featureDetails.get(tempObject[37]) +" ["+tempObject[40].toString()+"_"+isMandatory+"]";
				}else {
					featDesc = featureDetails.get(tempObject[37]);
				}
				
				featuredto.setFeatureDescription(featDesc);
				featuredto.setFeatureOfferingId(tempObject[37].toString());
				featureVO.add(featuredto);
			}
			if (tempObject[38] != null) {
				featuredto = new FeaturesVO();
				String featDesc = null;
				String isMandatory=null;
				if( tempObject[50] != null) {
				if(tempObject[50].toString().equalsIgnoreCase("U")) {
					isMandatory="M";
				}
				else if(tempObject[50].toString().equalsIgnoreCase("N")) {
					isMandatory=tempObject[50].toString();
				}
				if(tempObject[50] != null) {
					featDesc = featureDetails.get(tempObject[38]) + " ["+isMandatory+"]";
				}else {
					featDesc = featureDetails.get(tempObject[38]);
				}
				}
				
				featuredto.setFeatureDescription(featDesc);
				featuredto.setFeatureOfferingId(tempObject[38].toString());
				featureVO.add(featuredto);
			}
			if (tempObject[52] != null) {
				featuredto = new FeaturesVO();
				featuredto.setFeatureDescription(featureDetails.get(tempObject[52]));
				featuredto.setFeatureOfferingId(tempObject[52].toString());
				featureVO.add(featuredto);
			}

			newVO.setFeatureVo(featureVO);

			if (tempObject[54] != null) {
				newVO.setErrOrderActivityPk(tempObject[54].toString());
			}

			if (tempObject[13] != null) {
				newVO.setCreateUser(tempObject[13].toString());
			} else {
				newVO.setCreateUser(null);
			}
			if (tempObject[55] != null) {
				newVO.setLastUpdatedUser(tempObject[55].toString());
			}
			landingScreenSearchlist.add(newVO);
		}

		return landingScreenSearchlist;
	}

	private String getWhereData(SearchScreenInputVO landingScreenReqParams) throws ParseException {
		String data = "";

		if (!StringUtils.isEmpty(landingScreenReqParams.getTn())) {
			data = addWhereAndData(data);
			data = data + " ot.tn= '" + landingScreenReqParams.getTn() + "'";

		}
		if (!StringUtils.isEmpty(landingScreenReqParams.getVoiceOrderId())) {
			data = addWhereAndData(data);
			data = data + " sl.voice_order_id= '" + landingScreenReqParams.getVoiceOrderId() + "'";
		}

		/*
		 * if (landingScreenReqParams.getCustomerNumber() != null &&
		 * landingScreenReqParams.getCustomerNumber().toString().trim().length() > 0) {
		 * data = addWhereAndData(data); data = data + " sl.EXTERNAL_CUSTOMER_ID= '" +
		 * landingScreenReqParams.getCustomerNumber() + "'"; }
		 */
		if (!StringUtils.isEmpty(landingScreenReqParams.getCustomerId())) {
			data = addWhereAndData(data);
			data = data + " sl.external_customer_id= '" + landingScreenReqParams.getCustomerId() + "'";
		}

		if (!StringUtils.isEmpty(landingScreenReqParams.getBtn())) {
			data = addWhereAndData(data);
			data = data + " ot.btn= '" + landingScreenReqParams.getBtn() + "'";
		}
		if (landingScreenReqParams.getBan() != null && landingScreenReqParams.getBan().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + "( ot.billing_acc_num= '" + landingScreenReqParams.getBan() + "' OR "
					+ " ot.service_address_id= '" + landingScreenReqParams.getBan() + "' )";
		}
		if (!StringUtils.isEmpty(landingScreenReqParams.getOrderStatus())) {
			data = addWhereAndData(data);
			data = data + " osv.status= '" + landingScreenReqParams.getOrderStatus() + "'";
		}
		if (!StringUtils.isEmpty(landingScreenReqParams.getTc())) {
			data = addWhereAndData(data);
			data = data + " lprd.tc= '" + landingScreenReqParams.getTc() + "'";
		}
		if (!StringUtils.isEmpty(landingScreenReqParams.getSi())) {
			data = addWhereAndData(data);
			data = data + " lprd.si= '" + landingScreenReqParams.getSi() + "'";
		}

		if (!StringUtils.isEmpty(landingScreenReqParams.getOrderType())) {
			data = addWhereAndData(data);
			data = data + " at.name = '" + landingScreenReqParams.getOrderType() + "'";
		}

		/*
		 * if (landingScreenReqParams.getCustomerRequestDate() != null &&
		 * landingScreenReqParams.getCustomerRequestDate().toString().trim().length() >
		 * 0) { data = addWhereAndData(data); data = data +
		 * " (vo.customer_request_date >= " + "TO_DATE('"+
		 * landingScreenReqParams.getCustomerRequestDate() +"', 'yyyy-mm-dd') " +
		 * " and vo.customer_request_date < " + "TO_DATE('"+
		 * landingScreenReqParams.getCustomerRequestDate() +"', 'yyyy-mm-dd') + 1) "; }
		 * 
		 * if (!StringUtils.isEmpty(landingScreenReqParams.getOrderCompleteDate())) {
		 * data = addWhereAndData(data); data = data + " (sl.order_complete_date >= " +
		 * "TO_DATE('"+ landingScreenReqParams.getOrderCompleteDate().toString()
		 * +"', 'YYYY-MM-DD') " + " and sl.order_complete_date < " + "TO_DATE('"+
		 * landingScreenReqParams.getOrderCompleteDate().toString()
		 * +"', 'YYYY-MM-DD') + 1)"; }
		 */

		if (!StringUtils.isEmpty(landingScreenReqParams.getOrderCompleteDate())) {
			data = addWhereAndData(data);
			data = data + " TRUNC(sl.order_complete_date) = '" + landingScreenReqParams.getOrderCompleteDate() + "'";
		}

		return data;
	}

	private String addWhereAndData(String data) {
		if (StringUtils.isEmpty(data)) {
			data = data + " where ";
		} else {
			data = data + " and ";
		}
		return data;
	}

	public List<LandingScreenSearchVO> getDataFromVoid(SearchScreenInputVO landingScreenReqParams) {
		// TODO Auto-generated method stub
		return null;
	}

	private Map<String, String> getFeatureDetails() {
		Map<String, String> featureDetails = new HashMap<String, String>();

		for (String featureGroup : featuresGroup) {
			String[] features = featureGroup.split(":");
			featureDetails.put(features[0], features[1]);
		}

		return featureDetails;
	}
}