package com.level3.voice.tollfree.persist.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.MarketAreaProductOfferingDTO;

/**
 * This respository is to retrieve/persist the market area for the
 * product offering selected by the user in MarketAreaProductOffering
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Component
public interface MarketAreaProductOfferingRepository extends JpaRepository<MarketAreaProductOfferingDTO, Long> {

	@Query(value="from MarketAreaProductOfferingDTO where organizationId = ? and productOfferingId = ?")
	public MarketAreaProductOfferingDTO findMarketAreaProductOffering(String organizationId,Long productOfferingId);

}
