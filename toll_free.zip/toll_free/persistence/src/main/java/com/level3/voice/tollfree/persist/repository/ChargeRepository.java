package com.level3.voice.tollfree.persist.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ChargeDTO;

/**
 * This repository is to retrieve/persist charge details from charge table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Component
public interface ChargeRepository extends JpaRepository<ChargeDTO, Long> {

	@Query(value="select MAX(cDto.chargeId) from ChargeDTO cDto")
	public Long getMaxChargeid();

	@Query(value="from ChargeDTO where chargeId = ?")
	public ChargeDTO findChargeByChargeId(Long chargeId);
}
