package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.level3.voice.tollfree.persist.pk.ChargeStructureQuantityPK;

/**
 * This DTO is the representation of the ChargeStructureQuantity table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "ChargeStructureQuantity")
public class ChargeStructureQuantityDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ChargeStructureQuantityPK chargeStructureQuantityPK;
	
	@Column(name = "ChargeAmount")
	private Long chargeAmount;
	@Column(name = "Description")
	private String description;
	
	@Transient
	private Long chargeId;
	@Transient
	private String organizationId;
	@Transient
	private Long quantity;

//	@Id
//	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
//	@JoinColumn(name = "ChargeId")
//	@MapsId("chargeStructureQuantityDTOs")
//	private ChargeDTO charge;

	public Long getQuantity() {
		return quantity;
	}

	public Long getChargeAmount() {
		return chargeAmount;
	}

	public String getDescription() {
		return description;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public void setChargeAmount(Long chargeAmount) {
		this.chargeAmount = chargeAmount;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public ChargeStructureQuantityPK getChargeStructureQuantityPK() {
		return chargeStructureQuantityPK;
	}

	public void setChargeStructureQuantityPK(ChargeStructureQuantityPK chargeStructureQuantityPK) {
		this.chargeStructureQuantityPK = chargeStructureQuantityPK;
	}

	public Long getChargeId() {
		return chargeId;
	}

	public void setChargeId(Long chargeId) {
		this.chargeId = chargeId;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	
}
