package com.level3.voice.tollfree.persist.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.level3.voice.tollfree.persist.dto.GetNoResponseFtpDTO;


/**
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */
@Transactional
public interface NoResponseFtpRepository extends JpaRepository<GetNoResponseFtpDTO, Long> {
	@Query(value="from getNoResponseFtpView where entryDate >= ? and entryDate <=?")
	public List<GetNoResponseFtpDTO> getAllFtpData(Date startDate, Date endDate);

}
