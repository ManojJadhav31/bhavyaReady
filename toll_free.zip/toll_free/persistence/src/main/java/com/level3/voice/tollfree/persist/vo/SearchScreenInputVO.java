package com.level3.voice.tollfree.persist.vo;

import java.io.Serializable;


public class SearchScreenInputVO implements Serializable{

	private static final long serialVersionUID = 1L;


	private String voiceOrderId;
	private String customerNumber;
	private String customerRequestDate;
	private String orderType;
	private String tn;	
	private String btn ;
	private String ban ;
	private String customerId ;
	private String orderStatus ;
	private String tc ;
	private String si ;
	private String orderCompleteDate ;
	
	public String getVoiceOrderId() {
		return voiceOrderId;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public String getCustomerRequestDate() {
		return customerRequestDate;
	}
	public String getOrderType() {
		return orderType;
	}
	public String getTn() {
		return tn;
	}
	
	public String getOrderCompleteDate() {
		return orderCompleteDate;
	}
	public void setVoiceOrderId(String voiceOrderId) {
		this.voiceOrderId = voiceOrderId;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public void setCustomerRequestDate(String customerRequestDate) {
		this.customerRequestDate = customerRequestDate;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	
	public void setOrderCompleteDate(String orderCompleteDate) {
		this.orderCompleteDate = orderCompleteDate;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public String getBan() {
		return ban;
	}
	public void setBan(String ban) {
		this.ban = ban;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}


}
