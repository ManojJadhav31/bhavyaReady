package com.level3.voice.tollfree.persist.repository;

import java.math.BigDecimal;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.level3.voice.tollfree.persist.dto.TollFreeSubsciberLineDTO;

@Transactional
public interface TollFreeSubsciberLineRepository extends JpaRepository<TollFreeSubsciberLineDTO, Long> {

	@Query(value = "SELECT GENERIC_SEQ.nextval FROM DUAL", nativeQuery = true)
	BigDecimal getGenericNextval();

	@Query(value = "SELECT dto FROM TOLLFREE_SUBSCRIBER_LINE dto WHERE dto.tn = ?1 AND dto.activeYn = 'Y'")
	TollFreeSubsciberLineDTO findByTn(String tn);

	@Query(value = "select count(sbl) from TOLLFREE_SUBSCRIBER_LINE sbl where sbl.tn=?1 and sbl.activeYn=('Y')")
	public int hasPendingOrdersForTollFreeTn(String tn);

}
