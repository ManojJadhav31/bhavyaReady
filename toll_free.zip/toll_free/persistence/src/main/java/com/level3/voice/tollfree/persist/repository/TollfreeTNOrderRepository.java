package com.level3.voice.tollfree.persist.repository;

import java.util.Date;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.level3.voice.persist.dto.TnOrderDTO;

@Component
public class TollfreeTNOrderRepository {

	@Autowired
	EntityManager entityManager;

	public TnOrderDTO getTnBySlorderId(Long slOrderId) {
		return (TnOrderDTO) entityManager.createQuery("from TN_ORDER where slOrderId=:slOrderId")
				.setParameter("slOrderId", slOrderId).getSingleResult();
	}

	@Modifying
	@Transactional
	public void updateSlOrderBillStartDate(Long slOrderId, Date completionDate, Date billStartDate) {
		entityManager.createNativeQuery(
				"update sl_order set order_complete_date=:orderCompletionDate, bill_start_date=:billStartDate "
						+ "where sl_order_id =:slOrderId")
				.setParameter("orderCompletionDate", completionDate).setParameter("billStartDate", billStartDate)
				.setParameter("slOrderId", slOrderId).executeUpdate();
	}
	
	@Modifying
	@Transactional
	public void updateSlOrderBillEndDate(Long slOrderId, Date completionDate, Date billEndDate) {
		entityManager.createNativeQuery(
				"update sl_order set order_complete_date=:orderCompletionDate, bill_end_date=:billEndDate "
						+ "where sl_order_id =:slOrderId")
				.setParameter("orderCompletionDate", completionDate)
				.setParameter("billEndDate", billEndDate).setParameter("slOrderId", slOrderId).executeUpdate();
	}

}
