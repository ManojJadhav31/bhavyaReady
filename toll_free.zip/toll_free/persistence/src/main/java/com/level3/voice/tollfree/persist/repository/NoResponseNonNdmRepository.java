package com.level3.voice.tollfree.persist.repository;

import java.util.Date;
import java.util.List;

/**
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.level3.voice.tollfree.persist.dto.GetNoResponseNonNdmDTO;

@Transactional
public interface NoResponseNonNdmRepository  extends JpaRepository<GetNoResponseNonNdmDTO, Long>  {
	@Query(value="from getNoReponseNonNdmView where entryDate >= ? and entryDate <=?")
	public List<GetNoResponseNonNdmDTO> getAllNonNdmData(Date startDate, Date endDate);

}
