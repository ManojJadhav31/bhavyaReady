package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This DTO is representation of the charge table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "Charge")
public class ChargeDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ChargeId")
	private Long chargeId;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Column(name = "ProductId")
	private String productId;
	@Column(name = "ChargeType")
	private String chargeType;
	@Column(name = "Description")
	private String description;
	@Column(name = "TaxClassification")
	private String taxClassification;
	@Column(name = "ProrateCharges")
	private String prorateCharges;
	@Column(name = "AdvanceBill")
	private String advanceBill;
	@Column(name = "DiscountContributory")
	private String discountContributory;
	@Column(name = "DiscountEligible")
	private String discountEligible;
	@Column(name = "CommissionEligible")
	private String commissionEligible;
	@Column(name = "CommissionContributory")
	private String commissionContributory;
	@Column(name = "GeneralLedgerCode")
	private String generalLedgerCode;
	@Column(name = "DefaultTerm")
	private String defaultTerm;
	@Column(name = "DefaultCharge")
	private Long defaultCharge;
	@Column(name = "Overridable")
	private String overridable;
	@Column(name = "Status")
	private String status;
	@Column(name = "BeginDate")
	private Date beginDate;
	@Column(name = "EndDate")
	private Date endDate;
	@Column(name = "BillNotUsed")
	private String billNotUsed;
	@Column(name = "ChargeStructureType")
	private String chargeStructureType;
	@Column(name = "DefGeneralLedgerCode")
	private String defGeneralLedgerCode;
	@Column(name = "BlockForMigration")
	private String blockForMigration;

	@Transient
	private ProductOfferingChargeDTO productOfferingChargeDTO;
	@Transient
	private BusinessUnitChargeDTO businessUnitChargeDTO;
	@Transient
	private ChargeStructureQuantityDTO finalChargeStructureQuantityDTO;
	@Transient
	private ChargeStructureQuantityDTO initialChargeStructureQuantityDTO;

//	@OneToOne(mappedBy = "charge", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	@Basic(fetch = FetchType.LAZY)
//	private ProductOfferingChargeDTO prOfferingChargeDTO;
//
//	@OneToOne(mappedBy = "charge", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	@Basic(fetch = FetchType.LAZY)
//	private BusinessUnitChargeDTO buUnitChargeDTO;
//
//	@OneToMany(mappedBy = "charge", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	private List<ChargeStructureQuantityDTO> chStructureQuantityDTOs;

	public Long getChargeId() {
		return chargeId;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public String getProductId() {
		return productId;
	}

	public String getChargeType() {
		return chargeType;
	}

	public String getDescription() {
		return description;
	}

	public String getTaxClassification() {
		return taxClassification;
	}

	public String getProrateCharges() {
		return prorateCharges;
	}

	public String getAdvanceBill() {
		return advanceBill;
	}

	public String getDiscountContributory() {
		return discountContributory;
	}

	public String getDiscountEligible() {
		return discountEligible;
	}

	public String getCommissionEligible() {
		return commissionEligible;
	}

	public String getCommissionContributory() {
		return commissionContributory;
	}

	public String getGeneralLedgerCode() {
		return generalLedgerCode;
	}

	public String getDefaultTerm() {
		return defaultTerm;
	}

	public Long getDefaultCharge() {
		return defaultCharge;
	}

	public String getOverridable() {
		return overridable;
	}

	public String getStatus() {
		return status;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public String getBillNotUsed() {
		return billNotUsed;
	}

	public String getChargeStructureType() {
		return chargeStructureType;
	}

	public String getDefGeneralLedgerCode() {
		return defGeneralLedgerCode;
	}

	public String getBlockForMigration() {
		return blockForMigration;
	}

	public ProductOfferingChargeDTO getProductOfferingChargeDTO() {
		return productOfferingChargeDTO;
	}

	public BusinessUnitChargeDTO getBusinessUnitChargeDTO() {
		return businessUnitChargeDTO;
	}

	public void setChargeId(Long chargeId) {
		this.chargeId = chargeId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setTaxClassification(String taxClassification) {
		this.taxClassification = taxClassification;
	}

	public void setProrateCharges(String prorateCharges) {
		this.prorateCharges = prorateCharges;
	}

	public void setAdvanceBill(String advanceBill) {
		this.advanceBill = advanceBill;
	}

	public void setDiscountContributory(String discountContributory) {
		this.discountContributory = discountContributory;
	}

	public void setDiscountEligible(String discountEligible) {
		this.discountEligible = discountEligible;
	}

	public void setCommissionEligible(String commissionEligible) {
		this.commissionEligible = commissionEligible;
	}

	public void setCommissionContributory(String commissionContributory) {
		this.commissionContributory = commissionContributory;
	}

	public void setGeneralLedgerCode(String generalLedgerCode) {
		this.generalLedgerCode = generalLedgerCode;
	}

	public void setDefaultTerm(String defaultTerm) {
		this.defaultTerm = defaultTerm;
	}

	public void setDefaultCharge(Long defaultCharge) {
		this.defaultCharge = defaultCharge;
	}

	public void setOverridable(String overridable) {
		this.overridable = overridable;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setBillNotUsed(String billNotUsed) {
		this.billNotUsed = billNotUsed;
	}

	public void setChargeStructureType(String chargeStructureType) {
		this.chargeStructureType = chargeStructureType;
	}

	public void setDefGeneralLedgerCode(String defGeneralLedgerCode) {
		this.defGeneralLedgerCode = defGeneralLedgerCode;
	}

	public void setBlockForMigration(String blockForMigration) {
		this.blockForMigration = blockForMigration;
	}

	public void setProductOfferingChargeDTO(ProductOfferingChargeDTO productOfferingChargeDTO) {
		this.productOfferingChargeDTO = productOfferingChargeDTO;
	}

	public void setBusinessUnitChargeDTO(BusinessUnitChargeDTO businessUnitChargeDTO) {
		this.businessUnitChargeDTO = businessUnitChargeDTO;
	}

	public ChargeStructureQuantityDTO getFinalChargeStructureQuantityDTO() {
		return finalChargeStructureQuantityDTO;
	}

	public void setFinalChargeStructureQuantityDTO(ChargeStructureQuantityDTO finalChargeStructureQuantityDTO) {
		this.finalChargeStructureQuantityDTO = finalChargeStructureQuantityDTO;
	}

	public ChargeStructureQuantityDTO getInitialChargeStructureQuantityDTO() {
		return initialChargeStructureQuantityDTO;
	}

	public void setInitialChargeStructureQuantityDTO(ChargeStructureQuantityDTO initialChargeStructureQuantityDTO) {
		this.initialChargeStructureQuantityDTO = initialChargeStructureQuantityDTO;
	}
	
	
}
