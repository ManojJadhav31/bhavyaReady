package com.level3.voice.tollfree.persist.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ProductOfferingRatePlanDTO;

/**
 * This repository is to retrieve/persist product offering rate information for
 * product offering which user has selected/created
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Component
public interface ProductOfferingRatePlanRepository extends JpaRepository<ProductOfferingRatePlanDTO, Long> {

	@Query(value="from ProductOfferingRatePlanDTO where organizationId = ? and productOfferingId = ? ")
	public ProductOfferingRatePlanDTO findProductOfferingRatePlan(String orgId, Long productOfferingId);

}
