package com.level3.voice.tollfree.persist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import com.level3.voice.tollfree.persist.dto.CdrServiceTypeUsageDTO;


/**
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */
@Component
public interface CdrServiceTypeUsageRepository extends JpaRepository<CdrServiceTypeUsageDTO, Long> {
	
	@Query(value="select serviceType, sum(totalCalls), sum(totalMinutes) from cdrServiceType where account =?  and answerDate between ? and ? group by serviceType ")
	public List<Object[]> getUsageSummary(Long accountNo, Date fromDate,Date toDate);
	
}
