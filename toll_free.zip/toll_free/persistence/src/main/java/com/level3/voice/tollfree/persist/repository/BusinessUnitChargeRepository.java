package com.level3.voice.tollfree.persist.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.BusinessUnitChargeDTO;

/**
 * This repository is to retrieve data from the business unit
 * charge table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Component
public interface BusinessUnitChargeRepository extends JpaRepository<BusinessUnitChargeDTO, Long> {

	@Query(value="from BusinessUnitChargeDTO where chargeId = ?")
	public BusinessUnitChargeDTO findBusUnitChargeByChargeId(Long chargeId);

}
