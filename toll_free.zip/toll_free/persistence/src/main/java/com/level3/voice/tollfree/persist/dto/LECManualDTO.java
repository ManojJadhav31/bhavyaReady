/**
 * @author arun2.kumar
 */
package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is capturing OCN's related to the LEC MANUAL steps.
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "LECMANUAL")
public class LECManualDTO {

	/** identifier field */
	@Id
	@Column(name = "OCN")
	private String ocn;

	@Column(name = "TC")
	private String tc;

	@Column(name = "SI")
	private String si;

	/**
	 * @return the ocn
	 */
	public String getOcn() {
		return ocn;
	}

	/**
	 * @param ocn the ocn to set
	 */
	public void setOcn(String ocn) {
		this.ocn = ocn;
	}

	/**
	 * @return the tc
	 */
	public String getTc() {
		return tc;
	}

	/**
	 * @param tc the tc to set
	 */
	public void setTc(String tc) {
		this.tc = tc;
	}

	/**
	 * @return the si
	 */
	public String getSi() {
		return si;
	}

	/**
	 * @param si the si to set
	 */
	public void setSi(String si) {
		this.si = si;
	}

}
