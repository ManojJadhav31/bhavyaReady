package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ProdOfferingLocAsscQueueDTO;

/**
 * This the repository which is used to retrieve
 * and persist records in ProdOfferingLocAsscQueueDTO table
 * 
 * @author <a href="mailto:Nnupur.Krishnaa@centurylink.com">Nnupur.Krishnaa</a>
 *
 */
@Component
public interface ProdOfferingLocAsscQueueRepository extends JpaRepository<ProdOfferingLocAsscQueueDTO, Long>{

	@Query(value="from ProdOfferingLocAsscQueueDTO where dequeueDate = null")
	public List<ProdOfferingLocAsscQueueDTO> findDataWithNoDequeue();

}
