package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Profit center data is used to populate
 * the dropdown on the product offering
 * charge screen
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "ProfitCenter")
public class ProfitCenterDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Id
	@Column(name = "ProfitCenter")
	private String profitCenter;
	@Column(name = "ProfitCenterDesc")
	private String profitCenterDesc;
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getProfitCenter() {
		return profitCenter;
	}
	public void setProfitCenter(String profitCenter) {
		this.profitCenter = profitCenter;
	}
	public String getProfitCenterDesc() {
		return profitCenterDesc;
	}
	public void setProfitCenterDesc(String profitCenterDesc) {
		this.profitCenterDesc = profitCenterDesc;
	}
}
