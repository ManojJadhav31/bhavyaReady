package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ProductOfferingChargeDTO;

/**
 * This repository is to retrieve/persist the product offering charge
 * information in the productofferingcharge table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Component
public interface ProductOfferingChargeRepository extends JpaRepository<ProductOfferingChargeDTO, Long> {

	@Query(value="from ProductOfferingChargeDTO where organizationId = ? and productOfferingId = ?")
	public List<ProductOfferingChargeDTO> findAllByOrgIdAndproductOfferingId(String orgId, Long productOfferingId);

}
