package com.level3.voice.tollfree.persist.pk;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * This class is to represent the composite
 * key created with the mentioned columns [productOfferingId, OrganizationId, RatePlanId] against
 * ProductOfferingRatePlan
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Embeddable
public class ProductOfferingRatePlanPK implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "ProductOfferingId")
	private Long productOfferingId;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Column(name = "RatePlanId")
	private Long ratePlanId;
	
	public Long getProductOfferingId() {
		return productOfferingId;
	}
	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public Long getRatePlanId() {
		return ratePlanId;
	}
	public void setRatePlanId(Long ratePlanId) {
		this.ratePlanId = ratePlanId;
	}
}
