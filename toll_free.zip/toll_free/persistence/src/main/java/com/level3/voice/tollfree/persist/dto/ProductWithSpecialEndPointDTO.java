package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.level3.voice.tollfree.persist.pk.ProductWithSpecialEndPointPK;

/**
 * This class holds the product offering id relationship with
 * endpoint types
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "ProductWithSpecialEndPoint")
public class ProductWithSpecialEndPointDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ProductWithSpecialEndPointPK productWithSpecialEndPointPK;

	@Transient
	private Long productOfferingId;
	@Transient
	private String specialEndPointTypeCode;

	public ProductWithSpecialEndPointPK getProductWithSpecialEndPointPK() {
		return productWithSpecialEndPointPK;
	}

	public void setProductWithSpecialEndPointPK(ProductWithSpecialEndPointPK productWithSpecialEndPointPK) {
		this.productWithSpecialEndPointPK = productWithSpecialEndPointPK;
	}

	public Long getProductOfferingId() {
		return productOfferingId;
	}

	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}

	public String getSpecialEndPointTypeCode() {
		return specialEndPointTypeCode;
	}

	public void setSpecialEndPointTypeCode(String specialEndPointTypeCode) {
		this.specialEndPointTypeCode = specialEndPointTypeCode;
	}
}
