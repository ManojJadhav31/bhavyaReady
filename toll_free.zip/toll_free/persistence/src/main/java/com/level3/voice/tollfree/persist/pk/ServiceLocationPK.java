package com.level3.voice.tollfree.persist.pk;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 *  This class is to represent the composite
 * key created with the mentioned columns [organizationId, customerId, serviceLocationId] against
 * ServiceLocation
 * 
 * @author <a href="mailto:nnupur.krishnaa@centurylink.com">Nnupur.Krishnaa</a>
 *
 */
@Embeddable
public class ServiceLocationPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "OrganizationId")
	private String organizationId;
	@Column(name = "CustomerId")
	private String customerId;
	@Column(name = "ServiceLocationId")
	private String serviceLocationId;


	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getServiceLocationId() {
		return serviceLocationId;
	}
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}


}
