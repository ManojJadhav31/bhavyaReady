package com.level3.voice.tollfree.persist.vo;

public class ProductDiscPlanVo {
	
	private Long discountPlanId;
	private String discountPlanType;
	
	public ProductDiscPlanVo(Long discountPlanId, String discountPlanType) {
		super();
		this.discountPlanId = discountPlanId;
		this.discountPlanType = discountPlanType;
	}
	public ProductDiscPlanVo() {
		
	}

	public Long getDiscountPlanId() {
		return discountPlanId;
	}

	public void setDiscountPlanId(Long discountPlanId) {
		this.discountPlanId = discountPlanId;
	}

	public String getDiscountPlanType() {
		return discountPlanType;
	}

	public void setDiscountPlanType(String discountPlanType) {
		this.discountPlanType = discountPlanType;
	}
	
	
	

}
