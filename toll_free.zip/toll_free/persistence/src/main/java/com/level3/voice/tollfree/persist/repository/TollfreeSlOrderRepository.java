package com.level3.voice.tollfree.persist.repository;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class TollfreeSlOrderRepository {

	@Autowired
	EntityManager entityManager;

	@Modifying
	@Transactional
	public void updateLastUpdatedUser(String userName, Long slOrderId) {
		entityManager
				.createNativeQuery(
						"Update sl_order slo  SET slo.last_updated_user=:userName WHERE slo.sl_order_id =:slOrderId")
				.setParameter("userName", userName).setParameter("slOrderId", slOrderId).executeUpdate();
		entityManager.flush();
	}
}
