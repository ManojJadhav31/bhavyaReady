package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ProductOfferingDTO;

/**
 * This repository is to retrieve/persist product offering information
 * in productoffering table
 * 
 * @author <a href="mailto:Mushahid.Khan@centurylink.com">Mushahid.Khan</a>
 *
 */
@Component
public interface ProductOfferingRepository extends  JpaRepository<ProductOfferingDTO, Long> {
	
	@Query(value="from ProductOfferingDTO where organizationId = ? ")
	public List<ProductOfferingDTO> findAllByOrganizationId(String orgId);
	
	@Query(value="select MAX(poDto.productOfferingId) from ProductOfferingDTO poDto")
	public Long getMaxProductOfferingid();

	@Query(value="from ProductOfferingDTO where organizationId = ? and productOfferingId = ?")
	public ProductOfferingDTO findProductOffering(String organizationId,Long productOfferingId);

}
