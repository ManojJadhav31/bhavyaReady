package com.level3.voice.tollfree.persist.repository;

import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.level3.voice.tollfree.persist.dto.LECManualDTO;

/**
 * This repository is to fetch the records from LECMANUAL tables
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Transactional
public interface LECManualRepository extends JpaRepository<LECManualDTO, String> {

}
