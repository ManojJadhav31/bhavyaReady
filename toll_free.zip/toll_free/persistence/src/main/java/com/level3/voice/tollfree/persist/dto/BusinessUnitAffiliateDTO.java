package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.ConstructorResult;
import com.level3.voice.tollfree.persist.vo.VolumeDiscPlanVO;
/**
 * Business Unit affiliate table used for
 * product offering charge screen
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "BusinessUnitAffiliate")
@SqlResultSetMapping(
	    name="volumeDiscPlanResult",
	    classes={
	      @ConstructorResult(
	        targetClass=VolumeDiscPlanVO.class,
	        columns={
	          @ColumnResult(name="discountPlanId", type=Long.class),
	          @ColumnResult(name="discountPlanType", type=String.class)
	          })
	      }
)

public class BusinessUnitAffiliateDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Id
	@Column(name = "BusinessUnitAffiliate")
	private String businessUnitAffiliate;
	@Column(name = "BusinessUnitAffiliateDesc")
	private String businessUnitAffiliateDesc;
	@Column(name = "BusinessUnitAffiliateFlag")
	private String businessUnitAffiliateFlag;
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getBusinessUnitAffiliate() {
		return businessUnitAffiliate;
	}
	public void setBusinessUnitAffiliate(String businessUnitAffiliate) {
		this.businessUnitAffiliate = businessUnitAffiliate;
	}
	public String getBusinessUnitAffiliateDesc() {
		return businessUnitAffiliateDesc;
	}
	public void setBusinessUnitAffiliateDesc(String businessUnitAffiliateDesc) {
		this.businessUnitAffiliateDesc = businessUnitAffiliateDesc;
	}
	public String getBusinessUnitAffiliateFlag() {
		return businessUnitAffiliateFlag;
	}
	public void setBusinessUnitAffiliateFlag(String businessUnitAffiliateFlag) {
		this.businessUnitAffiliateFlag = businessUnitAffiliateFlag;
	}
	
}
