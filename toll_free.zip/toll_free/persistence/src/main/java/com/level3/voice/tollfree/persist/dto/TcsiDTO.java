/**
 * @author arun2.kumar
 */
package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.io.Serializable;
import java.util.Date;

/**
 * @author ab68221 Manjunatha D
 *
 */
@Entity
@Table(name = "TCSI", schema="SUBL_OWNER")
public class TcsiDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	private Long id;
	@Column(name = "SOURCE")
	private String source;
	@Column(name = "TC")
	private String tc;
	@Column(name = "SI")
	private String si;
	@Column(name = "SERVICE_TYPE")
	private String serviceType;
	@Column(name = "DESCRIPTION")
	private String description;
	@Column(name = "ACTION")
	private String action;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}

   }

