package com.level3.voice.tollfree.persist.repository;


import java.text.ParseException;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import com.level3.voice.tollfree.persist.dto.AniDataDTO;


/**
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */
@Component
public interface AniDataRepository extends JpaRepository<AniDataDTO, Long> {

@Query(value="select customerId,customerName,serviceAddressId,productOfferingId,tn,btn,"
		+ "cic,status,ocn,intralataFirstUsageDate,intralataLastUsageDate,interlataFirstUsageDate,interlataLastUsageDate from aniDataView where tn = ? and  btn =? and serviceAddressId = ? and customerId=?")
		public  Object[] getAniDataForReport(String tn, String btn, String serviceAddressId, String customerId);

@Query(value="select serviceAddressId, status,tn,btn,orderDate,intralataFirstUsageDate,intralataLastUsageDate,interlataFirstUsageDate,interlataLastUsageDate, disconnectDate from aniDataView where customerId=?")
		public Object[] getAllServiceLocation(String customerID);

		@Query(value="select tn,name from aniDataView where customerId=? and serviceAddressId=?")
		public Object[] getAniByStatus(String customerID, String serviceAddressId);
		
		/*@Query(value="select name, count(name) from aniDataView where customerId=? and serviceAddressId=? group by name")
		public Object[] getAniByStatusCount(AniSearchInputReqVO aniSearchReqParams);*/

		
}