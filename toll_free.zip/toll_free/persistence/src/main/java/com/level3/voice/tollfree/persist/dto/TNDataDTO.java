package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "GET_TNDATA_VIEW")
@Table(name = "GET_TNDATA_VIEW", schema = "SUBL_OWNER")
public class TNDataDTO {

	/** default constructor */
	public TNDataDTO() {

	}

	@Id
	@Column(name = "TN")
	private String tn;
	/** persistent field */
	@Column(name = "BTN", nullable = true)
	private String btn;
	/** persistent field */
	@Column(name = "CIC", nullable = true)
	private String cic;
	/** persistent field */
	@Column(name = "JURISDICTION", nullable = true)
	private String jurisdiction;
	/** persistent field */
	@Column(name = "PIC_REQUEST", nullable = true)
	private String picRequest;
	/** persistent field */
	@Column(name = "FORCED_ANI", nullable = true)
	private String forcedANI;
	@Column(name = "VOICE_ORDER_ID")
	private String voiceOrderId;
	/** persistent field */
	@Column(name = "SCID", nullable = true)
	private String scid;
	/** persistent field */
	@Column(name = "SERVICE_ID", nullable = true)
	private String serviceId;
	/** persistent field */
	@Column(name = "ORDER_COMPLETE_DATE", nullable = true)
	private String orderCompletionDate;
	/** persistent field */
	@Column(name = "SERVICE_ADDRESS_ID", nullable = true)
	private String serviceAddressId;
	/** persistent field */
	@Column(name = "SUBSCRIBER_LINE_ID", nullable = true)
	private String subsciberLineId;
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getPicRequest() {
		return picRequest;
	}
	public void setPicRequest(String picRequest) {
		this.picRequest = picRequest;
	}
	public String getForcedANI() {
		return forcedANI;
	}
	public void setForcedANI(String forcedANI) {
		this.forcedANI = forcedANI;
	}
	public String getVoiceOrderId() {
		return voiceOrderId;
	}
	public void setVoiceOrderId(String voiceOrderId) {
		this.voiceOrderId = voiceOrderId;
	}
	public String getScid() {
		return scid;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getOrderCompletionDate() {
		return orderCompletionDate;
	}
	public void setOrderCompletionDate(String orderCompletionDate) {
		this.orderCompletionDate = orderCompletionDate;
	}
	public String getServiceAddressId() {
		return serviceAddressId;
	}
	public void setServiceAddressId(String serviceAddressId) {
		this.serviceAddressId = serviceAddressId;
	}
	public String getSubsciberLineId() {
		return subsciberLineId;
	}
	public void setSubsciberLineId(String subsciberLineId) {
		this.subsciberLineId = subsciberLineId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((btn == null) ? 0 : btn.hashCode());
		result = prime * result + ((cic == null) ? 0 : cic.hashCode());
		result = prime * result + ((forcedANI == null) ? 0 : forcedANI.hashCode());
		result = prime * result + ((jurisdiction == null) ? 0 : jurisdiction.hashCode());
		result = prime * result + ((orderCompletionDate == null) ? 0 : orderCompletionDate.hashCode());
		result = prime * result + ((picRequest == null) ? 0 : picRequest.hashCode());
		result = prime * result + ((scid == null) ? 0 : scid.hashCode());
		result = prime * result + ((serviceAddressId == null) ? 0 : serviceAddressId.hashCode());
		result = prime * result + ((serviceId == null) ? 0 : serviceId.hashCode());
		result = prime * result + ((subsciberLineId == null) ? 0 : subsciberLineId.hashCode());
		result = prime * result + ((tn == null) ? 0 : tn.hashCode());
		result = prime * result + ((voiceOrderId == null) ? 0 : voiceOrderId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TNDataDTO other = (TNDataDTO) obj;
		if (btn == null) {
			if (other.btn != null)
				return false;
		} else if (!btn.equals(other.btn))
			return false;
		if (cic == null) {
			if (other.cic != null)
				return false;
		} else if (!cic.equals(other.cic))
			return false;
		if (forcedANI == null) {
			if (other.forcedANI != null)
				return false;
		} else if (!forcedANI.equals(other.forcedANI))
			return false;
		if (jurisdiction == null) {
			if (other.jurisdiction != null)
				return false;
		} else if (!jurisdiction.equals(other.jurisdiction))
			return false;
		if (orderCompletionDate == null) {
			if (other.orderCompletionDate != null)
				return false;
		} else if (!orderCompletionDate.equals(other.orderCompletionDate))
			return false;
		if (picRequest == null) {
			if (other.picRequest != null)
				return false;
		} else if (!picRequest.equals(other.picRequest))
			return false;
		if (scid == null) {
			if (other.scid != null)
				return false;
		} else if (!scid.equals(other.scid))
			return false;
		if (serviceAddressId == null) {
			if (other.serviceAddressId != null)
				return false;
		} else if (!serviceAddressId.equals(other.serviceAddressId))
			return false;
		if (serviceId == null) {
			if (other.serviceId != null)
				return false;
		} else if (!serviceId.equals(other.serviceId))
			return false;
		if (subsciberLineId == null) {
			if (other.subsciberLineId != null)
				return false;
		} else if (!subsciberLineId.equals(other.subsciberLineId))
			return false;
		if (tn == null) {
			if (other.tn != null)
				return false;
		} else if (!tn.equals(other.tn))
			return false;
		if (voiceOrderId == null) {
			if (other.voiceOrderId != null)
				return false;
		} else if (!voiceOrderId.equals(other.voiceOrderId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "TNDataDTO [tn=" + tn + ", btn=" + btn + ", cic=" + cic + ", jurisdiction=" + jurisdiction
				+ ", picRequest=" + picRequest + ", forcedANI=" + forcedANI + ", voiceOrderId=" + voiceOrderId
				+ ", scid=" + scid + ", serviceId=" + serviceId + ", orderCompletionDate=" + orderCompletionDate
				+ ", serviceAddressId=" + serviceAddressId + ", subsciberLineId=" + subsciberLineId + "]";
	}
	public TNDataDTO(String tn, String btn, String cic, String jurisdiction, String picRequest, String forcedANI,
			String voiceOrderId, String scid, String serviceId, String orderCompletionDate, String serviceAddressId,
			String subsciberLineId) {
		super();
		this.tn = tn;
		this.btn = btn;
		this.cic = cic;
		this.jurisdiction = jurisdiction;
		this.picRequest = picRequest;
		this.forcedANI = forcedANI;
		this.voiceOrderId = voiceOrderId;
		this.scid = scid;
		this.serviceId = serviceId;
		this.orderCompletionDate = orderCompletionDate;
		this.serviceAddressId = serviceAddressId;
		this.subsciberLineId = subsciberLineId;
	}

	
}
