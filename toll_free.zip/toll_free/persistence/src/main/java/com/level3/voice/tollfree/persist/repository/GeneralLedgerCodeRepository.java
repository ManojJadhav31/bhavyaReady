package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.GeneralLedgerCodeDTO;;

/**
 * This repository is to retrieve general ledger information based on selected
 * organization id
 * 
 * @author <a href="mailto:Mushahid.Khan@centurylink.com">Mushahid.Khan</a>
 */
@Component
public interface GeneralLedgerCodeRepository extends JpaRepository<GeneralLedgerCodeDTO, Long> {
	
	@Query("from GeneralLedgerCodeDTO where organizationId=?")
	public List<GeneralLedgerCodeDTO> findAllGeneralLedgerCodeDTO(String orgId);

}
