package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ProductMasterDTO;

/**
 * This repository is to retrieve product data from product
 * master table.
 * 
 * @author <a href="mailto:Mushahid.Khan@centurylink.com">Mushahid.Khan</a>
 *
 */
@Component
public interface ProductDataRepository extends  JpaRepository<ProductMasterDTO, Long> {
	@Query(value="from ProductMasterDTO")
	public List<ProductMasterDTO> findAllProductMasterData();

}
