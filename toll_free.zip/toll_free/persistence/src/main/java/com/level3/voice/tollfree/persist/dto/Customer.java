package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is a bean to have network Strategy data
 * @author <a href="mailto:Manjunatha.D@centurylink.com">Manjunatha</a>
 *
 */
@Embeddable
@Table(name = "Customer")
public class Customer implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="OrganizationId")
	private String organizationId;
	@Column(name="CustomerId")
	private String customerId;
	@Column(name="CustomerCode")
	private String customerCode;
	@Column(name="CustomerName")
	private String customerName;
	@Column(name="CustomerType")
	private String customerType;
	@Column(name="Address1")
	private String address1;
	@Column(name="Address2")
	private String address2;
	@Column(name="City")
	private String city;
	@Column(name="State")
	private String state;
	@Column(name="ZipCode")
	private String zipCode;
	@Column(name="Country")
	private String country;
	@Column(name="Phone")
	private String phone;
	@Column(name="EmailAddress")
	private String emailAddress;
	@Column(name="BillingCycleId")
	private String billingCycleId;
	@Column(name="MonthlyFee")
	private Long monthlyFee;
	@Column(name="InterestRate")
	private Long interestRate;
	@Column(name="CustomerBalance")
	private Long customerBalance;
	@Column(name="CreditLimit")
	private Long creditLimit;
	@Column(name="CreditAuthorized")
	private String creditAuthorized;
	@Column(name="CreditVerification")
	private Integer creditVerification;
	@Column(name="PaymentTermId")
	private String paymentTermId;
	@Column(name="PaymentMethodId")
	private Integer paymentMethodId;
	@Column(name="PaymentToId")
	private Integer paymentToId;
	@Column(name="CustomerBegin")
	private Date customerBegin;
	@Column(name="CustomerEnd")
	private Date customerEnd;
	@Column(name="Status")
	private String status;
	@Column(name="ControlGroupId")
	private String controlGroupId;
	@Column(name="BillingName")
	private String billingName;
	@Column(name="CreditClass")
	private String creditClass;
	@Column(name="GracePeriod")
	private Integer gracePeriod;
	@Column(name="EarlyPaymentDays")
	private Integer earlyPaymentDays;
	@Column(name="EarlyPaymentDiscount")
	private Long earlyPaymentDiscount;
	@Column(name="AddressId")
	private Integer addressId;
	@Column(name="BusOrg")
	private String busOrg;
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getBillingCycleId() {
		return billingCycleId;
	}
	public void setBillingCycleId(String billingCycleId) {
		this.billingCycleId = billingCycleId;
	}
	public Long getMonthlyFee() {
		return monthlyFee;
	}
	public void setMonthlyFee(Long monthlyFee) {
		this.monthlyFee = monthlyFee;
	}
	public Long getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(Long interestRate) {
		this.interestRate = interestRate;
	}
	public Long getCustomerBalance() {
		return customerBalance;
	}
	public void setCustomerBalance(Long customerBalance) {
		this.customerBalance = customerBalance;
	}
	public Long getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(Long creditLimit) {
		this.creditLimit = creditLimit;
	}
	public String getCreditAuthorized() {
		return creditAuthorized;
	}
	public void setCreditAuthorized(String creditAuthorized) {
		this.creditAuthorized = creditAuthorized;
	}
	public Integer getCreditVerification() {
		return creditVerification;
	}
	public void setCreditVerification(Integer creditVerification) {
		this.creditVerification = creditVerification;
	}
	public String getPaymentTermId() {
		return paymentTermId;
	}
	public void setPaymentTermId(String paymentTermId) {
		this.paymentTermId = paymentTermId;
	}
	public Integer getPaymentMethodId() {
		return paymentMethodId;
	}
	public void setPaymentMethodId(Integer paymentMethodId) {
		this.paymentMethodId = paymentMethodId;
	}
	public Integer getPaymentToId() {
		return paymentToId;
	}
	public void setPaymentToId(Integer paymentToId) {
		this.paymentToId = paymentToId;
	}
	public Date getCustomerBegin() {
		return customerBegin;
	}
	public void setCustomerBegin(Date customerBegin) {
		this.customerBegin = customerBegin;
	}
	public Date getCustomerEnd() {
		return customerEnd;
	}
	public void setCustomerEnd(Date customerEnd) {
		this.customerEnd = customerEnd;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getControlGroupId() {
		return controlGroupId;
	}
	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}
	public String getBillingName() {
		return billingName;
	}
	public void setBillingName(String billingName) {
		this.billingName = billingName;
	}
	public String getCreditClass() {
		return creditClass;
	}
	public void setCreditClass(String creditClass) {
		this.creditClass = creditClass;
	}
	public Integer getGracePeriod() {
		return gracePeriod;
	}
	public void setGracePeriod(Integer gracePeriod) {
		this.gracePeriod = gracePeriod;
	}
	public Integer getEarlyPaymentDays() {
		return earlyPaymentDays;
	}
	public void setEarlyPaymentDays(Integer earlyPaymentDays) {
		this.earlyPaymentDays = earlyPaymentDays;
	}
	public Long getEarlyPaymentDiscount() {
		return earlyPaymentDiscount;
	}
	public void setEarlyPaymentDiscount(Long earlyPaymentDiscount) {
		this.earlyPaymentDiscount = earlyPaymentDiscount;
	}
	public Integer getAddressId() {
		return addressId;
	}
	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}
	public String getBusOrg() {
		return busOrg;
	}
	public void setBusOrg(String busOrg) {
		this.busOrg = busOrg;
	}


}
