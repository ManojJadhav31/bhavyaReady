package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is the representation of the RatePlan table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "RatePlan")
public class RatePlanDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Id
	@Column(name = "RatePlanId")
	private Long ratePlanId;
	@Column(name = "RatePlanName")
	private String ratePlanName;
	@Column(name = "Description")
	private String description;
	@Column(name = "EffectiveBegin")
	private String effectiveBegin;
	@Column(name = "EffectiveEnd")
	private String effectiveEnd;
	@Column(name = "Status")
	private String status;
	public String getOrganizationId() {
		return organizationId;
	}
	public Long getRatePlanId() {
		return ratePlanId;
	}
	public String getRatePlanName() {
		return ratePlanName;
	}
	public String getDescription() {
		return description;
	}
	public String getEffectiveBegin() {
		return effectiveBegin;
	}
	public String getEffectiveEnd() {
		return effectiveEnd;
	}
	public String getStatus() {
		return status;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public void setRatePlanId(Long ratePlanId) {
		this.ratePlanId = ratePlanId;
	}
	public void setRatePlanName(String ratePlanName) {
		this.ratePlanName = ratePlanName;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setEffectiveBegin(String effectiveBegin) {
		this.effectiveBegin = effectiveBegin;
	}
	public void setEffectiveEnd(String effectiveEnd) {
		this.effectiveEnd = effectiveEnd;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
