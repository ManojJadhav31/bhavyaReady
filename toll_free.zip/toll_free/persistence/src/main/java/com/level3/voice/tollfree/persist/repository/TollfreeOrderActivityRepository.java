package com.level3.voice.tollfree.persist.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Component
public class TollfreeOrderActivityRepository {

	@Autowired
	EntityManager entityManager;

	@Modifying
	@Transactional
	public void completeActivity(Date date, String comment, Long orderActivityPk) {
		entityManager.createNativeQuery(
				"Update Order_Activity  SET status=3, complete_date=:date, LAST_PROCESSING_STOP=:date, comments = substr( (:comment || ':'  || nvl(comments, '')), 0, 510) WHERE order_activity_pk =:orderActivityPk")
				.setParameter("date", date).setParameter("comment", comment)
				.setParameter("orderActivityPk", orderActivityPk).executeUpdate();
	}

	@Modifying
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updatePonActivity(Integer status, Date date, String comment, Integer orderTypeId, Long pon,
			Integer seqNo, Integer activityId) {
		entityManager.createNativeQuery(
				"Update Order_Activity oa  SET status=:status,  complete_date=:date, LAST_PROCESSING_STOP=:date, "
						+ "comments = substr( (:comment || ':'  || nvl(comments, '')), 0, 510) "
						+ "where oa.SL_ORDER_ID in (select so.sl_order_id from SL_ORDER so where so.order_active_yn = 'Y' and order_type_id <> :orderTypeId and so.parent_trans_id = :pon)"
						+ " and activity_id = :seqNo and activity_type_id = :activityId")
				.setParameter("status", status).setParameter("date", date).setParameter("comment", comment)
				.setParameter("orderTypeId", orderTypeId).setParameter("orderTypeId", orderTypeId)
				.setParameter("pon", pon).setParameter("seqNo", seqNo).setParameter("activityId", activityId)
				.executeUpdate();
	}

	@Modifying
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updatePonActivity(Integer status, String comment, Integer orderTypeId, Long pon, Integer seqNo,
			Integer activityId) {
		entityManager.createNativeQuery("Update Order_Activity oa  SET status=:status,  "
				+ "comments = substr( (:comment || ':'  || nvl(comments, '')), 0, 510) "
				+ "where oa.SL_ORDER_ID in (select so.sl_order_id from SL_ORDER so where so.order_active_yn = 'Y' and order_type_id <> :orderTypeId and so.parent_trans_id = :pon)"
				+ " and activity_id = :seqNo and activity_type_id = :activityId").setParameter("status", status)
				.setParameter("comment", comment).setParameter("orderTypeId", orderTypeId)
				.setParameter("orderTypeId", orderTypeId).setParameter("pon", pon).setParameter("seqNo", seqNo)
				.setParameter("activityId", activityId).executeUpdate();
	}

	@Modifying
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateActivityComments(String comment, Integer orderTypeId, Long pon, Integer seqNo,
			Integer activityId) {
		entityManager.createNativeQuery("Update Order_Activity oa  SET comments = :comment "
				+ "where oa.SL_ORDER_ID in (select so.sl_order_id from SL_ORDER so where so.order_active_yn = 'Y' and order_type_id <> :orderTypeId and so.parent_trans_id = :pon)"
				+ " and activity_id = :seqNo and activity_type_id = :activityId")
				.setParameter("comment", comment).setParameter("orderTypeId", orderTypeId)
				.setParameter("orderTypeId", orderTypeId).setParameter("pon", pon).setParameter("seqNo", seqNo)
				.setParameter("activityId", activityId).executeUpdate();
	}

	@SuppressWarnings("unchecked")
	public List<Object> getProductSummary(String customerId, String serviceLocationId) {
		List<Object> objects = (List<Object>) entityManager.createNativeQuery("select * from " + "( "
				+ "select otf.product_offering_id, ssv.status as status from sl_order sl  "
				+ "left outer join SUBL_OWNER.GET_SERVICE_STATUS_VIEW ssv on ssv.sl_order_id = sl.sl_order_id "
				+ "left outer join Order_tollfree_features otf on otf.sl_order_id = sl.sl_order_id "
				+ "where otf.service_address_id =:serviceLocationId and sl.external_customer_id =:customerId)"
				+ "PIVOT  (count(status) AS qty FOR (status) IN ('Active' AS Active, 'Pending' AS Pending, 'Blocked' AS Blocked, 'Disconnected' as Disconnected))")
				.setParameter("customerId", customerId).setParameter("serviceLocationId", serviceLocationId)
				.getResultList();
		return objects;

	}

	@SuppressWarnings("unchecked")
	public List<Object> getCustProductSumamry(String customerId) {
		// TODO Auto-generated method stub
		List<Object> objects = (List<Object>) entityManager.createNativeQuery("select * from ( "
				+ "select otf.product_offering_id, ssv.status as status from sl_order sl  "
				+ "left outer join SUBL_OWNER.GET_SERVICE_STATUS_VIEW ssv on ssv.sl_order_id = sl.sl_order_id "
				+ "left outer join Order_tollfree_features otf on otf.sl_order_id = sl.sl_order_id "
				+ "where sl.external_customer_id =:customerId)"
				+ "PIVOT  (count(status) AS qty FOR (status) IN ('Active' AS Active, 'Pending' AS Pending, 'Blocked' AS Blocked, 'Disconnected' as Disconnected))")
				.setParameter("customerId", customerId).getResultList();
		return objects;

		/*
		 * List<Object> object = entityManager .createNativeQuery(
		 * "select * from (select otf.product_offering_id, ssv.status as status from sl_order sl left outer join "
		 * +
		 * "SUBL_OWNER.GET_SERVICE_STATUS_VIEW ssv on ssv.sl_order_id = sl.sl_order_id left outer join"
		 * +
		 * " Order_tollfree_features otf on otf.sl_order_id = sl.sl_order_id where sl.external_customer_id=:customerId)"
		 * +
		 * "PIVOT  (count(status) AS qty FOR (status) IN ('Active' AS Active, 'Pending' AS Pending, 'Blocked' AS Blocked, 'Disconnected' as Disconnected))"
		 * ) .setParameter("customerId", customerId).getResultList(); return object;
		 */
	}

}
