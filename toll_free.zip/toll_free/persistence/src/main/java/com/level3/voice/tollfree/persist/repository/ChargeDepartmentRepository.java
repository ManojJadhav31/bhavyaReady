package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ChargeDepartmentDTO;

/**
 * This repository is to retrieve all the charge departments based on the
 * selected organization id
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public interface ChargeDepartmentRepository extends JpaRepository<ChargeDepartmentDTO, String> {

	@Query(value="from ChargeDepartmentDTO where organizationId = ? ")
	public List<ChargeDepartmentDTO> retrieveProfitCenters(String orgId);
}
