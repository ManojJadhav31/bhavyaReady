package com.level3.voice.tollfree.persist.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.level3.voice.tollfree.persist.dto.LandingScreenDTO;
import com.level3.voice.tollfree.persist.dto.TNDataDTO;

@Component
@Transactional
public interface TNSearchRepository extends JpaRepository<TNDataDTO, Long>{
	@Query(value = "select gt from GET_TNDATA_VIEW gt where voiceOrderId = ? ")
	public List<TNDataDTO> getTNs(String voiceOrderId);
	
	@Query("select gt from GET_VOICEDATA_VIEW gt where voiceOrderId in :voids")
	public List<LandingScreenDTO> getTNsFromVoid(@Param("voids")List<Long> voids); 

}
