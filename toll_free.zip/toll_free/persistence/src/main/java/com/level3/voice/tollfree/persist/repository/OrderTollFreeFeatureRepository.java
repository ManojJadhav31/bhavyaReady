package com.level3.voice.tollfree.persist.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.level3.voice.common.util.OrderActionCodes;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;

/**
 * Repository for order tollfree Feature table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Transactional
public interface OrderTollFreeFeatureRepository extends JpaRepository<OrderTollFreeFeatureDTO, Long> {

	@Query(value = "select SL_ORDER_SEQ.nextval from dual", nativeQuery = true)
	public Long getParentTxId();

	@Query(value = "select 'SLDB-' || AUDIT_SEQ.nextval from dual", nativeQuery = true)
	String getAuditNextval();

	@Query(value = "select AUDIT_SEQ.nextval from dual", nativeQuery = true)
	String getAuditNextvalWithOutSLDB();

	@Query(value = "select * from ORDER_TOLLFREE_FEATURES where SL_ORDER_ID=?", nativeQuery = true)
	public List<OrderTollFreeFeatureDTO> getAllBySlOrderId(Long slOrderId);

	@Query(value = "select * from (select otf.* from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id "
			+ "where otf.tn = ?1 and slo.external_customer_id = ?2 " + "and slo.action_type_id IN ("
			+ OrderActionCodes.INSTALL + ',' + OrderActionCodes.CHANGE + ',' + 7 + ") "
			+ "order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public OrderTollFreeFeatureDTO getPreviousOrderTollFreeFeatures(String tn, String customerId);

	@Query(value = "select count(otf.sl_order_id) from order_tollfree_features otf "
			+ "inner join sl_order slo on slo.sl_order_id = otf.sl_order_id "
			+ "where otf.tn = ?1 and slo.external_customer_id = ?2", nativeQuery = true)
	public int getVersionCount(String tn, String customerId);

	@Query(value = "select * from ORDER_TOLLFREE_FEATURES ot join SL_ORDER sl on ot.SL_ORDER_ID = sl.SL_ORDER_ID "
			+ "and sl.order_active_yn = 'Y' and sl.order_complete_date is not null "
			+ "where sl.VOICE_ORDER_ID= ?1 and ot.tn= ?2", nativeQuery = true)
	public List<OrderTollFreeFeatureDTO> getAllByVoiceOrderId(Long voiceOrderId, String tn);

	@Query(value = "select slo.action_type_id from (select slo.action_type_id from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id "
			+ "where otf.tn = ?1 and slo.external_customer_id = ?2 "
			+ "order by slo.order_version desc) slo where rownum=1", nativeQuery = true)
	public int getActionType(String wtn, String customerId);

	@Query(value = "select slo.sl_order_id from sl_order slo inner join order_tollfree_features otf on otf.sl_order_id=slo.sl_order_id "
			+ "where otf.tn = ?1 and slo.external_customer_id = ?2 and slo.order_active_yn = 'Y' and slo.action_type_id not in (3)", nativeQuery = true)
	public Long getActiveNonDiscoSlOrderId(String tn, String customerId);

	@Query(value = "select slo.sl_order_id from sl_order slo inner join order_tollfree_features otf on otf.sl_order_id=slo.sl_order_id "
			+ "where otf.tn = ?1 and slo.external_customer_id = ?2 and slo.order_active_yn = 'Y' and slo.action_type_id = 3", nativeQuery = true)
	public Long getActiveDiscoSlOrderId(String tn, String customerId);

	@Query(value = "select * from (select otf.* from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id "
			+ "where otf.tn = ?1 and slo.external_customer_id = ?2 " + "and slo.action_type_id IN ("
			+ OrderActionCodes.INSTALL + ',' + OrderActionCodes.CHANGE + ',' + 7 + ") "
			+ "and slo.order_active_yn != 'Y' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public OrderTollFreeFeatureDTO getPrevNonActiveOrderTollFreeFeatures(String tn, String customerId);

	@Query(value = "select * from ORDER_TOLLFREE_FEATURES where tn=?1", nativeQuery = true)
	public List<OrderTollFreeFeatureDTO> getOrderByTN(String tn);

	@Query(value = "select external_customer_id from (select slo.external_customer_id from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.action_type_id IN (" + OrderActionCodes.INSTALL + ',' + OrderActionCodes.CHANGE + ',' + 6 + ','
			+ 7 + ") "
			+ "and slo.order_status_id = 4 and slo.order_active_yn != 'Y' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public String getPrevCustNonActiveCustomerId(String tn);

	@Query(value = "select * from (select otf.* from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.action_type_id IN (" + OrderActionCodes.INSTALL + ',' + OrderActionCodes.CHANGE + ',' + 6 + ','
			+ 7 + ") "
			+ "and slo.order_status_id = 4 and slo.order_active_yn = 'Y' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public OrderTollFreeFeatureDTO getPrevCustActiveOrderTollFreeFeatures(String tn);

	@Query(value = "select * from (select otf.* from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.action_type_id IN (" + OrderActionCodes.INSTALL + ',' + OrderActionCodes.CHANGE + ',' + 6 + ','
			+ 7 + ") "
			+ "and slo.order_status_id = 4 and slo.order_active_yn != 'Y' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public OrderTollFreeFeatureDTO getPrevCustNonActiveOrderTollFreeFeatures(String tn);

	@Query(value = "select external_customer_id from (select slo.external_customer_id from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.action_type_id IN (" + OrderActionCodes.INSTALL + ',' + OrderActionCodes.CHANGE + ',' + 6 + ','
			+ 7 + ") "
			+ "and slo.order_status_id = 4 and slo.order_active_yn = 'Y' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public String getPrevCustActiveCustomerId(String tn);

	@Query(value = "select external_customer_id from (select slo.external_customer_id from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.order_status_id = 4 and slo.order_active_yn = 'Y' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public String getPrevCustCustomerId(String tn);

	@Query(value = "select external_customer_id from (select slo.external_customer_id from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.voice_order_id = ?2 and slo.order_active_yn = 'N' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public String getPrevDiscoCustomerId(String tn, String voiceOrderId);

	@Query(value = "select DISCONNECT_DATE from (select slo.DISCONNECT_DATE from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.voice_order_id != ?2 and slo.action_type_id = 3 "
			+ "and slo.order_active_yn = 'N' order by slo.sl_order_id desc) otf1 where rownum=1", nativeQuery = true)
	public Date getPrevDiscoDisconnectDate(String tn, String voiceOrderId);

	@Query(value = "select SCID from (select otf.SCID from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.external_customer_id = ?2 and slo.order_active_yn = 'N' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public String getPrevOrderSCID(String tn, String customerId);

	@Query(value = "select sl_order_id from (select slo.sl_order_id from ORDER_TOLLFREE_FEATURES otf "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.voice_order_id = ?2 and slo.action_type_id = 3 and slo.order_active_yn = 'N' order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public String getPrevDiscoSlOrderId(String tn, String voiceOrderId);

	@Query(value = "select tn from ORDER_TOLLFREE_FEATURES where SL_ORDER_ID=?", nativeQuery = true)
	public String getTn(Long slOrderId);

	@Query(value = "select order_activity_pk  from ORDER_TOLLFREE_FEATURES otf inner join order_activity oa on "
			+ "oa.sl_order_id = otf.sl_order_id  where  activity_type_id='916' and tn= ? "
			+ "and oa.status in (2,7)  ", nativeQuery = true)
	public Long getPrevPICOrderActivityPK(String tn);
	
	@Query(value = "select oa.status  from ORDER_TOLLFREE_FEATURES otf inner join order_activity oa on "
			+ "oa.sl_order_id = otf.sl_order_id  where  activity_type_id='916' and tn= ? " , nativeQuery = true)
	public String getPrevPICOrderActivityStatus(String tn);
		
	@Query(value = "select action_type_id from (select slo.action_type_id from ORDER_TOLLFREE_FEATURES otf  "
			+ "inner join SL_ORDER slo on slo.sl_order_id = otf.sl_order_id " + "where otf.tn = ?1 "
			+ "and slo.external_customer_id = ?2 order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public Long getPrevOrderActionType(String tn, String customerId);
	
	@Query(value = "select order_status_id from(select slo.order_status_id from sl_order slo inner join order_tollfree_features otf on otf.sl_order_id=slo.sl_order_id "
			+ "where otf.tn = ?1  and slo.order_active_yn = 'Y'  order by slo.order_version desc) otf1 where rownum=1", nativeQuery = true)
	public Long getPrevSlOrderStatus(String tn);
	
	@Query(value = "select SWB_SEQ.nextval from dual", nativeQuery = true)
	public Long getSWBSeq();
}

