package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is the representation of the ProductOfferingCharge table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "ProductOfferingCharge")
public class ProductOfferingChargeDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ChargeId")
	private Long chargeId;
	@Column(name = "ProductOfferingId")
	private Long productOfferingId;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Column(name = "ChargeBegin")
	private Date chargeBegin;
	@Column(name = "ChargeEnd")
	private Date chargeEnd;
	@Column(name = "Status")
	private String status;

	//
	// @OneToOne(fetch = FetchType.LAZY)
	// @JoinColumn(name = "ChargeId")
	// @MapsId
	// private ChargeDTO charge;

	public Long getProductOfferingId() {
		return productOfferingId;
	}

	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public Long getChargeId() {
		return chargeId;
	}

	public void setChargeId(Long chargeId) {
		this.chargeId = chargeId;
	}

	public Date getChargeBegin() {
		return chargeBegin;
	}

	public void setChargeBegin(Date chargeBegin) {
		this.chargeBegin = chargeBegin;
	}

	public Date getChargeEnd() {
		return chargeEnd;
	}

	public void setChargeEnd(Date chargeEnd) {
		this.chargeEnd = chargeEnd;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
