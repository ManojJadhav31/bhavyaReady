package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is to hold the SpecialEndPointType details
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "SpecialEndPointType")
public class SpecialEndPointTypeDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "SpecialEndPointTypeCode")
	private String specialEndPointTypeCode;
	@Column(name = "SpecialEndPointTypeDesc")
	private String specialEndPointTypeDesc;

	public String getSpecialEndPointTypeCode() {
		return specialEndPointTypeCode;
	}

	public void setSpecialEndPointTypeCode(String specialEndPointTypeCode) {
		this.specialEndPointTypeCode = specialEndPointTypeCode;
	}

	public String getSpecialEndPointTypeDesc() {
		return specialEndPointTypeDesc;
	}

	public void setSpecialEndPointTypeDesc(String specialEndPointTypeDesc) {
		this.specialEndPointTypeDesc = specialEndPointTypeDesc;
	}

}
