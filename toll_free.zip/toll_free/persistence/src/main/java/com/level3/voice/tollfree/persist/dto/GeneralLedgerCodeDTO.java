package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is the representation of the generalledgercode table
 * 
 * @author <a href="mailto:Mushahid.Khan@centurylink.com">Mushahid.Khan</a>
 *
 */
@Entity
@Table(name = "generalledgercode")
public class GeneralLedgerCodeDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "OrganizationId")
	private String organizationId;
	@Id
	@Column(name = "GeneralLedgerCode")
	private String generalLedgerCode;
	@Column(name = "Description")
	private String description;

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public String getGeneralLedgerCode() {
		return generalLedgerCode;
	}

	public void setGeneralLedgerCode(String generalLedgerCode) {
		this.generalLedgerCode = generalLedgerCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
