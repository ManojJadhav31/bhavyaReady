package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */

@Entity(name = "cdrServiceType")
@Table(name = "CDRSERVTYPE_USAGE@SLCDB_RATING", schema = "CDR")
@IdClass(CdrServiceComposite.class)
public class CdrServiceTypeUsageDTO implements Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = -1231051879306196489L;
	
	public CdrServiceTypeUsageDTO(String serviceType, String totalCalls,
			String totalMinutes,String serviceDescription) {
		super();
		this.serviceType = serviceType;
		this.totalCalls = Double.parseDouble(totalCalls);
		this.totalMinutes = Double.parseDouble(totalMinutes);
		this.serviceDescription=serviceDescription;
	}
	public CdrServiceTypeUsageDTO() {
	}
	@Id
	@Column(name = "ACCOUNT")
	private Long account;
	@Column(name = "SERVTYPE")
	private String serviceType;
	@Id
	@Column(name = "ANSWER_DATE")
	private Date answerDate;
	@Column(name = "TOTAL_CALLS")
	private Double totalCalls;
	@Column(name = "TOTAL_MINUTES")
	private Double totalMinutes;
	@Transient
	private String serviceDescription;

	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public Date getAnswerDate() {
		return answerDate;
	}

	public void setAnswerDate(Date answerDate) {
		this.answerDate = answerDate;
	}

	public Long getAccount() {
		return account;
	}

	public void setAccount(Long account) {
		this.account = account;
	}

	public Double getTotalCalls() {
		return totalCalls;
	}

	public void setTotalCalls(Double totalCalls) {
		this.totalCalls = totalCalls;
	}

	public Double getTotalMinutes() {
		return totalMinutes;
	}

	public void setTotalMinutes(Double totalMinutes) {
		this.totalMinutes = totalMinutes;
	}

	
	
}
