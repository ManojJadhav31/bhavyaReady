package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * This DTO is the representation of the ProductOffering table
 * 
 * @author <a href="mailto:Mushahid.Khan@centurylink.com">Mushahid.Khan</a>
 *
 */
@Entity
@Table(name = "ProductOffering")
public class ProductOfferingDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ProductOfferingId")
	private Long productOfferingId;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Column(name = "ProductId")
	private String productId;
	@Column(name = "Description")
	private String description;
	@Column(name = "Status")
	private String status;
	@Column(name = "BeginDate")
	private Date beginDate;
	@Column(name = "EndDate")
	private Date endDate;
	@Column(name = "SalesRepId")
	private Long salesRepId;
	@Column(name = "CategoryId")
	private Long categoryId;
	@Column(name = "Quantity")
	private String quantity;
	@Column(name = "EnableQuantity")
	private String enableQuantity;
	@Column(name = "ProductGroupCode")
	private String productGroupCode;
	@Column(name = "ChargeCode")
	private String chargeCode;
	@Column(name = "SCID")
	private String scId;

	@Transient
	private List<ChargeDTO> chargeDTOs;
	@Transient
	private MarketAreaProductOfferingDTO marketAreaProductOfferingDTO;
	@Transient
	private ProductOfferingRatePlanDTO productOfferingRatePlanDTO;
	@Transient
	private List<ProductWithSpecialEndPointDTO> productWithSpecialEndPointDTOs;

	// @OneToOne(mappedBy = "productOffering", fetch = FetchType.LAZY, cascade =
	// CascadeType.ALL)
	// @Basic(fetch = FetchType.LAZY)
	// private MarketAreaProductOfferingDTO mAreaProductOfferingDTO;
	//
	// @OneToOne(mappedBy = "productOffering", fetch = FetchType.LAZY, cascade =
	// CascadeType.ALL)
	// @Basic(fetch = FetchType.LAZY)
	// private ProductOfferingRatePlanDTO prOfferingRatePlanDTO;

	public Long getProductOfferingId() {
		return productOfferingId;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public String getProductId() {
		return productId;
	}

	public String getDescription() {
		return description;
	}

	public String getStatus() {
		return status;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public Long getSalesRepId() {
		return salesRepId;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public String getQuantity() {
		return quantity;
	}

	public String getEnableQuantity() {
		return enableQuantity;
	}

	public String getProductGroupCode() {
		return productGroupCode;
	}

	public String getChargeCode() {
		return chargeCode;
	}

	public String getScId() {
		return scId;
	}

	public List<ChargeDTO> getChargeDTOs() {
		return chargeDTOs;
	}

	public MarketAreaProductOfferingDTO getMarketAreaProductOfferingDTO() {
		return marketAreaProductOfferingDTO;
	}

	public ProductOfferingRatePlanDTO getProductOfferingRatePlanDTO() {
		return productOfferingRatePlanDTO;
	}

	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setSalesRepId(Long salesRepId) {
		this.salesRepId = salesRepId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public void setEnableQuantity(String enableQuantity) {
		this.enableQuantity = enableQuantity;
	}

	public void setProductGroupCode(String productGroupCode) {
		this.productGroupCode = productGroupCode;
	}

	public void setChargeCode(String chargeCode) {
		this.chargeCode = chargeCode;
	}

	public void setScId(String scId) {
		this.scId = scId;
	}

	public void setChargeDTOs(List<ChargeDTO> chargeDTOs) {
		this.chargeDTOs = chargeDTOs;
	}

	public void setMarketAreaProductOfferingDTO(MarketAreaProductOfferingDTO marketAreaProductOfferingDTO) {
		this.marketAreaProductOfferingDTO = marketAreaProductOfferingDTO;
	}

	public void setProductOfferingRatePlanDTO(ProductOfferingRatePlanDTO productOfferingRatePlanDTO) {
		this.productOfferingRatePlanDTO = productOfferingRatePlanDTO;
	}

	public List<ProductWithSpecialEndPointDTO> getProductWithSpecialEndPointDTOs() {
		return productWithSpecialEndPointDTOs;
	}

	public void setProductWithSpecialEndPointDTOs(List<ProductWithSpecialEndPointDTO> productWithSpecialEndPointDTOs) {
		this.productWithSpecialEndPointDTOs = productWithSpecialEndPointDTOs;
	}

}
