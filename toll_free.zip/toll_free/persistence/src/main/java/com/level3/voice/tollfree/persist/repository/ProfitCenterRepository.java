package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ProfitCenterDTO;

/**
 * This repository is to retrieve all the profit centers rows
 * from the profitcenter table for the selected organization id
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public interface ProfitCenterRepository extends JpaRepository<ProfitCenterDTO, String> {

	@Query(value="from ProfitCenterDTO where organizationId = ? ")
	public List<ProfitCenterDTO> retrieveProfitCenters(String orgId);
}
