package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;


/**
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */

@Entity(name ="getNoResponseFtpView")
@Table(name = "GET_NO_RESPONSE_FTP_VIEW",schema="SUBL_OWNER")
public class GetNoResponseFtpDTO {
	@Column(name = "COMPANY_NAME")
	private String companyName;
	@Column(name = "OCN")
	private String ocn;
	@Column(name = "CUSTOMER_BIZ_ORG_NAME")
	private String customerBizOrgName;
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	@Column(name = "ENTRY_DATE")
	private Date entryDate;
	@Column(name = "PROVISION_BEGIN_DATE")
	private String provisionBeginDate;
	@Column(name = "BTN")
	private String btn;
	@Column(name = "WTN")
	private String wtn;
	@Column(name = "JURISDICTION")
	private String jurisdiction;
	@Id
	@Column(name = "ORDER_NUMBER")
	private String orderNumber;
	
	
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getOcn() {
		return ocn;
	}
	public void setOcn(String ocn) {
		this.ocn = ocn;
	}
	public String getCustomerBizOrgName() {
		return customerBizOrgName;
	}
	public void setCustomerBizOrgName(String customerBizOrgName) {
		this.customerBizOrgName = customerBizOrgName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public Date getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}
	public String getProvisionBeginDate() {
		return provisionBeginDate;
	}
	public void setProvisionBeginDate(String provisionBeginDate) {
		this.provisionBeginDate = provisionBeginDate;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public String getWtn() {
		return wtn;
	}
	public void setWtn(String wtn) {
		this.wtn = wtn;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
}
