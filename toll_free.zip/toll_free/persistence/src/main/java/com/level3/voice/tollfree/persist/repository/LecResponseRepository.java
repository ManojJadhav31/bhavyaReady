package com.level3.voice.tollfree.persist.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.level3.voice.tollfree.persist.dto.LECResponseDTO;

@Transactional
public interface LecResponseRepository extends JpaRepository<LECResponseDTO, Long> {

	@Query(value = "from LECResponseDTO where create_date between ?1 and ?2 ")
	public List<LECResponseDTO> getUnAuthorizedPicDisputes(Date startDate, Date endDate);

	@Query(value = "from LECResponseDTO where acOrderNum=?")
	public LECResponseDTO getBySlOrderId(String slOrderId);
}
