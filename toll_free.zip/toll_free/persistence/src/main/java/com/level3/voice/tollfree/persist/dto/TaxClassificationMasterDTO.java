package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is the representation of TaxClassificationMaster table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "TaxClassificationMaster")
public class TaxClassificationMasterDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "TaxClassificationId")
	private String taxClassificationId;
	@Column(name = "Description")
	private String description;

	public String getTaxClassificationId() {
		return taxClassificationId;
	}

	public void setTaxClassificationId(String taxClassificationId) {
		this.taxClassificationId = taxClassificationId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "TaxClassificationMasterDTO [taxClassificationId=" + taxClassificationId + ", description=" + description
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((taxClassificationId == null) ? 0 : taxClassificationId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxClassificationMasterDTO other = (TaxClassificationMasterDTO) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (taxClassificationId == null) {
			if (other.taxClassificationId != null)
				return false;
		} else if (!taxClassificationId.equals(other.taxClassificationId))
			return false;
		return true;
	}

}
