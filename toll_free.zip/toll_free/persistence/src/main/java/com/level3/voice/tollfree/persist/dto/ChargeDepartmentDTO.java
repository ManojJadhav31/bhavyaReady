package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.ConstructorResult;
import javax.persistence.ColumnResult;

import com.level3.voice.tollfree.persist.vo.CountryDetailsVO;

/**
 * Charge department data is used for
 * populating dropdown on product offering
 * charge screen
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "ChargeDepartment")
@SqlResultSetMapping(
	    name="countryDetailsResult",
	    classes={
	      @ConstructorResult(
	        targetClass=CountryDetailsVO.class,
	        columns={
	          @ColumnResult(name="countryId", type=Long.class),
	          @ColumnResult(name="countryName", type=String.class),
	          @ColumnResult(name="AddressFormatId", type=Long.class)
	          })
	      }
)
public class ChargeDepartmentDTO  implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Id
	@Column(name = "ChargeDepartment")
	private String chargeDepartment;
	@Column(name = "ChargeDepartmentDesc")
	private String chargeDepartmentDesc;
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getChargeDepartment() {
		return chargeDepartment;
	}
	public void setChargeDepartment(String chargeDepartment) {
		this.chargeDepartment = chargeDepartment;
	}
	public String getChargeDepartmentDesc() {
		return chargeDepartmentDesc;
	}
	public void setChargeDepartmentDesc(String chargeDepartmentDesc) {
		this.chargeDepartmentDesc = chargeDepartmentDesc;
	}
	
}
