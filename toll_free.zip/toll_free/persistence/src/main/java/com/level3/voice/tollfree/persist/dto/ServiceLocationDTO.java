package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.level3.voice.tollfree.persist.pk.ServiceLocationPK;


/**
 This DTO is the representation of the ServiceLocation table
 * 
 * @author <a href="mailto:nnupur.krishnaa@centurylink.com">Nnupur.Krishnaa</a>
 *
 */
@Entity
@Table(name = "ServiceLocation")
public class ServiceLocationDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private ServiceLocationPK serviceLocationPK;
	@Column(name = "GeographicCode")
	private String geographicCode;
	@Column(name = "ServiceLocationName")
	private String serviceLocationName;
	@Column(name = "ServiceLocationType")
	private String serviceLocationType;
	@Column(name = "MarketAreaId")
	private Long marketAreaId;
	@Column(name = "AddressId")
	private Long addressId;
	@Column(name = "Address1")
	private String address1;
	@Column(name ="Address2")
	private String address2;
	@Column(name = "City")
	private String city;
	@Column(name = "County")
	private String county;
	@Column(name ="State")
	private String state;
	@Column(name = "ZipCode")
	private String zipCode;
	@Column(name ="Country")
	private String country;	
	@Column(name = "EmailAddress")
	private String emailAddress;
	@Column(name ="ServiceLocationBegin")
	private Date serviceLocationBegin;
	@Column(name = "ServiceLocationEnd")
	private Date serviceLocationEnd;
	@Column(name = "Status")
	private String status;
	@Column(name ="E911PayableEntity")
	private String e911PayableEntity;
	@Column(name = "PayphoneDeclarationCode")
	private String payphoneDeclarationCode;
	@Column(name ="ControlGroupId")
	private String controlGroupId;
	
	@Transient
	private String organizationId;
	@Transient
	private String customerId;
	@Transient
	private String serviceLocationId;
	
	
	public ServiceLocationPK getServiceLocationPK() {
		return serviceLocationPK;
	}
	public void setServiceLocationPK(ServiceLocationPK serviceLocationPK) {
		this.serviceLocationPK = serviceLocationPK;
	}
	public String getGeographicCode() {
		return geographicCode;
	}
	public void setGeographicCode(String geographicCode) {
		this.geographicCode = geographicCode;
	}
	public String getServiceLocationName() {
		return serviceLocationName;
	}
	public void setServiceLocationName(String serviceLocationName) {
		this.serviceLocationName = serviceLocationName;
	}
	public String getServiceLocationType() {
		return serviceLocationType;
	}
	public void setServiceLocationType(String serviceLocationType) {
		this.serviceLocationType = serviceLocationType;
	}
	public Long getMarketAreaId() {
		return marketAreaId;
	}
	public void setMarketAreaId(Long marketAreaId) {
		this.marketAreaId = marketAreaId;
	}
	public Long getAddressId() {
		return addressId;
	}
	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public Date getServiceLocationBegin() {
		return serviceLocationBegin;
	}
	public void setServiceLocationBegin(Date serviceLocationBegin) {
		this.serviceLocationBegin = serviceLocationBegin;
	}
	public Date getServiceLocationEnd() {
		return serviceLocationEnd;
	}
	public void setServiceLocationEnd(Date serviceLocationEnd) {
		this.serviceLocationEnd = serviceLocationEnd;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getE911PayableEntity() {
		return e911PayableEntity;
	}
	public void setE911PayableEntity(String e911PayableEntity) {
		this.e911PayableEntity = e911PayableEntity;
	}
	public String getPayphoneDeclarationCode() {
		return payphoneDeclarationCode;
	}
	public void setPayphoneDeclarationCode(String payphoneDeclarationCode) {
		this.payphoneDeclarationCode = payphoneDeclarationCode;
	}
	public String getControlGroupId() {
		return controlGroupId;
	}
	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getServiceLocationId() {
		return serviceLocationId;
	}
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}

	
	
	
	
	

}
