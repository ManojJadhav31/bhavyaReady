package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is representation of the ProdOfferingLocAsscQueue table
 * 
 * @author <a href="mailto:Nnupur.Krishnaa@centurylink.com">Nnupur.Krishnaa</a>
 *
 */
@Entity
@Table(name = "ProdOfferingLocAsscQueue")
public class ProdOfferingLocAsscQueueDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ProdLocationQueueId")
	private Long prodLocationQueueId;
	@Column(name = "ServiceLocationId")
	private String serviceLocationId;
	@Column(name = "CustomerId")
	private String customerId;
	@Column(name = "CustomerBizOrgId")
	private String customerBizOrgId;
	@Column(name = "ControlGroupId")
	private String controlGroupId;
	@Column(name = "ProductOfferingId")
	private Long productOfferingId;
	@Column(name = "EventType")
	private Long eventType;
	@Column(name = "EnqueueDate")
	private Date enqueueDate;
	@Column(name = "DequeueDate")
	private Date dequeueDate;

	public Long getProdLocationQueueId() {
		return prodLocationQueueId;
	}

	public void setProdLocationQueueId(Long prodLocationQueueId) {
		this.prodLocationQueueId = prodLocationQueueId;
	}

	public String getServiceLocationId() {
		return serviceLocationId;
	}

	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerBizOrgId() {
		return customerBizOrgId;
	}

	public void setCustomerBizOrgId(String customerBizOrgId) {
		this.customerBizOrgId = customerBizOrgId;
	}

	public String getControlGroupId() {
		return controlGroupId;
	}

	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}

	public Long getProductOfferingId() {
		return productOfferingId;
	}

	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}

	public Long getEventType() {
		return eventType;
	}

	public void setEventType(Long eventType) {
		this.eventType = eventType;
	}

	public Date getEnqueueDate() {
		return enqueueDate;
	}

	public void setEnqueueDate(Date enqueueDate) {
		this.enqueueDate = enqueueDate;
	}

	public Date getDequeueDate() {
		return dequeueDate;
	}

	public void setDequeueDate(Date dequeueDate) {
		this.dequeueDate = dequeueDate;
	}

}
