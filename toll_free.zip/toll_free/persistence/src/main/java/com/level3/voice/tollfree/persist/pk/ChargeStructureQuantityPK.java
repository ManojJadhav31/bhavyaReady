package com.level3.voice.tollfree.persist.pk;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * This class is to represent the composite
 * key created with the mentioned columns [ChargeId, OrganizationId, Quantity] against
 * ChargeStructureQuantity
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Embeddable
public class ChargeStructureQuantityPK implements Serializable {

	private static final long serialVersionUID = 1L;
	@Column(name = "ChargeId")
	private Long chargeId;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Column(name = "Quantity")
	private Long quantity;
	
	public Long getChargeId() {
		return chargeId;
	}
	public void setChargeId(Long chargeId) {
		this.chargeId = chargeId;
	}
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public Long getQuantity() {
		return quantity;
	}
	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
}
