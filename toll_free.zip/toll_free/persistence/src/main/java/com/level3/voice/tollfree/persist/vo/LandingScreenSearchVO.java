package com.level3.voice.tollfree.persist.vo;

import java.io.Serializable;
import java.util.List;

public class LandingScreenSearchVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String tn;
	private String btn;
	private String cic;
	private String jurisdiction;
	private String picRequest;
	private String forcedANI;
	private String scid;
	private String serviceId;
	private String[] features;
	private String voiceOrderId;
	private String ban;
	private String serviceLocationId;
	private String ocn;
	private String lec;
	private String tc;
	private String si;
	private String tcsiDesc;
	private String orderCompleteDate;
	private String orderType;
	private String orderStatus;
	private String orderActive;
	private String sourceSystem;
	private String customerId;
	private String customerRequestDate;
	private String productOfferingId;
	private String serviceStatus;
	private String errOrderActivityPk;
	private String orderDate;
	private String createUser;
	private String lastUpdatedUser;
	
	public List<FeaturesVO> featureVo;

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}

	public String getBtn() {
		return btn;
	}

	public void setBtn(String btn) {
		this.btn = btn;
	}

	public String getCic() {
		return cic;
	}

	public void setCic(String cic) {
		this.cic = cic;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getPicRequest() {
		return picRequest;
	}

	public void setPicRequest(String picRequest) {
		this.picRequest = picRequest;
	}

	public String getForcedANI() {
		return forcedANI;
	}

	public void setForcedANI(String forcedANI) {
		this.forcedANI = forcedANI;
	}

	public String getScid() {
		return scid;
	}

	public void setScid(String scid) {
		this.scid = scid;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String[] getFeatures() {
		return features;
	}

	public void setFeatures(String[] features) {
		this.features = features;
	}

	public String getVoiceOrderId() {
		return voiceOrderId;
	}

	public void setVoiceOrderId(String voiceOrderId) {
		this.voiceOrderId = voiceOrderId;
	}

	public String getBan() {
		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	public String getServiceLocationId() {
		return serviceLocationId;
	}

	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}

	public String getOcn() {
		return ocn;
	}

	public void setOcn(String ocn) {
		this.ocn = ocn;
	}

	public String getLec() {
		return lec;
	}

	public void setLec(String lec) {
		this.lec = lec;
	}

	public String getOrderCompleteDate() {
		return orderCompleteDate;
	}

	public void setOrderCompleteDate(String orderCompleteDate) {
		this.orderCompleteDate = orderCompleteDate;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getOrderActive() {
		return orderActive;
	}

	public void setOrderActive(String orderActive) {
		this.orderActive = orderActive;
	}

	public String getTcsiDesc() {
		return tcsiDesc;
	}

	public void setTcsiDesc(String tcsiDesc) {
		this.tcsiDesc = tcsiDesc;
	}

	public String getTc() {
		return tc;
	}

	public void setTc(String tc) {
		this.tc = tc;
	}

	public String getSi() {
		return si;
	}

	public void setSi(String si) {
		this.si = si;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerRequestDate() {
		return customerRequestDate;
	}

	public void setCustomerRequestDate(String customerRequestDate) {
		this.customerRequestDate = customerRequestDate;
	}

	public List<FeaturesVO> getFeatureVo() {
		return featureVo;
	}

	public void setFeatureVo(List<FeaturesVO> featureVo) {
		this.featureVo = featureVo;
	}

	public String getProductOfferingId() {
		return productOfferingId;
	}

	public void setProductOfferingId(String productOfferingId) {
		this.productOfferingId = productOfferingId;
	}

	public String getServiceStatus() {
		return serviceStatus;
	}

	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}

	public String getErrOrderActivityPk() {
		return errOrderActivityPk;
	}

	public void setErrOrderActivityPk(String errOrderActivityPk) {
		this.errOrderActivityPk = errOrderActivityPk;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	
}
