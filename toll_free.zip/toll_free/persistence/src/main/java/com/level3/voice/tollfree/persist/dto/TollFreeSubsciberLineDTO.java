package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity(name = "TOLLFREE_SUBSCRIBER_LINE")
public class TollFreeSubsciberLineDTO implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	/** identifier field */
	@Id
	@SequenceGenerator(name = "SUBSCRIBER_LINE_ID_GENERATOR", sequenceName = "GENERIC_SEQ")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "SUBSCRIBER_LINE_ID_GENERATOR")
	private Long subscriberLineId;

	/** persistent field */
	@Column(name = "TN", nullable = true)
	private String tn;

	/** persistent field */
	@Column(name = "MASTER_BIZ_ORG_ID", nullable = true)
	private String masterBizOrgId;

	/** persistent field */
	@Column(name = "CUSTOMER_BIZ_ORG_ID", nullable = true)
	private String customerBizOrgId;

	/** persistent field */
	@Column(name = "CUSTOMER_BIZ_ORG_NAME", nullable = true)
	private String customerBizOrgName;

	/** persistent field */
	@Column(name = "LAST_UPDATED_USER", nullable = true)
	private String lastUpdatedUser;

	/** persistent field */
	@Column(name = "LAST_UPDATED", nullable = true)
	private Date lastUpdated;

	/** persistent field */
	@Column(name = "CREATED_DATE", nullable = true)
	private Date createdDate;

	/** persistent field */
	@Column(name = "ACTIVE_YN", nullable = true)
	private String activeYn;

	/** persistent field */
	@Column(name = "ACTIVE_YN_IMPL", nullable = true)
	private String activeYnImpl;

	/** persistent field */
	@Column(name = "SWITCH_TYPE", nullable = true)
	private String switchType;

	/** persistent field */
	@Column(name = "PRODUCT_ID", nullable = true)
	private Integer productId;

	/** persistent field */
	@Column(name = "SUBSCRIBER_SITE_ID", nullable = true)
	private Long subscriberSiteId;

	/** persistent field */
	@Column(name = "SERVICE_ADDRESS_ID", nullable = true)
	private Long serviceAddressId;

	/** persistent field */
	@Column(name = "SUBSCRIBER_ID", nullable = true)
	private Long subscriberId;

	/** nullable persistent field */
	@Column(name = "SERVICE_ID", nullable = false)
	private String serviceId;

	/** nullable persistent field */
	@Column(name = "COUNTRY_CODE", nullable = false)
	private String countryCode;

	public Long getSubscriberLineId() {
		return subscriberLineId;
	}

	public void setSubscriberLineId(Long subscriberLineId) {
		this.subscriberLineId = subscriberLineId;
	}

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}

	public String getMasterBizOrgId() {
		return masterBizOrgId;
	}

	public void setMasterBizOrgId(String masterBizOrgId) {
		this.masterBizOrgId = masterBizOrgId;
	}

	public String getCustomerBizOrgId() {
		return customerBizOrgId;
	}

	public void setCustomerBizOrgId(String customerBizOrgId) {
		this.customerBizOrgId = customerBizOrgId;
	}

	public String getCustomerBizOrgName() {
		return customerBizOrgName;
	}

	public void setCustomerBizOrgName(String customerBizOrgName) {
		this.customerBizOrgName = customerBizOrgName;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getActiveYn() {
		return activeYn;
	}

	public void setActiveYn(String activeYn) {
		this.activeYn = activeYn;
	}

	public String getActiveYnImpl() {
		return activeYnImpl;
	}

	public void setActiveYnImpl(String activeYnImpl) {
		this.activeYnImpl = activeYnImpl;
	}

	public String getSwitchType() {
		return switchType;
	}

	public void setSwitchType(String switchType) {
		this.switchType = switchType;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Long getSubscriberSiteId() {
		return subscriberSiteId;
	}

	public void setSubscriberSiteId(Long subscriberSiteId) {
		this.subscriberSiteId = subscriberSiteId;
	}

	public Long getServiceAddressId() {
		return serviceAddressId;
	}

	public void setServiceAddressId(Long serviceAddressId) {
		this.serviceAddressId = serviceAddressId;
	}

	public Long getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Long subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	@Override
	public String toString() {
		return "TollFreeSubsciberLineDTO [subscriberLineId=" + subscriberLineId + ", tn=" + tn + ", masterBizOrgId="
				+ masterBizOrgId + ", customerBizOrgId=" + customerBizOrgId + ", customerBizOrgName="
				+ customerBizOrgName + ", lastUpdatedUser=" + lastUpdatedUser + ", lastUpdated=" + lastUpdated
				+ ", createdDate=" + createdDate + ", activeYn=" + activeYn + ", activeYnImpl=" + activeYnImpl
				+ ", switchType=" + switchType + ", productId=" + productId + ", subscriberSiteId=" + subscriberSiteId
				+ ", serviceAddressId=" + serviceAddressId + ", subscriberId=" + subscriberId + ", serviceId="
				+ serviceId + ", countryCode=" + countryCode + "]";
	}
}