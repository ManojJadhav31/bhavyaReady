package com.level3.voice.tollfree.persist.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.SpecialEndPointTypeDTO;

/**
 * This repository is to retrieve the records from the
 * SpecialEndPointType table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public interface SpecialEndPointTypeRepository extends JpaRepository<SpecialEndPointTypeDTO, String> {

}
