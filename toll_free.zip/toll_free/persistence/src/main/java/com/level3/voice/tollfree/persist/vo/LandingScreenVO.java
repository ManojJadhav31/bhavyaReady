package com.level3.voice.tollfree.persist.vo;

public class LandingScreenVO {

	private String voiceOrderId;
	private String orderDate;
	private String orderCompleteDate;
	private String externalCustomerId;
	private String serviceId;
	private String orderTypeId;
	private String tn;
	private String btn;
	private String cic;
	private String jurisdiction;
	private String picRequest;
	private String forcedANI;
	private String scid;
	public String getVoiceOrderId() {
		return voiceOrderId;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public String getOrderCompleteDate() {
		return orderCompleteDate;
	}
	public String getExternalCustomerId() {
		return externalCustomerId;
	}
	public String getServiceId() {
		return serviceId;
	}
	public String getOrderTypeId() {
		return orderTypeId;
	}
	public String getTn() {
		return tn;
	}
	public String getBtn() {
		return btn;
	}
	public String getCic() {
		return cic;
	}
	public String getJurisdiction() {
		return jurisdiction;
	}
	public String getPicRequest() {
		return picRequest;
	}
	public String getForcedANI() {
		return forcedANI;
	}
	public String getScid() {
		return scid;
	}
	public void setVoiceOrderId(String voiceOrderId) {
		this.voiceOrderId = voiceOrderId;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public void setOrderCompleteDate(String orderCompleteDate) {
		this.orderCompleteDate = orderCompleteDate;
	}
	public void setExternalCustomerId(String externalCustomerId) {
		this.externalCustomerId = externalCustomerId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public void setOrderTypeId(String orderTypeId) {
		this.orderTypeId = orderTypeId;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}
	public void setPicRequest(String picRequest) {
		this.picRequest = picRequest;
	}
	public void setForcedANI(String forcedANI) {
		this.forcedANI = forcedANI;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	
	
}
