package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is the representation of the uv_IProductMaster table
 * 
 * @author <a href="mailto:Mushahid.Khan@centurylink.com">Mushahid.Khan</a>
 */
@Entity
@Table(name = "uv_IProductMaster")
public class ProductMasterDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ProductId")
	private String productId;
	@Column(name = "ProductType")
	private String productType;
	@Column(name = "DetailType")
	private String detailType;
	@Column(name = "Description")
	private String description;
	@Column(name = "Status")
	private String status;
	@Column(name = "ProductBegin")
	private Date productBegin;
	@Column(name = "ProductEnd")
	private Date productEnd;
	@Column(name = "ProvPlanType")
	private String provPlanType;
	
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getDetailType() {
		return detailType;
	}
	public void setDetailType(String detailType) {
		this.detailType = detailType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getProductBegin() {
		return productBegin;
	}
	public void setProductBegin(Date productBegin) {
		this.productBegin = productBegin;
	}
	public Date getProductEnd() {
		return productEnd;
	}
	public void setProductEnd(Date productEnd) {
		this.productEnd = productEnd;
	}
	public String getProvPlanType() {
		return provPlanType;
	}
	public void setProvPlanType(String provPlanType) {
		this.provPlanType = provPlanType;
	}
	
	
	@Override
	public String toString() {
		return "ProductMasterDTO [productId=" + productId + ", productType=" + productType + ", detailType="
				+ detailType + ", description=" + description + ", status=" + status + ", productBegin=" + productBegin
				+ ", productEnd=" + productEnd + ", provPlanType=" + provPlanType + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((detailType == null) ? 0 : detailType.hashCode());
		result = prime * result + ((productBegin == null) ? 0 : productBegin.hashCode());
		result = prime * result + ((productEnd == null) ? 0 : productEnd.hashCode());
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		result = prime * result + ((productType == null) ? 0 : productType.hashCode());
		result = prime * result + ((provPlanType == null) ? 0 : provPlanType.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductMasterDTO other = (ProductMasterDTO) obj;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (detailType == null) {
			if (other.detailType != null)
				return false;
		} else if (!detailType.equals(other.detailType))
			return false;
		if (productBegin == null) {
			if (other.productBegin != null)
				return false;
		} else if (!productBegin.equals(other.productBegin))
			return false;
		if (productEnd == null) {
			if (other.productEnd != null)
				return false;
		} else if (!productEnd.equals(other.productEnd))
			return false;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		if (productType == null) {
			if (other.productType != null)
				return false;
		} else if (!productType.equals(other.productType))
			return false;
		if (provPlanType == null) {
			if (other.provPlanType != null)
				return false;
		} else if (!provPlanType.equals(other.provPlanType))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}
	
	

}
