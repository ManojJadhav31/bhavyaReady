package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.level3.voice.tollfree.persist.pk.ProductOfferingRatePlanPK;

/**
 * This DTO is the representation of the ProductOfferingRatePlan table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "ProductOfferingRatePlan")
public class ProductOfferingRatePlanDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private ProductOfferingRatePlanPK productOfferingRatePlanPK;
	@Column(name = "RatePlanBegin")
	private Date ratePlanBegin;
	@Column(name = "RatePlanEnd")
	private Date ratePlanEnd;
	@Column(name = "Status")
	private String status;
	
	@Transient
	private Long productOfferingId;
	@Transient
	private String organizationId;
	@Transient
	private Long ratePlanId;
	@Transient
	private String description;
	

	// @OneToOne(fetch = FetchType.LAZY)
	// @JoinColumn(name = "ProductOfferingId")
	// @MapsId
	// private ProductOfferingDTO productOffering;

	public Date getRatePlanBegin() {
		return ratePlanBegin;
	}

	public Date getRatePlanEnd() {
		return ratePlanEnd;
	}

	public String getStatus() {
		return status;
	}

	public void setRatePlanBegin(Date ratePlanBegin) {
		this.ratePlanBegin = ratePlanBegin;
	}

	public void setRatePlanEnd(Date ratePlanEnd) {
		this.ratePlanEnd = ratePlanEnd;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ProductOfferingRatePlanPK getProductOfferingRatePlanPK() {
		return productOfferingRatePlanPK;
	}

	public void setProductOfferingRatePlanPK(ProductOfferingRatePlanPK productOfferingRatePlanPK) {
		this.productOfferingRatePlanPK = productOfferingRatePlanPK;
	}

	public Long getProductOfferingId() {
		return productOfferingId;
	}

	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public Long getRatePlanId() {
		return ratePlanId;
	}

	public void setRatePlanId(Long ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
