package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "Address")
public class ServiceAddressDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "AddressId")
	private Long addressId;
	@Column(name = "AddressFormatId")
	private Long addressFormatId;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Column(name = "CustomerId")
	private String customerId;
	@Column(name = "Address1")
	private String address1;
	@Column(name = "Address2")
	private String address2;
	@Column(name = "Address3")
	private String address3;
	@Column(name = "Address4")
	private String address4;
	@Column(name = "Address5")
	private String address5;
	@Column(name = "Address6")
	private String address6;
	@Column(name = "CountryId")
	private Long countryId;
	@Column(name = "CountyName")
	private String countyName;
	@Column(name = "ZipCodePlus4")
	private String ZipCodePlus4;
	@Column(name = "GeographicCode")
	private String geographicCode;
	@Column(name = "InsideOutsideCityLimits")
	private String insideOutsideCityLimits;

	@Transient
	private String countryCode;

	@Transient
	private String countryName;

	public Long getAddressId() {
		return addressId;
	}

	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	public Long getAddressFormatId() {
		return addressFormatId;
	}

	public void setAddressFormatId(Long addressFormatId) {
		this.addressFormatId = addressFormatId;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getAddress5() {
		return address5;
	}

	public void setAddress5(String address5) {
		this.address5 = address5;
	}

	public String getAddress6() {
		return address6;
	}

	public void setAddress6(String address6) {
		this.address6 = address6;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getCountyName() {
		return countyName;
	}

	public void setCountyName(String countyName) {
		this.countyName = countyName;
	}

	public String getZipCodePlus4() {
		return ZipCodePlus4;
	}

	public void setZipCodePlus4(String zipCodePlus4) {
		ZipCodePlus4 = zipCodePlus4;
	}

	public String getGeographicCode() {
		return geographicCode;
	}

	public void setGeographicCode(String geographicCode) {
		this.geographicCode = geographicCode;
	}

	public String getInsideOutsideCityLimits() {
		return insideOutsideCityLimits;
	}

	public void setInsideOutsideCityLimits(String insideOutsideCityLimits) {
		this.insideOutsideCityLimits = insideOutsideCityLimits;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
}
