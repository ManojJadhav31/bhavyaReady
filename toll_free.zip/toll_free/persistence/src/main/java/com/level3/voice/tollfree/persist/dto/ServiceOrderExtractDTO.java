package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO represents serviceorderextract table from
 * NS sandstone
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "ServiceOrderExtract")
public class ServiceOrderExtractDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "Order_ID")
	private String orderId;
	@Column(name = "Service_ID")
	private Long serviceId;
	@Column(name = "SO_Version")
	private Long soVersion;
	@Column(name = "BillStartDate")
	private Date billStartDate;
	@Column(name = "BillEndDate")
	private Date billEndDate;
	@Column(name = "Order_Status")
	private String orderStatus;
	@Column(name = "Installed_Date")
	private Date installedDate;
	@Column(name = "SCID")
	private String scid;
	@Column(name = "Component_Type")
	private String componentType;
	@Column(name = "Component_Action")
	private String componentAction;
	@Column(name = "Product_PIID")
	private String productPiid;
	@Column(name = "Service_Type_ID")
	private Long serviceTypeId;
	@Column(name = "Service_SCID")
	private String serviceScid;
	@Column(name = "IsRetrieved")
	private String isRetrieved;
	@Column(name = "BTN")
	private String btn;
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the serviceId
	 */
	public Long getServiceId() {
		return serviceId;
	}
	/**
	 * @param serviceId the serviceId to set
	 */
	public void setServiceId(Long serviceId) {
		this.serviceId = serviceId;
	}
	/**
	 * @return the soVersion
	 */
	public Long getSoVersion() {
		return soVersion;
	}
	/**
	 * @param soVersion the soVersion to set
	 */
	public void setSoVersion(Long soVersion) {
		this.soVersion = soVersion;
	}
	/**
	 * @return the billStartDate
	 */
	public Date getBillStartDate() {
		return billStartDate;
	}
	/**
	 * @param billStartDate the billStartDate to set
	 */
	public void setBillStartDate(Date billStartDate) {
		this.billStartDate = billStartDate;
	}
	/**
	 * @return the billEndDate
	 */
	public Date getBillEndDate() {
		return billEndDate;
	}
	/**
	 * @param billEndDate the billEndDate to set
	 */
	public void setBillEndDate(Date billEndDate) {
		this.billEndDate = billEndDate;
	}
	/**
	 * @return the orderStatus
	 */
	public String getOrderStatus() {
		return orderStatus;
	}
	/**
	 * @param orderStatus the orderStatus to set
	 */
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	/**
	 * @return the installedDate
	 */
	public Date getInstalledDate() {
		return installedDate;
	}
	/**
	 * @param installedDate the installedDate to set
	 */
	public void setInstalledDate(Date installedDate) {
		this.installedDate = installedDate;
	}
	/**
	 * @return the scid
	 */
	public String getScid() {
		return scid;
	}
	/**
	 * @param scid the scid to set
	 */
	public void setScid(String scid) {
		this.scid = scid;
	}
	/**
	 * @return the componentType
	 */
	public String getComponentType() {
		return componentType;
	}
	/**
	 * @param componentType the componentType to set
	 */
	public void setComponentType(String componentType) {
		this.componentType = componentType;
	}
	/**
	 * @return the componentAction
	 */
	public String getComponentAction() {
		return componentAction;
	}
	/**
	 * @param componentAction the componentAction to set
	 */
	public void setComponentAction(String componentAction) {
		this.componentAction = componentAction;
	}
	/**
	 * @return the productPiid
	 */
	public String getProductPiid() {
		return productPiid;
	}
	/**
	 * @param productPiid the productPiid to set
	 */
	public void setProductPiid(String productPiid) {
		this.productPiid = productPiid;
	}
	/**
	 * @return the serviceTypeId
	 */
	public Long getServiceTypeId() {
		return serviceTypeId;
	}
	/**
	 * @param serviceTypeId the serviceTypeId to set
	 */
	public void setServiceTypeId(Long serviceTypeId) {
		this.serviceTypeId = serviceTypeId;
	}
	/**
	 * @return the serviceScid
	 */
	public String getServiceScid() {
		return serviceScid;
	}
	/**
	 * @param serviceScid the serviceScid to set
	 */
	public void setServiceScid(String serviceScid) {
		this.serviceScid = serviceScid;
	}
	/**
	 * @return the isRetrieved
	 */
	public String getIsRetrieved() {
		return isRetrieved;
	}
	/**
	 * @param isRetrieved the isRetrieved to set
	 */
	public void setIsRetrieved(String isRetrieved) {
		this.isRetrieved = isRetrieved;
	}
	/**
	 * @return the btn
	 */
	public String getBtn() {
		return btn;
	}
	/**
	 * @param btn the btn to set
	 */
	public void setBtn(String btn) {
		this.btn = btn;
	}
	
}
