package com.level3.voice.tollfree.persist.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.level3.voice.tollfree.persist.dto.XMasterSubOcnDTO;

/**
 * This repository is to fetch the records from XMasterSubOcn tables
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Transactional
public interface XMasterSubOcnRepository extends JpaRepository<XMasterSubOcnDTO, String> {

	@Query("select masterOcn from XMASTER_SUB_OCN xmsOcn where subOcn in :subOcn")
	public String getMasterOcn(@Param("subOcn") String subOcn);
}
