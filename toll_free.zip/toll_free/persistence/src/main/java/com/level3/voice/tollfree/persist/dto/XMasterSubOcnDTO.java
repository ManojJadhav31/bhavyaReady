package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is capturing OCN's related to the XMASTER_SUB_OCN.
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity(name = "XMASTER_SUB_OCN")
@Table(name = "XMASTER_SUB_OCN")
public class XMasterSubOcnDTO {

	/** identifier field */
	@Id
	@Column(name = "MASTEROCN")
	private String masterOcn;

	@Column(name = "SUBOCN")
	private String subOcn;

	/**
	 * @return the masterOcn
	 */
	public String getMasterOcn() {
		return masterOcn;
	}

	/**
	 * @param masterOcn the masterOcn to set
	 */
	public void setMasterOcn(String masterOcn) {
		this.masterOcn = masterOcn;
	}

	/**
	 * @return the subOcn
	 */
	public String getSubOcn() {
		return subOcn;
	}

	/**
	 * @param subOcn the subOcn to set
	 */
	public void setSubOcn(String subOcn) {
		this.subOcn = subOcn;
	}

}
