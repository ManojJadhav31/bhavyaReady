package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.level3.voice.tollfree.persist.pk.MarketAreaProductOfferingPK;

/**
 * This DTO is the representation of the MarketAreaProductOffering table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Entity
@Table(name = "MarketAreaProductOffering")
public class MarketAreaProductOfferingDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private MarketAreaProductOfferingPK marketAreaProductOfferingPK;
	@Column(name = "OrganizationId")
	private String organizationId;
	@Column(name = "BeginDate")
	private Date beginDate;
	@Column(name = "EndDate")
	private Date endDate;
	@Column(name = "Status")
	private String status;
	
	@Transient
	private Long productOfferingId;
	@Transient
	private Long marketAreaId;

	// @OneToOne(fetch = FetchType.LAZY)
	// @JoinColumn(name = "ProductOfferingId")
	// @MapsId
	// private ProductOfferingDTO productOffering;

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public MarketAreaProductOfferingPK getMarketAreaProductOfferingPK() {
		return marketAreaProductOfferingPK;
	}

	public void setMarketAreaProductOfferingPK(MarketAreaProductOfferingPK marketAreaProductOfferingPK) {
		this.marketAreaProductOfferingPK = marketAreaProductOfferingPK;
	}

	public Long getProductOfferingId() {
		return productOfferingId;
	}

	public void setProductOfferingId(Long productOfferingId) {
		this.productOfferingId = productOfferingId;
	}

	public Long getMarketAreaId() {
		return marketAreaId;
	}

	public void setMarketAreaId(Long marketAreaId) {
		this.marketAreaId = marketAreaId;
	}
	
}
