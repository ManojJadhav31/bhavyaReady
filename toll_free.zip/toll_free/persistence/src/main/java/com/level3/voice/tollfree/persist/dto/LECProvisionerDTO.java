/**
 * @author arun2.kumar
 */
package com.level3.voice.tollfree.persist.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author kumar.arun2
 *
 */
@Entity
@Table(name = "LEC_PROVISIONER")
public class LECProvisionerDTO {
	
	/** identifier field */
    @Id
    @Column(name = "PROVISIONER_NAME")
    private String provisionerName;
    
    @Column(name = "OCN")
    private String ocn;
    
    @Column(name = "OCNABBR")
    private String  ocnAbbr;
    
    @Column(name = "DESCRIPTION")
    private String description;
        
    @Column(name = "STATUS")
    private String status;
    
    @Column(name = "ON_CIC_FLAG")
    private String onCicFlag;
    
    @Column(name = "CRLF_FLAG")
    private String crlfFlag;
    
    @Column(name = "APID")
    private String apid;
    
    @Column(name = "PIC_VERSION")
    private String picVersion;
    
    @Column(name = "RAO")
    private String rao;
    
    @Column(name = "METHOD")
     private  String method;

	public String getProvisionerName() {
		return provisionerName;
	}

	public void setProvisionerName(String provisionerName) {
		this.provisionerName = provisionerName;
	}

	public String getOcn() {
		return ocn;
	}

	public void setOcn(String ocn) {
		this.ocn = ocn;
	}

	public String getOcnAbbr() {
		return ocnAbbr;
	}

	public void setOcnAbbr(String ocnAbbr) {
		this.ocnAbbr = ocnAbbr;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String staus) {
		this.status = staus;
	}

	public String getOnCicFlag() {
		return onCicFlag;
	}

	public void setOnCicFlag(String onCicFlag) {
		this.onCicFlag = onCicFlag;
	}

	public String getCrlfFlag() {
		return crlfFlag;
	}

	public void setCrlfFlag(String crlfFlag) {
		this.crlfFlag = crlfFlag;
	}

	public String getApid() {
		return apid;
	}

	public void setApid(String apid) {
		this.apid = apid;
	}

	public String getPicVersion() {
		return picVersion;
	}

	public void setPicVersion(String picVersion) {
		this.picVersion = picVersion;
	}

	public String getRao() {
		return rao;
	}

	public void setRao(String rao) {
		this.rao = rao;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
    
   }

