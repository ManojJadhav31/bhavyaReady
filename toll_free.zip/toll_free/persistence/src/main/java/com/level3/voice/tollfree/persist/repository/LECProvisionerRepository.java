package com.level3.voice.tollfree.persist.repository;


import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.level3.voice.tollfree.persist.dto.LECProvisionerDTO;


@Transactional
public interface LECProvisionerRepository extends JpaRepository<LECProvisionerDTO, Long> {


	@Query(value="from LECProvisionerDTO "
            + " where provisionerName = ?1 and ocn=?2 and status='A' ")
	public LECProvisionerDTO findLECProvisionerByProvisonerNameOCN(String provisionerName,String ocn);  

	@Query(value="from LECProvisionerDTO Where status='A' ")
	public  List<LECProvisionerDTO> findAllLECProvisioners();
	
	@Query(value = "select provisionerName from LECProvisionerDTO Where ocn=?1 and status='A' ")
 	public String findProvisionerNameByOCN(String ocn);
	
	
}