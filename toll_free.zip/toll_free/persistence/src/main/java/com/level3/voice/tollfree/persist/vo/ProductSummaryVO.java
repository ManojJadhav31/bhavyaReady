package com.level3.voice.tollfree.persist.vo;

public class ProductSummaryVO {

	private static final long serialVersionUID = 1L;
	private String productOffering;
	private String qtyPending;
	private String qtyActive;
	private String qtyDisconnect;
	public String getProductOffering() {
		return productOffering;
	}
	public void setProductOffering(String productOffering) {
		this.productOffering = productOffering;
	}
	public String getQtyPending() {
		return qtyPending;
	}
	public void setQtyPending(String qtyPending) {
		this.qtyPending = qtyPending;
	}
	public String getQtyActive() {
		return qtyActive;
	}
	public void setQtyActive(String qtyActive) {
		this.qtyActive = qtyActive;
	}
	public String getQtyDisconnect() {
		return qtyDisconnect;
	}
	public void setQtyDisconnect(String qtyDisconnect) {
		this.qtyDisconnect = qtyDisconnect;
	}	
	
}
