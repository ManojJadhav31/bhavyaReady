package com.level3.voice.tollfree.persist.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * DTO to hold order tollfree features which would hold 1S/Tollfree related data
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */

@Entity(name = "ORDER_TOLLFREE_FEATURES")
public class OrderTollFreeFeatureDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** identifier field */
	@Id
	@Column(name = "SL_ORDER_ID")
	private Long slOrderId;

	/** persistent field */
	@Column(name = "TN", nullable = true)
	private String tn;

	/** persistent field */
	@Column(name = "LAST_UPDATED_USER", nullable = true)
	private String lastUpdatedUser;

	/** persistent field */
	@Column(name = "LAST_UPDATED", nullable = true)
	private Date lastUpdated;

	/** nullable persistent field */
	@Column(name = "BTN", nullable = false)
	private String btn;

	/** nullable persistent field */
	@Column(name = "START_DATE", nullable = false)
	private Date startDate;

	/** nullable persistent field */
	@Column(name = "PRODUCT_OFFERING_ID", nullable = false)
	private String productOfferingID;

	/** nullable persistent field */
	@Column(name = "RATE_PLAN", nullable = false)
	private String ratePlan;

	/** nullable persistent field */
	@Column(name = "CIC", nullable = false)
	private String cic;

	/** nullable persistent field */
	@Column(name = "POSITIVE_ANI", nullable = false)
	private String positiveANI;

	/** nullable persistent field */
	@Column(name = "BLOCKING", nullable = false)
	private String blocking;

	/** nullable persistent field */
	@Column(name = "BLOCK_ALL", nullable = false)
	private String blockAll;

	/** nullable persistent field */
	@Column(name = "BLOCK_CARIB_INTER", nullable = false)
	private String blockCaribInter;

	/** nullable persistent field */
	@Column(name = "BLOCK_FRAUD_ALL", nullable = false)
	private String blockFraudAll;

	/** nullable persistent field */
	@Column(name = "BLOCK_FRAUD_CARIB_INTER", nullable = false)
	private String blockFraudCaribInter;

	/** nullable persistent field */
	@Column(name = "FORCED_ANI", nullable = false)
	private String forcedANI;

	/** nullable persistent field */
	@Column(name = "PIC_ICPAY", nullable = false)
	private String picIcpay;

	/** nullable persistent field */
	@Column(name = "PIC_REQUEST", nullable = false)
	private String picRequest;

	/** nullable persistent field */
	@Column(name = "PIC_REQ_FEAT", nullable = false)
	private String picReqFeat;

	/** nullable persistent field */
	@Column(name = "JI_LOAD", nullable = false)
	private String jiLoad;

	/** nullable persistent field */
	@Column(name = "JURISDICTION", nullable = false)
	private String jurisdiction;

	/** nullable persistent field */
	@Column(name = "VALIDATED_AC", nullable = false)
	private String validatedAC;

	/** nullable persistent field */
	@Column(name = "UNVALIDATED_AC", nullable = false)
	private String unvalidatedAC;

	/** nullable persistent field */
	@Column(name = "AC_DIGITS", nullable = false)
	private String acDigits;

	/** nullable persistent field */
	@Column(name = "AC_TABLE_NAME", nullable = false)
	private String acTableName;

	/** nullable persistent field */
	@Column(name = "SCID", nullable = false)
	private String scId;

	/** nullable persistent field */
	@Column(name = "CONTROL_GROUP_ID", nullable = false)
	private String controlGroupId;

	/** nullable persistent field */
	@Column(name = "ACCOUNT_NUMBER", nullable = false)
	private String accountNumber;

	/** nullable persistent field */
	@Column(name = "SERVICE_ADDRESS_ID", nullable = false)
	private String serviceAddressId;

	/** nullable persistent field */
	@Column(name = "BILLING_ACC_NUM", nullable = false)
	private String billingAccNum;

	/** nullable persistent field */
	@Column(name = "CRC", nullable = false)
	private String crc;

	/** nullable persistent field */
	@Column(name = "OTHER_FEATURES", nullable = false)
	private String otherFeat;

	/** nullable persistent field */
	@Column(name = "OCN", nullable = false)
	private String ocn;

	/** nullable persistent field */
	@Column(name = "LEC_PROVISIONER_NAME", nullable = false)
	private String lecProvisionerName;

	/** nullable persistent field */
	@Column(name = "ACCOUNT_CODE_ESF", nullable = false)
	private String accountCodeEsf;

	/** nullable persistent field */
	@Column(name = "AC_TABLE_ID", nullable = false)
	private String acTableId;

	/** nullable persistent field */
	@Column(name = "PORTED_ANI", nullable = false)
	private String portedANI;

	/** nullable persistent field */
	@Column(name = "SERVICE_ID", nullable = false)
	private String serviceID;

	/** default constructor */
	public OrderTollFreeFeatureDTO() {
	}

	public OrderTollFreeFeatureDTO(Long slOrderId, String tn, String lastUpdatedUser, Date lastUpdated, String btn,
			Date startDate, String productOfferingID, String ratePlan, String cic, String positiveANI, String blocking,
			String blockAll, String blockCaribInter, String blockFraudAll, String blockFraudCaribInter,
			String forcedANI, String picIcpay, String picRequest, String picReqFeat, String jiLoad, String jurisdiction,
			String validatedAC, String unvalidatedAC, String acDigits, String acTableName, String scId,
			String controlGroupId, String accountNumber, String serviceAddressId, String billingAccNum, String crc,
			String otherFeat, String ocn, String lecProvisionerName, String accountCodeEsf, String acTableId,
			String portedANI, String serviceID) {
		super();
		this.slOrderId = slOrderId;
		this.tn = tn;
		this.lastUpdatedUser = lastUpdatedUser;
		this.lastUpdated = lastUpdated;
		this.btn = btn;
		this.startDate = startDate;
		this.productOfferingID = productOfferingID;
		this.ratePlan = ratePlan;
		this.cic = cic;
		this.positiveANI = positiveANI;
		this.blocking = blocking;
		this.blockAll = blockAll;
		this.blockCaribInter = blockCaribInter;
		this.blockFraudAll = blockFraudAll;
		this.blockFraudCaribInter = blockFraudCaribInter;
		this.forcedANI = forcedANI;
		this.picIcpay = picIcpay;
		this.picRequest = picRequest;
		this.picReqFeat = picReqFeat;
		this.jiLoad = jiLoad;
		this.jurisdiction = jurisdiction;
		this.validatedAC = validatedAC;
		this.unvalidatedAC = unvalidatedAC;
		this.acDigits = acDigits;
		this.acTableName = acTableName;
		this.scId = scId;
		this.controlGroupId = controlGroupId;
		this.accountNumber = accountNumber;
		this.serviceAddressId = serviceAddressId;
		this.billingAccNum = billingAccNum;
		this.crc = crc;
		this.otherFeat = otherFeat;
		this.ocn = ocn;
		this.lecProvisionerName = lecProvisionerName;
		this.accountCodeEsf = accountCodeEsf;
		this.acTableId = acTableId;
		this.portedANI = portedANI;
		this.serviceID = serviceID;
	}

	public Long getSlOrderId() {
		return slOrderId;
	}

	public void setSlOrderId(Long slOrderId) {
		this.slOrderId = slOrderId;
	}

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getBtn() {
		return btn;
	}

	public void setBtn(String btn) {
		this.btn = btn;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getProductOfferingID() {
		return productOfferingID;
	}

	public void setProductOfferingID(String productOfferingID) {
		this.productOfferingID = productOfferingID;
	}

	public String getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(String ratePlan) {
		this.ratePlan = ratePlan;
	}

	public String getCic() {
		return cic;
	}

	public void setCic(String cic) {
		this.cic = cic;
	}

	public String getPositiveANI() {
		return positiveANI;
	}

	public void setPositiveANI(String positiveANI) {
		this.positiveANI = positiveANI;
	}

	public String getBlocking() {
		return blocking;
	}

	public void setBlocking(String blocking) {
		this.blocking = blocking;
	}

	public String getBlockAll() {
		return blockAll;
	}

	public void setBlockAll(String blockAll) {
		this.blockAll = blockAll;
	}

	public String getBlockCaribInter() {
		return blockCaribInter;
	}

	public void setBlockCaribInter(String blockCaribInter) {
		this.blockCaribInter = blockCaribInter;
	}

	public String getBlockFraudAll() {
		return blockFraudAll;
	}

	public void setBlockFraudAll(String blockFraudAll) {
		this.blockFraudAll = blockFraudAll;
	}

	public String getBlockFraudCaribInter() {
		return blockFraudCaribInter;
	}

	public void setBlockFraudCaribInter(String blockFraudCaribInter) {
		this.blockFraudCaribInter = blockFraudCaribInter;
	}

	public String getForcedANI() {
		return forcedANI;
	}

	public void setForcedANI(String forcedANI) {
		this.forcedANI = forcedANI;
	}

	public String getPicIcpay() {
		return picIcpay;
	}

	public void setPicIcpay(String picIcpay) {
		this.picIcpay = picIcpay;
	}

	public String getPicRequest() {
		return picRequest;
	}

	public void setPicRequest(String picRequest) {
		this.picRequest = picRequest;
	}

	public String getJiLoad() {
		return jiLoad;
	}

	public void setJiLoad(String jiLoad) {
		this.jiLoad = jiLoad;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getValidatedAC() {
		return validatedAC;
	}

	public void setValidatedAC(String validatedAC) {
		this.validatedAC = validatedAC;
	}

	public String getUnvalidatedAC() {
		return unvalidatedAC;
	}

	public void setUnvalidatedAC(String unvalidatedAC) {
		this.unvalidatedAC = unvalidatedAC;
	}

	public String getAcDigits() {
		return acDigits;
	}

	public void setAcDigits(String acDigits) {
		this.acDigits = acDigits;
	}

	public String getAcTableName() {
		return acTableName;
	}

	public void setAcTableName(String acTableName) {
		this.acTableName = acTableName;
	}

	public String getPicReqFeat() {
		return picReqFeat;
	}

	public void setPicReqFeat(String picReqFeat) {
		this.picReqFeat = picReqFeat;
	}

	public String getOtherFeat() {
		return otherFeat;
	}

	public void setOtherFeat(String otherFeat) {
		this.otherFeat = otherFeat;
	}

	public String getScId() {
		return scId;
	}

	public void setScId(String scId) {
		this.scId = scId;
	}

	public String getControlGroupId() {
		return controlGroupId;
	}

	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getServiceAddressId() {
		return serviceAddressId;
	}

	public void setServiceAddressId(String serviceAddressId) {
		this.serviceAddressId = serviceAddressId;
	}

	public String getBillingAccNum() {
		return billingAccNum;
	}

	public void setBillingAccNum(String billingAccNum) {
		this.billingAccNum = billingAccNum;
	}

	public String getCrc() {
		return crc;
	}

	public void setCrc(String crc) {
		this.crc = crc;
	}

	public String getOcn() {
		return ocn;
	}

	public void setOcn(String ocn) {
		this.ocn = ocn;
	}

	public String getLecProvisionerName() {
		return lecProvisionerName;
	}

	public void setLecProvisionerName(String lecProvisionerName) {
		this.lecProvisionerName = lecProvisionerName;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("slOrderId", getSlOrderId()).toString();
	}

	@Override
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if (!(other instanceof OrderTollFreeFeatureDTO))
			return false;
		OrderTollFreeFeatureDTO castOther = (OrderTollFreeFeatureDTO) other;
		return new EqualsBuilder().append(this.getSlOrderId(), castOther.getSlOrderId()).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(getSlOrderId()).toHashCode();
	}

	public String getAccountCodeEsf() {
		return accountCodeEsf;
	}

	public void setAccountCodeEsf(String accountCodeEsf) {
		this.accountCodeEsf = accountCodeEsf;
	}

	public String getAcTableId() {
		return acTableId;
	}

	public void setAcTableId(String acTableId) {
		this.acTableId = acTableId;
	}

	public String getPortedANI() {
		return portedANI;
	}

	public void setPortedANI(String portedANI) {
		this.portedANI = portedANI;
	}

	/**
	 * @return the serviceID
	 */
	public String getServiceID() {
		return serviceID;
	}

	/**
	 * @param serviceID
	 *            the serviceID to set
	 */
	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}
}
