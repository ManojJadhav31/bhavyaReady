package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ServiceOrderExtractDTO;

/**
 * This the repository which is used to retrieve
 * and persist records in ServiceOrderExtract table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public interface ServiceOrderExtractRepository extends JpaRepository<ServiceOrderExtractDTO, Long>{

	@Query(value="from ServiceOrderExtractDTO where isRetrieved = 'N' and service_scid <> ''")
	public List<ServiceOrderExtractDTO> retrieveServiceExtract();
	
}
