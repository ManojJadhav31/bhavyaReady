package com.level3.voice.tollfree.persist.vo;

public class VolumeDiscPlanVO {

	private String discountPlanId;
	private String discountPlanType;
	private String description;
	
	public String getDiscountPlanId() {
		return discountPlanId;
	}
	public void setDiscountPlanId(String discountPlanId) {
		this.discountPlanId = discountPlanId;
	}
	public String getDiscountPlanType() {
		return discountPlanType;
	}
	public void setDiscountPlanType(String discountPlanType) {
		this.discountPlanType = discountPlanType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
}
