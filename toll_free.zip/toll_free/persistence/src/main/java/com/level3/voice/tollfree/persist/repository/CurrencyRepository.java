package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.CurrencyDTO;

/**
 * This repository is to retrieve all the
 * currency rows from the currency table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Component
public interface CurrencyRepository extends JpaRepository<CurrencyDTO, String> {

	@Query(value="from CurrencyDTO ")
	public List<CurrencyDTO> retrieveProfitCenters();
}
