package com.level3.voice.tollfree.persist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.persist.dto.ChargeStructureQuantityDTO;

/**
 * This repository is to retrieve/persist charge structure details in
 * chargeStructureQuantity table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 */
@Component
public interface ChargeStructureQuantityRepository extends JpaRepository<ChargeStructureQuantityDTO, Long> {

	@Query(value="from ChargeStructureQuantityDTO where chargeId = ?")
	public List<ChargeStructureQuantityDTO> findChargeStructureQuantityByChargeId(Long chargeId);

}
