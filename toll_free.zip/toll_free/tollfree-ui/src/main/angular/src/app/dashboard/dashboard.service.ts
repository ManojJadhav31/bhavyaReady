import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
@Injectable()
export class DashboardService {

  ordersChartURL="tollfree-order/ServiceDelivery/v1/Voice/dashboard/ordersChart"
  activitiesChartURL="tollfree-order/ServiceDelivery/v1/Voice/dashboard/activitiesChart";
  http: HttpClient;
  
  constructor(http: HttpClient) { 
    this.http=http;
  }


  
  
  loadActivityChart(baseUrl,userName):Observable<any[]> {
    return this.http.get<any[]>(baseUrl+"/"+this.activitiesChartURL+"/"+userName);
  }

  loadOrderChart(baseUrl,userName):Observable<any[]> {
    return this.http.get<any[]>(baseUrl+"/"+this.ordersChartURL+"/"+userName);
  }
}
