
export class BillingInformationVO{
    
    accountNumber:string;
    accountName:string;
   
}