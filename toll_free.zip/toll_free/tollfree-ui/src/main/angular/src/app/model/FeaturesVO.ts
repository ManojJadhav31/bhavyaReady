

export class FeaturesVO{
    
    featureOfferingId:string;
    featureDescription:string;
    accountCodeESF:string;
    
}