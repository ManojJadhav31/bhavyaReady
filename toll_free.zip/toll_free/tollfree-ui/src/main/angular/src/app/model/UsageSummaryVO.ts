export class UsageSummaryVO {
    account:Number;
    serviceType:String;
    fromDate:String;
    toDate:String;
}