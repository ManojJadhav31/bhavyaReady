export class GeneralLedgerCodeVO{
    organizationId :String;
	generalLedgerCode:String;
	description:String;
}