
export class InitialChargeStructureQuantityDTO {
    chargeId: string;
    organizationId: string;
    quantity: Number;
    chargeAmount: Number;
    description: string;

}