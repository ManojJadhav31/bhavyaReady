
export class DiscountPlanVO {
    discountPlanId:string="";
    discountPlanType:string ="";
}