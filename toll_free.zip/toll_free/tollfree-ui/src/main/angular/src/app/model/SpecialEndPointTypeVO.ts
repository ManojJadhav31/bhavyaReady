export class SpecialEndPointTypeDTO {
    specialEndPointTypeCode: string;
    specialEndPointTypeDesc: string;
}