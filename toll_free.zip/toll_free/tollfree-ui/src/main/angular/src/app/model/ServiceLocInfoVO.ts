import { AddressVO } from "./AddressVO";
import { ContactsVO } from "./ContactsVO";
import { ProductSummaryVO } from "./ProductSummaryVO";
import { MarketAreaVO } from "./MarketAreaVO";
import { PayPhoneVO } from "./PayPhoneVO";

export class ServiceLocInfoVO{

    serviceLocationName:string;
    serviceLocationId:string;
    piid:string;
    serviceLocationStatus:string="A ";
    serviceLocationType:string="B";
    controlGroupId:string="";
     marketAreaId:Number;
    marketArea:string;
   // marketAreaName:string;
    payPhoneBilling:string;
    accountNumber:string;
    billingAccountNumber:string;
    addressVO:AddressVO;
    numberName:string="-1";
    contactsVO: ContactsVO[];
    productSummaryVO:ProductSummaryVO[];
    marketAreaVO:MarketAreaVO[];
    payPhoneVO:PayPhoneVO[];

    
    productDiscountPlan:string="-1";
    volumeDiscountPlan:string="-1";
    
}