export class AddressVO{
    country:string;
    streetAddress1:string;
    streetAddress2:string;
    city:string;
    state:string;
    postalCode:string;
    countyName:string;
    countryName:string;
}