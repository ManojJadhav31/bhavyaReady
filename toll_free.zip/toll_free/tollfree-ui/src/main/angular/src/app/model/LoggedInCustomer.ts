export class LoggedInCustomer{
    public servLocId: string;
    public custId;
    public orgId;

}