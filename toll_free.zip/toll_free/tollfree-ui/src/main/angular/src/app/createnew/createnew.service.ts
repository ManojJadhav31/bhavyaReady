import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductsVO } from '../model/ProductMasterVO';
import { IproductsVO } from '../model/IproductsVO';
import { Observable } from 'rxjs';
import { TollFreeConstants } from "../../assets/constants/toll-free-constants";
import { ProductOfferingDTO } from '../model/ProductOfferingVO';
import { BusinessUnitAffiliateVO } from '../model/BusinessUnitAffiliateVO';
import { ChargeVO } from '../model/ChargeVO';
import { ProductOfferingChargeVO } from '../model/ProductOfferingChargeVO';
import { BusinessUnitChargeVO } from '../model/BusinessUnitChargeVO';
import { ChargeStructureQuantityVO } from '../model/ChargeStructureQuantityVO';
import { MarketAreaProductOfferingVO } from '../model/MarketAreaProductOfferingVO';
import { ProductOfferingRatePlanVO } from '../model/ProductOfferingRatePlanVO';
import { RatePlanVO } from '../model/RatePlanVO';


@Injectable()
export class CreateNewService {
  http: HttpClient;
  //prodMasterList: ProductMasterVO[];
  iProductsList: IproductsVO[];
 // baseUrl = TollFreeConstants.baseUrl;

  productMasterUrl =  "tollfree-data/ServiceDelivery/v1/admin/products";
  taxServiceUrl =  "tollfree-data/ServiceDelivery/v1/admin/taxservicecode";
  currenciesUrl =  "tollfree-data/ServiceDelivery/v1/admin/currencies/";
  profitCenterUrl =  "tollfree-data/ServiceDelivery/v1/admin/profitcenters";
  businessAffiliatesUrl =  "tollfree-data/ServiceDelivery/v1/admin/businessunitaffiliates";
  chargeDeptUrl =  "tollfree-data/ServiceDelivery/v1/admin/chargedepartments";
  accountcodesUrl =  "tollfree-data/ServiceDelivery/v1/admin/accountcodes";
  ratePlanUrl =  "tollfree-data/ServiceDelivery/v1/admin/rateplans";
  persistUrl =  "tollfree-data/ServiceDelivery/v1/admin/persist";
  copyExistingPOUrl =  "tollfree-data/ServiceDelivery/v1/admin/copyExisting";
  allProductDataUrl =  "tollfree-data/ServiceDelivery/v1/admin/allproducts";
  splEndPointsUrl =  "tollfree-data/ServiceDelivery/v1/admin/specialendpointtypes";


  constructor(http: HttpClient) {
    this.http = http;
  }

  loadProductMasterData(baseUrl,orgId: any): Observable<ProductsVO[]> {
    return this.http.get<ProductsVO[]>(baseUrl+"/"+this.productMasterUrl + "/" + orgId);
  }
  loadTaxService(baseUrl,orgId: any): Observable<any> {
    return this.http.get(baseUrl+"/"+this.taxServiceUrl + "/" + orgId);
  }
  loadAccCodes(baseUrl,orgId: any): Observable<any> {
    return this.http.get(baseUrl+"/"+this.accountcodesUrl + "/" + orgId);
  }
  loadBussinessAffiliates(baseUrl,orgId: any): Observable<any> {
    return this.http.get(baseUrl+"/"+this.businessAffiliatesUrl + "/" + orgId);
  }
  loadDept(baseUrl,orgId: any): Observable<any> {
    return this.http.get(baseUrl+"/"+this.chargeDeptUrl + "/" + orgId);
  }
  loadProfitCenter(baseUrl,orgId: any): Observable<any> {
    return this.http.get(baseUrl+"/"+this.profitCenterUrl + "/" + orgId);
  }
  loadCurrencies(baseUrl): Observable<any> {
    return this.http.get(baseUrl+"/"+this.currenciesUrl);
  }
  loadRatePlan(baseUrl,orgId: any): Observable<any> {
    return this.http.get(baseUrl+"/"+this.ratePlanUrl + "/" + orgId);
  }
  persistData(baseUrl,productOfferingVO: ProductOfferingDTO): Observable<any> {
    return this.http.post(baseUrl+"/"+this.persistUrl, productOfferingVO);
  }
  copyExistingPO(baseUrl,orgId, productOfferingId) {
    return this.http.get(baseUrl+"/"+this.copyExistingPOUrl + "/" + orgId + "/" + productOfferingId);
  }
  loadProductData(baseUrl): Observable<any> {
    return this.http.get(baseUrl+"/"+this.allProductDataUrl);
  }
  loadSplEndPoints(baseUrl):Observable<any>{
    return this.http.get(baseUrl+"/"+this.splEndPointsUrl);
  }
}