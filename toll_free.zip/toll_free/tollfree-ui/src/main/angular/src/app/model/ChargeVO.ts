import { ProductOfferingChargeVO } from "./ProductOfferingChargeVO";
import { BusinessUnitChargeVO } from "./BusinessUnitChargeVO";
import { ChargeStructureQuantityVO } from "./ChargeStructureQuantityVO";
import { InitialChargeStructureQuantityDTO } from "./InitialUnitChargeVO";
import { FinalChargeStructureQuantityDTO } from "./AdditionalUnitChargeVO";

export class ChargeVO {
    chargeId: string;
    organizationId: string;
    productId: string;
    chargeType: string="";
    description: string;
    taxClassification: string="8";
    prorateCharges: string="";
    advanceBill: string;
    discountContributory: string;
    discountEligible: string;
    commissionEligible: string;
    commissionContributory: string;
    generalLedgerCode: string="00000000";
    defaultTerm: string;
    defaultCharge: Number = 0.00;
    overridable: string;
    status: string="A";
    beginDate: Date;
    endDate: Date;
    billNotUsed: string;
    chargeStructureType: string="01";
    defGeneralLedgerCode: string="00000000";
    blockForMigration: string;
  //  productOfferingChargeDTO: ProductOfferingChargeVO;
    businessUnitChargeDTO:BusinessUnitChargeVO;
    //chargeStructureQuantityDTOs:ChargeStructureQuantityVO[];
    initialChargeStructureQuantityDTO: InitialChargeStructureQuantityDTO;
  finalChargeStructureQuantityDTO: FinalChargeStructureQuantityDTO;
}