import { Injectable } from '@angular/core';
import { SharedService } from './shared/shared.service'
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse,
  HttpResponse
} from '@angular/common/http';

import { Observable } from 'rxjs/Observable';

@Injectable()
export class TollfreeHttpInterceptor implements HttpInterceptor {
  constructor(private sharedService:SharedService){

  }
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const token = localStorage.getItem('tokenId');
        const appKey = localStorage.getItem('appKey');
        let cloneReq = null;
        
      if (token != null || appKey != null) {
        
        if(token){
           cloneReq = req.clone( { headers:req.headers
            .set('Authorization', "Bearer "+ token) } );
        }else if(appKey){
           cloneReq = req.clone( { headers:req.headers
            .set('appKey', appKey) } );
        }
        
        return next.handle(cloneReq)
        .do((event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
                //success --do nothing
            }
        },
            (error: any) => {
                if (error instanceof HttpErrorResponse) {
                    if (error.status === 403) {
                        this.sharedService.editAuthResult('unauthorised');
                    }
                }
            }
        )
       }
       
       return next.handle(req);
    }
}