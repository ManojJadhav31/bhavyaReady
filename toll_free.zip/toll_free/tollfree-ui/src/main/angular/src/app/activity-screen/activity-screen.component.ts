import { Component, OnInit } from '@angular/core';
import { BaseUrlService } from '../baseUrlService';
import { OneSOrderService } from '../one-s-order/one-s-order.service';
import { TollFreeConstants } from '../../assets/constants/toll-free-constants';
import { ActivitySearchVO } from '../model/ActivitySearchVO';
import { TriggerActivityInputVo } from '../model/TriggerActivityInputVo';
import { ActivitySearchInputVO } from '../model/ActivitySearchInputVO';

@Component({
  selector: 'app-activity-screen',
  templateUrl: './activity-screen.component.html',
  styleUrls: ['./activity-screen.component.css']
})
export class ActivityScreenComponent implements OnInit {

  isActivityStarted: boolean = false;
  constructor(private oneSOrderService: OneSOrderService, private baseurlService: BaseUrlService) { }
  tn: string;
  baseUrl = null;
  isLECForceComplete: Boolean = false;
  tc = "";
  si = "";

  activityScreenColumn = [
    { field: 'activityId', header: 'Activity Id' },
    { field: 'activityName', header: 'Activity Name' },
    { field: 'name', header: 'Status' },
    { field: 'startTime', header: 'Start Time' },
    { field: 'endTime', header: 'End Time' },
    { field: 'comments', header: 'Comments' },
    { field: 'tn', header: 'ANI' },
    { field: 'voiceOrderId', header: 'Order ID' }

  ];

  activitySearchResList;
  showActivityTable: boolean = false;
  loading: boolean = false;
  activities = [{ name: 'Add Comments', code: 'NY' },
  { name: 'Assign Self', code: 'RM' },
  { name: 'Change Owner', code: 'LDN' },
  { name: 'Complete Activity', code: 'IST' },
  { name: 'Reject ES Prov', code: 'PRS' },
  { name: 'Remove Self', code: 'RM' },
  { name: 'Restart Activity', code: 'LDN' },
  { name: 'Set as Pending Response', code: 'IST' },
  { name: 'Set as Urgent', code: 'PRS' },
  { name: 'Unset as Urgent', code: 'PRS' }];
  selectedActivity: string;
  activityAction: string = "-1";
  activitySearchlist: Array<ActivitySearchVO>;
  activityVoReq: TriggerActivityInputVo;
  errorMessages: Array<any> = [];
  activityResponse = false;
  msgs = [];
  activity = "-1";
  orderCompleteDate;
  voiceOrderId;
  monthArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEPT', 'OCT', 'NOV', 'DEC'];
  displayMessage;

  ngOnInit() {
    this.msgs = [];
    if (this.baseUrl == null) {
      this.baseurlService.getBaseUrl().subscribe(
        data => {
          var response = data;
          this.baseUrl = response.baseUrl;

        });
    }

  }
  clearMsgAndloadActivity() {
    this.msgs = [];
    this.loadActivity();
  }

  loadActivity() {
    this.activityAction = "-1";
    if (this.activitySearchlist) {
      this.activitySearchlist.splice(0, this.activitySearchlist.length);
    }

    this.msgs = [];
    this.activityResponse = false;
    this.displayMessage = "";
    if (!this.loading&&this.validateMendatoryFields()) {
      this.loading = true;
      let activitySearchReq = new ActivitySearchInputVO();

      if (this.voiceOrderId)
        activitySearchReq.voiceOrderId = this.voiceOrderId.trim();

      if (this.tn)
        activitySearchReq.tn = this.tn.trim();

      activitySearchReq.orderCompleteDate = this.orderCompleteDate;

      if (this.activity == "-1") {
        this.activity = null;
      }
      activitySearchReq.activity = this.activity;

      this.oneSOrderService.loadActivitySearch(this.baseUrl, activitySearchReq).subscribe(response => {
        this.activitySearchResList = response;
        if (this.activitySearchResList.length > 0) {
          this.showActivityTable = true;

        } else {
          this.msgs.push({ severity: 'info', summary: '', detail: 'No Records Found.' });
          this.showActivityTable = false;
        }
        this.loading = false;
        if (this.activity == null) {
          this.activity = "-1";
        }

      });
    }
  }

  validateAndRunActivityAction() {
    this.isActivityStarted = true;
    this.msgs = [];
    let lecCount = 0;
    if (this.activityAction == "Update TCSI") {
      this.tc = "";
      this.si = "";
      for (let selectedAct of this.activitySearchlist) {
        if (selectedAct.activityId == 916) {
          lecCount++;
        } else {
          this.msgs.push({ severity: 'warn', summary: '', detail: 'Only Send to LEC activity needs to be selected' });
          return;
        }
      }
      if (lecCount > 0) {
        this.isLECForceComplete = true;
        return;
      } else {
        this.msgs.push({ severity: 'warn', summary: '', detail: 'At least one Send to LEC activity needs to be selected' });
        return;
      }
    } else {
      this.runActivityAction();
    }
  }
  runActivityAction() {
    this.isLECForceComplete = false;
    this.isActivityStarted = true;
    this.msgs = [];
    let ponSet = new Set();

    try {
      this.activitySearchlist.forEach(element => {
        ponSet.add(element.parentTransId)
      });

      for (let selectedAct of this.activitySearchlist) {
        if (this.activityAction == "Complete Activity" || this.activityAction == "Update TCSI") {
          this.loading = true;
          this.oneSOrderService.forceComplete(this.baseUrl, selectedAct.orderActivityPk, this.tc, this.si)
            .subscribe(
              response => {
                if(response.statusType=='BAD_REQUEST'){
                  this.msgs.push({ severity: 'error', summary: '', detail: 'Please enter valid TCSI '});
                  this.loading = false;
                  this.isActivityStarted = false;
                }
                else {
                this.activityResponse = true;
                this.loadActivity();
                this.msgs.push({ severity: 'info', summary: '', detail: 'Complete Activity Triggered for ' + selectedAct.activityName });
                this.loading = false;

                this.isActivityStarted = false;
                this.activityAction = "-1";
                this.activitySearchlist.splice(0, this.activitySearchlist.length);
                }
              },
              err => {
                this.msgs.push({ severity: 'error', summary: '', detail: 'Complete Activity Trigger Failed for ' + selectedAct.activityName + ". " + err.statusText });
                this.loading = false;
                this.isActivityStarted = false;
              }

            );

        }
      }

      if (this.activityAction == "Restart Activity") {
        let parentTxActIds = [915, 921, 924, 914, 920, 923, 933, 936];
        let ponArray = Array.from(ponSet);
        let selectedAct = null;
        for (let i = 0; i < ponArray.length; i++) {
          let isFoundParentTxAct = false;
          for (let j = 0; j < this.activitySearchlist.length; j++) {
            if (ponArray[i] == this.activitySearchlist[j].parentTransId) {
              selectedAct = this.activitySearchlist[j];
              if (parentTxActIds.indexOf(this.activitySearchlist[j].activityId) > -1) {
                selectedAct = this.activitySearchlist[j];
                if (isFoundParentTxAct == false) {
                  isFoundParentTxAct = true;
                  this.restartActivityAPI(selectedAct);
                }
              } else {
                this.restartActivityAPI(selectedAct);
              }
            }
          }
        }
      }
  } catch (error) {
      this.msgs.push({ severity: 'error', summary: '', detail: 'Trigger Failed. ' + error.message });
      this.loading = false;
      this.isActivityStarted = false;
    }

  }

  showdateSelected(evt) {
    let today = new Date();
    today = evt;
    this.orderCompleteDate = today.getDate() + "-" + this.monthArray[today.getMonth()] + "-" + today.getFullYear().toString().substring(2);
  }

  validateMendatoryFields() {
    if (((this.voiceOrderId == null) || (this.voiceOrderId.trim().length <= 0) || (this.voiceOrderId == "")) &&
      ((this.tn == null) || (this.tn.trim().length <= 0) || (this.tn == "")) &&
      ((this.orderCompleteDate == null) || (this.orderCompleteDate.trim().length <= 0) || (this.orderCompleteDate == "")) &&
      ((this.activity == null) || (this.activity.trim().length <= 0) || (this.activity == "-1"))) {
      this.loading = false;
      this.displayMessage = "Enter at least one value.";
      return false;
    } else {
      return true;
    }
  }
  isAnyActivityCompleted() {
    for (let act of this.activitySearchResList) {
      if (act.name == 'Completed') {
        return true;
      }
    }
    return false;
  }

  keyDownFunction(event) {
    if (event.keyCode == 13) {
      this.loadActivity();
    }
  }

  restartActivityAPI(selectedAct): any {
    this.loading = true;
    this.oneSOrderService.restartActivity(this.baseUrl, selectedAct.orderActivityPk)
      .subscribe(
        (response: any) => {
          this.activityResponse = true;
          this.loadActivity();
          this.msgs.push({ severity: 'info', summary: '', detail: 'Restart Activity Triggered for ' + selectedAct.activityName });
          this.loading = false;

          this.isActivityStarted = false;
          this.activityAction = "-1";
          this.activitySearchlist.splice(0, this.activitySearchlist.length);
        },
        err => {
          this.msgs.push({ severity: 'error', summary: '', detail: 'Restart Activity Trigger Failed for ' + selectedAct.activityName + ". " + err.statusText });
          this.loading = false;
          this.isActivityStarted = false;
        }
      );
  }
}


