import { Injectable } from '@angular/core';
import { HttpErrorResponse } from "@angular/common/http";
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
@Injectable()
export class BaseUrlService
 {
  //http: HttpClient;
  baseUrl: string;
  envName:string;
  constructor(private http: HttpClient) { 
    
  }
 
  public getBaseUrl():Observable<any>{
    return this.http.get('./ui/properties/all');
  }
//     return new Promise((resolve, reject) => {
//       this.http.get('./ui/properties/all')
//         .subscribe(res => {
//           const data = (res as any);
//           this.baseUrl = data.baseUrl;
//           this.envName = data.envName;
//           alert('baseUrl :' + this.baseUrl);
//           alert('envName:' + this.envName);

          

//           resolve(true);
//         }, error => {
          

         
//           resolve(true);
//         });
//     });
// }
 }