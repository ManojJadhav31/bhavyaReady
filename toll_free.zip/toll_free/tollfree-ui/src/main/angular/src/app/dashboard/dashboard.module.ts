import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartComponent } from './chart/chart.component';
import {ChartModule} from 'primeng/chart';
import { DashboardService } from './dashboard.service';
import { DialogModule } from 'primeng/dialog';

@NgModule({
  imports: [
    CommonModule,
    ChartModule,
    DialogModule
  ],
  declarations: [ChartComponent],
  providers: [DashboardService]
})
export class DashboardModule { }
