import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceLocModalComponent } from './service-loc-modal.component';

describe('ServiceLocModalComponent', () => {
  let component: ServiceLocModalComponent;
  let fixture: ComponentFixture<ServiceLocModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceLocModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceLocModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
