export class ValidatedCustomAcctCodeVO {
    codeDigits:string;
    codeTableId:string;
    codeTableName:string;
}
