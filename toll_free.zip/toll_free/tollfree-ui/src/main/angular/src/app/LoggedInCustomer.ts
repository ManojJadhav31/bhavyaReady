export class LoggedInCustomer{
    public custId;
    public orgId;

}