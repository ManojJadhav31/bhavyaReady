export class ChargeDepartmentVO{
    organizationId :String;
	chargeDepartment :String;
	chargeDepartmentDesc :String;
}