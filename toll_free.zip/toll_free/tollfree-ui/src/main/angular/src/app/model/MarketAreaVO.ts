export class MarketAreaVO {
    marketAreaId: Number;
    marketAreaName: string;
    description: string;
    areaBegin: Date;
    areaEnd: Date;
    status: string;
}