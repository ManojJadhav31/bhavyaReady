import { Component, OnInit, Input } from '@angular/core';
import { CreateNewService } from './createnew.service';
import { HttpClient } from "@angular/common/http";
import { IproductsVO } from '../model/IproductsVO';
import { ProductOfferingDTO } from '../model/ProductOfferingVO';
import { OneSOrderService } from '../one-s-order/one-s-order.service';
//import { BusinessUnitAffiliateVO } from '../model/BusinessUnitAffiliateVO';
import { ProfitCenterVO } from '../model/ProfitCenterVO';
import { ChargeDepartmentVO } from '../model/ChargeDepartmentVO';
import { CurrencyVO } from '../model/CurrencyVO';
import { TaxClassificationMasterVO } from '../model/TaxClassificationMasterVO';
import { GeneralLedgerCodeVO } from '../model/GeneralLedgerCodeVO';
import { ChargeVO } from '../model/ChargeVO';
import { BusinessUnitChargeVO } from '../model/BusinessUnitChargeVO';
import { RatePlanVO } from '../model/RatePlanVO';
import { ProductOfferingRatePlanVO } from '../model/ProductOfferingRatePlanVO';
import { ChargeStructureQuantityVO } from '../model/ChargeStructureQuantityVO';
import { MarketAreaProductOfferingVO } from '../model/MarketAreaProductOfferingVO';
import { InputTextModule } from 'primeng/inputtext';
import { InitialChargeStructureQuantityDTO } from '../model/InitialUnitChargeVO';
import { FinalChargeStructureQuantityDTO } from '../model/AdditionalUnitChargeVO';
import { CheckboxModule } from 'primeng/checkbox';
import { ProductsVO } from '../model/ProductMasterVO';
import { SpecialEndPointTypeDTO } from '../model/SpecialEndPointTypeVO';
import { MultiSelectModule } from 'primeng/multiselect';
import { SelectItem } from 'primeng/api';
import { BaseUrlService } from '../baseUrlService';

@Component({
  selector: 'app-createnew',
  templateUrl: './createnew.component.html',
  styleUrls: ['./createnew.component.css']
})
export class CreatenewComponent implements OnInit {

  isEditing: boolean;
  http: HttpClient;
  createNewService: CreateNewService;
  iProducts: IproductsVO[];
  iProductsList: IproductsVO;
  productofferingName: string;
  data: any;
  chargesInfoList: Array<ChargeVO> = [];
  //productId:string="-1";
  activeSection: string = "productCharges";
  productOfferingDTO: ProductOfferingDTO;
  productWithSpecialEndPointDTOs: SpecialEndPointTypeDTO[] = [];
  productsVO: ProductsVO = new ProductsVO();
  //businessUnitAffiliateVO: BusinessUnitAffiliateVO;
  marketAreaProductOfferingVO: MarketAreaProductOfferingVO;
  ratePlanVO: RatePlanVO = null;
  modalOrgId: string;
  modalProductId: string;
  modalProductOffering: string;
  modalStatus: string;
  accList: GeneralLedgerCodeVO[];
  bussList: BusinessUnitChargeVO[];
  busUnitList: BusinessUnitChargeVO[];
  deptList: ChargeDepartmentVO[];
  taxList: TaxClassificationMasterVO[];
  prodList: ProductsVO[];
  profitList: ProfitCenterVO[];
  currList: CurrencyVO[];
  rateList: RatePlanVO[];
  endPointData: SpecialEndPointTypeDTO[];
  busAff = [];
  busUnit = [];
  isNextDisable = true;
  showNewCharge: boolean = false;
  chargeType: string = "-1";
  copyExistingProductOffering: boolean = false;
  showDetails: boolean = true;
  //structureType: string = "-1";
  chargeVO: ChargeVO;
  businessUnitChargeVO: BusinessUnitChargeVO = null;
  chargeStructureQuantityVO: ChargeStructureQuantityVO;
  initialChargeStructureQuantityDTO: InitialChargeStructureQuantityDTO = null;
  finalChargeStructureQuantityDTO: FinalChargeStructureQuantityDTO = null;
  selectedValues: string[] = [];

  chargeStructureQuantityList = [];
  orderResp;
  chargesInfoListToPass: Array<ChargeVO> = [];
  showMessage = false;
  displaySuccessMessage = "";
  selectedCharge: ChargeVO;
  enableQuantityChecked: boolean = false;
  enableEndPointChecked: boolean = false;
  discountEligibleChecked: boolean = false;
  overridableChecked: boolean = false;
  discountContributoryChecked: boolean = false;
  commissionEligibleChecked: boolean = false;
  commissionContributoryChecked: boolean = false;
  advanceBillChecked: boolean = false;
  scIdEnable: boolean = false;
  chargeCodeEnable: boolean = false;
  isEnableQuant: boolean = false;
  isMaxQuant: boolean = false;
  isEndPoint: boolean = false;
  isEndDesc: boolean = false;
  productSpecialEndPointDTOs: SpecialEndPointTypeDTO;
  baseUrl:string = null;

  constructor(private baseurlService: BaseUrlService,createNewService: CreateNewService, http: HttpClient) {
    this.createNewService = createNewService;
    this.http = http;
  }

  ngOnInit() {
    this.productOfferingDTO = new ProductOfferingDTO;
    this.chargeVO = new ChargeVO;
    this.chargeVO.businessUnitChargeDTO = new BusinessUnitChargeVO;
    this.ratePlanVO = new RatePlanVO;
    this.chargeStructureQuantityVO = new ChargeStructureQuantityVO;
    this.initialChargeStructureQuantityDTO = new InitialChargeStructureQuantityDTO;
    this.finalChargeStructureQuantityDTO = new FinalChargeStructureQuantityDTO;
    //   this.productOfferingRatePlanVO = new ProductOfferingRatePlanVO;
    this.marketAreaProductOfferingVO = new MarketAreaProductOfferingVO;
    this.productSpecialEndPointDTOs = new SpecialEndPointTypeDTO;
    this.loadCurrencies(this.baseUrl);
    this.loadSplEndPoints(this.baseUrl);
    if(this.baseUrl == null){
      this.baseurlService.getBaseUrl().subscribe(
        data => {
          var response = data;
          this.baseUrl=response.baseUrl;
          
        });
      }
  }

  loadProductMasterData(orgId) {
    this.createNewService.loadProductMasterData(this.baseUrl,orgId).subscribe(
      prodList => {
        this.prodList = JSON.parse(JSON.stringify(prodList));
      });
  }

  goprevious() {
    this.activeSection = "productCharges";
  }
  next() {
    this.activeSection = "chargeInfo";
  }

  secnext() {
    this.activeSection = "chargeAttr"
  }
  accnext() {
    this.activeSection = "accCodes"
  }
  chargeCols = [
    { field: 'chargeId', header: 'Charge ID' },
    { field: 'chargeType', header: 'Charge Type' },
    { field: 'description', header: 'Description' }

  ];
  showNewChargeDialogue() {
    this.selectedValues = [];
    this.chargeVO = new ChargeVO;
    this.chargeVO.businessUnitChargeDTO = new BusinessUnitChargeVO;
    this.ratePlanVO = new RatePlanVO;
    this.chargeStructureQuantityVO = new ChargeStructureQuantityVO;
   /*  this.initialChargeStructureQuantityDTO = new InitialChargeStructureQuantityDTO;
    this.finalChargeStructureQuantityDTO = new FinalChargeStructureQuantityDTO; */
    this.marketAreaProductOfferingVO = new MarketAreaProductOfferingVO;
    this.productSpecialEndPointDTOs = new SpecialEndPointTypeDTO;


    this.showNewCharge = true;
    this.loadAccCodes(this.productOfferingDTO.organizationId);
    this.loadBussinessAffiliates(this.productOfferingDTO.organizationId);
    this.loadDept(this.productOfferingDTO.organizationId);
    this.loadTaxService(this.productOfferingDTO.organizationId);
    this.loadProfitCenter(this.productOfferingDTO.organizationId);
    this.loadBussinessUnit(this.productOfferingDTO.organizationId);
    if (this.productOfferingDTO.enableQuantity && this.productOfferingDTO.enableQuantity == "true") {
      this.productOfferingDTO.enableQuantity = 'Y'
    } else {
      this.productOfferingDTO.enableQuantity = 'N'
      this.productOfferingDTO.quantity = '0'
    }
  }

  loadTaxService(orgId) {
    this.createNewService.loadTaxService(this.baseUrl,orgId)
      .subscribe(
        taxList => {
          this.taxList = JSON.parse(JSON.stringify(taxList));
        }
      );
  }

  loadAccCodes(orgId) {
    this.createNewService.loadAccCodes(this.baseUrl,orgId)
      .subscribe(
        accList => {
          this.accList = JSON.parse(JSON.stringify(accList));
        }
      );
  }
  loadBussinessAffiliates(orgId) {
    this.createNewService.loadBussinessAffiliates(this.baseUrl,orgId)
      .subscribe(
        bussList => {

          for (let bus of bussList) {
            if (bus.businessUnitAffiliateFlag == "N") {
              this.busAff.push(bus);

            }
          }

        }
      );
  }

  loadBussinessUnit(orgId) {
    this.createNewService.loadBussinessAffiliates(this.baseUrl,orgId)
      .subscribe(
        busUnitList => {
          for (let bus of busUnitList) {
            if (bus.businessUnitAffiliateFlag == "Y") {
              this.busUnit.push(bus);
            }
          }

        }
      );
  }
  loadDept(orgId) {
    this.createNewService.loadDept(this.baseUrl,orgId)
      .subscribe(
        deptList => {
          this.deptList = JSON.parse(JSON.stringify(deptList));
        }
      );
  }
  loadProfitCenter(orgId) {
    this.createNewService.loadProfitCenter(this.baseUrl,orgId)
      .subscribe(
        profitList => {
          this.profitList = JSON.parse(JSON.stringify(profitList));
        }
      );
  }
  loadCurrencies(baseUrl) {
    this.createNewService.loadCurrencies(baseUrl)
      .subscribe(
        currList => {
          this.currList = JSON.parse(JSON.stringify(currList));
        }
      )
  }
  loadSplEndPoints(baseUrl) {
    this.createNewService.loadSplEndPoints(baseUrl).subscribe(
      endPointData => {
        this.endPointData = JSON.parse(JSON.stringify(endPointData));
      });
  }

  loadOrgId() {
    if (this.productOfferingDTO.organizationId != "-1" && this.productOfferingDTO.productId != "-1" && this.productOfferingDTO.description) {
      this.isNextDisable = false;
    } else {
      this.isNextDisable = true;
    }
    this.modalOrgId = this.productOfferingDTO.organizationId;
    this.loadProductMasterData(this.modalOrgId);
    this.loadAccCodes(this.modalOrgId);
    this.loadBussinessAffiliates(this.modalOrgId);
    this.loadDept(this.modalOrgId);
    this.loadTaxService(this.modalOrgId);
    this.loadProfitCenter(this.modalOrgId);
    this.loadBussinessUnit(this.modalOrgId);
    this.loadRatePlan(this.modalOrgId);
  }

  loadProductId() {
    let productType;
    let detailType;

    for (var i = 0; i < this.prodList.length; i++) {
      if (this.prodList[i].productId.trim() == this.productOfferingDTO.productId.trim()) {
        productType = this.prodList[i].productType;
        detailType = this.prodList[i].detailType;
      }
    }
    if (this.productOfferingDTO.organizationId != "-1" && this.productOfferingDTO.productId != "-1" && this.productOfferingDTO.description) {
      this.isNextDisable = false;
    } else {
      this.isNextDisable = true;
    }
    this.modalProductId = this.productOfferingDTO.productId;
    if (this.productOfferingDTO.productId && this.productOfferingDTO.productId.charAt(0) == 'S') {
      this.scIdEnable = true;
    } else {
      this.scIdEnable = false;
    }
    if (this.productOfferingDTO.productId && this.productOfferingDTO.productId.charAt(0) == 'F') {
      this.chargeCodeEnable = true;
    } else {
      this.chargeCodeEnable = false;
    }
    if (productType == 'SV' && detailType == 'PL') {
      this.isEndPoint = true;
      this.isEndDesc = true;
    } else {
      this.isEndPoint = false;
      this.isEndDesc = false;
    }

    if (productType == 'SF' || (productType == 'SV' && detailType == 'LS')) {
      this.isEnableQuant = true;
      this.isMaxQuant = true;
    } else {
      this.isEnableQuant = false;
      this.isMaxQuant = false;
    }
  }


  loadProdOffering() {
    if (this.productOfferingDTO.organizationId != "-1" && this.productOfferingDTO.productId != "-1" && this.productOfferingDTO.description) {
      this.isNextDisable = false;
    } else {
      this.isNextDisable = true;
    }
    this.modalProductOffering = this.productOfferingDTO.description;
  }

  loadStatus() {
    this.modalStatus = this.productOfferingDTO.status;

  }

  enableShowDetails() {
    if (this.chargeVO.chargeStructureType == "02") {
      this.chargeVO.initialChargeStructureQuantityDTO = new InitialChargeStructureQuantityDTO();
      this.chargeVO.finalChargeStructureQuantityDTO = new FinalChargeStructureQuantityDTO();
      this.showDetails = false;
    } else {
      this.showDetails = true;
    }
  }
  loadRatePlan(orgId) {
    this.createNewService.loadRatePlan(this.baseUrl,orgId)
      .subscribe(
        rateList => {
          this.rateList = JSON.parse(JSON.stringify(rateList));
        }
      );
  }
  persistData() {
    // productOfferingDTO basic data
    let productOfferingRatePlanVO: ProductOfferingRatePlanVO = null;
    // adding charges
    this.chargesInfoListToPass.splice(0, this.chargesInfoListToPass.length);
    if (this.chargesInfoList.length != 0) {
      for (let charge of this.chargesInfoList) {

        if (charge.chargeType != 'U') {
          charge.chargeId = null;
          // charge.businessUnitChargeDTO = this.businessUnitChargeVO;

          if (charge.chargeStructureType == '02') {

            charge.initialChargeStructureQuantityDTO.organizationId = this.productOfferingDTO.organizationId;
            charge.initialChargeStructureQuantityDTO.quantity = 0;
            charge.initialChargeStructureQuantityDTO.chargeAmount = charge.initialChargeStructureQuantityDTO.chargeAmount;
            charge.initialChargeStructureQuantityDTO.description = charge.initialChargeStructureQuantityDTO.description;

            charge.initialChargeStructureQuantityDTO = charge.initialChargeStructureQuantityDTO;
            charge.finalChargeStructureQuantityDTO.organizationId = this.productOfferingDTO.organizationId;
            charge.finalChargeStructureQuantityDTO.quantity = 1;
            charge.finalChargeStructureQuantityDTO.chargeAmount = charge.finalChargeStructureQuantityDTO.chargeAmount;
            charge.finalChargeStructureQuantityDTO.description = charge.finalChargeStructureQuantityDTO.description;

            charge.finalChargeStructureQuantityDTO = charge.finalChargeStructureQuantityDTO;
          }
          charge.discountEligible = 'N';
          charge.discountContributory = 'N';
          charge.commissionEligible = 'N';
          charge.commissionContributory = 'N';
          charge.advanceBill = 'N';
          charge.overridable = 'N';
          for (let attr of this.selectedValues) {
            if (attr == 'discountEligible') {
              charge.discountEligible = 'Y';
            }
            if (attr == 'discountContributory') {
              charge.discountContributory = 'Y';
            }
            if (attr == 'commissionEligible') {
              charge.commissionEligible = 'Y';
            }
            if (attr == 'commissionContributory') {
              charge.commissionContributory = 'Y';
            }
            if (attr == 'advanceBill') {
              charge.advanceBill = 'Y';
            }
            if (attr == 'overridable') {
              charge.overridable = 'Y';
            }

          }
          this.chargesInfoListToPass.push(charge);
        } else {
          productOfferingRatePlanVO = new ProductOfferingRatePlanVO();
          // seperate usage charge here and form productOfferingRatePlanVO
          //this.productOfferingRatePlanVO.organizationId = this.productOfferingDTO.organizationId;
          productOfferingRatePlanVO.organizationId = this.productOfferingDTO.organizationId;
          productOfferingRatePlanVO.ratePlanBegin = this.productOfferingDTO.beginDate;
          productOfferingRatePlanVO.ratePlanEnd = this.productOfferingDTO.endDate;
          productOfferingRatePlanVO.status = this.productOfferingDTO.status;
          productOfferingRatePlanVO.ratePlanId = this.ratePlanVO.ratePlanId;


        }
      }
    }
    this.productOfferingDTO.chargeDTOs = this.chargesInfoListToPass;

    //setting marketAreaProductOfferingVO
    this.marketAreaProductOfferingVO.organizationId = this.productOfferingDTO.organizationId;
    this.marketAreaProductOfferingVO.beginDate = this.productOfferingDTO.beginDate;
    this.marketAreaProductOfferingVO.endDate = this.productOfferingDTO.endDate;
    this.marketAreaProductOfferingVO.status = this.productOfferingDTO.status;
    this.marketAreaProductOfferingVO.marketAreaId = 1;

    this.productOfferingDTO.marketAreaProductOfferingDTO = this.marketAreaProductOfferingVO;
    this.productOfferingDTO.productOfferingRatePlanDTO = productOfferingRatePlanVO;
    this.productOfferingDTO.productWithSpecialEndPointDTOs = this.productWithSpecialEndPointDTOs;

    return this.http.post(this.baseUrl+"/"+this.createNewService.persistUrl, this.productOfferingDTO)
      .subscribe(
        res => {
          this.orderResp = res;
          this.displaySuccessMessage = this.orderResp.displayMessage;
          this.showMessage = true;
        });
  }

  addProdCharge() {
    if (!this.isEditing) {

      if (this.chargesInfoList.length) {
        var nextVal = this.chargesInfoList.length + 1;
        this.chargeVO.chargeId = nextVal.toString();
      } else {
        var fVal = 1;
        this.chargeVO.chargeId = fVal.toString();
      }
    }
    this.chargeVO.organizationId = this.productOfferingDTO.organizationId;
    this.chargeVO.productId = this.productOfferingDTO.productId;
    if (this.chargeVO.chargeType != 'U') {
      this.chargeVO.description = this.chargeVO.description;
    } else {
      this.chargeVO.description = this.ratePlanVO.description;
    }

    this.chargeVO.defaultTerm = this.productOfferingDTO.categoryId;
    this.chargeVO.prorateCharges = this.chargeVO.prorateCharges;
    this.chargeVO.beginDate = this.chargeVO.beginDate;
    this.chargeVO.endDate = this.chargeVO.endDate;
    this.chargeVO.billNotUsed = "N";
    this.chargeVO.blockForMigration = "N";
    this.chargeVO.businessUnitChargeDTO.organizationId = this.productOfferingDTO.organizationId;
    if (!this.isEditing) {
      this.chargesInfoList.push(this.chargeVO);
    }

    this.chargeVO = new ChargeVO();
    this.showNewCharge = false;
    this.isEditing = false;
  }

  hideMessage() {
    this.showMessage = false;
  }
  createCopy(passedObjModel) {
    this.loadProductMasterData(passedObjModel.organizationId);
    this.chargesInfoList = [];
    if (passedObjModel.chargeDTOs.length == 0 && passedObjModel.productOfferingRatePlanDTO != null) {
      this.loadRatePlan(passedObjModel.organizationId);
      let chargeObj = new ChargeVO;
      chargeObj.chargeId = "1";
      chargeObj.chargeType = "Usage";
      chargeObj.description = passedObjModel.productOfferingRatePlanDTO.description;

      this.chargesInfoList.push(chargeObj);
      this.ratePlanVO.ratePlanId = passedObjModel.productOfferingRatePlanDTO.ratePlanId;
    } else {
      this.loadAccCodes(passedObjModel.organizationId);
      this.loadBussinessAffiliates(passedObjModel.organizationId);
      this.loadDept(passedObjModel.organizationId);
      this.loadTaxService(passedObjModel.organizationId);
      this.loadProfitCenter(passedObjModel.organizationId);
      this.loadBussinessUnit(passedObjModel.organizationId);
      this.chargesInfoList = passedObjModel.chargeDTOs;
      let count = 0;
      for (let charge of this.chargesInfoList) {
        count = count + 1;
        charge.chargeId = count.toString();
        charge.chargeType = charge.chargeType.trim()
      }
    }
    this.productOfferingDTO = passedObjModel;
    this.productOfferingDTO.organizationId = this.productOfferingDTO.organizationId.trim();
    this.productOfferingDTO.status = this.productOfferingDTO.status.trim();
    this.productOfferingDTO.beginDate = new Date();
    this.productOfferingDTO.endDate = new Date();
    this.isNextDisable = false;
  }

  showChargeValues(rowData) {
    this.isEditing = true;
    this.selectedValues = [];
    this.showNewCharge = true;
    this.modalProductOffering = this.productOfferingDTO.description.trim();
    this.modalOrgId = this.productOfferingDTO.organizationId;
    this.modalProductId = this.productOfferingDTO.productId;
    this.chargeVO = rowData;
    this.chargeVO.chargeType = this.chargeVO.chargeType.trim();
    if (this.chargeVO.chargeType.trim() == "Installation") {
      this.chargeVO.chargeType = "I";
    }
    if (this.chargeVO.chargeType.trim() == "Recurring") {
      this.chargeVO.chargeType = "R";
    }
    if (this.chargeVO.chargeType.trim() == "Usage") {
      this.chargeVO.chargeType = "U";
    }
    if (this.chargeVO.chargeType == "I" || this.chargeVO.chargeType == "R") {
      this.chargeVO.status = this.chargeVO.status.trim();
      this.chargeVO.generalLedgerCode = this.chargeVO.generalLedgerCode.trim();
      this.chargeVO.defGeneralLedgerCode = this.chargeVO.defGeneralLedgerCode.trim();
      if(this.chargeVO.chargeStructureType == "02" && this.chargeVO.initialChargeStructureQuantityDTO !=null && this.chargeVO.finalChargeStructureQuantityDTO !=null){
        
      //  this.businessUnitChargeVO.businessUnit = this.chargeVO.businessUnitChargeDTO.businessUnit;
      // this.businessUnitChargeVO.profitCenter = this.chargeVO.businessUnitChargeDTO.profitCenter;
      // this.businessUnitChargeVO.affiliate = this.chargeVO.businessUnitChargeDTO.affiliate;
      // this.businessUnitChargeVO.chargeDepartment = this.chargeVO.businessUnitChargeDTO.chargeDepartment;
      // this.businessUnitChargeVO.currency = this.chargeVO.businessUnitChargeDTO.currency;
       this.chargeVO.initialChargeStructureQuantityDTO.chargeAmount = this.chargeVO.initialChargeStructureQuantityDTO.chargeAmount;
      this.chargeVO.initialChargeStructureQuantityDTO.description = this.chargeVO.initialChargeStructureQuantityDTO.description;
      this.chargeVO.finalChargeStructureQuantityDTO.chargeAmount = this.chargeVO.finalChargeStructureQuantityDTO.chargeAmount;
      this.chargeVO.finalChargeStructureQuantityDTO.description = this.chargeVO.finalChargeStructureQuantityDTO.description;
      }
      if (this.chargeVO.discountEligible == "Y") {
        this.selectedValues.push("discountEligible");
      }
      if (this.chargeVO.discountContributory == "Y") {
        this.selectedValues.push("discountContributory");
      }
      if (this.chargeVO.commissionEligible == "Y") {
        this.selectedValues.push("commissionEligible");
      }
      if (this.chargeVO.commissionContributory == "Y") {
        this.selectedValues.push("commissionContributory");
      }
      if (this.chargeVO.advanceBill == "Y") {
        this.selectedValues.push("advanceBill");
      }
      if (this.chargeVO.overridable == "Y") {
        this.selectedValues.push("overridable");
      }
    }
  }

  detectChange(event) {
    this.enableQuantityChecked = true;
    if (this.enableQuantityChecked == true) {
      this.productOfferingDTO.enableQuantity = 'Y';
    } else {
      this.productOfferingDTO.enableQuantity = 'N';
    }
  }

  onClose() {
    this.copyExistingProductOffering = false;
  }

  showValues(evt) {
    for (var i = 0; i < evt.target.selectedOptions.length; i++) {
      let endPoint = new SpecialEndPointTypeDTO;
      endPoint.specialEndPointTypeCode = evt.target.selectedOptions[i].value.split("'")[1].replace("'", "").trim();
      var obj = new SpecialEndPointTypeDTO;
      obj.specialEndPointTypeCode = endPoint.specialEndPointTypeCode.toString();
      this.productWithSpecialEndPointDTOs.push(obj);
    }
  }

  deleteProdCharge() {
    let index = this.chargesInfoList.indexOf(this.selectedCharge);
    this.chargesInfoList = this.chargesInfoList.filter((val, i) => i != index);
    this.showNewCharge = false;
  }

  setRatePlanDescription(evt){
    let ratePlanId= evt.target.value;
    
    for(let i =0;i<this.rateList.length;i++){
      if(this.rateList[i].ratePlanId == ratePlanId){

        this.ratePlanVO.description = this.rateList[i].description.trim();
      }
    }
  }
}


