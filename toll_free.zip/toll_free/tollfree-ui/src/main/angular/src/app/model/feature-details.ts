

export class FeaturesVO{
    
    featureId:string;
    featureDesc:string;
    
}