import { tnModel } from "../one-s-order/uploadedTnView/tnModel";
import { GridRecordVO } from "./grid-record";

export class OrderInfo {
   controlGroupId: any;
   servLocId: string = "-1";
   custId: string;
   orgId: string;
   busOrgId: string;
   cic: string;
   businessType: string;
   prodId:string;
   orderNumber:string ="New";
   customerId:string;
   customerName:string;
   ban:string="-1";
   serviceLocationType:string ="Business";
   todayDate: string;
   gridRecordVO:GridRecordVO=null;
  
}