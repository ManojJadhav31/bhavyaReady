
import { ValidatedCustomAcctCodeVO } from "./ValidatedCustomAcctCodeVO";
import { FeaturesVO } from "./FeaturesVO";


export class TNDataVO {
	
    isSelected: boolean=false;
	wtn:string;
	btn:string;
	pic:string;
	jurisdiction:string;
	forceAniLoad:string;
	cic:string ="-1";
	features:Array<FeaturesVO>;
	validatedCustomAcctCodeVO:ValidatedCustomAcctCodeVO;
	valid: boolean =true;
}
