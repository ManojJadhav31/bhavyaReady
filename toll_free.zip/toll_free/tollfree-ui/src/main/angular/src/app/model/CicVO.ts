
export class CicVO{
    
    cic:string;
    preference:string;
    
}