export class FinalChargeStructureQuantityDTO {
    chargeId: string;
    organizationId: string;
    quantity: Number;
    chargeAmount: Number;
    description: string;

}