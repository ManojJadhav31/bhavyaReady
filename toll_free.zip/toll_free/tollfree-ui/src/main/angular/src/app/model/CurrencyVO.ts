export class CurrencyVO{
    currency :String;
	currencyDesc:String;
}