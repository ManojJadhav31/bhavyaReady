import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BaseUrlService } from '../../baseUrlService';
import { LookupService } from '../lookup.service';
import { ServiceLocInfoVO } from '../../model/ServiceLocInfoVO';
import { Router, ActivatedRoute } from '@angular/router';
import { ServiceLocModalComponent } from '../service-loc-modal/service-loc-modal.component';
import { OrderVO } from '../../model/OrderVO';
import { LoggedInCustomer } from '../../model/LoggedInCustomer';
import { OneSOrderService } from '../../one-s-order/one-s-order.service';
import { ContactsVO } from '../../model/ContactsVO';
import { ProductSummaryVO } from '../../model/ProductSummaryVO';
import { AddressVO } from '../../model/AddressVO';
import { MarketAreaVO } from '../../model/MarketAreaVO';
import { PayPhoneVO } from '../../model/PayPhoneVO';

@Component({
  selector: 'app-service-lookup',
  templateUrl: './service-lookup.component.html',
  styleUrls: ['./service-lookup.component.css']
})
export class ServiceLookupComponent implements OnInit {


  constructor(private baseurlService: BaseUrlService, lookUpService: LookupService, private http: HttpClient,
    private router: Router, private route: ActivatedRoute) {
    this.lookUpService = lookUpService;
    this.http = http;
  }

  lookUpService: LookupService;
  oneSOrderService: OneSOrderService;
  baseUrl: string = null;
  data: any;
  selectedValues: string[] = [];
  showSevInfo: boolean = false;
  activeSection: string = "servInfo";
  //ServLocationVO:ServiceLocInfoVO;
  selectedServLocation: ServiceLocInfoVO;
  servLocationVO = new ServiceLocInfoVO();
  orgId = "WCG";
  custId = "00001157";
  serviceLocModalComponent: ServiceLocModalComponent = new ServiceLocModalComponent(this.lookUpService, this.router)
  servInfoModal: boolean = false;
  busOrg;
  orderdetails: OrderVO;
  loggedInCustomer: LoggedInCustomer = new LoggedInCustomer();
  customerId = null;
  customerName = null;
  userName = null;
  accDetails: ContactsVO;
  status: ServiceLocInfoVO;
  contactType = "06"
  contactsList: ContactsVO[];
  productList: ProductSummaryVO[];
  servloc: ServiceLocInfoVO;
  addressVO: AddressVO;
  contactsVO: ContactsVO;
  productSummaryVO: ProductSummaryVO;
  marketAreaList: MarketAreaVO[];
  marketAreaVO: MarketAreaVO;
  PayPhoneList: PayPhoneVO[];
  payPhoneVO: PayPhoneVO;
  prodList;
  loading: boolean;

  ngOnInit() {
    if (this.baseUrl == null) {
      this.baseurlService.getBaseUrl().subscribe(
        data => {
          var response = data;
          this.baseUrl = response.baseUrl;

          //this.baseUrl = "http://localhost:8081";
          this.route.queryParams.subscribe(params => {
            this.customerId = params['customerId'];
            this.customerName = params['customerName'];
            this.userName = params['userName'];
            if (params['tokenId']) {
              localStorage.setItem("tokenId", params['tokenId']);
            }
            var custIdPattern = /^\d{8}$/;
            if (this.customerId != null && !this.customerId.match(custIdPattern) && this.isBase64(this.customerId) == true) {
              this.customerId = atob(this.customerId);
            }
            if (this.isBase64(this.customerName) == true) {
              this.customerName = atob(this.customerName);
            }
            if (this.isBase64(this.userName) == true) {
              this.userName = atob(this.userName);
            }

            if (this.customerId && this.customerName && this.userName) {
              this.oneSOrderService.loadCustInfo(this.baseUrl, this.customerId, this.orgId).subscribe(response => {
                localStorage.setItem("customerId", btoa(response.customerId));
                localStorage.setItem("customerBizOrgId", btoa(response.customerBizOrgId));
                localStorage.setItem("customerName", btoa(response.customerName));
                localStorage.setItem("organizationId", btoa(response.organizationId));
                localStorage.setItem("userName", btoa(this.userName));

                if (localStorage.getItem("customerId")) {
                  this.servInfoModal = false;
                  let sessionObject = {
                    "customerId": atob(localStorage.getItem('customerId')),
                    "customerName": atob(localStorage.getItem('customerName')),
                    "busOrg": atob(localStorage.getItem('customerBizOrgId')),
                    "organizationId": atob(localStorage.getItem('organizationId'))
                  };
                  this.displayCustomerId(sessionObject);
                }
              });
            } else {

              this.showCustomerInfoModal();

            }
            let isFromOneStop = localStorage.getItem("tokenId") != null ? true : false;
            localStorage.setItem("isFromOneStop", String(isFromOneStop));
          });
        });

        }
    this.contactsVO = new ContactsVO();

      this.addressVO = new AddressVO();
      this.marketAreaVO = new MarketAreaVO();
      this.payPhoneVO = new PayPhoneVO();
    }
    isBase64(str) {
      try {
        return btoa(atob(str)) == str;
      } catch (err) {
        return false;
      }
    }
    ServCols = [
      { field: 'serviceLocationId', header: 'Service Location ID' },
      { field: 'serviceLocationStatus', header: 'Status' },
      { field: 'serviceLocationType', header: 'Type' },
      { field: 'serviceLocationName', header: 'Name' },
      { field: 'accountNumber', header: 'Account Number' },
      { field: 'piid', header: 'PIID' },
      { field: 'billingAccountNumber', header: 'Xref BAN' }
    ];
    contactsCols = [
      { field: 'firstName', header: 'Name' },
      { field: 'workPhone', header: 'phone' },
      { field: 'title', header: 'Title' }
    ];
    productCols = [
      { field: 'productOffering', header: 'Service' },
      { field: 'qtyPending', header: 'Qty Pending' },
      { field: 'qtyActive', header: 'Qty Active' },
      { field: 'qtyDisconnect', header: 'Qty Disconnect' }

    ];
    histroyCols = [
      { field: 'entryDate', header: 'Entry Date' },
      { field: 'userId', header: 'User Id' },
      { field: 'reason', header: 'Reason' },
      { field: 'orgId', header: 'Organization ID' },
      { field: 'customerId', header: 'Customer ID' }
    ];

    showCustomerInfoModal() {
      this.servInfoModal = true;
      this.serviceLocModalComponent.show();
    }

    showServLocValues(rowData) {
      this.selectedValues = [];
      this.servLocationVO = new ServiceLocInfoVO();
      this.servLocationVO.serviceLocationId = rowData.serviceLocationId;
      this.servLocationVO.serviceLocationName = rowData.serviceLocationName;
      this.servLocationVO.piid = rowData.piid;
      //  this.servLocationVO.numberName= rowData.accountNumber;
      this.servLocationVO.accountNumber = rowData.accountNumber;
      this.showSevInfo = true;
      this.loadServLocDetails();
      this.loadStatus();
      this.loadMarketArea();
      this.loadPayPhone();
      this.loadAccountInfo();
      this.loadContacts();
      //this.loadProdList();
      this.loadproductSummary();
      this.loadProdOfferingInfo();
    }

    displayCustomerId(response) {
      this.busOrg = response.busOrg;
      this.customerId = response.customerId;
      this.customerName = response.customerName;
      this.orgId = response.organizationId;
      // this.busOrgId = this.busOrg;
      this.loggedInCustomer.custId = this.customerId;
      this.loggedInCustomer.orgId = this.orgId;
      this.onClose();
      this.lookUpService.loadServInfo(this.baseUrl, this.orgId, this.customerId).subscribe(
        data => {
          this.data = JSON.parse(JSON.stringify(data));
          for (var i = 0; i < data.length; i++) {
            if (this.servLocationVO.serviceLocationStatus = this.data[i].serviceLocationStatus) {
              this.data[i].serviceLocationStatus = "Active";
            }
            if (this.servLocationVO.serviceLocationType = this.data[i].serviceLocationType) {
              this.data[i].serviceLocationType = "Business";
              this.servLocationVO.serviceLocationType = this.data[i].serviceLocationType;
            }
          }
        });
    }

    onClose() {
      this.servInfoModal = false;
    }
    loadAccountInfo() {
      this.lookUpService.loadAccountInfo(this.baseUrl, this.customerId, this.servLocationVO.serviceLocationId).subscribe(
        data => {
          this.accDetails = JSON.parse(JSON.stringify(data));
        });
    }

    loadStatus() {
      this.lookUpService.loadStatus(this.baseUrl, this.servLocationVO.accountNumber).subscribe(
        data => {
          this.status = JSON.parse(JSON.stringify(data));
        });
    }

    loadContacts() {
      this.lookUpService.loadContacts(this.baseUrl, this.orgId, this.customerId, this.servLocationVO.serviceLocationId, this.contactType).subscribe(
        data => {
          this.contactsList = JSON.parse(JSON.stringify(data));
          this.servLocationVO.contactsVO = this.contactsList;
        });
    }
    loadproductSummary() {
      this.servLocationVO.productSummaryVO = new Array<ProductSummaryVO>();
      this.lookUpService.loadServProductSum(this.baseUrl, this.customerId, this.servLocationVO.serviceLocationId).subscribe(
        data => {
          this.productList = JSON.parse(JSON.stringify(data));
          if (this.productList != null && this.productList.length > 0) {
            let productIOfferingIds: Array<number> = [];
            for (var i = 0; i < this.productList.length; i++) {
              if (this.productList[i].productOffering != null && this.productList[i].productOffering != "-1" &&
                (this.productList[i].qtyActive != "0" || this.productList[i].qtyPending != "0" || this.productList[i].qtyDisconnect != "0")) {
                this.servLocationVO.productSummaryVO.push(this.productList[i]);
                productIOfferingIds.push(Number(this.productList[i].productOffering));
                /*      this.lookUpService.loadProdOfferingInfo(this.baseUrl, this.productSummaryVO).subscribe(
                     data => {
                       var response = JSON.parse(JSON.stringify(data));
                       this.prodList = response.productVOs;
                       for (var i = 0; i < this.prodList.length; i++) {
                         if (this.servLocationVO.productSummaryVO[i].productOffering == this.prodList[i].productIOfferingId) {
                           this.servLocationVO.productSummaryVO[i].productOffering = this.prodList[i].productName;
                         }
                       }
                     }); */

              }
            }

            this.lookUpService.loadProdOfferingInfo(this.baseUrl, productIOfferingIds).subscribe(
              data => {
                var response = JSON.parse(JSON.stringify(data));
                this.prodList = response.productVOs;
                for (var k = 0; k < this.servLocationVO.productSummaryVO.length; k++) {
                  for (var j = 0; j < this.prodList.length; j++) {
                    if (this.servLocationVO.productSummaryVO[k].productOffering == this.prodList[j].productIOfferingId) {
                      this.servLocationVO.productSummaryVO[k].productOffering = this.prodList[j].productName;
                    }
                  }
                }
                this.loading = false;
              });

          }
        });
    }

    loadServLocDetails() {
      this.lookUpService.loadServLocDetails(this.baseUrl, this.customerId, this.servLocationVO.serviceLocationId).subscribe(
        data => {
          this.servloc = JSON.parse(JSON.stringify(data));
          this.servLocationVO.controlGroupId = this.servloc[0].controlGroupId;
          this.servLocationVO.marketAreaId = this.servloc[0].marketAreaId;
          this.servLocationVO.payPhoneBilling = this.servloc[0].payPhoneDeclarationCode;
        });
      this.lookUpService.loadAddress(this.baseUrl, this.customerId, this.servLocationVO.serviceLocationId).subscribe(
        data => {
          this.addressVO = JSON.parse(JSON.stringify(data));
          this.servLocationVO.addressVO = this.addressVO;
        });
    }

    loadMarketArea() {
      this.lookUpService.loadMarketArea(this.baseUrl).subscribe(
        marketAreaList => {
          this.marketAreaList = JSON.parse(JSON.stringify(marketAreaList));
          this.servLocationVO.marketAreaVO = this.marketAreaList;
          for (let i = 0; i < this.marketAreaList.length; i++) {
            /* if (this.servLocationVO.marketAreaId == this.marketAreaList[i].marketAreaId) {
               this.marketAreaVO.marketAreaName = this.marketAreaList[i].marketAreaName;  */
            if (this.marketAreaList[i].marketAreaId = 1) {
              this.marketAreaVO.marketAreaName = this.marketAreaList[0].marketAreaName;
            } else {
              if (this.marketAreaList[i].marketAreaId = 3) {
                this.marketAreaVO.marketAreaName = this.marketAreaList[1].marketAreaName;
              }
            }
            // }
          }

        });
    }
    loadPayPhone() {
      this.lookUpService.loadPayPhone(this.baseUrl).subscribe(
        PayPhoneList => {
          this.PayPhoneList = JSON.parse(JSON.stringify(PayPhoneList));
          for (let i = 0; i < this.PayPhoneList.length; i++) {
            if (this.servLocationVO.payPhoneBilling != null && this.servLocationVO.payPhoneBilling.length != 0) {
              if (this.servLocationVO.payPhoneBilling == this.PayPhoneList[i].code.trim()) {
                this.payPhoneVO.description = this.PayPhoneList[i].description;
                this.servLocationVO.payPhoneVO = this.PayPhoneList;
              }
            } else {
              this.payPhoneVO.description = "";
            }
          }
        });

    }

    loadProdOfferingInfo() {


    }
  }
