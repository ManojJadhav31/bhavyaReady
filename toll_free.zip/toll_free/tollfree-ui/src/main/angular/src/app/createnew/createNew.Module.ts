import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { CreateNewService } from './createnew.service';
import {DialogModule} from 'primeng/dialog';
import {ButtonModule} from 'primeng/button';
import {TabViewModule} from 'primeng/tabview';

@NgModule({
    imports: [
      CommonModule,
      RouterModule,
      DialogModule,
      ButtonModule,
      TabViewModule
    ],
    providers: [CreateNewService],
    declarations: [],
    exports: [],
  })
  export class CreateNewModule {

  }