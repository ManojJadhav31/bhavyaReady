export class ActivitySearchInputVO{
    tn: string;
    voiceOrderId: string;
    customerRequestDate: string;
    orderCompleteDate: string;
    activity:string;
}