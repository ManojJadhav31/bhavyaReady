export class ValidationMessageVO {
    displayMessage:string;
    entityName:string;
    code:string;
}
