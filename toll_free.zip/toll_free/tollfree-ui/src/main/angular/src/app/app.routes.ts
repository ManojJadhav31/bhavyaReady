import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { OneSOrderComponent } from "./one-s-order/one-s-order-component/one-s-order-component";
import { ProductOfferingComponent } from './product-offering/product-offering.component';
import { CreatenewComponent } from './createnew/createnew.component';
import { SearchLandingComponent } from './search-landing/search-landing.component';
import { OrderSetupComponent } from './one-s-order/order-setup/order-setup.component';
import { ActivityScreenComponent } from './activity-screen/activity-screen.component';
import { ChartComponent } from './dashboard/chart/chart.component';
import { BulkOrderUploadComponent } from './one-s-order/bulk-order-upload/bulk-order-upload.component';
import { OrderReportComponent } from './reports/order-report/order-report.component';
import { LocationReportComponent } from './reports/location-report/location-report.component';
import {ServiceSummaryComponent} from './reports/service-summary/service-summary.component';
import {UsageSummaryComponent} from './reports/usage-summary/usage-summary.component';
import {NoResponseReportComponent} from './reports/no-response-report/no-response-report.component'
import {UnauthorizedPicDisputesComponent} from './reports/unauthorized-pic-disputes/unauthorized-pic-disputes.component'
import { CustomerLookupComponent } from './lookup/customer-lookup/customer-lookup.component';
import { ServiceLookupComponent } from './lookup/service-lookup/service-lookup.component';
import { TerminationComponent } from './tollfree/termination/termination.component';
import { TerminationSearchComponent } from './tollfree/termination-search/termination-search.component';
export const routes: Routes = [
   // { path: 'one-s', component: OneSOrderComponent },
   
   { path: 'one-s', component: OrderSetupComponent },
    { path: 'newProductOffering', component: CreatenewComponent },
    { path: 'productOffering', component: ProductOfferingComponent },
    { path: 'landing-screen', component: SearchLandingComponent },
    { path: 'activity-screen', component: ActivityScreenComponent},
    { path: 'bulk-order-upload', component: BulkOrderUploadComponent},
    { path: 'order-report', component: OrderReportComponent},
    { path: 'location-report', component: LocationReportComponent},
    { path: 'service-summary', component: ServiceSummaryComponent },
    { path: 'usage-summary', component: UsageSummaryComponent },
    { path: 'no-response-report', component: NoResponseReportComponent },
    { path: 'unauthorized-pic-disputes', component: UnauthorizedPicDisputesComponent},
    {path:  'customer-lookup',component:CustomerLookupComponent},
    {path: 'service-lookup', component:ServiceLookupComponent},
    {path:'termination',component:TerminationComponent},
    {path:'termination-search',component:TerminationSearchComponent},
    { path: '', component: ChartComponent }
];

export const routing = RouterModule.forRoot(routes,{ useHash: true }); 