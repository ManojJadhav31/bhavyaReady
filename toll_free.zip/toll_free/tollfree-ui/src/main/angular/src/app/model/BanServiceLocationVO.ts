
export class BanServiceLocationVO{
    
    accountNumber:string;
    serviceLocationId:string;
    serviceLocationName:string;
    controlGroupId:string;
    customerId:string;
    detailType:string;
    label:string;
    
}