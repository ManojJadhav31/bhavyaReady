export class MarketAreaProductOfferingVO {
    productOfferingId: String;
    marketAreaId: Number;
    organizationId: String;
    beginDate: Date;
    endDate: Date;
    status: String;
}