export class PayPhoneVO {

    contextId: string;
    code:string;
    description: string;
    sortPriority:string;
}