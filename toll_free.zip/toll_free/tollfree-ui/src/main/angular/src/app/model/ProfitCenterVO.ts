export class ProfitCenterVO{

    organizationId:String;
	profitCenter:String;
	profitCenterDesc:String;
}