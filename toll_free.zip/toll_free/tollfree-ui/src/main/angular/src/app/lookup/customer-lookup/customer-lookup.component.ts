import { Component, OnInit, Input } from '@angular/core';
import { BaseUrlService } from '../../baseUrlService';
import { OneSOrderService } from '../../one-s-order/one-s-order.service';
import { HttpClient } from '@angular/common/http';
import { LookupService } from '../lookup.service';
import { CustomerInfoVO } from '../../model/CustomerInfoVO';
import { ContactsVO } from '../../model/ContactsVO';
import { ProductSummaryVO } from '../../model/ProductSummaryVO';
import { AddressVO } from '../../model/AddressVO';
import { BillingInformationVO } from '../../model/BillingInformationVO';
import { DiscountPlanVO } from '../../model/DiscountPlanVO';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-customer-lookup',
  templateUrl: './customer-lookup.component.html',
  styleUrls: ['./customer-lookup.component.css']
})
export class CustomerLookupComponent implements OnInit {

  orgId = "WCG";
  oneSOrderService: OneSOrderService;
  baseUrl: string = null;
  lookUpService: LookupService;
  data: any;
  selectedCustomer: CustomerInfoVO;
  selectedValues: string[] = [];
  showCustInfo: boolean = false;
  activeSection: string = "custInfo";
  customerVO = new CustomerInfoVO();
  accDetails: any;
  status: any;
  contactType = "06"
  contactsList: ContactsVO[];
  productList: ProductSummaryVO[];
  addressVO: AddressVO;
  customerId = null;
  serviceLocId;
  contactsVO: ContactsVO;
  salesRepList: ContactsVO[];
  billingInformationVO: BillingInformationVO;
  volumeDiscPlan: DiscountPlanVO[];
  productDiscPlan: DiscountPlanVO[];
  discountPlanVO: DiscountPlanVO;
  custAccDetails: BillingInformationVO[];
  productSummaryVO: ProductSummaryVO;
  prodList;
  productSummaryList;
  loading: boolean;
  enableDisableIntralataCheckBox: boolean = false;

  constructor(private baseurlService: BaseUrlService, lookUpService: LookupService, private http: HttpClient) {
    this.lookUpService = lookUpService;
    this.http = http;
  }

  ngOnInit() {
    if (this.baseUrl == null) {
      this.baseurlService.getBaseUrl().subscribe(
        data => {
          var response = data;
          this.baseUrl = response.baseUrl;
     // this.baseUrl = "http://localhost:8081";
      this.loadCustomerDetails();


      /* this.http.get("./assets/data/customerLookup.json")
        .subscribe((data) => {
          setTimeout(() => {
            this.data = JSON.parse(JSON.stringify(data));
          }, 1000);
        }); */
     });

    }
    this.addressVO = new AddressVO();
    this.contactsVO = new ContactsVO();
    this.customerVO.billingInformationVO = new BillingInformationVO;
    this.customerVO.volDiscountPlanVO = new DiscountPlanVO();
    this.customerVO.prodDiscountPlanVO = new DiscountPlanVO();
  }
  custCols = [
    { field: 'customerName', header: 'Customer Name' },
    { field: 'status', header: 'Status' },
    { field: 'customerId', header: 'Customer ID' },
  ];

  productCols = [
    { field: 'productOffering', header: 'Product Offering' },
    { field: 'qtyPending', header: 'Qty Pending' },
    { field: 'qtyActive', header: 'Qty Active' },
    { field: 'qtyDisconnect', header: 'Qty Disconnect' }

  ];
  custContactCols = [
    { field: 'firstName', header: 'Name' },
    { field: 'workPhone', header: 'Phone' },
    { field: 'title', header: 'Title' },
  ];
  salesServCols = [
    { field: 'firstName', header: 'Name' },
    { field: 'workPhone', header: 'Phone' },
    { field: 'title', header: 'Title' },
  ];

  loadCustomerDetails() {
    this.loading = true;
    this.lookUpService.loadCustInfo(this.baseUrl, this.orgId).subscribe(
      data => {
        this.data = JSON.parse(JSON.stringify(data));
        for (var i = 0; i < data.length; i++) {
          if (this.data[i].status.trim() == "A") {
            this.data[i].status = "Active";
          } else {
            this.data[i].status = "Inactive";
          }
          this.customerVO.status = this.data[i].status;
          this.loading = false;

        }
      });


  }

  showCustomerValues(rowData) {
    this.loading = true;
    this.selectedValues = [];
    this.showCustInfo = true;
    this.customerVO.customerName = rowData.customerName;
    this.customerVO.status = rowData.status;
    this.customerVO.customerId = rowData.customerId;
    this.customerVO.customerCode = rowData.customerCode;
    if (rowData.customerType == "W") {
      this.customerVO.customerType = "WholeSale";
    }
    if (rowData.customerType == "R") {
      this.customerVO.customerType = "Enterprise";
    }
    if (rowData.customerType == "H") {
      this.customerVO.customerType = "Helper";
    }
    this.customerVO.controlGroupId = rowData.controlGroupId;
    this.customerVO.busOrgId = rowData.busOrg;
    this.customerVO.customerBegin = rowData.customerBegin;
    this.customerVO.customerEnd = rowData.customerEnd;
    this.loadCustAddr();
    this.loadContacts();
    this.loadCustSalesRep();
    this.loadCustAccDetails();
    this.loadProductDiscPlan();
    this.loadVolumeDiscPlan();
    this.loadCustProductSum();
    this.loadIntraLataDetail();
  }

  loadIntraLataDetail() {
    this.enableDisableIntralataCheckBox = false;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'text/plain'
      }),
      responseType: 'text'
    };
    this.lookUpService.loadIntraLataDetails(this.baseUrl, this.customerVO.customerId, this.orgId, httpOptions).subscribe(
      data => {
        let str = data;
        if (str.toLowerCase() == "y")
          this.enableDisableIntralataCheckBox = true;
        else if (str.toLowerCase() == "n") {
          this.enableDisableIntralataCheckBox = false;
        }
      });
    this.loading = false;
  }
  loadCustAddr() {
    this.lookUpService.loadCustAddr(this.baseUrl, this.customerVO.customerId).subscribe(
      data => {
        this.addressVO = JSON.parse(JSON.stringify(data));
        this.customerVO.addressVO = this.addressVO;
      });
  }
  loadContacts() {
    this.lookUpService.loadCustContacts(this.baseUrl, this.orgId, this.customerVO.customerId).subscribe(
      data => {
        this.contactsList = JSON.parse(JSON.stringify(data));
        this.customerVO.contactsVO = this.contactsList;
      });
  }
  loadCustSalesRep() {
    this.lookUpService.loadCustSalesRep(this.baseUrl, this.orgId, this.customerVO.customerId).subscribe(
      data => {
        this.salesRepList = JSON.parse(JSON.stringify(data));
        this.customerVO.salesRepVO = this.salesRepList;
      });
  }

  loadCustAccDetails() {
    this.lookUpService.loadCustAccDetails(this.baseUrl, this.customerVO.customerId, this.orgId).subscribe(
      data => {
        this.custAccDetails = JSON.parse(JSON.stringify(data));
        // this.customerVO.billingInformationVO = this.custAccDetails;
        if (this.custAccDetails != null && this.custAccDetails.length > 0) {
          this.customerVO.billingInformationVO = this.custAccDetails[0];
        }
      });
  }
  loadVolumeDiscPlan() {
    this.lookUpService.loadCustVolumeDiscPlan(this.baseUrl, this.customerVO.customerId, this.orgId).subscribe(
      data => {
        this.volumeDiscPlan = JSON.parse(JSON.stringify(data));
        if (this.volumeDiscPlan != null && this.volumeDiscPlan.length > 0) {
          this.customerVO.volDiscountPlanVO = this.volumeDiscPlan[2];
        }
        //   this.customerVO.discountPlanVO = this.volumeDiscPlan;
      });
  }
  loadProductDiscPlan() {
    this.lookUpService.loadProductDiscPlan(this.baseUrl, this.customerVO.customerId, this.orgId).subscribe(
      data => {
        this.productDiscPlan = JSON.parse(JSON.stringify(data));
        if (this.productDiscPlan != null && this.productDiscPlan.length > 0) {
          this.customerVO.prodDiscountPlanVO = this.productDiscPlan[2];
        }
      });
  }

  loadCustProductSum() {
    this.loading = true;
    this.customerVO.productSummaryVO = new Array<ProductSummaryVO>();
    this.lookUpService.loadCustProductSum(this.baseUrl, this.customerVO.customerId).subscribe(
      data => {
        this.productList = JSON.parse(JSON.stringify(data));
        if (this.productList != null && this.productList.length > 0) {
          let productIOfferingIds: Array<number> = [];
          for (var i = 0; i < this.productList.length; i++) {
            if (this.productList[i].productOffering != null && this.productList[i].productOffering != "-1" &&
              (this.productList[i].qtyActive != "0" || this.productList[i].qtyPending != "0" || this.productList[i].qtyDisconnect != "0")) {
              this.customerVO.productSummaryVO.push(this.productList[i]);
              productIOfferingIds.push(Number(this.productList[i].productOffering));

            }
          }
          this.lookUpService.loadProdOfferingInfo(this.baseUrl, productIOfferingIds).subscribe(
            data => {
              var response = JSON.parse(JSON.stringify(data));
              this.prodList = response.productVOs;
              for (var k = 0; k < this.customerVO.productSummaryVO.length; k++) {
                for (var j = 0; j < this.prodList.length; j++) {
                  if (this.customerVO.productSummaryVO[k].productOffering == this.prodList[j].productIOfferingId) {
                    this.customerVO.productSummaryVO[k].productOffering = this.prodList[j].productName;
                  }
                }
              }
              this.loading = false;
            });
        }
      });
  }
}

