export class CodeTableVO{
    
    codeTableId:string;
    codeTableName:string;
    codeDigits:string;
    nonMandatoryInd:string;
    
}