export class ValidatedCustomAcctCode {
    codeDigits:string;
    codeTable:string;
}
