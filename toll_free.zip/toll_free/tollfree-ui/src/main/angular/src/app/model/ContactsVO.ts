export class ContactsVO{

    firstName :String;
    title:String;
    workPhone:String;
}