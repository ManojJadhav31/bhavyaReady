import { TNDataVO } from "./TNDataVO";


export class OrderVO {

   customerID:string;
   customerName:string;
   ban:string="-1";
   serviceLocationId: string = "-1";
   productId:string="-1" ;
   orderDate: Date;
   orgId:string;
   busOrgId:string;
   orderType:string;
   tnDataVOs:Array<TNDataVO>=[];

 //  businessType: string;  
   orderNumber:string ="New"; // not available for now
   serviceLocationType:string ="Business"; 
   controlGroupId: any;
   actionType:string;
   userName:string;
   orderSourceId:string;
}