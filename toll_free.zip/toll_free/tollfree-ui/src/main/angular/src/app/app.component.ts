import { Component } from '@angular/core';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import {MenuModule} from 'primeng/menu';
import { MenuItem } from 'primeng/api';
import {SidebarModule} from 'primeng/sidebar';
import { OneSOrderService } from './one-s-order/one-s-order.service';
import { BaseUrlService } from './baseUrlService';
import { TollFreeConstants } from '../assets/constants/toll-free-constants';
import { ResponseOptions } from '@angular/http';
import { SharedService} from './shared/shared.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  isFromOneStop: boolean;
  constructor(private baseurlService: BaseUrlService, private oneSOrderService: OneSOrderService, 
    public route: ActivatedRoute, private sharedService: SharedService) {
    localStorage.removeItem('customerId');
    localStorage.removeItem('customerName');
    localStorage.removeItem('userName');
    localStorage.removeItem('tokenId');
  }
  title = 'app';
  items: MenuItem[];
  orgId = "WCG";
  busOrg = "";
  customerId = null;
  customerName = null;
  userName = null;
  baseUrl: string = null;
  visibleSidebar1;
  showUsername: boolean =false;
  unauthorised: boolean = false;

  ngOnInit() {
    this.sharedService.authResult.subscribe(data =>{
      if(data == 'unauthorised'){
        this.unauthorised = true;
      } else {
        this.unauthorised = false;
      }
    })
    this.showUsername = false;
    localStorage.removeItem('customerId');
    localStorage.removeItem('customerName')
    localStorage.removeItem('customerBizOrgId')
    localStorage.removeItem('organizationId')
    localStorage.removeItem('appKey')

    this.route.queryParams.subscribe(params => {
      this.customerId = params['customerId'];
      this.customerName = params['customerName'];
      this.userName = params['userName'];
      if(params['appKey']){
        localStorage.setItem("appKey", (params['appKey']));
      }
      if(params['tokenId']){
        localStorage.setItem("tokenId", params['tokenId']);
      }
      
      if (this.userName) {
        if(this.isBase64(this.userName)){
          this.userName = atob(this.userName);
          localStorage.setItem("userName", btoa(this.userName));
        }else{
          localStorage.setItem("userName", btoa(this.userName));
        }
        
        this.showUsername = true;
        }else{
          if (localStorage.getItem("userName")) {
            this.userName= atob(localStorage.getItem("userName"));
            this.showUsername = true;
          }
      }
      this.isFromOneStop = localStorage.getItem("tokenId")!=null?true:false;
      localStorage.setItem("isFromOneStop",String(this.isFromOneStop));
    });

    if (this.baseUrl == null) {
     this.baseurlService.getBaseUrl().subscribe(
       data => {
         var response = data;
         this.baseUrl = response.baseUrl;
       });
    }
    this.items = [
      {
        label : 'Create 1S Order'
      },
      {
        label : 'Bulk Upload'
      },
      {
      label: 'Search',
      items: [
          {label: 'Order-ANI Search', icon: ''},
          {label: 'ANI activity Search', icon: ''}
      ]
  },
  {
      label: 'Admin',
      items: [
          {label: 'Create Product Offering Id', icon: ''},
          {label: 'Product Offering Search', icon: ''}
      ]
  }];
  
  }

  isBase64(str) {
      try {
          return btoa(atob(str)) == str;
      } catch (err) {
          return false;
      }
  }
}