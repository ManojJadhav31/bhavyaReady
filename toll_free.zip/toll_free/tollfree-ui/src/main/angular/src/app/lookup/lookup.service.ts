import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ProductSummaryVO } from '../model/ProductSummaryVO';

@Injectable()
export class LookupService {

  http: HttpClient;

  custInfoUrl = "tollfree-data/ServiceDelivery/v1/Voice/getCustomerInfo";
  servInfoUrl = "tollfree-data/ServiceDelivery/v1/Voice/getServiceLocInfo";
  custUrl = "tollfree-data/ServiceDelivery/v1/Voice/customer/";
  custNameUrl = "tollfree-data/ServiceDelivery/v1/Voice/getCustomerName";
  busOrgUrl = "tollfree-data/ServiceDelivery/v1/Voice/busorg/";
  accountInfoUrl = "tollfree-data/ServiceDelivery/v1/Voice/getAccountInfo";
  statusUrl = "tollfree-data/ServiceDelivery/v1/Voice/getStatus";
  contactsUrl = "tollfree-data/ServiceDelivery/v1/Voice/getContacts";
  productSummUrl ="tollfree-data/ServiceDelivery/v1/Voice/getProductSummary";
  servLocDetailsUrl ="tollfree-data/ServiceDelivery/v1/Voice/getCustomerDetails";
  addressUrl="tollfree-data/ServiceDelivery/v1/Voice/getCustomerAddress";
  marketAreaUrl="tollfree-data/ServiceDelivery/v1/Voice/getMarketArea/";
  payPhoneUrl ="tollfree-data/ServiceDelivery/v1/Voice/getPayPhoneBilling";
  
  custAddrUrl="tollfree-data/ServiceDelivery/v1/Voice/getCustAddress";
  custContactsUrl="tollfree-data/ServiceDelivery/v1/Voice/getCustContacts";
  custSalesRepUrl="tollfree-data/ServiceDelivery/v1/Voice/getSalesRepDetails";
  custAccDetailsUrl="tollfree-data/ServiceDelivery/v1/Voice/getCustAccInfo";
  custVolumeDiscPlanUrl="tollfree-data/ServiceDelivery/v1/Voice/getVolumeDiscPLan";
  custProductDiscPlanUrl="tollfree-data/ServiceDelivery/v1/Voice/getProductDiscPLan";

  servProductSumUrl="tollfree-order/ServiceDelivery/v1/Voice/order/productSummary";
  prodUrl="tollfree-data/ServiceDelivery/v1/Voice/product";
  custProdSummUrl="tollfree-order/ServiceDelivery/v1/Voice/order/getCustProductSummary";
  prodOffInfoUrl="tollfree-data/ServiceDelivery/v1/Voice/getProductOffering";
  getIntraLataUrl= "tollfree-data/ServiceDelivery/v1/Voice/getIntraLataDetails";

  constructor(http: HttpClient) {
    this.http = http;
  }

  loadCustInfo(baseUrl, orgId): Observable<any> {
    return this.http.get<any>(baseUrl + "/" + this.custInfoUrl + "/" + orgId);
  }
  loadServInfo(baseUrl, orgId, custId): Observable<any> {
    return this.http.get<any>(baseUrl + "/" + this.servInfoUrl + "/" + orgId + "/" + custId);

  }
  loadCustDetailInfo(baseUrl, custId, orgId): Observable<any> {
    return this.http.get<any>(baseUrl + "/" + this.custUrl + orgId + "/" + custId);
  }

  loadCustName(baseUrl, custName): Observable<any> {
    return this.http.get<any>(baseUrl + "/" + this.custNameUrl + "/" + custName);

  }
  loadBusOrgInfo(baseUrl, busOrg: any): Observable<any> {
    return this.http.get<any>(baseUrl + "/" + this.busOrgUrl + "/" + busOrg);
  }
  loadAccountInfo(baseUrl, custId, serviceLocationId): Observable<any> {
    return this.http.get<any>(baseUrl + "/" + this.accountInfoUrl + "/" + custId + "/" + serviceLocationId);
  }
  loadStatus(baseUrl, accountNum): Observable<any> {
    return this.http.get<any>(baseUrl + "/" + this.statusUrl + "/" + accountNum);
  }
  loadContacts(baseUrl, orgId, custId, serviceLocationId,contactType) {
    return this.http.get<any>(baseUrl + "/" + this.contactsUrl + "/" + orgId + "/" + custId + "/" + serviceLocationId+"/"+contactType);
  }
  loadProductSummary(baseUrl, orgId, custId, serviceLocationId){
    return this.http.get<any>(baseUrl + "/" + this.productSummUrl + "/" + orgId + "/" + custId + "/" + serviceLocationId);
  }
  loadServLocDetails(baseUrl, custId, serviceLocationId){
    return this.http.get<any>(baseUrl + "/" + this.servLocDetailsUrl + "/" + custId + "/" + serviceLocationId);
  }
  loadMarketArea(baseUrl){
    return this.http.get<any>(baseUrl +"/" +this.marketAreaUrl);
  }
  loadAddress(baseUrl, custId, serviceLocationId){
    return this.http.get<any>(baseUrl + "/" + this.addressUrl + "/" + custId + "/" + serviceLocationId);
  }
  loadPayPhone(baseUrl){
    return this.http.get<any>(baseUrl +"/" +this.payPhoneUrl);
  }

  loadCustAddr(baseUrl, custId){
    return this.http.get<any>(baseUrl + "/" + this.custAddrUrl + "/" + custId);
  
  }
  loadCustContacts(baseUrl, orgId, custId){
    return this.http.get<any>(baseUrl + "/" + this.custContactsUrl + "/" + orgId + "/" + custId+"/"+"Customer");
  }

  loadCustSalesRep(baseUrl, orgId, custId){
    return this.http.get<any>(baseUrl + "/" + this.custSalesRepUrl + "/" + orgId + "/" + custId+"/"+"Representatives");
  }
  loadCustAccDetails(baseUrl, custId,orgId){
    return this.http.get<any>(baseUrl + "/" + this.custAccDetailsUrl + "/" +custId + "/" + orgId);
  }
  loadCustVolumeDiscPlan(baseUrl, custId,orgId){
    return this.http.get<any>(baseUrl + "/" + this.custVolumeDiscPlanUrl + "/" +custId + "/" + orgId);
  }
  loadProductDiscPlan(baseUrl,custId,orgId){
    return this.http.get<any>(baseUrl + "/" + this.custProductDiscPlanUrl + "/" +custId + "/" + orgId);
  }
  loadServProductSum(baseUrl, custId, serviceLocationId){
    return this.http.get<any>(baseUrl + "/" + this.servProductSumUrl + "/" + custId + "/" + serviceLocationId);
  }
  loadProdList(baseUrl,orgId,custId, serviceLocationId){
    return this.http.get<any>(baseUrl + "/" + this.prodUrl + "/" + orgId + "/" + custId +"/"+ serviceLocationId+"/"+"1S");
  }
  loadCustProductSum(baseUrl, custId){
    return this.http.get<any>(baseUrl + "/" + this.custProdSummUrl + "/" + custId);
  }

  loadProdOfferingInfo(baseUrl,productIOfferingIds){
    return this.http.post<any>(baseUrl + "/" + this.prodOffInfoUrl, productIOfferingIds);
  }
  loadIntraLataDetails(baseUrl,customerId,orgId,httpOptions): Observable<any> {
    return this.http.get<any>(baseUrl+"/"+this.getIntraLataUrl+"/"+customerId+"/"+orgId,httpOptions);
  }
}
