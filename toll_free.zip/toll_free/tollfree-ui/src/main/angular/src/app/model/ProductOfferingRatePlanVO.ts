export class ProductOfferingRatePlanVO {
    productOfferingId: string;
    organizationId: string;
    ratePlanId: Number;
    ratePlanBegin: Date;
    ratePlanEnd: Date;
    status: string;
}