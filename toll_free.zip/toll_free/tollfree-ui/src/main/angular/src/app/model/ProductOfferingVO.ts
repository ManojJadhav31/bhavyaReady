import { ChargeVO } from "./ChargeVO";
import { MarketAreaProductOfferingVO } from "./MarketAreaProductOfferingVO";
import { ProductOfferingRatePlanVO } from "./ProductOfferingRatePlanVO";
import { SpecialEndPointTypeDTO } from "./SpecialEndPointTypeVO";

export class ProductOfferingDTO {

    productOfferingId: string;
    organizationId: string = "-1";
    productId: string = "-1";
    description: string;
    status: string ="A";
    beginDate: Date;
    endDate: Date;
    salesRepId: number = 123;
    categoryId: string = "1";
    quantity: string = "0";
    enableQuantity: string = "N";
    productGroupCode: string = "1S";
    chargeCode: string = null;
    scId: string = null;
    // features:Array<FeaturesVO>;
    chargeDTOs: Array<ChargeVO>;
    marketAreaProductOfferingDTO: MarketAreaProductOfferingVO;
    productOfferingRatePlanDTO: ProductOfferingRatePlanVO;
    productWithSpecialEndPointDTOs: Array<SpecialEndPointTypeDTO>;

}