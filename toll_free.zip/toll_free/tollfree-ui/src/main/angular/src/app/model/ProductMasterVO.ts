
export class ProductsVO {

    productId: string;
    productType: string;
    detailType: string;
    description: string;
    status: string;
    productBegin: string;
    productEnd: string;
    provPlanType: string;

}