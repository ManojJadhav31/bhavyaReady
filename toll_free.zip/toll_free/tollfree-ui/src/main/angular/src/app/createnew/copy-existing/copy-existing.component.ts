import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { OneSOrderService } from '../../one-s-order/one-s-order.service';
import { ProductOfferingDTO } from '../../model/ProductOfferingVO';
import { CreateNewService } from '../createnew.service';
import { CreatenewComponent } from '../createnew.component';


@Component({
  selector: 'app-copy-existing',
  templateUrl: './copy-existing.component.html',
  styleUrls: ['./copy-existing.component.css']
})
export class CopyExistingComponent implements OnInit {

  constructor(private oneS:OneSOrderService, private createService:CreateNewService) { }

  products;
  @Input()
  copyExistingProductOffering:boolean;
  @Output()
  modelObjectTopass = new EventEmitter();
  @Output() onClose: EventEmitter<string> = new EventEmitter<string>();
  @Input()
  baseUrl:string;
  
  ngOnInit() {
  }
  organizationId:string= "-1";
  prodOfferingObj :ProductOfferingDTO[];
  selectedProdOffering : ProductOfferingDTO;
  prodOfferingObjModel : ProductOfferingDTO;
 
  getProductOfferingsforOrg(){
    
    this.oneS.loadProdOffering(this.baseUrl,this.organizationId).subscribe(
      response=>{
        this.prodOfferingObj = response;
       }
    );
    
  }

  getSelectedProdOffer(){
   // alert(this.selectedProdOffering.organizationId +" "+ this.selectedProdOffering.productOfferingId);
   this.createService.copyExistingPO(this.baseUrl,this.selectedProdOffering.organizationId,this.selectedProdOffering.productOfferingId)
   .subscribe(resp =>{
    this.prodOfferingObjModel = JSON.parse(JSON.stringify(resp));
    this.modelObjectTopass.emit(this.prodOfferingObjModel);
    let modalWindow: HTMLElement=document.getElementById("closeModalWindow");
    modalWindow.click();
    this.copyExistingProductOffering = false;

    
   });
    
  }
  onHide(e: any) {
    this.onClose.emit("false");
  }

  existingChargeCol = [
    { field: 'organizationId', header: 'Organization' },
    { field: 'description', header: 'Product Offering' },
    { field: 'productOfferingId', header: 'Product Offering ID' }
   

  ];

}
