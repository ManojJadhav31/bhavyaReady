export class ServiceLocationVO{
    
    serviceLocationId:string;
    serviceLocationName:string;
    controlGroupId:string;
    
}