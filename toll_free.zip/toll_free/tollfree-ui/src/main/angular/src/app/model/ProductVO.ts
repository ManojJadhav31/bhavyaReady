
export class ProductVO{
    
    productIOfferingId:string;
    productName:string;
    label:string;
    
}