import { InitialChargeStructureQuantityDTO } from "./InitialUnitChargeVO";
import { FinalChargeStructureQuantityDTO } from "./AdditionalUnitChargeVO";

export class ChargeStructureQuantityVO {
 
    initialChargeStructureQuantityDTO: InitialChargeStructureQuantityDTO;
    finalChargeStructureQuantityDTO : FinalChargeStructureQuantityDTO;
}