export class SearchScreenVO {
    tn: string;
    voiceOrderId: string;
    customerRequestDate: string;
    orderCompleteDate: string;
    customerId: string;
    btn: string;
    ban: string;
    orderType: string;
    isActive:string;
    orderStatus:string;
    tc:string;
    si:string;
}