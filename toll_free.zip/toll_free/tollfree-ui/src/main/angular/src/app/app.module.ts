import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { OneSOrderModule } from './one-s-order/one-s-order.module'
import { DataTableModule } from "angular2-datatable";
import { OneSOrderService } from './one-s-order/one-s-order.service';
import {ShareDataService} from './one-s-order/shareData.service';
import { HttpModule } from "@angular/http";
import {routing } from "./app.routes";
import { RouterModule } from '@angular/router';
import { ProductOfferingComponent } from './product-offering/product-offering.component';
import { NewProductOfferingCreateComponent } from './product-offering/new-product-offering-create/new-product-offering-create.component';
import { CreatenewComponent } from './createnew/createnew.component';
import { CreateNewService } from './createnew/createnew.service';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ButtonModule} from 'primeng/button';
import {TabViewModule} from 'primeng/tabview';
import { CopyExistingComponent } from './createnew/copy-existing/copy-existing.component';
import {FieldsetModule} from 'primeng/fieldset';
import {CheckboxModule} from 'primeng/checkbox';
import {AccordionModule} from 'primeng/accordion';
import { SearchLandingComponent } from './search-landing/search-landing.component';
import { SearchScreenService } from './one-s-order/searchScreen.service';
import { TnTableViewComponent } from './search-landing/tn-table-view/tn-table-view.component';
import {FileUploadModule} from 'primeng/fileupload';
import {MegaMenuModule} from 'primeng/megamenu';
import { BaseUrlService } from './baseUrlService';
import {PanelModule} from 'primeng/panel';
import { SingleChangeComponent } from './search-landing/single-change/single-change.component';
import {DropdownModule} from 'primeng/dropdown';
import {MessagesModule} from 'primeng/messages';
import {MessageService} from 'primeng/api';
import { ActivityScreenComponent } from './activity-screen/activity-screen.component';
import {SlideMenuModule} from 'primeng/slidemenu';
import {MenuItem} from 'primeng/api';
import {MenuModule} from 'primeng/menu';
import {SidebarModule} from 'primeng/sidebar';
import {PickListModule} from 'primeng/picklist';
import {CalendarModule} from 'primeng/calendar';
import {BulkOrderUploadComponent} from './one-s-order/bulk-order-upload/bulk-order-upload.component';
import {ReportsModule} from './reports/reports.module';
import {RadioButtonModule} from 'primeng/radiobutton';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import { ServiceLookupComponent } from './lookup/service-lookup/service-lookup.component';
import { CustomerLookupComponent } from './lookup/customer-lookup/customer-lookup.component';
import { LookupService } from './lookup/lookup.service';
import { ServiceLocModalComponent } from './lookup/service-loc-modal/service-loc-modal.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { TollfreeHttpInterceptor } from './http.interceptor';
import { TollfreeModule } from './tollfree/tollfree.module';
import { SharedModule} from './shared/shared.module'


@NgModule({
  declarations: [
    AppComponent,
    ProductOfferingComponent,
    NewProductOfferingCreateComponent,
    CreatenewComponent,
    CopyExistingComponent,
    SearchLandingComponent,
    TnTableViewComponent,
    SingleChangeComponent,
    ActivityScreenComponent,
    BulkOrderUploadComponent,
    CustomerLookupComponent, 
    ServiceLookupComponent,
    ServiceLocModalComponent,
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    DataTableModule,
  	HttpModule,
    OneSOrderModule,
    routing,
    RouterModule,
    TableModule,
    DialogModule,
    BrowserAnimationsModule,
    ButtonModule,
    TabViewModule,
    FieldsetModule,
    CheckboxModule,
    AccordionModule,
    FileUploadModule,
    MegaMenuModule,
    PanelModule,
    DropdownModule,
    MessagesModule,
    SlideMenuModule,
    MenuModule,
    SidebarModule,
    PickListModule,
    CalendarModule,
    ReportsModule,
    RadioButtonModule,
    OverlayPanelModule,
    TollfreeModule,
    SharedModule.forRoot()
    ],
  providers: [
    BaseUrlService,
    OneSOrderService,
    CreateNewService,
    ShareDataService,
    SearchScreenService,
    MessageService,
    LookupService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TollfreeHttpInterceptor,
      multi: true
    }
  
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }