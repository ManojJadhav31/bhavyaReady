export class AniDataReportVO{
    customerId:string="";
    serviceLocationId:string="";
    wtn:string;
    btn:string;
    name:string=""
    orderType:String;
    status:String=""
    orderStartDate:Date;
    orderEndDate:Date;
}