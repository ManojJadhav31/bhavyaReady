

export class IproductsVO{

     organizationId:String;
     productId:String;
     productType:String;
     detailType:String;
     descrition:String;
     status:String;
     productBegin:String;
     productEnd:String;

}