import { AddressVO } from "./AddressVO";
import { ContactsVO } from "./ContactsVO";
import { BillingInformationVO } from "./BillingInformationVO";
import { DiscountPlanVO } from "./DiscountPlanVO";
import { ProductSummaryVO } from "./ProductSummaryVO";

export class CustomerInfoVO {

    customerId:string;
    status:string="-1";
    customerName:string;
    customerCode:string;
    customerType:string="B";
    controlGroupId:string="-1";
    customerBegin:Date;
    customerEnd:Date;
    busOrgId:string;
    intraOnlyCapable:boolean;

    addressVO:AddressVO;
    contactsVO: ContactsVO[];
    salesRepVO:ContactsVO[];
    billingInformationVO:BillingInformationVO;
    volDiscountPlanVO:DiscountPlanVO;
    prodDiscountPlanVO:DiscountPlanVO;
    productDiscountPlan:string="";
    productSummaryVO:ProductSummaryVO[];
 
}