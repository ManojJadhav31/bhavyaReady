import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyExistingComponent } from './copy-existing.component';

describe('CopyExistingComponent', () => {
  let component: CopyExistingComponent;
  let fixture: ComponentFixture<CopyExistingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CopyExistingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyExistingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
