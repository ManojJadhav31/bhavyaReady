import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../dashboard.service';
import { BaseUrlService } from '../../baseUrlService';

@Component({
    selector: 'app-chart',
    templateUrl: './chart.component.html',
    styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit {

    isUnderMaintenance: any="false";
    maintenanceMessage: any="";
    showActivityChartData: boolean;
    showOrderChartData: boolean;
    orderChartData: any;
    activityChartData: { labels: string[]; datasets: { data: number[]; backgroundColor: string[]; hoverBackgroundColor: string[]; }[]; };
    baseUrl: any;
    baseurlService: BaseUrlService;
    dashboardService: DashboardService;
    barData: { labels: string[]; datasets: { label: string; backgroundColor: string; borderColor: string; data: number[]; }[]; };
    data: any;
    userName: string;

    /* activitiesLabels: ['Processing',
                        'Error',
                        'Completed',
                        'Cancelled',
                        'New',
                        'E911Rejected',
                        'Parent Tx Wait',
                        'System Wait',
                        'Scheduled',
                        'Response Pending'];

    orderLabels: [ "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December" ]; */

    datasetActivities = [];
    constructor(dashboardService: DashboardService, baseurlService: BaseUrlService) {
        this.dashboardService = dashboardService;
        this.baseurlService = baseurlService;
        
        if (this.baseUrl == null) {
            this.baseurlService.getBaseUrl().subscribe(
                data => {
                    var response = data;
                    this.baseUrl = response.baseUrl;
                    this.isUnderMaintenance = response.maintenanceFlag;
                    this.maintenanceMessage = response.maintenanceMessage;

                    if (localStorage.getItem("userName")) {
                        this.userName = atob(localStorage.getItem("userName"));
                    } else {
                        this.userName = "TEST";
                    }
                    dashboardService.loadActivityChart(this.baseUrl, this.userName).subscribe(
                        data => {
                            var response = data;
                            let activityCount = [];
                            let activitiesLabels = [];

                            for (let item of JSON.parse(JSON.stringify(data))) {
                                activitiesLabels.push(item.status);
                                activityCount.push(item.noOfActivities);
                                this.showActivityChartData = true;
                            }
                            this.activityChartData = {
                                labels: activitiesLabels,
                                datasets: [
                                    {
                                        data: activityCount,
                                        backgroundColor: [
                                            "#FF6384",
                                            "#36A2EB",
                                            "#FFCE56",
                                            "#b19cd9",
                                            "#9CCC65"
                                        ],
                                        hoverBackgroundColor: [
                                            "#FF6384",
                                            "#36A2EB",
                                            "#FFCE56",
                                            "#b19cd9",
                                            "#9CCC65"
                                        ]
                                    }]
                            };
                        });

                    dashboardService.loadOrderChart(this.baseUrl, this.userName).subscribe(
                        data => {
                            var response = data;
                            let orderCount = [];
                            let orderLabels = [];

                            for (let item of JSON.parse(JSON.stringify(data))) {
                                orderLabels.push(item.month);
                                orderCount.push(item.orderCount);
                                this.showOrderChartData = true;
                            }
                            this.orderChartData = {
                                labels: orderLabels,
                                datasets: [
                                    {
                                        label: 'Number  of Orders Submitted',
                                        backgroundColor: '#42A5F5',
                                        borderColor: '#1E88E5',
                                        data: orderCount
                                    }
                                ]
                            }
                        }
                    );
                });


        }/* else{
                this.baseUrl="http://localhost:8080/tollfree-order/"
            } */


    }

    ngOnInit() {

    }

}
