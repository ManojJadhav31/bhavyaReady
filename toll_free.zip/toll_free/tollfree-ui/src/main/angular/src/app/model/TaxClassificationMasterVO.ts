export class TaxClassificationMasterVO{
    taxClassificationId: String;
	description: String ;
}