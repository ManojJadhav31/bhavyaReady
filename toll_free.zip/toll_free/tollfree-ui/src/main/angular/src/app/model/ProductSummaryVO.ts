export class ProductSummaryVO {

    productOffering: string;
    qtyPending: string;
    qtyActive: string;
    qtyDisconnect: string;
}