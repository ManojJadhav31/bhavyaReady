export class RatePlanVO {
    organizationId: string;
    ratePlanId: Number;
    ratePlanName: string;
    description: string;
    effectiveBegin: Date;
    effectiveEnd: Date;
    status: string;
}