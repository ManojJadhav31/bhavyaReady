export class ProductOfferingChargeVO {
    chargeId: String;
    productOfferingId: String;
    organizationId;
    chargeBegin: Date;
    chargeEnd: Date;
    status: String;
}