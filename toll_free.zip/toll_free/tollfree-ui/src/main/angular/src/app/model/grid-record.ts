import { FeaturesVO } from "./feature-details";
import { ValidatedCustomAcctCode } from "./validated-custom-acct-code";

export class GridRecordVO {
    wtn:string
	btn:string
	pic:string
	jurisdiction:string
	forceAniLoad:string
	cic:string	
	features=[];
	featureRecordVO:FeaturesVO;
	validatedCustomAcctCodeVO:ValidatedCustomAcctCode;
		
}