import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { OrderVO } from '../../model/OrderVO';
import { LookupService } from '../lookup.service';
import { Router } from '@angular/router';
import { OneSOrderService } from '../../one-s-order/one-s-order.service';

@Component({
  selector: 'app-service-loc-modal',
  templateUrl: './service-loc-modal.component.html',
  styleUrls: ['./service-loc-modal.component.css']
})
export class ServiceLocModalComponent implements OnInit {

  lookUpService: LookupService;
  customerId = "";
  orgId = "WCG";
  busOrg = "";
  customerName = "";
  custNameInfo: OrderVO[];
  selectedCustInfo: OrderVO;
  displayErrorMessage = '';
  @Output() valueTopass = new EventEmitter();
  @Input() baseUrl: string;
  @Input() servLocModal: boolean;
  @Input() servInfoModal: boolean;
  @Input('show-modal') showModal: boolean;
  @Output() onClose: EventEmitter<string> = new EventEmitter<string>();
  oneSOrderService: OneSOrderService;
  CustNameValid: boolean = false;

  constructor(lookUpService: LookupService, private router: Router) {
    this.lookUpService = lookUpService;
  }


  existingCustCol = [
    { field: 'customerId', header: 'Customer Id' },
    { field: 'customerName', header: 'Customer Name' },
    { field: 'customerBizOrgId', header: 'BusOrg ID' }
  ];

  ngOnInit() {
  }

  keyDownFunction(event) {
    if (event.keyCode == 13) {
      this.passValuetoParent();
    }
  }
  show() {
    this.showModal = true;
  }


  onHide(e: any) {

    this.onClose.emit("false");
  }


  passValuetoParent() {
    if ((this.customerId == null || this.customerId.length == 0) && (this.customerName == null || this.customerName.length == 0) && (this.busOrg == null || this.busOrg.length == 0)) {
      this.displayErrorMessage = "Please enter at least one value."
      return false;
    }
    if (this.customerId || this.busOrg) {
      this.passValtoParent();
    } else if (this.customerName) {
      this.getCustomerInfo(this.selectedCustInfo);

    }
  }

  getCustomerInfo(selectedCustInformtion) {
    let response = {
      "customerId": selectedCustInformtion.customerId,
      "busOrg": selectedCustInformtion.customerBizOrgId,
      "customerName": selectedCustInformtion.customerName,
      "organizationId": selectedCustInformtion.organizationId
    };
    this.valueTopass.emit(response);
  }

  custValidation(num: any, size: number): string {
    let s = num + "";
    while (s.length < 8) s = "0" + s;
    return s;
  }

  passValtoParent() {

    //this.customerId ="00001157";
    let custval = this.custValidation(this.customerId, 8);
    if (this.customerId && this.customerId.trim().length > 0) {
      this.lookUpService.loadCustDetailInfo(this.baseUrl, custval, this.orgId).subscribe(resp => {
        resp.customerId = custval;
        resp.organizationId = this.orgId;
        resp.busOrg = resp.customerBizOrgId;
        this.valueTopass.emit(resp);
      });
    } else if (this.busOrg && this.busOrg.trim().length > 0) {
      this.lookUpService.loadBusOrgInfo(this.baseUrl, this.busOrg).subscribe(resp => {
        resp.busOrg = this.busOrg;
        this.valueTopass.emit(resp);
      });;
    }
  }

  passCustNametoParent() {

    this.CustNameValid = true;
    if (this.customerName && this.customerName.trim().length > 0) {
      this.lookUpService.loadCustName(this.baseUrl, this.customerName).subscribe(resp => {
        /* for(let i=0;i<resp.length;i++){
          if(resp[i].customerBizOrgId === 'null'){
            resp[i].customerBizOrgId = "";
          }
        } */
        this.custNameInfo = resp;

      });

    }
  }

  cancel() {
    this.router.navigate(["/landing-screen"]);
  }
}
