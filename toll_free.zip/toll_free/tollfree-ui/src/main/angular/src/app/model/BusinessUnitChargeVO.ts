export class BusinessUnitChargeVO {
    organizationId: string;
    chargeId: string;
    businessUnit: string="00452";
    chargeDepartment: string = "000000";
    affiliate: string = "00000";
    costCode: string = "0000";
    profitCenter: string = "000000";
    currency: string = "AUD";

}