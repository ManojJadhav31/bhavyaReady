export class BusinessUnitAffiliateVO{

    businessUnitAffiliate:String;
    businessUnitAffiliateDesc:String;
    businessUnitAffiliateFlag:String;
    organizationId:String;
}