export class ActivitySearchVO{
    activityId: number ;
	orderActivityPk:Number ;
	activityName:string ;
	name:string ;
	parentTransId:Number;
}