export class TriggerActivityInputVo {
    actionType: string;
    orderActivityPk: Array<Number>=[];
}