package com.level3.voice.tollfree.bulk.batch.processor;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * It has two batch jobs. One job reads excel and writes in the database and other job picks the data from database and submits the order
 * @author <a href="mailto:manjunatha.d@centurylink.com">Manjunatha D</a>
 *
 */
@Component
@Lazy
public class BulkOrderProcessor  {

	 private final Logger logger = Logger.getLogger(BulkOrderProcessor.class);

	@Autowired
    JobLauncher jobLauncher;

    @Autowired
	@Qualifier("bulkOrderSubmitBatchJob")
	Job bulkOrderSubmitBatchJob;
    
    @Autowired
	@Qualifier("bulkOrderUploadBatchJob")
	Job bulkOrderUploadBatchJob;
    
	@Autowired
   	@Qualifier("bulkOrderNSUploadBatchJob")
   	Job bulkOrderNSUploadBatchJob;
	
	/**
	 * The job which reads excel (from given file[filePath]) and writes in the database with VOICE_ORDER_ID
	 * @param filePath
	 * @param voiceOrderId
	 * @param bulkOrderUploadId 
	 * @param subscriberId 
	 * @throws Exception
	 */
    //@Async("batchJobExecutor")
	public void startBulkOrderUploadBatch(String filePath, Long voiceOrderId, Long bulkOrderUploadId, Long subscriberId) throws Exception {
		JobParametersBuilder builder = new JobParametersBuilder();
		builder.addLong("VOICE_ORDER_ID", voiceOrderId);
		builder.addString("FILE_PATH", filePath);
		builder.addString("BULK_ORDER_UPLOAD_ID", bulkOrderUploadId.toString());
		builder.addLong("SUBSCRIBER_ID", subscriberId);
		logger.info("Before startBulkOrderUploadBatch Joblauncher");
		try {
			jobLauncher.run(bulkOrderUploadBatchJob, builder.toJobParameters());
			logger.info("After startBulkOrderUploadBatch Joblauncher");
		} catch (JobExecutionAlreadyRunningException | JobRestartException |
				JobInstanceAlreadyCompleteException
				| JobParametersInvalidException ex) {
			throw ex;
		}
	}
	
	@Async("batchJobExecutor")
	public void startBulkOrderSubmitBatch(Long voId, Long subscriberId) throws Exception {
		JobParametersBuilder builder = new JobParametersBuilder();
		builder.addLong("VOICE_ORDER_ID", voId);
		builder.addLong("SUBSCRIBER_ID", subscriberId);
		builder.addLong("time",System.currentTimeMillis());
		logger.info("Before startBulkOrderSubmitBatch Joblauncher");
		try {
			jobLauncher.run(bulkOrderSubmitBatchJob, builder.toJobParameters());
			logger.info("After startBulkOrderSubmitBatch Joblauncher");
		} catch (JobExecutionAlreadyRunningException | JobRestartException |
				JobInstanceAlreadyCompleteException
				| JobParametersInvalidException ex) {
			throw ex;
		}
	}
	
	 /**
	 * The job which reads BULK/DAT (from given file[filePath]) and writes in the database with VOICE_ORDER_ID
	 * @param filePath
	 * @param voiceOrderId
	 * @param bulkOrderUploadId 
	 * @throws Exception
	 */
	 
    @Async("batchJobExecutor")
	public void startNSBulkOrderUploadBatch(String filePath, Long voiceOrderId, Long bulkOrderUploadId,Long subscriberId) throws Exception {
		JobParametersBuilder builder = new JobParametersBuilder();
		builder.addLong("VOICE_ORDER_ID", voiceOrderId);
		builder.addString("FILE_PATH", filePath);
	//	builder.addString("BULK_ORDER_UPLOAD_ID", bulkOrderUploadId.toString());
		builder.addLong("SUBSCRIBER_ID", subscriberId); 
		logger.info("Before startNSBulkOrderUploadBatch Joblauncher");
		try {
			jobLauncher.run(bulkOrderNSUploadBatchJob, builder.toJobParameters());
			logger.info("After startBulkOrderUploadBatch Joblauncher");
		} catch (JobExecutionAlreadyRunningException | JobRestartException |
				JobInstanceAlreadyCompleteException
				| JobParametersInvalidException ex) {
			throw ex;
		}
	}
	
}