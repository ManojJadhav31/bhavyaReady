package com.level3.voice.tollfree.manager;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.client.DataMSClient;
import com.level3.voice.tollfree.client.PROClient;
import com.level3.voice.tollfree.model.Switches;
import com.level3.voice.tollfree.model.TrunkGroups;

/**
 * Manager to hold the business logics which would be invoked from the service
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class TerminationOrderServiceManager {

	@Autowired
	DataMSClient dataMSClient;

	@Autowired
	PROClient proClient;

	/**
	 * This method is to retrieve the switches associated to a BAN in case of DIFF
	 * BAN flag N and also retrieve all the switches associated to all BANs
	 * associated to the selected BAN
	 * 
	 * @param ban
	 * @return
	 * @throws Exception
	 */
	public Switches retrieveSwitchDetails(String ban) throws Exception {
		Switches switches = new Switches();
		List<String> customerBans = getBanData(ban);
		if (dataMSClient.isDifferentBanEnabled(ban)) {
			customerBans = dataMSClient.getCustomerBans(ban);
		}

		if (customerBans != null && !customerBans.isEmpty()) {
			for (String customerBan : customerBans) {
				Switches proSwitches = proClient.retrieveSwitchesByBan(customerBan);
				if (proSwitches != null) {
					switches.addSwitches(proSwitches.getSwitches());
				}
			}
		}

		return switches;
	}

	/**
	 * This method is to create a list with the BAN selected
	 * 
	 * @param ban
	 * @return
	 */
	private List<String> getBanData(String ban) {
		List<String> banData = new ArrayList<>();
		banData.add(ban);
		return banData;
	}

	/**
	 * This method is to retrieve the trunk groups from PRO using the ban and switch
	 * final number which is selected by user
	 * 
	 * @param ban
	 * @param switchfinalNumber
	 * @return
	 * @throws Exception
	 */
	public TrunkGroups retrieveTrunkGroupDetails(String ban, String switchfinalNumber) throws Exception {
		return proClient.retrieveTrunkGroupsByBanSwitch(ban, switchfinalNumber);
	}

}
