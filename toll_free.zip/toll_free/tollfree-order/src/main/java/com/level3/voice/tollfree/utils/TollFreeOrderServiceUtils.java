package com.level3.voice.tollfree.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.OrderActionCodes;
import com.level3.voice.tollfree.client.NUMSClient;
import com.level3.voice.tollfree.constants.TollFreeOrderConstants;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.tollfree.vo.FeaturesVO;
import com.level3.voice.tollfree.vo.TNDataVO;
import com.level3.voice.tollfree.vo.ValidatedCustomAcctCodeVO;

/**
 * Util methods for TollFreeOrderServiceManager
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class TollFreeOrderServiceUtils {

	@Autowired
	private TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	@Autowired
	NUMSClient numsClient;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;
	
	@Value("#{'${list.of.features}'.split(',')}")
	private List<String> featuresGroup;

	private static final Logger logger = Logger.getLogger(TollFreeOrderServiceUtils.class);

	/**
	 * Method to retrieve sheetname present in the workbook
	 * 
	 * @param workbook
	 * @return Sheetnames
	 */
	public String getSheetName(XSSFWorkbook workbook) {
		String sheetName = "";

		for (int j = 0; j < workbook.getNumberOfSheets();) {
			XSSFSheet sheet = workbook.getSheetAt(j);
			return sheet.getSheetName();
		}
		return sheetName;
	}

	/**
	 * Method to check if the sheet name is part of the sheetnames configured in
	 * the application.properties [allSheetNames]
	 * 
	 * @param workBookSheetName
	 * @param allSheetNames
	 * @return True or False
	 * @throws SLDBException
	 */
	public boolean getSheetNames(String workBookSheetName, String allSheetNames) throws SLDBException {
		if (StringUtils.isEmpty(allSheetNames)) {
			throw new SLDBException(
					"@TollFreeOrderServiceUtils getSheetNames: sheet.names is not available in property file.");
		}
		if (allSheetNames.contains(workBookSheetName)) {
			return true;
		}
		return false;
	}

	/**
	 * Create a TN Property Record VO for each row in the spreadsheet using the
	 * sheetColumns retrieved from property file
	 * 
	 * @param HSSFRow
	 * @param sheetColumns
	 * @return TNPropertyRecordVO
	 */
	public TNDataVO getTNDataVO(XSSFRow r, Map<String, String> sheetColumns) {

		if (sheetColumns == null || (sheetColumns != null && sheetColumns.isEmpty())) {
			return null;
		}

		DataFormatter objDefaultFormat = new DataFormatter();
		TNDataVO tnPropertyRecordVO = new TNDataVO();
		ValidatedCustomAcctCodeVO validatedCustomAcctCodeVO = new ValidatedCustomAcctCodeVO();

		Iterator<Entry<String, String>> sheetColumnsIter = sheetColumns.entrySet().iterator();
		while (sheetColumnsIter.hasNext()) {
			List<FeaturesVO> features = new ArrayList<>();
			Entry<String, String> entry = sheetColumnsIter.next();
			String key = entry.getKey();
			String value = entry.getValue();
			if (TollFreeOrderConstants.BTN.equalsIgnoreCase(key)) {
				tnPropertyRecordVO.setBtn(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.WTN.equalsIgnoreCase(key)) {
				tnPropertyRecordVO.setWtn(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.PIC.equalsIgnoreCase(key)) {
				tnPropertyRecordVO.setPic(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.JURISDICTION.equalsIgnoreCase(key)) {
				tnPropertyRecordVO
						.setJurisdiction(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.FORCE_ANI_LOAD.equalsIgnoreCase(key)) {
				tnPropertyRecordVO
						.setForceAniLoad(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.CIC.equalsIgnoreCase(key)) {
				tnPropertyRecordVO.setCic(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.FEATURES.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				features = getFeaturesList(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
				tnPropertyRecordVO.setFeatures(features);
			} else if (TollFreeOrderConstants.CODE_DIGITS.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				 validatedCustomAcctCodeVO
						.setCodeDigits(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
				 tnPropertyRecordVO.setValidatedCustomAcctCodeVO(validatedCustomAcctCodeVO);
			} else if (TollFreeOrderConstants.CODE_TABLE.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				validatedCustomAcctCodeVO
						.setCodeTableName(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
				tnPropertyRecordVO.setValidatedCustomAcctCodeVO(validatedCustomAcctCodeVO);
			} else if (TollFreeOrderConstants.FEATURE_ID.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				features = getFeaturesFromIds(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
				tnPropertyRecordVO.setFeatures(features);
			} else if (TollFreeOrderConstants.IS_MANDATORY.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				features = setAccountCodeEFS(tnPropertyRecordVO, objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			}
			// TODO need clarity on reading custom feaure from excel
		
			/* if(!StringUtils.isEmpty(validatedCustomAcctCodeVO.getCodeDigits()
			 )) { for(FeaturesVO feature : features) {
			 if(feature.getFeatureDesc().contains("Custom")) {
			 feature.setValidatedCustomAcctCodeVO(validatedCustomAcctCodeVO);
			 break; } } }*/
			 
		}
		return tnPropertyRecordVO;
	}

	private List<FeaturesVO> getFeaturesFromIds(String featureIds) {
		List<FeaturesVO> featureList = new ArrayList<>();

		if (featureIds.indexOf(",") > 1) {
			String[] featureData = featureIds.split(",");
			for (String f : featureData) {
				FeaturesVO featuresVO = new FeaturesVO();
				featuresVO.setFeatureDescription(getFeatureDetails().get(f));
				featuresVO.setFeatureOfferingId(f);
				featureList.add(featuresVO);

			}
		} else {
			FeaturesVO featuresVO = new FeaturesVO();
			featuresVO.setFeatureDescription(getFeatureDetails().get(featureIds));
			featuresVO.setFeatureOfferingId(featureIds);
			featureList.add(featuresVO);
		}
		return featureList;
	}

	private List<FeaturesVO> setAccountCodeEFS(TNDataVO tnPropertyRecordVO,String isMandatoryFeature) {
		List<FeaturesVO> featureList = tnPropertyRecordVO.getFeatures();
		String esfFlag = null;
		for (FeaturesVO feature : featureList) {
				if (StringUtils.isNotEmpty(feature.getFeatureDescription())
						&& feature.getFeatureDescription().contains("Unvalidated Acct Codes")) {
					if ("Yes".equals(isMandatoryFeature))
						esfFlag = "U";
					else if ("No".equals(isMandatoryFeature))
						esfFlag = "N";
				}
				if (StringUtils.isNotEmpty(feature.getFeatureDescription())
						&& feature.getFeatureDescription().contains("Validated Custom")) {
					if ("Yes".equals(isMandatoryFeature))
						esfFlag = "C";
					else if ("No".equals(isMandatoryFeature))
						esfFlag = "Y";
				}
				feature.setAccountCodeESF(esfFlag);
			}
		return featureList;
	}

	/**
	 * Get the List of features from features values retrieved from the
	 * spreadsheet
	 * 
	 * @param features
	 * @return List<String>
	 */
	private List<FeaturesVO> getFeaturesList(String features) {
		List<FeaturesVO> featureList = new ArrayList<>();

		if (features.indexOf(",") > 1) {
			String[] featureData = features.split(",");
			for (String f : featureData) {
				FeaturesVO featuresVO = new FeaturesVO();
				featuresVO.setFeatureDescription(f.substring(0, f.indexOf("[")));
				featuresVO.setFeatureOfferingId(f.substring(f.indexOf("[") + 1, f.indexOf("]")));
				featureList.add(featuresVO);

			}
		} else {
			FeaturesVO featuresVO = new FeaturesVO();
			featuresVO.setFeatureDescription(features.substring(0, features.indexOf("[")));
			featuresVO.setFeatureOfferingId(features.substring(features.indexOf("[") + 1, features.indexOf("]")));
			featureList.add(featuresVO);
		}
		return featureList;
	}

	/**
	 * Method to create a map of key value pairs for the data using sheetColumns
	 * 
	 * @param sheetColumns
	 * @return Map<String, String>
	 * @throws SLDBException
	 */
	public Map<String, String> getSheetColumns(String sheetColumns) throws SLDBException {
		return getSheetColumns(sheetColumns, false);
	}

	/**
	 * Method to create a map of key value pairs for the data using sheetColumns
	 * 
	 * @param sheetColumns
	 * @return Map<String, String>
	 * @throws SLDBException
	 */
	public Map<String, String> getSheetColumns(String sheetColumns, boolean switchKeyValue) throws SLDBException {
		if (StringUtils.isEmpty(sheetColumns)) {
			throw new SLDBException(
					"@TollFreeOrderServiceUtils getSheetNames: sheet.names is not available in property file.");
		}

		Map<String, String> customerDetails = new HashMap<String, String>();
		String[] customerInfoArry = sheetColumns.split(",");
		for (int i = 0; i < customerInfoArry.length; i++) {
			String customerDetail = customerInfoArry[i];
			if (customerDetail.indexOf(":") == -1) {
				continue;
			}
			String[] customerDetailArry = customerDetail.split(":");
			if (switchKeyValue) {
				customerDetails.put(customerDetailArry[1].trim(), customerDetailArry[0].trim());
			} else {
				customerDetails.put(customerDetailArry[0].trim(), customerDetailArry[1].trim());
			}

		}
		return customerDetails;
	}

	/**
	 * Method to write data on to the spreadsheet by reading the List of
	 * TNPropertyRecordVO
	 * 
	 * @param allSheetColumns
	 * @param datatypeSheet
	 * @param tnPropertyRecordVOs
	 */
	public void updateExcelData(Map<String, String> allSheetColumns, Sheet datatypeSheet,
			List<TNDataVO> tnPropertyRecordVOs) {

		long startTime = System.currentTimeMillis();

		Iterator<Row> iterator = datatypeSheet.iterator();
		while (iterator.hasNext()) {
			Row currentRow = iterator.next();
			if (currentRow.getRowNum() == 0) {
				continue;
			}
			if (currentRow.getRowNum() == (tnPropertyRecordVOs.size() + 1)) {
				break;
			}
			TNDataVO gvo = tnPropertyRecordVOs.get(currentRow.getRowNum() - 1);
			Iterator<Cell> cellIterator = currentRow.iterator();

			while (cellIterator.hasNext()) {

				Cell currentCell = cellIterator.next();
				if (currentCell.getColumnIndex() == allSheetColumns.size()) {
					break;
				}

				String cellNum = String.valueOf(currentCell.getColumnIndex());

				if (!allSheetColumns.containsKey(cellNum))
					continue;

				String value = allSheetColumns.get(cellNum);
				if (TollFreeOrderConstants.BTN.equalsIgnoreCase(value)) {
					currentCell.setCellValue(gvo.getBtn());
				} else if (TollFreeOrderConstants.WTN.equalsIgnoreCase(value)) {
					currentCell.setCellValue(gvo.getWtn());
				} else if (TollFreeOrderConstants.PIC.equalsIgnoreCase(value)) {
					currentCell.setCellValue(gvo.getPic());
				} else if (TollFreeOrderConstants.JURISDICTION.equalsIgnoreCase(value)) {
					currentCell.setCellValue(gvo.getJurisdiction());
				} else if (TollFreeOrderConstants.FORCE_ANI_LOAD.equalsIgnoreCase(value)) {
					currentCell.setCellValue(gvo.getForceAniLoad());
				} else if (TollFreeOrderConstants.CIC.equalsIgnoreCase(value)) {
					currentCell.setCellValue(gvo.getCic());
				} else if (TollFreeOrderConstants.FEATURES.equalsIgnoreCase(value) && gvo.getFeatures() != null
						&& !gvo.getFeatures().isEmpty()) {
					String features = "";
					for (FeaturesVO featuresVO : gvo.getFeatures()) {
						features = features + featuresVO.getFeatureDescription() + "["
								+ featuresVO.getFeatureOfferingId() + "],";
					}

					if (features.length() > 0) {
						features.substring(0, features.length() - 1);
					}
					currentCell.setCellValue(features.substring(0, features.length() - 1));

				} else if (TollFreeOrderConstants.CODE_DIGITS.equalsIgnoreCase(value)
						&& gvo.getValidatedCustomAcctCodeVO() != null) {
					currentCell.setCellValue(gvo.getValidatedCustomAcctCodeVO().getCodeDigits());
				} else if (TollFreeOrderConstants.CODE_TABLE.equalsIgnoreCase(value)
						&& gvo.getValidatedCustomAcctCodeVO() != null) {
					currentCell.setCellValue(gvo.getValidatedCustomAcctCodeVO().getCodeTableName());
				}
			}
		}
		long endTime = System.currentTimeMillis();
		logger.info("@TollFreeOrderServiceUtils @uploadExcelData took " + (endTime - startTime) + " milliseconds.");
	}

	/**
	 * Method to check if the TN format is valid using regular expression
	 * 
	 * @param tn
	 * @param format
	 * @return boolean
	 */
	public boolean isTNValid(String tn, String format) {
		if (StringUtils.isEmpty(format) || StringUtils.isEmpty(tn)) {
			return false;

		}
		Pattern tnPattern = Pattern.compile(format);
		Matcher matcher = tnPattern.matcher(tn);
		return matcher.matches();
	}

	/**
	 * Method to check if the TN is inflight by checking against the 3FLOW DB
	 * 
	 * @param tn
	 * @return boolean
	 * @throws Exception
	 */
	public boolean isTNInflight(String tn) {
		if (tollFreeSubsciberLineRepository.hasPendingOrdersForTollFreeTn(tn) > 0) {
			return true;
		}
		return false;
	}

	public boolean isTNPresentInNums(String tn) throws Exception {
		return numsClient.isTNPresentInNums(tn);
	}

	/**
	 * Set jurisdiction value based on the UI selection
	 * 
	 * @param gVO
	 * @return
	 */
	public String getJurisdiction(TNDataVO gVO) {
		if ("Inter & Intra LATA".equalsIgnoreCase(gVO.getJurisdiction())) {
			return "B";
		} else if ("Inter LATA".equalsIgnoreCase(gVO.getJurisdiction())) {
			return "E";
		}
		return null;
	}

	public boolean isCustomerMove(String tn, String actionType, String currentCustomerId) {
		if (StringUtils.isEmpty(tn) || StringUtils.isEmpty(actionType) || StringUtils.isEmpty(currentCustomerId)) {
			return false;
		}
		String customerID = orderTollFreeFeatureRepository.getPrevCustActiveCustomerId(tn);

		return OrderActionCodes.INSTALL_STRING.equalsIgnoreCase(actionType) && !StringUtils.isEmpty(customerID)
				&& !customerID.equalsIgnoreCase(currentCustomerId);
	}
	
	/**
	 * It reads the features from property file and creates the Map<String, String>
	 * (featureId and description)
	 * 
	 * @return
	 */
	private Map<String, String> getFeatureDetails() {
		Map<String, String> featureDetails = new HashMap<String, String>();

		for (String featureGroup : featuresGroup) {
			String[] features = featureGroup.split(":");
			featureDetails.put(features[0], features[1]);
		}

		return featureDetails;
	}
}
