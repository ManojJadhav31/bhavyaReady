package com.level3.voice.tollfree.client;

import java.net.URL;
import java.rmi.RemoteException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.CacheConstants;
import com.level3.voice.tollfree.client.sauiupdate.ActivityPkArrayRequestVo;
import com.level3.voice.tollfree.client.sauiupdate.ForceCompleteActivityRequestVo;
import com.level3.voice.tollfree.client.sauiupdate.SAUI_Update_ServiceLocator;
import com.level3.voice.tollfree.client.sauiupdate.SAUI_Update_ServicePort_PortType;
import com.level3.voice.tollfree.client.sauiupdate.UIResponseVo;


/**
 * SAUI update service client, source files generated 
 * using axis. 
 * 
 * @author <a href="mailto:Nnupur.Krishnaa@centurylink.com">Nnupur Krishnaa</a>
 *
 */
@Component
public class SAUIUpdateServiceClient {

	public static SAUI_Update_ServicePort_PortType SAUI_Update_ServicesPort = null;

	@Value("${sldb.3flow.saui.url}")
	private String requestBaseURL;
	
	private static final Logger log = Logger.getLogger(SAUI_Update_ServicePort_PortType.class);

	private SAUI_Update_ServicePort_PortType getServiceClient() {
		if (SAUI_Update_ServicesPort != null)
			return SAUI_Update_ServicesPort;

		try {
			URL url = new java.net.URL(requestBaseURL);
			SAUI_Update_ServicesPort = new SAUI_Update_ServiceLocator().getSAUI_Update_ServicePort(url);
		} catch (Exception e) {
			log.error("Exeption in getSAUI_Update_ServicePort: "+e);
		}
		return SAUI_Update_ServicesPort;
	}
	
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":ForceComplete")
	public UIResponseVo[] forceCompleteActivity(long[] activityPkArray) throws RemoteException {
		
		//long[] activityPkArray = null ;
		ForceCompleteActivityRequestVo forceCompleteActivityRequestVo  = new ForceCompleteActivityRequestVo();
		//ActivityPkArrayRequestVo orderActivityPkArray = new ActivityPkArrayRequestVo();
		//orderActivityPkArray.setOrderActivityPkArray(activityPkArray);
		
		forceCompleteActivityRequestVo.setOrderActivityPkArray(activityPkArray);
		return getServiceClient().forceCompleteActivity(forceCompleteActivityRequestVo);
	}

	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":RestartActivity")
	public UIResponseVo[] restartActivity(long[] activityPkArray) throws RemoteException {
		//long[] activityPkArray = null ;
		ActivityPkArrayRequestVo activityPkArrayRequestVo = new ActivityPkArrayRequestVo();
		activityPkArrayRequestVo.setOrderActivityPkArray(activityPkArray);
		
		return getServiceClient().restartActivity(activityPkArrayRequestVo);
	}
	
}
