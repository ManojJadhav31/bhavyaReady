package com.level3.voice.tollfree;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.centurylink.microservice.springfox.EnableSwaggerDocumentation;
import com.level3.voice.tollfree.service.SwaggerDocumentationConfig;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@SpringBootApplication
@EnableAsync
@EnableSwagger2
@ComponentScan(basePackages = { "com.level3.voice.tollfree", "com.level3.voice.persist.repository" })
@EnableDiscoveryClient
@EnableSwaggerDocumentation(apiTitle="Staged Orders",
apiDescription="Mangement of Staged Orders")
@Import({SwaggerDocumentationConfig.class})
public class TollFreeOrderApplication {

	/**
	 * Starts the service.
	 *
	 * @param args
	 *            not used.
	 */
	public static void main(String... args) {
		SpringApplication.run(TollFreeOrderApplication.class, args);
	}
	
	/**
	 * Executor for 1S ld order submission process
	 * 
	 * @return
	 */
	@Bean
	@Qualifier("ldOrderSubmitProcessorExecutor")
	public ThreadPoolTaskExecutor getOrderSubmitProcessorExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setMaxPoolSize(100);
		executor.setCorePoolSize(20);
		executor.setThreadNamePrefix("T-ld-Order-Submit-Batch");
		executor.initialize();

		return executor;
	}

}
