package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class BanServiceLocationVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String accountNumber;
	private String serviceLocationId;
	private String serviceLocationName;
	private String controlGroupId;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getServiceLocationId() {
		return serviceLocationId;
	}
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}
	public String getServiceLocationName() {
		return serviceLocationName;
	}
	public void setServiceLocationName(String serviceLocationName) {
		this.serviceLocationName = serviceLocationName;
	}
	public String getControlGroupId() {
		return controlGroupId;
	}
	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}
}
