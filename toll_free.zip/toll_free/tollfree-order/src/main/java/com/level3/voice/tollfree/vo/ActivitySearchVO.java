package com.level3.voice.tollfree.vo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ActivitySearchVO implements Serializable {
	
	/*public ActivitySearchVO(int activityId, String activityName, String name) {
		super();
		this.activityId = activityId;
		this.activityName = activityName;
		this.name = name;
	}*/
	
	
	private int activityId;
	private String orderActivityPk;
	private String activityName;
	private String name;
	private String startTime;
	private String endTime;
	private String comments;
	private String tn;
	private String voiceOrderId;
	private String parentTransId;
	
	public String getParentTransId() {
		return parentTransId;
	}
	public void setParentTransId(String parentTransId) {
		this.parentTransId = parentTransId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getActivityId() {
		return activityId;
	}
	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}
	public String getOrderActivityPk() {
		return orderActivityPk;
	}
	public void setOrderActivityPk(String orderActivityPk) {
		this.orderActivityPk = orderActivityPk;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getVoiceOrderId() {
		return voiceOrderId;
	}
	public void setVoiceOrderId(String voiceOrderId) {
		this.voiceOrderId = voiceOrderId;
	}
	
	
	
	
	
	
	
	
	

}
