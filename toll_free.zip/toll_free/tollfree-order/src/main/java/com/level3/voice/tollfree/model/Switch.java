package com.level3.voice.tollfree.model;

import java.io.Serializable;
import java.util.Map;

/**
 * Model object to represent the switch object sent from PRO
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class Switch implements Serializable {

	private static final long serialVersionUID = 1L;
	private String type;
	private String vendor;
	private String finalNumber;
	private String softwareVersion;
	private String cleiCode;
	private String ipAddress;
	private String model;
	private String description;
	private String pointCode;
	private String clliCode;
	private String updateAppId;
	private int updateDate;
	private int objectId;
	private String createLogonId;
	private int createDate;
	private String updateLogonId;
	private String createUserId;
	private String createAppId;
	private String updateUserId;
	private Map<String, String> metaDataMap;

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the vendor
	 */
	public String getVendor() {
		return vendor;
	}

	/**
	 * @param vendor the vendor to set
	 */
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	/**
	 * @return the finalNumber
	 */
	public String getFinalNumber() {
		return finalNumber;
	}

	/**
	 * @param finalNumber the finalNumber to set
	 */
	public void setFinalNumber(String finalNumber) {
		this.finalNumber = finalNumber;
	}

	/**
	 * @return the softwareVersion
	 */
	public String getSoftwareVersion() {
		return softwareVersion;
	}

	/**
	 * @param softwareVersion the softwareVersion to set
	 */
	public void setSoftwareVersion(String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}

	/**
	 * @return the cleiCode
	 */
	public String getCleiCode() {
		return cleiCode;
	}

	/**
	 * @param cleiCode the cleiCode to set
	 */
	public void setCleiCode(String cleiCode) {
		this.cleiCode = cleiCode;
	}

	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the pointCode
	 */
	public String getPointCode() {
		return pointCode;
	}

	/**
	 * @param pointCode the pointCode to set
	 */
	public void setPointCode(String pointCode) {
		this.pointCode = pointCode;
	}

	/**
	 * @return the clliCode
	 */
	public String getClliCode() {
		return clliCode;
	}

	/**
	 * @param clliCode the clliCode to set
	 */
	public void setClliCode(String clliCode) {
		this.clliCode = clliCode;
	}

	/**
	 * @return the updateAppId
	 */
	public String getUpdateAppId() {
		return updateAppId;
	}

	/**
	 * @param updateAppId the updateAppId to set
	 */
	public void setUpdateAppId(String updateAppId) {
		this.updateAppId = updateAppId;
	}

	/**
	 * @return the updateDate
	 */
	public int getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(int updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the objectId
	 */
	public int getObjectId() {
		return objectId;
	}

	/**
	 * @param objectId the objectId to set
	 */
	public void setObjectId(int objectId) {
		this.objectId = objectId;
	}

	/**
	 * @return the createLogonId
	 */
	public String getCreateLogonId() {
		return createLogonId;
	}

	/**
	 * @param createLogonId the createLogonId to set
	 */
	public void setCreateLogonId(String createLogonId) {
		this.createLogonId = createLogonId;
	}

	/**
	 * @return the createDate
	 */
	public int getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(int createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the updateLogonId
	 */
	public String getUpdateLogonId() {
		return updateLogonId;
	}

	/**
	 * @param updateLogonId the updateLogonId to set
	 */
	public void setUpdateLogonId(String updateLogonId) {
		this.updateLogonId = updateLogonId;
	}

	/**
	 * @return the createUserId
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/**
	 * @param createUserId the createUserId to set
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/**
	 * @return the createAppId
	 */
	public String getCreateAppId() {
		return createAppId;
	}

	/**
	 * @param createAppId the createAppId to set
	 */
	public void setCreateAppId(String createAppId) {
		this.createAppId = createAppId;
	}

	/**
	 * @return the updateUserId
	 */
	public String getUpdateUserId() {
		return updateUserId;
	}

	/**
	 * @param updateUserId the updateUserId to set
	 */
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	/**
	 * @return the metaDataMap
	 */
	public Map<String, String> getMetaDataMap() {
		return metaDataMap;
	}

	/**
	 * @param metaDataMap the metaDataMap to set
	 */
	public void setMetaDataMap(Map<String, String> metaDataMap) {
		this.metaDataMap = metaDataMap;
	}

}
