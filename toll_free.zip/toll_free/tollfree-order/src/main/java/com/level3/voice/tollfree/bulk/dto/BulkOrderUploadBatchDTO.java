package com.level3.voice.tollfree.bulk.dto;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This DTO is representation of the BULK Batch table
 * 
 * @author <a href="mailto:Arun2.kumar@centurylink.com">Arun Kumar</a>
 *
 */


@Entity
@Table(name = "BULK_ORDER_UPLOAD_BATCH")
public class BulkOrderUploadBatchDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	@Column(name = "FILE_NAME")
	private String fileName;
	@Column(name = "FILE_DATA")
	private byte[] fileData;
	
	@Id
	@Column(name = "VOID")
	private String voId;
	
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFileData() {
		return fileData;
	}

	public void setFileData(byte[] bs) {
		this.fileData = bs;
	}
	
	public String getVoId() {
		return voId;
	}

	public void setVoId(String voId) {
		this.voId = voId;
	}

	
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
}
