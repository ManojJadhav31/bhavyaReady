package com.level3.voice.tollfree.vo;

public class NS1SBulkOrderVO {
	private String versionNumber;
	private String serviceType;
	private String orderType;
	private String organizationId;
	private String customerId;
	private String productId;
	private String btn;
	private String wtn;
	private String terminalNumber;
	private String serviceLocationId;
	private String loaDate;
	private String salesRepId;
	private String customerBatchNumber;
	private String customerOrderNumber;
	private String customerDate;
	private String customerAcctNbr;
	private String customerSalesRep;
	private String customerSalesAgent;
	private String customer1;
	private String customer2;
	private String customer3;
	private String customer4;
	private String processDate;
	private String reserved1;
	private String reserved2;
	private String sandStoneTC;
	private String sandStoneSI;
	private String cic;
	private String sandStoneOrderStatus;
	private String completionDate;
	private String reserved3;
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public String getWtn() {
		return wtn;
	}
	public void setWtn(String wtn) {
		this.wtn = wtn;
	}
	public String getTerminalNumber() {
		return terminalNumber;
	}
	public void setTerminalNumber(String terminalNumber) {
		this.terminalNumber = terminalNumber;
	}
	public String getServiceLocationId() {
		return serviceLocationId;
	}
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}
	public String getLoaDate() {
		return loaDate;
	}
	public void setLoaDate(String loaDate) {
		this.loaDate = loaDate;
	}
	public String getSalesRepId() {
		return salesRepId;
	}
	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}
	public String getCustomerBatchNumber() {
		return customerBatchNumber;
	}
	public void setCustomerBatchNumber(String customerBatchNumber) {
		this.customerBatchNumber = customerBatchNumber;
	}
	public String getCustomerOrderNumber() {
		return customerOrderNumber;
	}
	public void setCustomerOrderNumber(String customerOrderNumber) {
		this.customerOrderNumber = customerOrderNumber;
	}
	public String getCustomerDate() {
		return customerDate;
	}
	public void setCustomerDate(String customerDate) {
		this.customerDate = customerDate;
	}
	public String getCustomerAcctNbr() {
		return customerAcctNbr;
	}
	public void setCustomerAcctNbr(String customerAcctNbr) {
		this.customerAcctNbr = customerAcctNbr;
	}
	public String getCustomerSalesRep() {
		return customerSalesRep;
	}
	public void setCustomerSalesRep(String customerSalesRep) {
		this.customerSalesRep = customerSalesRep;
	}
	public String getCustomerSalesAgent() {
		return customerSalesAgent;
	}
	public void setCustomerSalesAgent(String customerSalesAgent) {
		this.customerSalesAgent = customerSalesAgent;
	}
	public String getCustomer1() {
		return customer1;
	}
	public void setCustomer1(String customer1) {
		this.customer1 = customer1;
	}
	public String getCustomer2() {
		return customer2;
	}
	public void setCustomer2(String customer2) {
		this.customer2 = customer2;
	}
	public String getCustomer3() {
		return customer3;
	}
	public void setCustomer3(String customer3) {
		this.customer3 = customer3;
	}
	public String getCustomer4() {
		return customer4;
	}
	public void setCustomer4(String customer4) {
		this.customer4 = customer4;
	}
	public String getProcessDate() {
		return processDate;
	}
	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}
	public String getReserved1() {
		return reserved1;
	}
	public void setReserved1(String reserved1) {
		this.reserved1 = reserved1;
	}
	public String getReserved2() {
		return reserved2;
	}
	public void setReserved2(String reserved2) {
		this.reserved2 = reserved2;
	}
	public String getSandStoneTC() {
		return sandStoneTC;
	}
	public void setSandStoneTC(String sandStoneTC) {
		this.sandStoneTC = sandStoneTC;
	}
	public String getSandStoneSI() {
		return sandStoneSI;
	}
	public void setSandStoneSI(String sandStoneSI) {
		this.sandStoneSI = sandStoneSI;
	}
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public String getSandStoneOrderStatus() {
		return sandStoneOrderStatus;
	}
	public void setSandStoneOrderStatus(String sandStoneOrderStatus) {
		this.sandStoneOrderStatus = sandStoneOrderStatus;
	}
	public String getCompletionDate() {
		return completionDate;
	}
	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}
	public String getReserved3() {
		return reserved3;
	}
	public void setReserved3(String reserved3) {
		this.reserved3 = reserved3;
	}
	
	public static NS1SBulkOrderVO to1SObject(String line) {
		NS1SBulkOrderVO nsObject=new NS1SBulkOrderVO();
		if(line.length()>24 && (!("H".equals(line.substring(10, 12).trim())) ) ){		
			nsObject.setVersionNumber(getStringValue(line,0, 10));
			nsObject.setServiceType(getStringValue(line,10,12));
			
			nsObject.setOrderType(line.substring(12,13).trim());
			nsObject.setOrganizationId(getStringValue(line,13,21));
			nsObject.setCustomerId(getStringValue(line,21,29));
			nsObject.setProductId(getStringValue(line,29,39));
			nsObject.setBtn(getStringValue(line,39,49));
			nsObject.setWtn(getStringValue(line,49,59));
			nsObject.setTerminalNumber(getStringValue(line,59,63));
			nsObject.setServiceLocationId(getStringValue(line,63,73));
			nsObject.setLoaDate(getStringValue(line,73,81));
			nsObject.setSalesRepId(getStringValue(line,81,91));
			nsObject.setCustomerBatchNumber(getStringValue(line,91,101));
			nsObject.setCustomerOrderNumber(getStringValue(line,101,111));
			nsObject.setCustomerDate(getStringValue(line,111,119));
			nsObject.setCustomerAcctNbr(getStringValue(line,119,129));
			nsObject.setCustomerSalesRep(getStringValue(line,129,139));
			nsObject.setCustomerSalesAgent(getStringValue(line,139,149));
			nsObject.setCustomer1(getStringValue(line,149,169));
			nsObject.setCustomer2(getStringValue(line,169,189));
			nsObject.setCustomer3(getStringValue(line,189,209));
			nsObject.setCustomer4(getStringValue(line,209,229));
			nsObject.setProcessDate(getStringValue(line,229,237));
			nsObject.setReserved1(getStringValue(line,237,239));
			nsObject.setReserved2(getStringValue(line,239,241));
			nsObject.setSandStoneTC(getStringValue(line,241,243));
			nsObject.setSandStoneSI(getStringValue(line,243,245));
			nsObject.setCic(getStringValue(line,245,249));
			nsObject.setSandStoneOrderStatus(getStringValue(line,249,250));
			nsObject.setCompletionDate(getStringValue(line,250,258));
			nsObject.setReserved3(getStringValue(line,258,309)); 
		}
		return nsObject;
	}
	
	private static String getStringValue(String line, int startIndex, int endIndex) {
		if (line.length() < startIndex)
			return "";
		if (line.length() < endIndex)
			return line.substring(startIndex, line.length()).trim();
		return line.substring(startIndex, endIndex).trim();
	}

}
