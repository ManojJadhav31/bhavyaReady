package com.level3.voice.tollfree.manager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.repository.TollFreeDashboardRepository;
import com.level3.voice.tollfree.vo.ActivityChartVO;
import com.level3.voice.tollfree.vo.CICVO;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.OrderChartVO;

/**
 * 
 * @author <a href="mailto:Manjunatha.D@centurylink.com">Manjunatha D</a>
 *
 */
@Component
public class TollFreeDashboardServiceManager {

	private static final Logger logger = Logger.getLogger(TollFreeDashboardServiceManager.class);
	
	@Autowired
	TollFreeDashboardRepository tollFreeDashboardRepository;
	
	public List<OrderChartVO> getOrderChart(String createdBy) {
		
		List orderChartVOs = tollFreeDashboardRepository.getOrderChart(createdBy);
		return orderChartVOs;
	}

	public List<ActivityChartVO> getActivityChart(String createdBy) {
		List activityChartVOs = tollFreeDashboardRepository.getActivityChart(createdBy);
		
		Iterator<Object> objectsItor = activityChartVOs.iterator();
		List<ActivityChartVO> activityChartVOList = new ArrayList<>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			ActivityChartVO activityChartVO = new ActivityChartVO();
			activityChartVO.setYear(String.valueOf(object[0]).trim());
			activityChartVO.setStatus(String.valueOf(object[1].toString()));
			activityChartVO.setNoOfActivities(Long.parseLong(object[2].toString()));
			activityChartVOList.add(activityChartVO);
		}
		return activityChartVOList;
	}

}
