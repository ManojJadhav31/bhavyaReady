package com.level3.voice.tollfree.utils;

/**
 * Enum to capture all the validation
 * scenario with its code and messages
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public enum ValidationCode {

	TNVALID("ANI is valid", "00"),
	TNINFLIGHT("is currently assigned to another pending order.", "01"),
	TNINVALID("format is invalid, Please enter valid 10-digit format.", "02"),
	TNINVALIDNPANXX("Invalid WTN: WTN NOT found in NPA NXX table.", "03"),
	SUBMITSUCCESS("Order has been successfully created with voice order id: ", "04"),
	SUBMITFAILURE("Order submission failure: ", "05"),
	TNINNUMS("is currently assigned in NUMS. ", "06"),
	TNISEMPTY("Tn is Empty , Enter a value","07");

	private String message;
	private String code;

	ValidationCode(String message,String code){
		this.message = message;
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public String getMessageCode() {
		return code;
	}
}
