package com.level3.voice.tollfree.utils;

/**
 * This class contains the list of order action types.
 * @author <a href="mailto:Nnupur.Krishnaa@centurylink.com">Nnupur Krishnaa</a>
 *
 */
public class OrderActionCodes {

	public static final int INSTALL = 1;
	public static final int CHANGE = 2;
	public static final int DISCONNECT = 3;
	public static final int RENEW = 4;
	public static final int QUERY = 5;
	public static final int BLOCK = 6;
	public static final int UNBLOCK = 7;

	public static final String INSTALL_STRING = "Install";
	public static final String CHANGE_STRING = "Change";
	public static final String DISCONNECT_STRING = "Disconnect";
	public static final String RENEW_STRING = "Renew";
	public static final String QUERY_STRING = "Query";
	public static final String BLOCK_STRING = "Block";
	public static final String UNBLOCK_STRING = "Unblock";

	public static final Integer INSTALL_INTEGER = new Integer(INSTALL);
	public static final Integer CHANGE_INTEGER = new Integer(CHANGE);
	public static final Integer DISCONNECT_INTEGER = new Integer(DISCONNECT);
	public static final Integer RENEW_INTEGER = new Integer(RENEW);
	public static final Integer QUERY_INTEGER = new Integer(QUERY);
	public static final Integer BLOCK_INTEGER = new Integer(BLOCK);
	public static final Integer UNBLOCK_INTEGER = new Integer(UNBLOCK);

	public static String getOrderActionCode(int actionCodeInt) {
		String orderActionCode = null;
		switch (actionCodeInt) {
		case INSTALL:
			orderActionCode = INSTALL_STRING;
			break;
		case CHANGE:
			orderActionCode = CHANGE_STRING;
			break;
		case DISCONNECT:
			orderActionCode = DISCONNECT_STRING;
			break;
		case RENEW:
			orderActionCode = RENEW_STRING;
			break;
		case QUERY:
			orderActionCode = QUERY_STRING;
			break;
		case BLOCK:
			orderActionCode = BLOCK_STRING;
			break;
		case UNBLOCK:
			orderActionCode = UNBLOCK_STRING;
			break;
		default:
			break;
		}
		return orderActionCode;
	}

	public static Integer getOrderActionCode(String actionCodeString) {

		if (INSTALL_STRING.equalsIgnoreCase(actionCodeString)) {
			return INSTALL_INTEGER;
		} else if (CHANGE_STRING.equalsIgnoreCase(actionCodeString)) {
			return CHANGE_INTEGER;
		} else if (DISCONNECT_STRING.equalsIgnoreCase(actionCodeString)) {
			return DISCONNECT_INTEGER;
		} else if (RENEW_STRING.equalsIgnoreCase(actionCodeString)) {
			return RENEW_INTEGER;
		} else if (QUERY_STRING.equalsIgnoreCase(actionCodeString)) {
			return QUERY_INTEGER;
		} else if (BLOCK_STRING.equalsIgnoreCase(actionCodeString)) {
			return BLOCK_INTEGER;
		} else if (UNBLOCK_STRING.equalsIgnoreCase(actionCodeString)) {
			return UNBLOCK_INTEGER;
		} else {
			return null;
		}
	}
}
