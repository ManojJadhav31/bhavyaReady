package com.level3.voice.tollfree.bulk.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.batch.item.support.ListItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.level3.voice.common.util.BatchProcessConstants;
import com.level3.voice.tollfree.bulk.batch.processor.BulkOrderExcelTemplateProcessor;
import com.level3.voice.tollfree.bulk.batch.processor.BulkOrderSubmitProcessor;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadItemDTO;
import com.level3.voice.tollfree.bulk.repository.BulkOrderUploadItemRepository;
import com.level3.voice.tollfree.manager.TollFreeOrderServiceManager;
import com.level3.voice.tollfree.vo.OrderVO;
import com.level3.voice.tollfree.vo.ValidationMessageVO;


/**
 * This class is for Bulk order batch upload
 * It has two batch jobs. One job reads excel and writes in the database and other job picks the data from database and submits the order
 * @author <a href="mailto:manjunatha.d@centurylink.com">Manjunatha D</a>
 *
 */
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	private static final Logger log = LoggerFactory.getLogger(BatchConfiguration.class);

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	BulkOrderExcelTemplateProcessor bulkOrderExcelTemplateProcessor;
	
	@Autowired
    EntityManager entityManager;
	
	@Autowired
	BulkOrderUploadItemRepository bulkOrderUploadItemRepository;
	
	@Autowired
	TollFreeOrderServiceManager tollFreeOrderServiceManager;
    
	private static final String BATCH_STATUS_REPROVISION = "REPROV";
	
	@Bean
    @Qualifier("batchJobExecutor")
    public TaskExecutor getBatchJobExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setMaxPoolSize(500);
        executor.setCorePoolSize(100);
        executor.setThreadNamePrefix("T-BatchJob");
        executor.initialize();

        return executor;
    }
    
	/**
	 * This batch job has one step called excelStep1 and listener which triggers the 2nd job of batch order submit job.
	 * @param listener
	 * @param excelStep1
	 * @return
	 */
	@Bean(name = "bulkOrderUploadBatchJob")
	public Job bulkOrderUploadBatchJob(ExcelUploadCompletionNotificationListener listener,Step excelStep1) {
		log.info("==================bulkOrderUploadBatchJob started=================");
		return jobBuilderFactory.get("bulkOrderUploadBatchJob").incrementer(new RunIdIncrementer()).listener(listener).flow(excelStep1)
				.end().build();
	}
	
	/**
	 * This bean gets created and used in bulkOrderUploadBatchJob as excelStep1
	 * @param excelReader
	 * @param excelItemWriter
	 * @param excelProcessor
	 * @return
	 */
	@Bean
	public Step excelStep1(ItemReader<BulkOrderUploadItemDTO> excelReader,
			JpaItemWriter<BulkOrderUploadItemDTO> excelItemWriter,
			ItemProcessor<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO> excelProcessor) {
		return stepBuilderFactory.get("excelStep1").<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO>chunk(500).reader(excelReader)
				.processor(excelProcessor).writer(excelItemWriter).build();
	}
	
	/**
	 * It reads the excel template data given by the file to path "filepath". The contents will be attached to given voiceOrderId
	 * @param filePath
	 * @param voiceOrderId
	 * @return
	 * @throws Exception
	 */
	@Bean
	@StepScope
	ListItemReader<BulkOrderUploadItemDTO> excelReader(@Value("#{jobParameters['FILE_PATH']}") final String filePath
			,@Value("#{jobParameters['VOICE_ORDER_ID']}") final Long voiceOrderId, @Value("#{jobParameters['BULK_ORDER_UPLOAD_ID']}") final String bulkOrderUploadId) 
			throws Exception {
		log.info("Read Started  at "+System.currentTimeMillis()+"Msec for File Path:" + filePath);
		List<BulkOrderUploadItemDTO> aniList = null;

		if(filePath!=null) {
			aniList = bulkOrderExcelTemplateProcessor.readBulkOrderExcelTemplate(filePath, voiceOrderId,bulkOrderUploadId);
			log.info("Read complete. Tn size:"+aniList.size());
			return new ListItemReader<BulkOrderUploadItemDTO>(aniList);
		}
		return null;
	}
	
	/**
	 * It process the excel which got read by the ExcelReader 
	 * @return
	 */
	@Bean
	public ItemProcessor<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO> excelProcessor() {
		return new BulkOrderExcelTemplateProcessor();
	}
	
	/**
	 * This will write the data to the table SUBL_OWNER.BULK_ORDER_UPLOAD_ITEM 
	 * @return
	 */
	@Bean
	@StepScope
	public JpaItemWriter excelItemWriter() {
		log.info("Entered into excelItemWriter ");
		JpaItemWriter<BulkOrderUploadItemDTO> itemWriter = new JpaItemWriter<>();
		
		itemWriter.setEntityManagerFactory(entityManager.getEntityManagerFactory());
		return itemWriter;
	}
	
	/**
	 * This will write the data to the table SUBL_OWNER.BULK_ORDER_UPLOAD_ITEM 
	 * @return
	 */
	@Bean
	@StepScope
	public JpaItemWriter bulkItemWriter() {
		log.info("Entered into bulkItemWriter ");
		JpaItemWriter<BulkOrderUploadItemDTO> itemWriter = new JpaItemWriter<>();
		
		itemWriter.setEntityManagerFactory(entityManager.getEntityManagerFactory());
		return itemWriter;
	}

	/**The batch job which reads from bulkupload tables and submits the order in batch wise 
	 * @param listener
	 * @param bulkOrderSubmitStep1
	 * @return
	 */
	@Bean(name = "bulkOrderSubmitBatchJob")
	public Job bulkOrderSubmitBatchJob(BulkOrderSubmitJobCompletionNotificationListener listener,Step bulkOrderSubmitStep1) {
		log.info("==================bulkOrderSubmitBatchJob started=================");
		return jobBuilderFactory.get("bulkOrderSubmitBatchJob")
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(bulkOrderSubmitStep1)
				.end()
				.build();
	}
	
	/** The batch job which reads from bulkupload tables and submits the order in batch wise. This is the bulkOrderSubmitStep1.
	 * @param reader
	 * @param bulkOrderItemWriter
	 * @param submitProcessor
	 * @return
	 */
	@Bean
	public Step bulkOrderSubmitStep1(ItemReader<BulkOrderUploadItemDTO> reader,
			ListItemWriter<BulkOrderUploadItemDTO> bulkOrderItemWriter,
			ItemProcessor<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO> submitProcessor) {
		return stepBuilderFactory.get("bulkOrderSubmitStep1").<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO>chunk(500).reader(reader)
				.processor(submitProcessor).writer(bulkOrderItemWriter).build();
	}
	
	/**The Bulk Order Submit Processor. It process the each item and creats the orderVo and attach to the BulkOrderUploadItemDTO 
	 * @return
	 */
	@Bean
	public ItemProcessor<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO> submitProcessor() {
		return new BulkOrderSubmitProcessor();
	}
	
	/**Its bulkOrderSubmitStep1 reader. It reads from bulkupload tables
	 * @param voId
	 * @return
	 */
	@Bean
	@StepScope
	ListItemReader<BulkOrderUploadItemDTO> reader(@Value("#{jobParameters['VOICE_ORDER_ID']}") final String voId) {
		log.info("bulkOrderSubmitStep1 Read Started at "+System.currentTimeMillis()+"Msec for voId:"+voId);
		List<BulkOrderUploadItemDTO> allTns = null;
		if(voId!=null) {
			allTns = bulkOrderUploadItemRepository.findByVoId(voId);
			log.info("bulkOrderSubmitStep1 Read complete. Tn size:"+allTns.size());
			
			return new ListItemReader<BulkOrderUploadItemDTO>(allTns);
		}
		return null;
	}
	
	/** It writes the BulkOrderUploadItemDTO and submits the order
	 * @param voiceOrderId
	 * @return
	 */
	@Bean
	@StepScope
	public ListItemWriter<BulkOrderUploadItemDTO> bulkOrderItemWriter(@Value("#{jobParameters['VOICE_ORDER_ID']}") final Long voiceOrderId,
			@Value("#{jobParameters['SUBSCRIBER_ID']}") final Long subscriberId) {
		log.info("Entered into BulkOrderVOItemWriter ");
		
		return new ListItemWriter<BulkOrderUploadItemDTO>() {
			@Override
			public void write(List<? extends BulkOrderUploadItemDTO> items) throws Exception {
				List<OrderVO> orderVOList = new ArrayList<OrderVO>();
				
				for (BulkOrderUploadItemDTO item : items) {
					
					if(item.getStatus().equals(BatchProcessConstants.BATCH_STATUS_RECEIVED) && item.getOrderVO()!=null && item.getOrderVO().isDoSubmit()) {
						try {
							Long count= orderVOList.stream().filter(
									order -> (item.getOrderVO().getActionType().equals(order.getActionType())
											&& item.getOrderVO().getBan().equals(order.getBan())
											&& item.getOrderVO().getProductId().equals(order.getProductId())))
											.collect(Collectors.counting());
							if(count > 0) {
								orderVOList.stream().filter(order -> (item.getOrderVO().getActionType().equals(order.getActionType())
										&& item.getOrderVO().getBan().equals(order.getBan())
										&& item.getOrderVO().getProductId().equals(order.getProductId())))
										.forEach(order-> order.getTnDataVOs().addAll(item.getOrderVO().getTnDataVOs()));
							}
							else {
								orderVOList.add(item.getOrderVO());
							}
							item.setStatus(BatchProcessConstants.BATCH_STATUS_SUCCESS);
							
						}catch(Exception e) {
							e.printStackTrace();
							log.error(e.getMessage());
							item.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
							item.setComments(e.getMessage());
						}
							
					}
					else if(item.getStatus().equals(BatchProcessConstants.BATCH_STATUS_SUCCESS) ) {
						item.setStatus(BatchProcessConstants.BATCH_STATUS_SUCCESS);
						item.setPon(null);
					}
					else {
						item.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						item.setPon(null);
						if(StringUtils.isEmpty(item.getComments())) {
							if(item.getOrderVO()!=null && item.getOrderVO().getValidationMessageVO()!=null) {
								item.setComments(item.getOrderVO().getValidationMessageVO().toString());	
							}else if(item.getOrderVO()!=null && item.getOrderVO().getTnDataVOs()!=null && item.getOrderVO().getTnDataVOs().size()>0) {
								for(ValidationMessageVO val : item.getOrderVO().getTnDataVOs().get(0).getValidationMessageVOs()) {
									item.setComments(item.getComments()!=null?item.getComments():""+val.toString());
								}
							}
						}
					}
				}
				if(orderVOList!=null || orderVOList.size() > 0 ) {
					for(OrderVO orderVO : orderVOList) {
						if(orderVO!=null && orderVO.getTnDataVOs()!=null && orderVO.getTnDataVOs().size()>0) {
							tollFreeOrderServiceManager.submitBulkOrder(orderVO, voiceOrderId,subscriberId);
						}
					}
				}
				bulkOrderUploadItemRepository.save(items);
				bulkOrderUploadItemRepository.flush();
			}
		};
	}
	/**
	 * This batch job has one step called excelStep1 and listener which triggers the 2nd job of batch order submit job.
	 * @param listener
	 * @param excelStep1
	 * @return
	 */
	@Bean(name = "bulkOrderNSUploadBatchJob")
	public Job bulkOrderNSUploadBatchJob(ExcelUploadCompletionNotificationListener listener,Step nsBulkStep1) {
		log.info("==================bulkOrderNSUploadBatchJob started=================");
		return jobBuilderFactory.get("bulkOrderNSUploadBatchJob").incrementer(new RunIdIncrementer()).listener(listener).flow(nsBulkStep1)
				.end().build();
	}
	/**
	 * This bean gets created and used in bulkOrderUploadBatchJob as excelStep1
	 * @param excelReader
	 * @param excelItemWriter
	 * @param excelProcessor
	 * @return
	 */
	@Bean
	public Step nsBulkStep1(ItemReader<BulkOrderUploadItemDTO> nsBulkReader,
			JpaItemWriter<BulkOrderUploadItemDTO> bulkItemWriter,
			ItemProcessor<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO> excelProcessor) {
		return stepBuilderFactory.get("nsBulkStep1").<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO>chunk(500).reader(nsBulkReader)
				.processor(excelProcessor).writer(bulkItemWriter).build();
	}
	
	/**
	 * It reads the excel template data given by the file to path "filepath". The contents will be attached to given voiceOrderId
	 * @param filePath
	 * @param voiceOrderId
	 * @return
	 * @throws Exception
	 */
	@Bean
	@StepScope
	ListItemReader<BulkOrderUploadItemDTO> nsBulkReader(@Value("#{jobParameters['FILE_PATH']}") final String filePath
			,@Value("#{jobParameters['VOICE_ORDER_ID']}") final Long voiceOrderId, @Value("#{jobParameters['BULK_ORDER_UPLOAD_ID']}") final String bulkOrderUploadId) 
			throws Exception {
		log.info("Read Started for File Path:" + filePath);
		List<BulkOrderUploadItemDTO> aniList = null;

		if(filePath!=null) {
			aniList = bulkOrderExcelTemplateProcessor.readBulkOrderNSTemplate(filePath, voiceOrderId,bulkOrderUploadId);
			log.info("Read complete. Tn size:"+aniList.size());
			return new ListItemReader<BulkOrderUploadItemDTO>(aniList);
		}
		return null;
	}
	
}
