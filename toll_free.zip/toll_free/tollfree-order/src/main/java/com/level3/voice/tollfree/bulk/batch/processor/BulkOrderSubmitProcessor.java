package com.level3.voice.tollfree.bulk.batch.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.level3.voice.common.util.BatchProcessConstants;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadItemDTO;
import com.level3.voice.tollfree.client.DataMSClient;
import com.level3.voice.tollfree.manager.TollFreeOrderServiceManager;
import com.level3.voice.tollfree.vo.BanServiceLocationVO;
import com.level3.voice.tollfree.vo.CodeTableVO;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.FeaturesVO;
import com.level3.voice.tollfree.vo.OrderVO;
import com.level3.voice.tollfree.vo.TNDataVO;
import com.level3.voice.tollfree.vo.ValidatedCustomAcctCodeVO;
import com.level3.voice.tollfree.vo.ValidationMessageVO;

/**
 * This class is for bulk order submit processor
 * 
 * @author <a href="mailto:manjunatha.d@centurylink.com">Manju (ab68221)</a>
 *
 */
public class BulkOrderSubmitProcessor implements ItemProcessor<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO> {

	private static final Logger log = LoggerFactory.getLogger(BulkOrderSubmitProcessor.class);

	@Autowired
	DataMSClient dataMSClient;

	@Value("#{'${list.of.features}'.split(',')}")
	private List<String> featuresGroup;

	@Autowired
	TollFreeOrderServiceManager tollFreeOrderServiceManager;

	@Override
	public BulkOrderUploadItemDTO process(BulkOrderUploadItemDTO itemDTO) {
		CustomerVO customerVO;
		try {
			if ((BatchProcessConstants.BATCH_STATUS_RECEIVED).equals(itemDTO.getStatus())) {
				OrderVO orderVO = new OrderVO();
				orderVO.setProductId(itemDTO.getBulkOrderUploadDTO().getProduct());
				orderVO.setBan(itemDTO.getBulkOrderUploadDTO().getBan());
				orderVO.setCustomerID(itemDTO.getBulkOrderUploadDTO().getCustomerId());
				orderVO.setActionType(itemDTO.getBulkOrderUploadDTO().getOrderType());

				orderVO.setOrderType("1S");
				orderVO.setOrgId("WCG");
				if ("BULK".equals(itemDTO.getBulkOrderUploadDTO().getFileType()))
					orderVO.setOrderSourceId(19);
				else
					orderVO.setOrderSourceId(8); // 8-Bulkload - Batch [from order_source table]

				customerVO = dataMSClient.retrieveCustomerInfo(orderVO.getOrgId(), orderVO.getCustomerID());
				if (customerVO != null) {
					orderVO.setCustomerName(customerVO.getCustomerName());
					orderVO.setBusOrgId(customerVO.getCustomerBizOrgId());
				}

				CustomerVO customerVOBan = dataMSClient.serviceLocationByBan(orderVO.getOrgId(),
						orderVO.getCustomerID(), orderVO.getBan());
				if (customerVOBan != null && customerVOBan.getBanServiceLocationVOs() != null
						&& customerVOBan.getBanServiceLocationVOs().size() > 0) {
					String serviceLocationId = null;
					for(BanServiceLocationVO banServiceLocationVO :customerVOBan.getBanServiceLocationVOs()) {
						if(banServiceLocationVO.getAccountNumber()!=null && banServiceLocationVO.getAccountNumber().equals(orderVO.getBan())) {
							serviceLocationId = banServiceLocationVO.getServiceLocationId();
							break;
						}
					}
					orderVO.setServiceLocationId(serviceLocationId);
				}

				TNDataVO tnDataVO = new TNDataVO();
				List<TNDataVO> tnDataVOs = new ArrayList<>();

				tnDataVO.setBtn(itemDTO.getBtn());
				tnDataVO.setCic(itemDTO.getCic());
				tnDataVO.setCrc(itemDTO.getCrc());
				tnDataVO.setPon(itemDTO.getPon());
				if (!StringUtils.isEmpty(itemDTO.getFeatureId())) {
					tnDataVO.setFeatures(getFeaturesFromIds(itemDTO.getFeatureId(), itemDTO.getIsMandatoryFeature()));
				}

				tnDataVO.setForceAniLoad(itemDTO.getForceAniLoad());
				tnDataVO.setJurisdiction(itemDTO.getJurisdiction());
				tnDataVO.setPic(itemDTO.getPic());

				if (!StringUtils.isEmpty(itemDTO.getCodeDigit()) && !StringUtils.isEmpty(itemDTO.getCodeTable())) {
					if (!StringUtils.isEmpty(itemDTO.getFeatureId()) && itemDTO.getFeatureId().contains("622")) {
						ValidatedCustomAcctCodeVO validatedCustomAcctCodeVO = new ValidatedCustomAcctCodeVO();
						validatedCustomAcctCodeVO.setCodeDigits(itemDTO.getCodeDigit());
						validatedCustomAcctCodeVO.setCodeTableName(itemDTO.getCodeTable());
						CustomerVO customerTableVO = dataMSClient.fetchCodeTabList("WCG",
								itemDTO.getBulkOrderUploadDTO().getCustomerId());
						if (customerTableVO.getCodeTableVOs() != null && !customerTableVO.getCodeTableVOs().isEmpty()) {
							List<CodeTableVO> codeTable = customerTableVO.getCodeTableVOs().stream()
									.filter(item -> item.getCodeTableName().equals(itemDTO.getCodeTable()))
									.collect(Collectors.toList());
							if (codeTable.size() > 0)
								validatedCustomAcctCodeVO.setCodeTableId(codeTable.get(0).getCodeTableId());
						}
						tnDataVO.setValidatedCustomAcctCodeVO(validatedCustomAcctCodeVO);
					} else {
						itemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						itemDTO.setComments(getErrorMessageInValidationMessageVO(
								"Validated custom account code feature is missing"));
						log.info("Validated custom account code feature is missing");
					}
				}
				if (!StringUtils.isEmpty(itemDTO.getFeatureId()) && itemDTO.getFeatureId().contains("622")) {
					if (StringUtils.isEmpty(itemDTO.getCodeDigit()) || StringUtils.isEmpty(itemDTO.getCodeTable())) {
						itemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						itemDTO.setComments(
								getErrorMessageInValidationMessageVO("Code digit and code table is missing."));
						log.info("Code digit and code table is missing.");
					}
				}
				tnDataVO.setWtn(itemDTO.getWtn());

				List<ValidationMessageVO> validationMessageVOs = tollFreeOrderServiceManager.validateTNData(tnDataVO,
						orderVO);
				if (validationMessageVOs != null && !validationMessageVOs.isEmpty()) {
					tnDataVO.setValidationMessageVOs(validationMessageVOs);
					orderVO.setDoSubmit(false);
					tnDataVO.setPon(null);
				}

				tnDataVOs.add(tnDataVO);

				orderVO.setTnDataVOs(tnDataVOs);
				orderVO.setUserName(itemDTO.getBulkOrderUploadDTO().getCreatedBy());

				itemDTO.setOrderVO(orderVO);
			}

		} catch (Exception e) {
			itemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			itemDTO.setComments(
					"Exception in row, please verify the row data. Also verify if the tf-data/tf-nums services are up");
			log.error("Exception in row, please verify the row data. Also verify if the tf-data/tf-nums services are up"
					+ e);
			e.printStackTrace();
		}

		return itemDTO;
	}

	/**
	 * It takes the featureIds and creates the List<FeaturesVO>
	 * 
	 * @param featureIds
	 * @return
	 */
	private List<FeaturesVO> getFeaturesFromIds(String featureIds, String isMandatoryFeature) {
		List<FeaturesVO> featureList = new ArrayList<>();
		Map<String, String> featureDetails = getFeatureDetails();
		if (featureIds.indexOf(",") > 1) {
			String[] featureData = featureIds.split(",");
			for (String f : featureData) {
				FeaturesVO featuresVO = new FeaturesVO();
				featuresVO.setFeatureDescription(featureDetails.get(f));
				featuresVO.setFeatureOfferingId(f);
				featuresVO.setAccountCodeESF(getAccountCodeEsf(f, isMandatoryFeature));
				featureList.add(featuresVO);

			}
		} else {
			FeaturesVO featuresVO = new FeaturesVO();
			featuresVO.setFeatureDescription(featureDetails.get(featureIds));
			featuresVO.setFeatureOfferingId(featureIds);
			featuresVO.setAccountCodeESF(getAccountCodeEsf(featureIds, isMandatoryFeature));
			featureList.add(featuresVO);
			
		}
		return featureList;
	}
	
	/**
	 * It takes the featureId and mandatory flag to create the accountCodeEFS Flag
	 * 
	 * @param featureIds
	 * @param isMandatoryFeature
	 * @return
	 */
	private String getAccountCodeEsf(String featureId, String isMandatoryFeature) {
		String esfFlag = null;
		if (getFeatureDetails().get(featureId).contains("Unvalidated Acct Codes")) {
			if ("Y".equals(isMandatoryFeature))
				esfFlag = "U";
			else if ("N".equals(isMandatoryFeature))
				esfFlag = "N";
		}
		if (getFeatureDetails().get(featureId).contains("Validated Custom")) {
			if ("Y".equals(isMandatoryFeature))
				esfFlag = "C";
			else if ("N".equals(isMandatoryFeature))
				esfFlag = "Y";
		}
		return esfFlag;
	}

	/**
	 * It reads the features from property file and creates the Map<String, String>
	 * (featureId and description)
	 * 
	 * @return
	 */
	private Map<String, String> getFeatureDetails() {
		Map<String, String> featureDetails = new HashMap<String, String>();

		for (String featureGroup : featuresGroup) {
			String[] features = featureGroup.split(":");
			featureDetails.put(features[0], features[1]);
		}

		return featureDetails;
	}
	
	private String getErrorMessageInValidationMessageVO(String message) {
		ValidationMessageVO validationMessageVO = new ValidationMessageVO();
		validationMessageVO.setCode("08");
		validationMessageVO.setDisplayMessage(message);
		return validationMessageVO.toString();
	}
}
