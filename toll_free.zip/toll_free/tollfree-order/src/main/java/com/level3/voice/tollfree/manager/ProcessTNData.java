package com.level3.voice.tollfree.manager;

import java.util.Date;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.persist.dto.AddressDTO;
import com.level3.voice.persist.dto.ProductDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.SubscriberDTO;
import com.level3.voice.persist.dto.TnOrderDTO;
import com.level3.voice.persist.repository.ProductRepository;
import com.level3.voice.persist.repository.SubscriberLineRepository;
import com.level3.voice.persist.repository.SubscriberRepository;
import com.level3.voice.tollfree.assembler.OrderSubmissionAssembler;
import com.level3.voice.tollfree.persist.dto.TollFreeSubsciberLineDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.vo.OrderVO;
import com.level3.voice.tollfree.vo.TNDataVO;

/**
 * @author ab68221
 *
 */
@Component
public class ProcessTNData {

	@Autowired
	OrderSubmissionAssembler orderSubmissionAssembler;
	
	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;	
	
	@Autowired
	SubscriberRepository subscriberRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	SubscriberLineRepository subscriberLineRepository;

	private static final Logger logger = Logger.getLogger(ProcessTNData.class);
			
	/**
	 * This method is to process all the TNData and create subscriber line, tn order
	 * entry order tollfree features, order features, order dir listing and order
	 * E911 Features and then trigger the workflow for those TNs
	 * 
	 * @param orderVO
	 * @param sysdate
	 * @param ponInfo
	 * @param inHouseBizOrgId 
	 * @param long1
	 * @param address
	 * @param integer 
	 * @param isPonSentByBulk
	 * @throws Exception
	 */
	@Transactional
	public void process(OrderVO orderVO, TNDataVO gVO, Map<String, Long> ponInfo, Date sysdate, Long voiceOrderId,
			Long subscriberId, Integer productId, String inHouseBizOrgId) throws Exception {
		long startTime = System.currentTimeMillis();
		final SubscriberDTO sub = subscriberRepository.findOne(subscriberId);
		final ProductDTO prod = productRepository.getOne(new Integer(productId));
		AddressDTO address = orderSubmissionAssembler.assembleAddress(orderVO);
		/*SubscriberLineDTO subscriberLineDTO = orderSubmissionAssembler.assembleSubscriberLine(orderVO, gVO, sysdate,
				sub, prod, address);*/
		TollFreeSubsciberLineDTO tollFreeSubsciberLineDTO = orderSubmissionAssembler.assembleTollfreeSubscriberLine(orderVO, gVO, sysdate,
				sub, prod, address);
		
		/*TnOrderDTO tnOrder = orderSubmissionAssembler.assembleTNOrder(orderVO, sysdate, ponInfo, sub,
				prod, tollFreeSubsciberLineDTO, subscriberLineDTO, address, voiceOrderId,gVO);*/
		
		TnOrderDTO tnOrder = orderSubmissionAssembler.assembleTNOrder(orderVO, sysdate, ponInfo, sub,
				prod, tollFreeSubsciberLineDTO, address, voiceOrderId,gVO,inHouseBizOrgId);

		SlOrderDTO slOrder = tnOrder.getSlOrder();
		updateSlOrderVersion(slOrder, gVO.getWtn(), orderVO.getCustomerID());

		orderSubmissionAssembler.assembleOrderTollFreeFeatures(orderVO, gVO, sysdate, slOrder);
		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @processTNData took " + (endTime - startTime)
				+ " milliseconds for VOID: " + voiceOrderId + "TN: " + gVO.getWtn());
	}
	
	/**
	 * Retrieve Count of version for the TN and for a customer id
	 * 
	 * @param slOrder
	 * @param tn
	 * @param customerID
	 * @return
	 */
	private void updateSlOrderVersion(SlOrderDTO slOrder, String tn, String customerID) {
		int currentVersionCount = orderTollFreeFeatureRepository.getVersionCount(tn, customerID);
		slOrder.setOrderVersion(currentVersionCount + 1);
	}
}
