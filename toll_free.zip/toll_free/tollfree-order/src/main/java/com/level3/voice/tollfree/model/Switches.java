package com.level3.voice.tollfree.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Model object to represent the switches object sent from PRO
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class Switches implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<Switch> switches;

	/**
	 * @return the switches
	 */
	public List<Switch> getSwitches() {
		return switches;
	}

	/**
	 * @param switches the switches to set
	 */
	public void setSwitches(List<Switch> switches) {
		this.switches = switches;
	}
	
	/**
	 * @param switches the switches to set
	 */
	public void addSwitches(List<Switch> switches) {
		if(this.switches == null) {
			this.switches = new ArrayList<>();	
		}
		this.switches.addAll(switches);
	}

}
