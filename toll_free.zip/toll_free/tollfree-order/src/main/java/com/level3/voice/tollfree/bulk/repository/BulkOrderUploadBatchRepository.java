package com.level3.voice.tollfree.bulk.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadBatchDTO;

/**
 * This repository is Bulk Batch table
 * 
 * @author <a href="mailto:Arun2.kumar@centurylink.com">Arun Kumar</a>
 */
@Component
public interface BulkOrderUploadBatchRepository extends JpaRepository<BulkOrderUploadBatchDTO, Long> {
	
}
