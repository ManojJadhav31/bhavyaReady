package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class ValidateTNRequestVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String tn;
	private String actionType;
	private String customerId;
	private boolean validateInflightTN;

	public String getTn() {
		return tn;
	}

	public void setTn(String tn) {
		this.tn = tn;
	}

	public boolean isValidateInflightTN() {
		return validateInflightTN;
	}

	public void setValidateInflightTN(boolean validateInflightTN) {
		this.validateInflightTN = validateInflightTN;
	}

	/**
	 * @return the actionType
	 */
	public String getActionType() {
		return actionType;
	}

	/**
	 * @param actionType
	 *            the actionType to set
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
}
