package com.level3.voice.tollfree.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.manager.LandingDataServiceManager;
import com.level3.voice.tollfree.persist.dto.TNDataDTO;
import com.level3.voice.tollfree.persist.vo.LandingScreenSearchVO;
import com.level3.voice.tollfree.persist.vo.SearchScreenInputVO;
import com.level3.voice.tollfree.vo.OrderVO;

/**
 * 
 * @author <a href="mailto:Nnupur.Krishna@centurylink.com">Nnupur.Krishna</a>
 *
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/Voice/order")
public class LandingDataService {

	private static final Logger logger = Logger.getLogger(LandingDataService.class);

	@Autowired
	private LandingDataServiceManager landingDataServiceManager;

	@RequestMapping(path = "/VoiceData", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, consumes = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<LandingScreenSearchVO> getVoiceData(@RequestBody SearchScreenInputVO landingScreenReqParams) {
		List<LandingScreenSearchVO> landingScreenDTOs = null;
		if (landingScreenReqParams != null && StringUtils.isEmpty(landingScreenReqParams.getVoiceOrderId())
				&& StringUtils.isEmpty(landingScreenReqParams.getTn())
				&& StringUtils.isEmpty(landingScreenReqParams.getCustomerId())) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid search request. Please select at-least one of the required fields");
			throw new ServiceException(l3Response);
		}

		try {
			landingScreenDTOs = landingDataServiceManager.getDataForLandingScreen(landingScreenReqParams);
		} catch (Exception e) {
			logger.error("@getTNs: Exception processing getTNs", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		return landingScreenDTOs;
	}

	@RequestMapping(path = "/TnData/{voiceOrderId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<TNDataDTO> getTNs(@PathVariable String voiceOrderId) {
		List<TNDataDTO> tnDataDTOs = null;
		try {
			tnDataDTOs = landingDataServiceManager.getTNs(voiceOrderId);
		} catch (Exception e) {
			logger.error("@getTNs: Exception processing getTNs", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		return tnDataDTOs;
	}

	@RequestMapping(path = "/OrderTnData/{voiceOrderId}/{tn}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public OrderVO getOrderTnData(@PathVariable String voiceOrderId, @PathVariable String tn) {
		OrderVO orderVOs = null;
		try {
			orderVOs = landingDataServiceManager.getOrderTnData(voiceOrderId, tn);
		} catch (Exception e) {
			logger.error("@getTNs: Exception processing getTNs", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		return orderVOs;
	}

}
