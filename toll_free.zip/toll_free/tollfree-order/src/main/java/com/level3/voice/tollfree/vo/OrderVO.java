package com.level3.voice.tollfree.vo;

import java.io.Serializable;
import java.util.List;

import com.level3.voice.tollfree.utils.OrderActionCodes;

public class OrderVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String customerID;
	private String customerName;
	private String ban;
	private String serviceId;
	private String billingAccNum;
	private String serviceLocationId;
	private String productId;
	private String orderDate;
	private String orgId;
	private String busOrgId;
	private String orderType;
	private String controlGroupId;
	private String ratePlanId;
	private String crc;
	private String scid;
	private String actionType;
	private String userName;
	private Integer orderSourceId;
	private boolean doSubmit = true;
	private ValidationMessageVO validationMessageVO;
	private List<TNDataVO> tnDataVOs;

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getBan() {
		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getBillingAccNum() {
		return billingAccNum;
	}

	public void setBillingAccNum(String billingAccNum) {
		this.billingAccNum = billingAccNum;
	}

	public String getServiceLocationId() {
		return serviceLocationId;
	}

	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getBusOrgId() {
		return busOrgId;
	}

	public void setBusOrgId(String busOrgId) {
		this.busOrgId = busOrgId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getControlGroupId() {
		return controlGroupId;
	}

	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}

	public String getRatePlanId() {
		return ratePlanId;
	}

	public void setRatePlanId(String ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public String getCrc() {
		return crc;
	}

	public void setCrc(String crc) {
		this.crc = crc;
	}

	public String getScid() {
		return scid;
	}

	public void setScid(String scid) {
		this.scid = scid;
	}

	public ValidationMessageVO getValidationMessageVO() {
		return validationMessageVO;
	}

	public void setValidationMessageVO(ValidationMessageVO validationMessageVO) {
		this.validationMessageVO = validationMessageVO;
	}

	public List<TNDataVO> getTnDataVOs() {
		return tnDataVOs;
	}

	public void setTnDataVOs(List<TNDataVO> tnDataVOs) {
		this.tnDataVOs = tnDataVOs;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public boolean isInstallFlow() {
		return OrderActionCodes.INSTALL_STRING.equalsIgnoreCase(this.actionType);
	}
	
	public boolean isBlockFlow() {
		return OrderActionCodes.BLOCK_STRING.equalsIgnoreCase(this.actionType);
	}
	
	public boolean isUnblockFlow() {
		return OrderActionCodes.UNBLOCK_STRING.equalsIgnoreCase(this.actionType);
	}
	
	public boolean isChangeFlow() {
		return OrderActionCodes.CHANGE_STRING.equalsIgnoreCase(this.actionType);
	}
	
	public boolean isDisconnectFlow() {
		return OrderActionCodes.DISCONNECT_STRING.equalsIgnoreCase(this.actionType);
	}

	public boolean isDoSubmit() {
		return doSubmit;
	}

	public void setDoSubmit(boolean doSubmit) {
		this.doSubmit = doSubmit;
	}

	public Integer getOrderSourceId() {
		return orderSourceId;
	}

	public void setOrderSourceId(Integer orderSourceId) {
		this.orderSourceId = orderSourceId;
	}
	
}
