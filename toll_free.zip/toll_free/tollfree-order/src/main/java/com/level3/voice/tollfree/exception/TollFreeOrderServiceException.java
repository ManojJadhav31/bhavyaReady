package com.level3.voice.tollfree.exception;

import com.level3.voice.common.exception.SLDBException;

/**
 * This class is to create a custom exception which can be thrown for
 * few specific cases 
 * @author 
 * <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class TollFreeOrderServiceException extends SLDBException {
    private static final long serialVersionUID = 1L;

    /**
     * 
     */
    public TollFreeOrderServiceException() {
        super();
      }
    
    /**
     * @param anErrorCode
     */
    public TollFreeOrderServiceException(int anErrorCode) {
      super(anErrorCode);
    }
    
    /**
     * @param aMsg
     */
    public TollFreeOrderServiceException(String aMsg) {
      super(aMsg);
    }
    
    /**
     * @param aMsg
     * @param anErrorCode
     */
    public TollFreeOrderServiceException(String aMsg, int anErrorCode) {
      super(aMsg, anErrorCode);
    }

}
