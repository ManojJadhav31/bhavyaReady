package com.level3.voice.tollfree.vo;

public class ServiceLocationByCustIdVO {
	private String serviceLocationID;
	private String status;
	private String wtn;
	private String btn;
	private String serviceBeginDate;
	private String intraLataFirstUsage;
	private String intraLataLastUsage;
	private String interLatafirstUsage;
	private String interLataLastUsage;
	private String serviceEndDate;
	
	
	public String getServiceLocationID() {
		return serviceLocationID;
	}
	public void setServiceLocationID(String serviceLocationID) {
		this.serviceLocationID = serviceLocationID;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getWtn() {
		return wtn;
	}
	public void setWtn(String wtn) {
		this.wtn = wtn;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public String getServiceBeginDate() {
		return serviceBeginDate;
	}
	public void setServiceBeginDate(String serviceBeginDate) {
		this.serviceBeginDate = serviceBeginDate;
	}
	public String getIntraLataFirstUsage() {
		return intraLataFirstUsage;
	}
	public void setIntraLataFirstUsage(String intraLataFirstUsage) {
		this.intraLataFirstUsage = intraLataFirstUsage;
	}
	public String getIntraLataLastUsage() {
		return intraLataLastUsage;
	}
	public void setIntraLataLastUsage(String intraLataLastUsage) {
		this.intraLataLastUsage = intraLataLastUsage;
	}
	public String getInterLatafirstUsage() {
		return interLatafirstUsage;
	}
	public void setInterLatafirstUsage(String interLatafirstUsage) {
		this.interLatafirstUsage = interLatafirstUsage;
	}
	public String getInterLataLastUsage() {
		return interLataLastUsage;
	}
	public void setInterLataLastUsage(String interLataLastUsage) {
		this.interLataLastUsage = interLataLastUsage;
	}
	public String getServiceEndDate() {
		return serviceEndDate;
	}
	public void setServiceEndDate(String serviceEndDate) {
		this.serviceEndDate = serviceEndDate;
	}
	
	
	

}
