package com.level3.voice.tollfree.assembler;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.NetworkConstants;
import com.level3.voice.common.util.OrderConstants;
import com.level3.voice.common.util.OrderStatusConstants;
import com.level3.voice.persist.dto.ActionTypeDTO;
import com.level3.voice.persist.dto.AddressDTO;
import com.level3.voice.persist.dto.DirListTypeDTO;
import com.level3.voice.persist.dto.OrderDirListFeatureDTO;
import com.level3.voice.persist.dto.OrderE911FeatureDTO;
import com.level3.voice.persist.dto.OrderFeatureDTO;
import com.level3.voice.persist.dto.OrderTypeDTO;
import com.level3.voice.persist.dto.ProductDTO;
import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.dto.SubscriberDTO;
import com.level3.voice.persist.dto.TnOrderDTO;
import com.level3.voice.persist.dto.VoiceOrderDTO;
import com.level3.voice.persist.repository.ActionTypeRepository;
import com.level3.voice.persist.repository.AddressRepository;
import com.level3.voice.persist.repository.OrderDirListFeatureRepository;
import com.level3.voice.persist.repository.OrderE911FeatureRepository;
import com.level3.voice.persist.repository.OrderFeatureRepository;
import com.level3.voice.persist.repository.OrderStatusRepository;
import com.level3.voice.persist.repository.OrderTypeRepository;
import com.level3.voice.persist.repository.ProductRepository;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.SubscriberLineRepository;
import com.level3.voice.persist.repository.SubscriberRepository;
import com.level3.voice.persist.repository.TnOrderRepository;
import com.level3.voice.persist.repository.VoiceOrderRepository;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadDTO;
import com.level3.voice.tollfree.client.DataMSClient;
import com.level3.voice.tollfree.client.PipeLineServiceIdClient;
import com.level3.voice.tollfree.client.TaiClient;
import com.level3.voice.tollfree.constants.TollFreeOrderConstants;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.dto.ServiceAddressDTO;
import com.level3.voice.tollfree.persist.dto.TollFreeSubsciberLineDTO;
import com.level3.voice.tollfree.persist.repository.LECProvisionerRepository;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.tollfree.persist.repository.XMasterSubOcnRepository;
import com.level3.voice.tollfree.utils.OrderActionCodes;
import com.level3.voice.tollfree.utils.TollFreeOrderServiceUtils;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.FeaturesVO;
import com.level3.voice.tollfree.vo.OrderAdditionalDetailsVO;
import com.level3.voice.tollfree.vo.OrderVO;
import com.level3.voice.tollfree.vo.TNDataVO;
import com.level3.voice.tollfree.vo.ValidatedCustomAcctCodeVO;

/**
 * Assembler to assemble the DTO objects from the VO objects during order
 * submission flow
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class OrderSubmissionAssembler {

	@Autowired
	VoiceOrderRepository voiceOrderRepository;
	@Autowired
	OrderStatusRepository orderStatusRepository;
	@Autowired
	OrderTypeRepository orderTypeRepository;
	@Autowired
	SubscriberRepository subscriberRepository;
	@Autowired
	DataMSClient dataMSClient;
	@Autowired
	ProductRepository productRepository;
	@Autowired
	AddressRepository addressRepository;
	@Autowired
	SubscriberLineRepository subscriberLineRepository;
	@Autowired
	ActionTypeRepository actionTypeRepository;
	@Autowired
	PipeLineServiceIdClient pipeLineClient;
	@Autowired
	TnOrderRepository tnOrderRepository;
	@Autowired
	SlOrderRepository slOrderRepository;
	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;
	@Autowired
	OrderE911FeatureRepository orderE911FeatureRepository;
	@Autowired
	OrderFeatureRepository orderFeatureRepository;
	@Autowired
	OrderDirListFeatureRepository orderDirListFeatureRepository;
	@Autowired
	TollFreeOrderServiceUtils tollFreeOrderServiceUtils;
	@Autowired
	TaiClient taiClient;
	@Autowired
	LECProvisionerRepository lecProvisionerRepository;
	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;
	@Autowired
	XMasterSubOcnRepository xMasterSubOcnRepository;


	private static final Logger logger = Logger.getLogger(OrderSubmissionAssembler.class);

	/**
	 * Create Voice Order data for the order submitted
	 * 
	 * @param orderVO
	 * @param voiceOrderId
	 */
	public void assembleVoiceOrder(OrderVO orderVO, Long voiceOrderId) {
		VoiceOrderDTO voiceOrderDTO = new VoiceOrderDTO();
		voiceOrderDTO.setVoiceOrderId(voiceOrderId);
		voiceOrderDTO.setOrderStatus(orderStatusRepository.findByName("Created"));
		voiceOrderDTO.setRequestedTnQty(null);
		voiceOrderDTO.setRelatedServiceId(orderVO.getProductId());
		voiceOrderDTO.setRelatedServiceType(orderVO.getOrderType());
		voiceOrderDTO.setByobYn("N");
		voiceOrderDTO.setUpdateBy(getUserName(orderVO));
		voiceOrderDTO.setUpdateDate(new Date());
		voiceOrderDTO.setCreateBy(getUserName(orderVO));
		voiceOrderDTO.setCreateDate(new Date());
		voiceOrderDTO.setCustomerRequestDate(new Date());
		voiceOrderDTO.setCustomerName(orderVO.getCustomerName());
		voiceOrderDTO.setCustomerNumber(orderVO.getCustomerID());
		voiceOrderDTO.setLnpYn("N");
		// TODO Customer Requested Date - CRD - what value?
		// voiceOrderDTO.setCustomerRequestDate(new Date());
		voiceOrderDTO.setExtProductId(getProductId(orderVO));
		voiceOrderDTO.setIsBackorderYn(OrderConstants.BACKORDER_N);
		voiceOrderDTO.setProjectYn("N");
		voiceOrderDTO.setDraftYn("N");
		voiceOrderDTO.setRequest("NA");

		OrderTypeDTO orderTypeDto = orderTypeRepository.findOne(1);
		voiceOrderDTO.setOrderType(orderTypeDto);

		voiceOrderDTO.setActionType(getActionTypeId(orderVO));

		voiceOrderDTO.setSwitchType(NetworkConstants.SWITCH_SONUS);

		voiceOrderRepository.saveAndFlush(voiceOrderDTO);
	}

	public void saveVoiceOrder(OrderVO orderVO, Long voiceOrderId) {
		VoiceOrderDTO voiceOrderDTO = new VoiceOrderDTO();
		voiceOrderDTO.setVoiceOrderId(voiceOrderId);
		voiceOrderDTO.setOrderStatus(orderStatusRepository.findByName("Created"));
		voiceOrderDTO.setRequestedTnQty(null);
		voiceOrderDTO.setRelatedServiceId(orderVO.getProductId());
		voiceOrderDTO.setRelatedServiceType(orderVO.getOrderType());
		voiceOrderDTO.setByobYn("N");
		voiceOrderDTO.setUpdateBy(getUserName(orderVO));
		voiceOrderDTO.setUpdateDate(new Date());
		voiceOrderDTO.setCreateBy(getUserName(orderVO));
		voiceOrderDTO.setCreateDate(new Date());
		voiceOrderDTO.setCustomerRequestDate(new Date());
		voiceOrderDTO.setCustomerName(orderVO.getCustomerName());
		voiceOrderDTO.setCustomerNumber(orderVO.getCustomerID());
		voiceOrderDTO.setLnpYn("N");
		// TODO Customer Requested Date - CRD - what value?
		// voiceOrderDTO.setCustomerRequestDate(new Date());
		voiceOrderDTO.setExtProductId(getProductId(orderVO));
		voiceOrderDTO.setIsBackorderYn(OrderConstants.BACKORDER_N);
		voiceOrderDTO.setProjectYn("N");
		voiceOrderDTO.setDraftYn("N");
		voiceOrderDTO.setRequest("NA");

		OrderTypeDTO orderTypeDto = orderTypeRepository.findOne(1);
		voiceOrderDTO.setOrderType(orderTypeDto);

		voiceOrderDTO.setActionType(getActionTypeId(orderVO));

		voiceOrderDTO.setSwitchType(NetworkConstants.SWITCH_SONUS);

		voiceOrderRepository.save(voiceOrderDTO);
	}

	/**
	 * Get product ID for the external product id mapping
	 * 
	 * @param orderVO
	 * @return
	 */
	private String getProductId(OrderVO orderVO) {
		if ("1S".equalsIgnoreCase(orderVO.getOrderType())) {
			return "BM22";
		}
		return null;
	}

	/**
	 * Need to create Subscriber but with which data hardcoding the same for now
	 * Need to populate once this UI is integrated with MOAB screen where user name
	 * would be available
	 * 
	 * @param orderVO
	 * @param sysdate
	 * @return
	 */
	public SubscriberDTO assembleSubscriber(OrderVO orderVO, Date sysdate) {
		SubscriberDTO subscriber = new SubscriberDTO();
		subscriber.setBusinessName(orderVO.getCustomerName());
		subscriber.setLastUpdatedUser(getUserName(orderVO));
		subscriber.setCustTypeInd("B");
		subscriber.setLastUpdated(sysdate);
		subscriberRepository.saveAndFlush(subscriber);
		return subscriber;
	}

	/**
	 * This is for bulk save and need to create Subscriber but with which data
	 * hardcoding the same for now Need to populate once this UI is integrated with
	 * MOAB screen where user name would be available
	 * 
	 * @param bulkOrderUploadDTO
	 * @param sysdate
	 * @return
	 * @throws SLDBException
	 */
	public SubscriberDTO assembleSubscriber(BulkOrderUploadDTO bulkOrderUploadDTO, Date sysdate) throws SLDBException {
		SubscriberDTO subscriber = null;

		CustomerVO customerVO = dataMSClient.retrieveCustomerInfo("WCG", bulkOrderUploadDTO.getCustomerId());
		if (customerVO != null) {
			subscriber = new SubscriberDTO();
			subscriber.setBusinessName(customerVO.getCustomerName());
			subscriber.setLastUpdatedUser("TEST");
			subscriber.setCustTypeInd("B");
			subscriber.setLastUpdated(sysdate);
			subscriberRepository.saveAndFlush(subscriber);
		}
		return subscriber;
	}

	/**
	 * Create Address for the service location id which user has selected. For this
	 * we need to call the data microservice to retrieve the location details and
	 * persist the same in address table
	 * 
	 * @param orderVO
	 * @return
	 * @throws SLDBException
	 */
	public AddressDTO assembleAddress(OrderVO orderVO) throws SLDBException {
		// AddressDTO address = stubAddress();
		ServiceAddressDTO serviceAddressDTO = dataMSClient.retrieveServiceLocation(orderVO.getOrgId(),
				orderVO.getCustomerID(), orderVO.getServiceLocationId());
		AddressDTO address = createAddressDTO(serviceAddressDTO);
		addressRepository.saveAndFlush(address);
		return address;
	}

	/**
	 * Method to assemble the addressDTO object using the response data
	 * 
	 * @param serviceAddressDTO
	 * @return
	 */
	private AddressDTO createAddressDTO(ServiceAddressDTO serviceAddressDTO) {
		AddressDTO address = new AddressDTO();

		address.setStreetName(serviceAddressDTO.getAddress1());
		address.setStreetNameAddition(serviceAddressDTO.getAddress2());
		address.setCity(serviceAddressDTO.getAddress3());
		address.setStateProv(serviceAddressDTO.getAddress4());
		setZipDetails(serviceAddressDTO, address);
		address.setOverrideYn("Y");
		return address;
	}

	/**
	 * Retrieving and setting ZIP and ZIP4 details on to AddressDTO
	 * 
	 * @param serviceAddressDTO
	 * @param address
	 */
	private void setZipDetails(ServiceAddressDTO serviceAddressDTO, AddressDTO address) {
		String zipCodeDetail = serviceAddressDTO.getAddress5();
		if (zipCodeDetail == null)
			return;

		if (zipCodeDetail.indexOf("-") > -1) {
			address.setZip(zipCodeDetail.substring(0, zipCodeDetail.indexOf("-")));
			address.setZip4(zipCodeDetail.substring(zipCodeDetail.indexOf("-") + 1));
		} else {
			address.setZip(zipCodeDetail);
		}
	}

	/**
	 * Retrieve the product using the product id sent from the UI if not present
	 * then create a productDTO with that product id
	 * 
	 * @param orderVO
	 * @return
	 */
	public ProductDTO assmebleProduct(OrderVO orderVO) {
		String productId = orderVO.getProductId();
		if ("1S".equalsIgnoreCase(orderVO.getOrderType())) {
			productId = "1754";
		}
		ProductDTO product = productRepository.getOne(new Integer(productId));
		if (product == null) {
			product = new ProductDTO();
			product.setProductId(new Integer(orderVO.getProductId()));
			product.setName("PIC Long Distance");
		}
		return product;
	}

	@SuppressWarnings("unused")
	private AddressDTO stubAddress() {
		AddressDTO address = new AddressDTO();
		address.setAddressId(Long.valueOf(20409));
		address.setZip("92663");
		return address;
	}

	/**
	 * This method is to retrieve rateplan, scid and billing account number from
	 * Sandstone
	 * 
	 * @param orderVO
	 * @return
	 * @throws SLDBException
	 */
	public OrderVO assembleOrderAdditionalDetails(OrderVO orderVO) throws SLDBException {
		long startTime = System.currentTimeMillis();
		OrderAdditionalDetailsVO orderAdditionalDetailsVO = dataMSClient.getOrderAdditionalDetails(orderVO.getOrgId(),
				orderVO.getProductId(), orderVO.getBan(), orderVO.getServiceLocationId());
		orderVO.setRatePlanId(orderAdditionalDetailsVO.getRatePlanId());
		orderVO.setScid(orderAdditionalDetailsVO.getScid());
		orderVO.setBillingAccNum(orderAdditionalDetailsVO.getAccountNumber());
		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @assembleOrderAdditionalDetails took " + (endTime - startTime)
				+ " milliseconds for for : " + orderVO.getOrgId() + " : " + orderVO.getProductId() + " : "
				+ orderVO.getBan() + " : " + orderVO.getServiceLocationId());
		return orderVO;
	}

	/**
	 * Flow based creation or retrieval of Tollfree subscribtion line
	 * 
	 * @param orderVO
	 * @param gVO
	 * @param sysdate
	 * @param sub
	 * @param product
	 * @param address
	 * @return
	 * @throws Exception
	 */
	public TollFreeSubsciberLineDTO assembleTollfreeSubscriberLine(OrderVO orderVO, TNDataVO gVO, Date sysdate,
			SubscriberDTO sub, ProductDTO product, AddressDTO address) throws Exception {
		TollFreeSubsciberLineDTO tollFreeSubsciberLineDTO = null;
		if (orderVO.isInstallFlow())
			tollFreeSubsciberLineDTO = createTollfreeSubscriberLine(orderVO, sysdate, sub, product, address, gVO);
		else {
			tollFreeSubsciberLineDTO = tollFreeSubsciberLineRepository.findByTn(gVO.getWtn());
			if (orderVO.isDisconnectFlow()) {
				tollFreeSubsciberLineDTO.setActiveYn("N");
				tollFreeSubsciberLineDTO.setActiveYnImpl("N");
			}
		}

		if (tollFreeSubsciberLineDTO == null) {
			throw new SLDBException("SubscriberLine is not available for ANI: " + gVO.getWtn());
		}

		return tollFreeSubsciberLineDTO;
	}

	/**
	 * Create Tollfree subscriber line and persist the same with user selected data
	 * 
	 * @param orderVO
	 * @param sysdate
	 * @param sub
	 * @param product
	 * @param address
	 * @param gVO
	 * @return
	 * @throws Exception
	 */
	private TollFreeSubsciberLineDTO createTollfreeSubscriberLine(OrderVO orderVO, Date sysdate, SubscriberDTO sub,
			ProductDTO product, AddressDTO address, TNDataVO gVO) {
		TollFreeSubsciberLineDTO tollFreeSubsciberLineDTO = new TollFreeSubsciberLineDTO();

		tollFreeSubsciberLineDTO.setTn(gVO.getWtn());
		tollFreeSubsciberLineDTO.setCustomerBizOrgId(orderVO.getBusOrgId());
		tollFreeSubsciberLineDTO.setMasterBizOrgId(orderVO.getBusOrgId());
		tollFreeSubsciberLineDTO.setCustomerBizOrgName(orderVO.getCustomerName());
		tollFreeSubsciberLineDTO.setLastUpdatedUser(getUserName(orderVO));
		tollFreeSubsciberLineDTO.setLastUpdated(sysdate);
		tollFreeSubsciberLineDTO.setCreatedDate(sysdate);
		tollFreeSubsciberLineDTO.setActiveYn("Y");
		tollFreeSubsciberLineDTO.setActiveYnImpl("Y");
		tollFreeSubsciberLineDTO.setSwitchType(NetworkConstants.SWITCH_SONUS);// 1S, 1D
		tollFreeSubsciberLineDTO.setSubscriberId(sub.getSubscriberId());
		tollFreeSubsciberLineDTO.setProductId(product.getProductId());
		tollFreeSubsciberLineDTO.setSubscriberSiteId(address.getAddressId());
		tollFreeSubsciberLineDTO.setServiceAddressId(address.getAddressId());

		tollFreeSubsciberLineRepository.save(tollFreeSubsciberLineDTO);
		return tollFreeSubsciberLineDTO;
	}

	/**
	 * Create TN order and persist the same with user selected data
	 * 
	 * @param orderVO
	 * @param sysdate
	 * @param ponInfo
	 * @param sub
	 * @param product
	 * @param tollFreeSubsciberLineDTO
	 * @param voiceOrderId
	 * @param gVO
	 * @param inHouseBizOrgId 
	 * @return
	 * @throws SLDBException 
	 */
	public TnOrderDTO assembleTNOrder(OrderVO orderVO, Date sysdate, Map<String, Long> ponInfo, SubscriberDTO sub,
			ProductDTO product, TollFreeSubsciberLineDTO tollFreeSubsciberLineDTO, AddressDTO address,
			Long voiceOrderId, TNDataVO gVO, String inHouseBizOrgId) throws SLDBException {
		TnOrderDTO tnOrderDTO = new TnOrderDTO();
		tnOrderDTO.setSlOrder(new SlOrderDTO());
		updatePrevSlOrder(orderVO, tollFreeSubsciberLineDTO, gVO);

		assembleSlOrder(orderVO, sysdate, ponInfo, tnOrderDTO, voiceOrderId, gVO, inHouseBizOrgId);

		// tnOrderDTO.setSubscriberLineBySubscriberLineId(subscriberLineDTO);
		tnOrderDTO.setTollfreeSubscriberLineId(tollFreeSubsciberLineDTO.getSubscriberLineId());
		tnOrderDTO.setInternalPortYn("N");
		tnOrderDTO.setServiceTransferYn("Y");
		tnOrderDTO.setSwitchType("SONUS");
		tnOrderDTO.setLnpLctDipYn("N");
		tnOrderDTO.setLsrServiceAddress(address);
		tnOrderDTO.setAddress(address);
		tnOrderDTO.setSubscriberSiteId(8059576860L);
		tnOrderDTO.setProduct(product);
		tnOrderDTO.setSubscriber(sub);
		tnOrderDTO.setMigrationYn("Y");
		tnOrderDTO.setLastUpdated(sysdate);
		tnOrderDTO = tnOrderRepository.save(tnOrderDTO);
		return tnOrderDTO;
	}

	/**
	 * This method is to update the previous salesorder incase of change block
	 * unblock or disconnect active indicator to Y or N
	 * 
	 * @param orderVO
	 * @param tnDataVO
	 * @param subscriberLineDTO
	 */
	private void updatePrevSlOrder(OrderVO orderVO, TollFreeSubsciberLineDTO tollFreeSubsciberLineDTO,
			TNDataVO tnDataVO) {
		String customerID = orderTollFreeFeatureRepository.getPrevCustCustomerId(tollFreeSubsciberLineDTO.getTn());
		Long slOrderId = orderTollFreeFeatureRepository.getActiveNonDiscoSlOrderId(tollFreeSubsciberLineDTO.getTn(),
				customerID);
		if (slOrderId != null) {
			if(!isCustomerMove(customerID, orderVO)) {
				SlOrderDTO slOrderDTO = slOrderRepository.findOne(slOrderId);
				slOrderDTO.setOrderActiveYn("N");
				slOrderRepository.saveAndFlush(slOrderDTO);
			}
		} else {
			Long discoSlOrderId = orderTollFreeFeatureRepository
					.getActiveDiscoSlOrderId(tollFreeSubsciberLineDTO.getTn(), customerID);

			if (discoSlOrderId != null) {
				SlOrderDTO slOrderDTO = slOrderRepository.findOne(discoSlOrderId);
				slOrderDTO.setOrderActiveYn("N");
				slOrderRepository.saveAndFlush(slOrderDTO);
			}
		}
	}

	private boolean isCustomerMove(String customerID, OrderVO orderVO) {
		return OrderActionCodes.INSTALL_STRING.equalsIgnoreCase(orderVO.getActionType())
				&& !StringUtils.isEmpty(customerID) && !customerID.equalsIgnoreCase(orderVO.getCustomerID());
	}

	/**
	 * Create salesOrder for each TN and persist with user selected data
	 * 
	 * @param orderVO
	 * @param sysdate
	 * @param ponInfo
	 * @param tnOrderDTO
	 * @param voiceOrderId
	 * @param gVO
	 * @param inHouseBizOrgId 
	 * @return
	 * @throws SLDBException 
	 */
	private SlOrderDTO assembleSlOrder(OrderVO orderVO, Date sysdate, Map<String, Long> ponInfo, TnOrderDTO tnOrderDTO,
			Long voiceOrderId, TNDataVO gVO, String inHouseBizOrgId) throws SLDBException {
		SlOrderDTO slOrder = tnOrderDTO.getSlOrder();
		slOrder.setExpediteYn("N");
		slOrder.setSlOrderType(TollFreeOrderConstants.AN_ORDER_TYPE);
		slOrder.setActionTypeId(getActionTypeId(orderVO).getActionTypeId());
		slOrder.setOrderStatusId(new Integer(OrderStatusConstants.ORDER_STATUS_CREATED));
		slOrder.setOrderActiveYn("Y");
		slOrder.setOrderDate(new Timestamp(System.currentTimeMillis()));
		slOrder.setCreateUser(getUserName(orderVO));
		slOrder.setLastUpdatedUser(getUserName(orderVO));
		slOrder.setLastUpdated(sysdate);
		slOrder.setCustomerBizOrgId(orderVO.getBusOrgId());
		slOrder.setMasterBizOrgId(inHouseBizOrgId);
		slOrder.setCustomerBizOrgName(orderVO.getCustomerName());
		slOrder.setSuppAllowedFlag(OrderConstants.SUPP_ALLOWED_NONE);
		slOrder.setSaUrgentYn("N");
		slOrder.setOrderTypeId(1);
		if (orderVO.getOrderSourceId() != null) {
			slOrder.setOrderSourceId(orderVO.getOrderSourceId());
		} else {
			slOrder.setOrderSourceId(1);
		}
		String key = getUniqueKey(gVO, orderVO);
		if (gVO.getPon() != null) {
			slOrder.setParentTransId(gVO.getPon());
		} else {
			slOrder.setParentTransId(ponInfo.get(key));
		}

		slOrder.setExternalCustomerId(orderVO.getCustomerID());
		slOrder.setVoiceOrderId(voiceOrderId);
		if (orderVO.isDisconnectFlow()) {
			slOrder.setDisconnectDate(sysdate);
		}
		slOrderRepository.save(slOrder);
		return slOrder;
	}

	/**
	 * This method is to retrieve the action type DTO based on the action type
	 * string value
	 * 
	 * @param orderVO
	 * @return
	 */
	private ActionTypeDTO getActionTypeId(OrderVO orderVO) {
		Integer currentActionTypeId = OrderActionCodes.getOrderActionCode(orderVO.getActionType());
		ActionTypeDTO actionTypeDto = actionTypeRepository.findOne(currentActionTypeId);
		return actionTypeDto;
	}

	/**
	 * Flow based assembling of the order tollfreefeatures
	 * 
	 * @param orderVO
	 * @param gVO
	 * @param sysdate
	 * @param slOrder
	 * @throws Exception 
	 */
	public void assembleOrderTollFreeFeatures(OrderVO orderVO, TNDataVO gVO, Date sysdate, SlOrderDTO slOrder)
			throws Exception {
		if (!orderVO.isUnblockFlow()) {
			createOrderTollFreeFeature(sysdate, gVO, slOrder, orderVO);
		} else {
			populatePreviousOrderTollfreeFeature(sysdate, gVO, slOrder, orderVO);
		}

		String ocn = taiClient.getOcnData(gVO.getWtn());
		OrderTollFreeFeatureDTO orderTollFreeFeatureDTO = orderTollFreeFeatureRepository
				.findOne(slOrder.getSlOrderId());
		orderTollFreeFeatureDTO.setOcn(ocn);
		ocn = getMasterOCN(ocn);
		String provisionerName = lecProvisionerRepository.findProvisionerNameByOCN(ocn);
		orderTollFreeFeatureDTO.setLecProvisionerName(provisionerName);
		orderTollFreeFeatureRepository.save(orderTollFreeFeatureDTO);
	}
	
	private String getMasterOCN(String ocn) {
		return xMasterSubOcnRepository.getMasterOcn(ocn);
	}

	/**
	 * Create order Toll free feature with the TN data which user has selected
	 * 
	 * @param sysdate
	 * @param gVO
	 * @param slOrder
	 * @param orderVO
	 * @param ratePlanId
	 * @throws Exception 
	 */
	private void createOrderTollFreeFeature(Date sysdate, TNDataVO gVO, SlOrderDTO slOrder, OrderVO orderVO) throws Exception {
		OrderTollFreeFeatureDTO orderTollFreeFeatureDTO = new OrderTollFreeFeatureDTO();
		orderTollFreeFeatureDTO.setTn(gVO.getWtn());
		orderTollFreeFeatureDTO.setBtn(gVO.getBtn());
		orderTollFreeFeatureDTO.setCic(gVO.getCic());
		orderTollFreeFeatureDTO.setForcedANI(gVO.getForceAniLoad());
		orderTollFreeFeatureDTO.setJurisdiction(tollFreeOrderServiceUtils.getJurisdiction(gVO));
		orderTollFreeFeatureDTO.setPicRequest(gVO.getPic());
		orderTollFreeFeatureDTO.setStartDate(sysdate);
		orderTollFreeFeatureDTO.setSlOrderId(slOrder.getSlOrderId());
		orderTollFreeFeatureDTO.setLastUpdatedUser(getUserName(orderVO));
		orderTollFreeFeatureDTO.setLastUpdated(sysdate);
		orderTollFreeFeatureDTO.setAccountNumber(orderVO.getBan());
		orderTollFreeFeatureDTO.setControlGroupId(orderVO.getControlGroupId());
		orderTollFreeFeatureDTO.setServiceAddressId(orderVO.getServiceLocationId());
		orderTollFreeFeatureDTO.setRatePlan(orderVO.getRatePlanId());
		orderTollFreeFeatureDTO.setScId(orderVO.getScid());
		orderTollFreeFeatureDTO.setBillingAccNum(orderVO.getBillingAccNum());
		orderTollFreeFeatureDTO.setCrc(gVO.getCrc());
		orderTollFreeFeatureDTO.setProductOfferingID(orderVO.getProductId());

		if (gVO.getJurisdiction() != null) {
			orderTollFreeFeatureDTO.setJiLoad("Yes");
		}
		
		if (orderVO.getScid() != null && !orderVO.getScid().equals("")) {
			String serviceId = pipeLineClient.retrieveServiceId(orderVO.getScid());
			orderTollFreeFeatureDTO.setServiceID(serviceId);
		}

		setOrderTollFreeFeatures(gVO, orderTollFreeFeatureDTO);
		orderTollFreeFeatureRepository.saveAndFlush(orderTollFreeFeatureDTO);
	}

	/**
	 * Set feature information against the created order tollfree feature object
	 * which user has selected
	 * 
	 * @param gVO
	 * @param orderTollFreeFeatureDTO
	 */
	private void setOrderTollFreeFeatures(TNDataVO gVO, OrderTollFreeFeatureDTO orderTollFreeFeatureDTO) {
		List<FeaturesVO> features = gVO.getFeatures();
		if (features == null)
			return;
		for (FeaturesVO feature : features) {
			if (feature.getFeatureDescription().contains("Unvalidated Acct Codes")) {
				orderTollFreeFeatureDTO.setUnvalidatedAC(feature.getFeatureOfferingId());
				orderTollFreeFeatureDTO.setAccountCodeEsf(feature.getAccountCodeESF());
			} else if (feature.getFeatureDescription().contains("Validated Custom")) {
				orderTollFreeFeatureDTO.setValidatedAC(feature.getFeatureOfferingId());
				orderTollFreeFeatureDTO.setAccountCodeEsf(feature.getAccountCodeESF());
			} else if (feature.getFeatureDescription().contains("Intl and Caribbean Blocking")) {
				orderTollFreeFeatureDTO.setBlockCaribInter(feature.getFeatureOfferingId());
			} else if (feature.getFeatureDescription().contains("Fraud International and Caribbean Block")) {
				orderTollFreeFeatureDTO.setBlockFraudCaribInter(feature.getFeatureOfferingId());
			} else if (feature.getFeatureDescription().contains("Customer All Block")) {
				orderTollFreeFeatureDTO.setBlockAll(feature.getFeatureOfferingId());
			} else if (feature.getFeatureDescription().contains("Fraud All Block")) {
				orderTollFreeFeatureDTO.setBlockFraudAll(feature.getFeatureOfferingId());
			} else if (feature.getFeatureDescription().contains("Ported ANI Load")) {
				orderTollFreeFeatureDTO.setPortedANI(feature.getFeatureOfferingId());
			} else if (feature.getFeatureDescription().contains("Ent PIC LD Ported ANI Load")) {
				orderTollFreeFeatureDTO.setPortedANI(feature.getFeatureOfferingId());
			} else if (feature.getFeatureDescription().contains("Positive ANI Load")) {
				orderTollFreeFeatureDTO.setPositiveANI(feature.getFeatureOfferingId());
			}
		}
		ValidatedCustomAcctCodeVO validatedCustomAcctCodeVO = gVO.getValidatedCustomAcctCodeVO();
		if (validatedCustomAcctCodeVO == null)
			return;

		orderTollFreeFeatureDTO.setAcTableName(validatedCustomAcctCodeVO.getCodeTableName());
		orderTollFreeFeatureDTO.setAcDigits(validatedCustomAcctCodeVO.getCodeDigits());
		orderTollFreeFeatureDTO.setAcTableId(validatedCustomAcctCodeVO.getCodeTableId());

	}

	/**
	 * Retrieve previous latest Change or install features and use the same for the
	 * current unblock scenario
	 * 
	 * @param orderVO
	 * @param slOrder
	 * @param gVO
	 * @param sysdate
	 * @throws Exception 
	 * 
	 */
	private void populatePreviousOrderTollfreeFeature(Date sysdate, TNDataVO gVO, SlOrderDTO slOrder, OrderVO orderVO) throws Exception {
		OrderTollFreeFeatureDTO prevFeaturesDTO = orderTollFreeFeatureRepository
				.getPreviousOrderTollFreeFeatures(gVO.getWtn(), orderVO.getCustomerID());
		
		if(isDataMigrationFlow(prevFeaturesDTO)) {
			createOrderTollFreeFeature(sysdate, gVO, slOrder, orderVO);
			OrderTollFreeFeatureDTO orderTollFreeFeatureDTO = orderTollFreeFeatureRepository.findOne(slOrder.getSlOrderId());
			orderTollFreeFeatureDTO.setBlockAll(null);
			orderTollFreeFeatureRepository.saveAndFlush(orderTollFreeFeatureDTO);
			return;
		}

		OrderTollFreeFeatureDTO orderTollFreeFeatureDTO = new OrderTollFreeFeatureDTO();
		orderTollFreeFeatureDTO.setTn(gVO.getWtn());
		orderTollFreeFeatureDTO.setBtn(gVO.getBtn());
		orderTollFreeFeatureDTO.setCic(gVO.getCic());
		orderTollFreeFeatureDTO.setForcedANI(gVO.getForceAniLoad());
		orderTollFreeFeatureDTO.setJurisdiction(tollFreeOrderServiceUtils.getJurisdiction(gVO));
		orderTollFreeFeatureDTO.setPicRequest(gVO.getPic());
		orderTollFreeFeatureDTO.setStartDate(sysdate);
		orderTollFreeFeatureDTO.setSlOrderId(slOrder.getSlOrderId());
		orderTollFreeFeatureDTO.setLastUpdatedUser(getUserName(orderVO));
		orderTollFreeFeatureDTO.setLastUpdated(sysdate);
		orderTollFreeFeatureDTO.setAccountNumber(orderVO.getBan());
		orderTollFreeFeatureDTO.setControlGroupId(orderVO.getControlGroupId());
		orderTollFreeFeatureDTO.setServiceAddressId(orderVO.getServiceLocationId());
		orderTollFreeFeatureDTO.setRatePlan(orderVO.getRatePlanId());
		orderTollFreeFeatureDTO.setScId(orderVO.getScid());
		orderTollFreeFeatureDTO.setBillingAccNum(orderVO.getBillingAccNum());
		orderTollFreeFeatureDTO.setCrc(gVO.getCrc());
		orderTollFreeFeatureDTO.setProductOfferingID(orderVO.getProductId());

		if (gVO.getJurisdiction() != null) {
			orderTollFreeFeatureDTO.setJiLoad("Yes");
		}

		setOrderTollFreeFeatures(orderTollFreeFeatureDTO, prevFeaturesDTO);
		orderTollFreeFeatureRepository.saveAndFlush(orderTollFreeFeatureDTO);
	}

	/**
	 * In case of datamigration flow the ordertollfreefeatures will have
	 * all the previous feature too. So we will reuse the same createordertollfreefeatures
	 * and then set block all to null.
	 * 
	 * @param prevFeaturesDTO
	 * @return
	 */
	private boolean isDataMigrationFlow(OrderTollFreeFeatureDTO prevFeaturesDTO) {
		return prevFeaturesDTO == null;
	}

	private String getUserName(OrderVO orderVO) {
		return orderVO.getUserName() != null ? orderVO.getUserName() : "TEST";
	}

	/**
	 * Set feature information against the created order tollfree feature object
	 * which user has selected
	 * 
	 * @param gVO
	 * @param newOrderTollfreeFeatures
	 */
	private void setOrderTollFreeFeatures(OrderTollFreeFeatureDTO newOrderTollfreeFeatures,
			OrderTollFreeFeatureDTO prevOrderTollfreeFeatures) {
		newOrderTollfreeFeatures.setUnvalidatedAC(prevOrderTollfreeFeatures.getUnvalidatedAC());
		newOrderTollfreeFeatures.setValidatedAC(prevOrderTollfreeFeatures.getValidatedAC());
		newOrderTollfreeFeatures.setBlockCaribInter(prevOrderTollfreeFeatures.getBlockCaribInter());
		newOrderTollfreeFeatures.setBlockFraudCaribInter(prevOrderTollfreeFeatures.getBlockFraudCaribInter());
		newOrderTollfreeFeatures.setBlockAll(prevOrderTollfreeFeatures.getBlockAll());
		newOrderTollfreeFeatures.setBlockFraudAll(prevOrderTollfreeFeatures.getBlockFraudAll());
		newOrderTollfreeFeatures.setAcTableName(prevOrderTollfreeFeatures.getAcTableName());
		newOrderTollfreeFeatures.setAcDigits(prevOrderTollfreeFeatures.getAcDigits());
		newOrderTollfreeFeatures.setAccountCodeEsf(prevOrderTollfreeFeatures.getAccountCodeEsf());
		newOrderTollfreeFeatures.setAcTableId(prevOrderTollfreeFeatures.getAcTableId());
		newOrderTollfreeFeatures.setPortedANI(prevOrderTollfreeFeatures.getPortedANI());
		newOrderTollfreeFeatures.setPositiveANI(prevOrderTollfreeFeatures.getPositiveANI());
	}

	/**
	 * Create order feature with dummy data to support 1S, 8S, 8D orders to show up
	 * on the MOAB search screen Currently views which are used are needed this
	 * table to have a record against the sales order id
	 * 
	 * @param gVO
	 * @param slOrder
	 * @param sysdate
	 */
	public void assembleOrderFeature(TNDataVO gVO, TnOrderDTO tnOrder, Date sysdate) {
		OrderFeatureDTO orderFeatureDTO = new OrderFeatureDTO();
		orderFeatureDTO.setTnOrder(tnOrder);
		orderFeatureDTO.setTn(gVO.getWtn());
		orderFeatureDTO.setLnpYn("N");
		orderFeatureDTO.setLastUpdatedUser("UNKNOWN");
		orderFeatureDTO.setLastUpdated(sysdate);
		orderFeatureRepository.save(orderFeatureDTO);
	}

	/**
	 * Create order dir listing feature with dummy data to support 1S, 8S, 8D orders
	 * to show up on the MOAB search screen Currently views which are used are
	 * needed this table to have a record against the sales order id
	 * 
	 * @param slOrder
	 * @param tnOrder
	 * @param sysdate
	 */
	public void assembleOrderDirListing(SlOrderDTO slOrder, TnOrderDTO tnOrder) {
		OrderDirListFeatureDTO orderDirListFeatureDTO = new OrderDirListFeatureDTO();
		DirListTypeDTO dirListTypeDTO = new DirListTypeDTO();
		dirListTypeDTO.setDirListTypeId(0);
		orderDirListFeatureDTO.setTnOrder(tnOrder);
		orderDirListFeatureDTO.setDirListType(dirListTypeDTO);
		orderDirListFeatureRepository.save(orderDirListFeatureDTO);
	}

	/**
	 * Create order E911 feature with dummy data to support 1S, 8S, 8D orders to
	 * show up on the MOAB search screen Currently views which are used are needed
	 * this table to have a record against the sales order id
	 * 
	 * @param slOrder
	 * @param tnOrder
	 */
	public void assembleOrderE911Feature(SlOrderDTO slOrder, TnOrderDTO tnOrder) {
		OrderE911FeatureDTO orderE911FeatureDTO = new OrderE911FeatureDTO();
		orderE911FeatureDTO.setTnOrder(tnOrder);
		orderE911FeatureRepository.save(orderE911FeatureDTO);
	}

	/**
	 * This method is used to create the unique key with the TN data which helps to
	 * identify the unique TN and groups them when config matches under a pon
	 * 
	 * @param tnDataVO
	 * @param orderVO
	 * @return
	 */
	private String getUniqueKey(TNDataVO tnDataVO, OrderVO ordVO) {
		String key = tnDataVO.getPic() + "_" + tnDataVO.getCrc() + "_" + tnDataVO.getForceAniLoad() + "_"
				+ tollFreeOrderServiceUtils.getJurisdiction(tnDataVO);

		String customerID = orderTollFreeFeatureRepository.getPrevCustActiveCustomerId(tnDataVO.getWtn());

		if (OrderActionCodes.INSTALL_STRING.equalsIgnoreCase(ordVO.getActionType()) && !StringUtils.isEmpty(customerID)
				&& !customerID.equalsIgnoreCase(ordVO.getCustomerID())) {
			key = key + "_" + customerID;
		}
		
		List<FeaturesVO> featuresVOs = tnDataVO.getFeatures();
		if (featuresVOs == null) {
			return key;
		}

		for (FeaturesVO featuresVO : featuresVOs) {
			key = key + "_" + featuresVO.getFeatureOfferingId();
		}

		if (tnDataVO.getValidatedCustomAcctCodeVO() == null) {
			return key;
		}

		ValidatedCustomAcctCodeVO validatedCustomAcctCodeVO = tnDataVO.getValidatedCustomAcctCodeVO();
		key = key + "_" + validatedCustomAcctCodeVO.getCodeDigits() + "_"
				+ validatedCustomAcctCodeVO.getCodeTableName();

		return key;
	}
}
