package com.level3.voice.tollfree.bulk.batch.processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.BatchProcessConstants;
import com.level3.voice.common.util.OrderStatusConstants;
import com.level3.voice.persist.repository.SubscriberLineRepository;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadDTO;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadItemDTO;
import com.level3.voice.tollfree.bulk.repository.BulkOrderUploadRepository;
import com.level3.voice.tollfree.client.DataMSClient;
import com.level3.voice.tollfree.client.WorkflowClient;
import com.level3.voice.tollfree.constants.TollFreeOrderConstants;
import com.level3.voice.tollfree.exception.TollFreeOrderServiceException;
import com.level3.voice.tollfree.manager.TollFreeOrderServiceManager;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.dto.TollFreeSubsciberLineDTO;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeSubsciberLineRepository;
import com.level3.voice.tollfree.utils.OrderActionCodes;
import com.level3.voice.tollfree.utils.TollFreeOrderServiceUtils;
import com.level3.voice.tollfree.vo.BanServiceLocationVO;
import com.level3.voice.tollfree.vo.CodeTableVO;
import com.level3.voice.tollfree.vo.CrcVO;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.NS1SBulkOrderVO;
import com.level3.voice.tollfree.vo.ProductFeaturesVO;
import com.level3.voice.tollfree.vo.ValidationMessageVO;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;

@Component
public class BulkOrderExcelTemplateProcessor implements ItemProcessor<BulkOrderUploadItemDTO, BulkOrderUploadItemDTO> {

	@Autowired
	TollFreeOrderServiceUtils tollFreeOrderServiceUtils;

	@Value("${tn.upload.excel.template.sheet.names}")
	public String sheetNames;

	@Value("${tn.upload.excel.template.1spicld.columns}")
	public String oneSPICLDColumns;

	@Value("${tn.upload.excel.bulk.template.sheet.names}")
	public String bulkSheetNames;

	@Value("${tn.upload.excel.bulk.template.columns}")
	public String bulkChangeColumns;

	@Value("${tn.upload.excel.bulk.template.rows}")
	public String bulkChangeRows;

	@Value("#{'${list.of.features}'.split(',')}")
	private List<String> featuresGroup;

	@Value("${tn.upload.excel.bulk.folder.location}")
	public String folderLocation;

	@Value("${tn.upload.excel.bulk.ftp.user}")
	public String ftpUser;

	@Value("${tn.upload.excel.bulk.ftp.password}")
	public String ftpPassword;

	@Autowired
	TollFreeOrderServiceManager tollFreeOrderServiceManager;

	@Autowired
	BulkOrderUploadRepository bulkOrderUploadRepository;

	@Autowired
	DataMSClient dataMSClient;

	@Autowired
	WorkflowClient workflowClient;

	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;

	@Autowired
	SubscriberLineRepository subscriberLineRepository;

	@Autowired
	TollFreeSubsciberLineRepository tollFreeSubsciberLineRepository;

	private static final String PATTERN = "\\d{10}";
	private static final Logger logger = Logger.getLogger(BulkOrderExcelTemplateProcessor.class);

	public List<BulkOrderUploadItemDTO> readBulkOrderExcelTemplate(String filePath, Long voiceOrderId,
			String bulkOrderUploadId) throws Exception {
		InputStream file = new FileInputStream(new File(filePath));

		XSSFWorkbook workbook = new XSSFWorkbook(file);
		String workBookSheetName = tollFreeOrderServiceUtils.getSheetName(workbook);
		if (!tollFreeOrderServiceUtils.getSheetNames(workBookSheetName, bulkSheetNames)) {
			throw new TollFreeOrderServiceException("@TollFreeOrderServiceManager: process: Invalid sheets.");
		}

		List<BulkOrderUploadItemDTO> bulkOrderUploadItemDTOs = new ArrayList<BulkOrderUploadItemDTO>();
		Map<String, String> allSheetColumns = tollFreeOrderServiceUtils.getSheetColumns(getColumns(workBookSheetName));

		if (allSheetColumns == null || (allSheetColumns != null && allSheetColumns.isEmpty())) {
			throw new TollFreeOrderServiceException(
					"@TollFreeOrderServiceManager process: Sheet columns are not available.");
		}

		BulkOrderUploadDTO bulkOrderUploadDTO = null;
		Map<String, Long> ponInfo = new HashMap<String, Long>();
		for (int j = 0; j < workbook.getNumberOfSheets();) {
			XSSFSheet sheet = workbook.getSheetAt(j);

			Iterator<Row> rows = sheet.rowIterator();
			while ((rows.hasNext())) {

				XSSFRow r = (XSSFRow) rows.next();

				if (r.getRowNum() <= 4) {
					continue;
				}

				BulkOrderUploadItemDTO bulkOrderUploadItemDTO = getTNDataVO(r, allSheetColumns);
				if (StringUtils.isEmpty(bulkOrderUploadItemDTO.getBtn())
						&& StringUtils.isEmpty(bulkOrderUploadItemDTO.getWtn())
						&& StringUtils.isEmpty(bulkOrderUploadItemDTO.getCic())
						&& StringUtils.isEmpty(bulkOrderUploadItemDTO.getJurisdiction())
						&& StringUtils.isEmpty(bulkOrderUploadItemDTO.getPic())
						&& StringUtils.isEmpty(bulkOrderUploadItemDTO.getFeatureId())
						&& StringUtils.isEmpty(bulkOrderUploadItemDTO.getCodeDigit())
						&& StringUtils.isEmpty(bulkOrderUploadItemDTO.getCodeDigit())
						&& StringUtils.isEmpty(bulkOrderUploadItemDTO.getIsMandatoryFeature())) {
					// Found empty row and skipping it
					continue;
				}

				if (bulkOrderUploadDTO == null) {
					bulkOrderUploadDTO = bulkOrderUploadRepository.findOne(Long.parseLong(bulkOrderUploadId));
				}
				bulkOrderUploadItemDTO.setBulkOrderUploadDTO(bulkOrderUploadDTO);
				bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_RECEIVED);

				validateAndGeneratePON(bulkOrderUploadItemDTO, bulkOrderUploadDTO.getCustomerId(), ponInfo);

				Long duplicateCount = bulkOrderUploadItemDTOs.stream()
						.filter(item -> !item.getStatus().equals(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS))
						.filter(item -> item.getWtn().equals(bulkOrderUploadItemDTO.getWtn()))
						.collect(Collectors.counting());

				if (duplicateCount > 0L) {
					bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
					bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("Duplicate WTN."));
				}
				bulkOrderUploadItemDTOs.add(bulkOrderUploadItemDTO);
			}
			return bulkOrderUploadItemDTOs;
		}
		return null;
	}

	private void validateAndGeneratePON(BulkOrderUploadItemDTO bulkOrderUploadItemDTO, String customerId,
			Map<String, Long> ponInfo) throws SLDBException {
		if (validateBulkOrderUploadItem(bulkOrderUploadItemDTO)) {
			String uniqueKey = getUniqueKey(bulkOrderUploadItemDTO);
			Long parentTransId = null;
			bulkOrderUploadItemDTO.setCrc(getCrc("WCG", customerId, bulkOrderUploadItemDTO.getCic()));
			if (ponInfo != null && ponInfo.containsKey(uniqueKey)) {
				parentTransId = ponInfo.get(uniqueKey);
			} else {
				parentTransId = orderTollFreeFeatureRepository.getParentTxId();
				ponInfo.put(uniqueKey, parentTransId);
			}
			bulkOrderUploadItemDTO.setPon(parentTransId);
		}
	}

	private boolean validateBulkOrderUploadItem(BulkOrderUploadItemDTO bulkOrderUploadItemDTO) throws SLDBException {
		Pattern pattern = Pattern.compile(PATTERN);
		BulkOrderUploadDTO bulkOrderUploadDTO = bulkOrderUploadItemDTO.getBulkOrderUploadDTO();
		if (StringUtils.isEmpty(bulkOrderUploadItemDTO.getBtn()) || StringUtils.isEmpty(bulkOrderUploadItemDTO.getWtn())
				|| StringUtils.isEmpty(bulkOrderUploadItemDTO.getCic())
				|| StringUtils.isEmpty(bulkOrderUploadItemDTO.getJurisdiction())
				|| StringUtils.isEmpty(bulkOrderUploadItemDTO.getPic())) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
					"Please enter mandatory fields(WTN/BTN/CIC/Jurisdiction/PIC)."));
			return false;
		}

		if (bulkOrderUploadItemDTO.getWtn().length() != 10) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("WTN is not 10 digits."));
			return false;
		}
		if (!pattern.matcher(bulkOrderUploadItemDTO.getWtn()).matches()) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("Non-numeric data in WTN."));
			return false;
		}
		if (bulkOrderUploadItemDTO.getBtn().length() != 10) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("BTN is not 10 digits."));
			return false;
		}
		if (!pattern.matcher(bulkOrderUploadItemDTO.getBtn()).matches()) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("Non-numeric data in BTN."));
			return false;
		}

		if (bulkOrderUploadItemDTO.getBtn().length() > 10 || bulkOrderUploadItemDTO.getWtn().length() > 10) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("Invalid WTN("
					+ bulkOrderUploadItemDTO.getWtn() + ")/BTN(" + bulkOrderUploadItemDTO.getWtn() + ")"));

			// Trimming to 10 digits since DB accepts 10(comments will have the actual
			// entered details)
			bulkOrderUploadItemDTO.setBtn(bulkOrderUploadItemDTO.getBtn().substring(0, 9));
			bulkOrderUploadItemDTO.setWtn(bulkOrderUploadItemDTO.getWtn().substring(0, 9));
			return false;
		}

		if (!isValidAccCodeWithMand(bulkOrderUploadItemDTO.getFeatureId(),
				bulkOrderUploadItemDTO.getIsMandatoryFeature())) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
					"IS_ACC_CODE_MANDATORY is required for validated/unvalidated account code features"));
			return false;
		}

		if (!bulkOrderUploadDTO.getOrderType().equals("Install")) {
			TollFreeSubsciberLineDTO tollFreeSubsciberLineDTO = tollFreeSubsciberLineRepository
					.findByTn(bulkOrderUploadItemDTO.getWtn());
			if (tollFreeSubsciberLineDTO == null) {
				bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
				bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
						"ANI does not exist in system to perform " + bulkOrderUploadDTO.getOrderType()));
				return false;
			}
		}

		if (StringUtils.isNotEmpty(bulkOrderUploadItemDTO.getCodeTable())) {
			CustomerVO customerVO = dataMSClient.fetchCodeTabList("WCG", bulkOrderUploadDTO.getCustomerId());
			if (customerVO.getCodeTableVOs() != null && !customerVO.getCodeTableVOs().isEmpty()) {
				Long countTab = customerVO.getCodeTableVOs().stream()
						.filter(item -> item.getCodeTableName().equals(bulkOrderUploadItemDTO.getCodeTable()))
						.collect(Collectors.counting());
				if (countTab <= 0) {
					bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
					bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("Invalid Code Table"));
					return false;
				}
			}
		}
		if (StringUtils.isNotEmpty(bulkOrderUploadItemDTO.getCodeDigit())) {
			CustomerVO customerVO = dataMSClient.fetchCodeTabList("WCG", bulkOrderUploadDTO.getCustomerId());
			if (customerVO.getCodeTableVOs() != null && !customerVO.getCodeTableVOs().isEmpty()) {
				Long countDigit = customerVO.getCodeTableVOs().stream()
						.filter(item -> item.getCodeDigits().equals(bulkOrderUploadItemDTO.getCodeDigit()))
						.collect(Collectors.counting());
				if (countDigit <= 0) {
					bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
					bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("Invalid Code Digit"));
					return false;
				}
			}
		}

		if (StringUtils.isNotEmpty(bulkOrderUploadItemDTO.getCic())) {
			CustomerVO customerVOBan = dataMSClient.serviceLocationByBan("WCG", bulkOrderUploadDTO.getCustomerId(),
					bulkOrderUploadDTO.getBan());
			if (customerVOBan == null || customerVOBan.getBanServiceLocationVOs() == null
					|| customerVOBan.getBanServiceLocationVOs().size() == 0) {
				logger.info("BAN not found - " + bulkOrderUploadDTO.getBan());
				return false;
			}
			String serviceLocationId = null;
			for (BanServiceLocationVO banServiceLocationVO : customerVOBan.getBanServiceLocationVOs()) {
				if (banServiceLocationVO.getAccountNumber() != null
						&& banServiceLocationVO.getAccountNumber().equals(bulkOrderUploadDTO.getBan())) {
					serviceLocationId = banServiceLocationVO.getServiceLocationId();
					break;
				}
			}

			CustomerVO customerVO = dataMSClient.fetchCICVO("WCG", bulkOrderUploadDTO.getCustomerId(),
					serviceLocationId);
			if (customerVO.getCicVOs() != null && !customerVO.getCicVOs().isEmpty()) {
				Long cicCount = customerVO.getCicVOs().stream()
						.filter(item -> item.getCic().equals(bulkOrderUploadItemDTO.getCic()))
						.collect(Collectors.counting());
				if (cicCount <= 0) {
					bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
					bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("Invalid CIC"));
					return false;
				}
			}
		}
		if (StringUtils.isNotEmpty(bulkOrderUploadItemDTO.getFeatureId())) {
			String[] featureIds = bulkOrderUploadItemDTO.getFeatureId().split(",");
			for (String featureId : featureIds) {
				if (!getFeatureDetails().containsKey(featureId)) {
					bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
					bulkOrderUploadItemDTO
							.setComments(getErrorMessageInValidationMessageVO("Invalid Feature ID:" + featureId));
					return false;
				}
			}
		}

		if (StringUtils.isEmpty(bulkOrderUploadItemDTO.getForceAniLoad())
				|| (!bulkOrderUploadItemDTO.getForceAniLoad().equals("Yes")
						&& !bulkOrderUploadItemDTO.getForceAniLoad().equals("No"))) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
					"Invalid ForceAniLoad:" + bulkOrderUploadItemDTO.getForceAniLoad()));
			return false;
		}

		if (StringUtils.isEmpty(bulkOrderUploadItemDTO.getJurisdiction())
				|| getJurisdiction(bulkOrderUploadItemDTO) == null) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
					"Invalid Jurisdiction:" + bulkOrderUploadItemDTO.getJurisdiction()));
			return false;
		}

		if (!StringUtils.isEmpty(bulkOrderUploadItemDTO.getPic()) && !bulkOrderUploadItemDTO.getPic().equalsIgnoreCase("Self")
				&& !bulkOrderUploadItemDTO.getPic().equalsIgnoreCase("CTL")
				&& !bulkOrderUploadItemDTO.getPic().equalsIgnoreCase("ICPay")) {
			bulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			bulkOrderUploadItemDTO.setComments(
					getErrorMessageInValidationMessageVO("Invalid PIC:" + bulkOrderUploadItemDTO.getPic()));
			return false;
		}
		return true;
	}

	private boolean isValidAccCodeWithMand(String featureIds, String isMand) {
		Boolean isValidAccCodeWithMand = true;

		if (StringUtils.isEmpty(featureIds)) {
			return isValidAccCodeWithMand;
		}

		if (featureIds.indexOf(",") > 1) {
			String[] featureData = featureIds.split(",");
			for (String f : featureData) {
				if (getFeatureDetails().get(f).contains("Unvalidated Acct Codes")
						|| getFeatureDetails().get(f).contains("Validated Custom")) {
					if (StringUtils.isEmpty(isMand)) {
						isValidAccCodeWithMand = false;
					} else if (!("Y".equalsIgnoreCase(isMand) || "N".equalsIgnoreCase(isMand))) {
						isValidAccCodeWithMand = false;
					}
				}
			}
		} else {
			if (getFeatureDetails().get(featureIds).contains("Unvalidated Acct Codes")
					|| getFeatureDetails().get(featureIds).contains("Validated Custom")) {
				if (StringUtils.isEmpty(isMand)) {
					isValidAccCodeWithMand = false;
				} else if (!("Y".equalsIgnoreCase(isMand) || "N".equalsIgnoreCase(isMand))) {
					isValidAccCodeWithMand = false;
				}
			}
		}
		return isValidAccCodeWithMand;
	}

	@Override
	public BulkOrderUploadItemDTO process(final BulkOrderUploadItemDTO bulkOrderUploadItemDTO) throws Exception {
		return bulkOrderUploadItemDTO;
	}

	/**
	 * Retrieve the proper columns from the application properties based on the
	 * sheet name
	 * 
	 * @param workBookSheetName
	 * @return columns related to that sheetname
	 */
	private String getColumns(String workBookSheetName) {
		if (TollFreeOrderConstants.ONESPICLD.equalsIgnoreCase(workBookSheetName)) {
			return oneSPICLDColumns;
		} else if (TollFreeOrderConstants.BULK_CHANGE.equalsIgnoreCase(workBookSheetName)) {
			return bulkChangeColumns;
		} else if (TollFreeOrderConstants.ORDER_INFO.equalsIgnoreCase(workBookSheetName)) {
			return bulkChangeRows;
		}
		return null;
	}

	public BulkOrderUploadItemDTO getTNDataVO(XSSFRow r, Map<String, String> sheetColumns) {

		if (sheetColumns == null || (sheetColumns != null && sheetColumns.isEmpty())) {
			return null;
		}

		DataFormatter objDefaultFormat = new DataFormatter();
		BulkOrderUploadItemDTO tnPropertyRecordVO = new BulkOrderUploadItemDTO();

		Iterator<Entry<String, String>> sheetColumnsIter = sheetColumns.entrySet().iterator();
		while (sheetColumnsIter.hasNext()) {
			String features = "";
			Entry<String, String> entry = sheetColumnsIter.next();
			String key = entry.getKey();
			String value = entry.getValue();
			if (TollFreeOrderConstants.BTN.equalsIgnoreCase(key)) {
				tnPropertyRecordVO.setBtn(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.WTN.equalsIgnoreCase(key)) {
				tnPropertyRecordVO.setWtn(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.PIC.equalsIgnoreCase(key)) {
				tnPropertyRecordVO.setPic(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.JURISDICTION.equalsIgnoreCase(key)) {
				tnPropertyRecordVO
						.setJurisdiction(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.FORCE_ANI_LOAD.equalsIgnoreCase(key)) {
				tnPropertyRecordVO
						.setForceAniLoad(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.CIC.equalsIgnoreCase(key)) {
				tnPropertyRecordVO.setCic(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.CODE_DIGITS.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				tnPropertyRecordVO.setCodeDigit(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.CODE_TABLE.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				tnPropertyRecordVO.setCodeTable(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))));
			} else if (TollFreeOrderConstants.FEATURE_ID.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				features = objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value)));
				tnPropertyRecordVO.setFeatureId(features);
			} else if (TollFreeOrderConstants.IS_MANDATORY.equalsIgnoreCase(key)
					&& !StringUtils.isEmpty(objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value))))) {
				String isMandatoryFeature = objDefaultFormat.formatCellValue(r.getCell(Integer.parseInt(value)));
				if (StringUtils.isNotEmpty(isMandatoryFeature)) {
					tnPropertyRecordVO.setIsMandatoryFeature(isMandatoryFeature.equalsIgnoreCase("Yes") ? "Y"
							: isMandatoryFeature.equalsIgnoreCase("No") ? "N" : null);
				}

			}
		}
		return tnPropertyRecordVO;
	}

	/**
	 * This method is used to create the unique key with the TN data which helps to
	 * identify the unique TN and groups them when config matches under a pon
	 * 
	 * @param bulkOrderUploadItemDTO
	 * @return
	 */
	private String getUniqueKey(BulkOrderUploadItemDTO bulkOrderUploadItemDTO) {
		String key = bulkOrderUploadItemDTO.getPic() + "_" + bulkOrderUploadItemDTO.getCrc() + "_"
				+ bulkOrderUploadItemDTO.getForceAniLoad() + "_" + getJurisdiction(bulkOrderUploadItemDTO) + "_"
				+ bulkOrderUploadItemDTO.getBulkOrderUploadDTO().getBan() + "_"
				+ bulkOrderUploadItemDTO.getBulkOrderUploadDTO().getProduct() + "_"
				+ bulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType();

		String customerID = orderTollFreeFeatureRepository.getPrevCustActiveCustomerId(bulkOrderUploadItemDTO.getWtn());

		if (OrderActionCodes.INSTALL_STRING.equalsIgnoreCase(bulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType()) && !StringUtils.isEmpty(customerID)
				&& !customerID.equalsIgnoreCase(bulkOrderUploadItemDTO.getBulkOrderUploadDTO().getCustomerId())) {
			key = key + "_" + customerID;
		}

		String featureIds = bulkOrderUploadItemDTO.getFeatureId();
		if (featureIds == null) {
			return key;
		}

		String[] featureId = featureIds.split(",");
		for (String fId : featureId) {
			key = key + "_" + fId;
		}

		if (bulkOrderUploadItemDTO.getCodeDigit() == null && bulkOrderUploadItemDTO.getCodeTable() == null) {
			return key;
		}

		key = key + "_" + bulkOrderUploadItemDTO.getCodeDigit() + "_" + bulkOrderUploadItemDTO.getCodeTable();

		return key;
	}

	/**
	 * Set jurisdiction value based on the UI selection
	 * 
	 * @param bulkOrderUploadItemDTO
	 * @return
	 */
	public String getJurisdiction(BulkOrderUploadItemDTO bulkOrderUploadItemDTO) {
		if ("Inter & Intra LATA".equalsIgnoreCase(bulkOrderUploadItemDTO.getJurisdiction())) {
			return "B";
		} else if ("Inter LATA".equalsIgnoreCase(bulkOrderUploadItemDTO.getJurisdiction())) {
			return "E";
		}
		return null;
	}

	/**
	 * This method is to retrieve customer details from sandstone
	 * 
	 * @param orderVO
	 * @return
	 * @throws SLDBException
	 */
	private String getCrc(String orgId, String customerID, String cic) throws SLDBException {
		CrcVO crcVO = dataMSClient.getCrc(orgId, customerID, cic);
		String crc = StringUtils.isEmpty(crcVO.getCrc()) ? "WCG" : crcVO.getCrc();
		return crc;
	}

	/**
	 * This method is to read the NS Bulk File and create the List of
	 * BulkOrderUploadItemDTO
	 * 
	 * @param fileName
	 * @param void
	 * @param bulkUploadOrderId
	 * @return
	 * @throws SLDBException
	 */

	public List<BulkOrderUploadItemDTO> readBulkOrderNSTemplate(String fileName, Long voiceOrderId,
			String bulkOrderUploadId) throws Exception {

		List<BulkOrderUploadItemDTO> bulkOrderUploadItemDTOs = new ArrayList<BulkOrderUploadItemDTO>();
		BulkOrderUploadItemDTO prevBulkOrderUploadItemDTO = null;
		BulkOrderUploadItemDTO curBulkOrderUploadItemDTO = null;
		String reProvisionFlag = null;
		Map<String, Long> ponInfo = new HashMap<String, Long>();
		/* Read from the smb file */
		String url = "smb:" + folderLocation + "BulkOrdersArchive/" + fileName;
		NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(null, ftpUser, ftpPassword);
		SmbFile dir = new SmbFile(url, auth);

		BufferedReader reader = new BufferedReader(new InputStreamReader(new SmbFileInputStream(dir)));
		String line = reader.readLine();

		if (line.isEmpty()) {
			reader.close();
			throw new TollFreeOrderServiceException("@TollFreeOrderServiceManager process: Empty Bulk file ");
		}
		do {
			if (!line.isEmpty()) {
				if ("1S".equals(line.substring(10, 12).trim()) || "H".equals(line.substring(10, 12).trim())) {
					if (prevBulkOrderUploadItemDTO != curBulkOrderUploadItemDTO) {
						if (!BatchProcessConstants.BATCH_STATUS_ERROR_CAPS
								.equals(curBulkOrderUploadItemDTO.getStatus())) {
							curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_RECEIVED);

							validateNSBulkFile(curBulkOrderUploadItemDTO, reProvisionFlag, ponInfo);
						}
						bulkOrderUploadItemDTOs.add(curBulkOrderUploadItemDTO);
						prevBulkOrderUploadItemDTO = curBulkOrderUploadItemDTO;

					}
					if ("H".equals(line.substring(10, 12).trim()))
						break;
					curBulkOrderUploadItemDTO = new BulkOrderUploadItemDTO();

					NS1SBulkOrderVO nsData = NS1SBulkOrderVO.to1SObject(line);

					BulkOrderUploadDTO bulkOrderUploadDTO = new BulkOrderUploadDTO();
					if (StringUtils.isEmpty(nsData.getServiceLocationId())) {
						curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						curBulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
								"Missing required value - Column: ServiceLocationId   Offset: 64"));
					}

					CustomerVO customerVOBan = dataMSClient.retrieveServiceLocations("WCG", nsData.getCustomerId(),
							"1S");
					for (BanServiceLocationVO banServiceLocationVO : customerVOBan.getBanServiceLocationVOs()) {
						if (banServiceLocationVO.getAccountNumber() != null
								&& banServiceLocationVO.getServiceLocationId().equals(nsData.getServiceLocationId())) {
							bulkOrderUploadDTO.setBan(banServiceLocationVO.getAccountNumber());
							break;
						}
					}
					if (StringUtils.isEmpty(bulkOrderUploadDTO.getBan())) {
						curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						curBulkOrderUploadItemDTO
								.setComments(getErrorMessageInValidationMessageVO("Service Location does not exist."));
					}
					bulkOrderUploadDTO.setCreatedBy("BULKLOAD-BATCH");
					bulkOrderUploadDTO.setCreatedOn(new Date());
					bulkOrderUploadDTO.setFileName(fileName);
					bulkOrderUploadDTO.setFileType("BULK");
					bulkOrderUploadDTO.setModifiedBy("BULKLOAD-BATCH");
					bulkOrderUploadDTO.setModifiedOn(new Date());

					bulkOrderUploadDTO.setCustomerId(nsData.getCustomerId());
					bulkOrderUploadDTO.setOrderType(getOrderActionCode(nsData.getOrderType()));
					bulkOrderUploadDTO.setProduct(nsData.getProductId());
					bulkOrderUploadDTO.setVoId(voiceOrderId.toString());
					reProvisionFlag = null;
					if (OrderActionCodes.INSTALL_STRING.equals(bulkOrderUploadDTO.getOrderType())) {
						Long orderActionType = orderTollFreeFeatureRepository.getPrevOrderActionType(nsData.getWtn(),
								nsData.getCustomerId());
						if (orderActionType != null)
							if (orderActionType.intValue() != OrderActionCodes.DISCONNECT) {
								bulkOrderUploadDTO.setOrderType(OrderActionCodes.CHANGE_STRING);
								reProvisionFlag = "A";
							}
					}
					if ("P".equals(nsData.getOrderType())) {
						reProvisionFlag = "P";
						bulkOrderUploadDTO.setOrderType(OrderActionCodes.CHANGE_STRING);
					}
					if (StringUtils.isEmpty(nsData.getBtn())) {
						curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						curBulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
								"Missing required value - Column: BTN   Offset: 40 "));
					}
					if (StringUtils.isEmpty(nsData.getWtn())) {
						curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						curBulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
								"Missing required value - Column: WTN   Offset: 50 "));
					}

					if (StringUtils.isEmpty(bulkOrderUploadDTO.getOrderType())) {
						curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						curBulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
								"Missing required value - Column: OrderType   Offset: 13 "));
					}

					
					curBulkOrderUploadItemDTO.setBulkOrderUploadDTO(bulkOrderUploadDTO);
					curBulkOrderUploadItemDTO.setBtn(nsData.getBtn());
					curBulkOrderUploadItemDTO.setWtn(nsData.getWtn());
					curBulkOrderUploadItemDTO.setCic(nsData.getCic());

					if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getCic())) {
						curBulkOrderUploadItemDTO.setCic(dataMSClient.getDefaultCIC("WCG",
								bulkOrderUploadDTO.getCustomerId(), nsData.getServiceLocationId()));
					}

				} else if ("FT".equals(getStringValue(line, 10, 12))) {
					String featureId = getStringValue(line, 29, 39);
					String featureValue = getStringValue(line, 39, 89);

					if (StringUtils.isEmpty(featureId)) {
						curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						curBulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO(
								"Missing required value - Column: ProductOfferingId   Offset: 30"));
					}
					if ("D".equals(getStringValue(line, 12, 13))) {
						if ("381,7225,6785,382".contains(featureId.trim())) {
							curBulkOrderUploadItemDTO.setPic("Self");
						}
						if ("2227".contains(featureId.trim())) {
							curBulkOrderUploadItemDTO.setForceAniLoad("No");
						}
						if (getFeatureDetails().get(featureId.trim()) != null) {
							if (getFeatureDetails().get(featureId.trim()).contains("Validated Custom")) {
								curBulkOrderUploadItemDTO.setIsMandatoryFeature("D");
							}
							if (getFeatureDetails().get(featureId.trim()).contains("Unvalidated Acct Codes")) {
								curBulkOrderUploadItemDTO.setIsMandatoryFeature("D");
							}
						}
					} else {
						if ("381,6784,6785,7225,7431,1865,7224,382".contains(featureId.trim())) {
							if ("B".equals(featureValue.trim())) {
								curBulkOrderUploadItemDTO.setJurisdiction("Inter & Intra LATA");
							} else if ("E".equals(featureValue.trim())) {
								curBulkOrderUploadItemDTO.setJurisdiction("Inter LATA");
							}
						}
						if ("2227".contains(featureId.trim())) {
							curBulkOrderUploadItemDTO.setForceAniLoad("Yes");
						}
						if ("381,7225,6785,382".contains(featureId.trim())) {
							curBulkOrderUploadItemDTO.setPic("CTL");
						}
						if (getFeatureDetails().get(featureId.trim()) != null) {
							if (getFeatureDetails().get(featureId.trim()).contains("Validated Custom")) {
								/* Add Account Code name or ID based on this value */
								String featureAc = getStringValue(line, 39, 47);
								if (StringUtils.isNotEmpty(featureAc)) {
									CustomerVO customerVO = dataMSClient.fetchCodeTabList("WCG",
											curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getCustomerId());
									if (customerVO.getCodeTableVOs() != null
											&& !customerVO.getCodeTableVOs().isEmpty()) {
										Optional<CodeTableVO> codeTable = customerVO.getCodeTableVOs().stream()
												.filter(item -> item.getCodeTableName().equals(featureAc)).findFirst();
										if (codeTable.isPresent()) {
											curBulkOrderUploadItemDTO.setCodeDigit(codeTable.get().getCodeDigits());
											curBulkOrderUploadItemDTO.setIsMandatoryFeature(
													"Y".equals(codeTable.get().getNonMandatoryInd()) ? "N" : "Y");
										}
									}
								}
								curBulkOrderUploadItemDTO.setCodeTable(featureAc);
								if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getIsMandatoryFeature()))
									curBulkOrderUploadItemDTO.setIsMandatoryFeature("Y");
							}
							if (getFeatureDetails().get(featureId.trim()).contains("Unvalidated Acct Codes")) {
								curBulkOrderUploadItemDTO
										.setIsMandatoryFeature("Y".equals(featureValue.trim()) ? "N" : "Y");
							}
						}
						if (!("381,6784,6785,7225,7431,1865,7224,2227,382".contains(featureId.trim()))) {
							if (curBulkOrderUploadItemDTO.getFeatureId() == null) {
								curBulkOrderUploadItemDTO.setFeatureId(featureId);
							} else {
								curBulkOrderUploadItemDTO
										.setFeatureId(curBulkOrderUploadItemDTO.getFeatureId() + "," + featureId);
							}
						}
					}
				}
			}
			line = reader.readLine();
		} while (line != null);

		reader.close();

		return bulkOrderUploadItemDTOs;
	}

	/**
	 * This method is to send the data as string from the line
	 * 
	 * @param line
	 * @return
	 * @throws SLDBException
	 */

	private String getStringValue(String line, int startIndex, int endIndex) {
		if (line.length() < startIndex)
			return "";
		if (line.length() < endIndex)
			return line.substring(startIndex, line.length()).trim();
		return line.substring(startIndex, endIndex).trim();
	}

	/**
	 * This method is to retrieve default customer features and update the Item
	 * 
	 * @param curBulkOrderUploadItemDTO
	 * @return
	 * @throws SLDBException
	 */

	private void addDefaultFeature(BulkOrderUploadItemDTO curBulkOrderUploadItemDTO) {
		try {
			String controlGroupId = getControlGroupId(curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getBan(),
					curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getCustomerId());
			if (controlGroupId == null)
				return;
			CustomerVO customer = dataMSClient.getDefaultFetaures("WCG",
					curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getProduct(), controlGroupId);
			if (customer != null) {
				for (ProductFeaturesVO feature : customer.getProductFeaturesVOs()) {

					if ("381,6784,6785,7225,7431,1865,7224".contains(feature.getFeatureOfferingId())
							&& StringUtils.isEmpty(curBulkOrderUploadItemDTO.getJurisdiction())) {
						curBulkOrderUploadItemDTO.setJurisdiction("Inter & Intra LATA");
					}
					if ("2227".equals(feature.getFeatureOfferingId())
							&& StringUtils.isEmpty(curBulkOrderUploadItemDTO.getForceAniLoad())) {
						curBulkOrderUploadItemDTO.setForceAniLoad("Yes");
					}
					if ("381".equals(feature.getFeatureOfferingId())
							&& StringUtils.isEmpty(curBulkOrderUploadItemDTO.getPic())) {
						curBulkOrderUploadItemDTO.setPic("CTL");
					}
				}
			}
			if (curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType()
					.equals(OrderActionCodes.INSTALL_STRING)) {
				if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getJurisdiction()))
					curBulkOrderUploadItemDTO.setJurisdiction("Inter & Intra LATA");
				if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getForceAniLoad()))
					curBulkOrderUploadItemDTO.setForceAniLoad("No");
				if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getPic()))
					curBulkOrderUploadItemDTO.setPic("Self");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * It reads the features from property file and creates the Map<String, String>
	 * (featureId and description)
	 * 
	 * @return
	 */
	private Map<String, String> getFeatureDetails() {
		Map<String, String> featureDetails = new HashMap<String, String>();

		for (String featureGroup : featuresGroup) {
			String[] features = featureGroup.split(":");
			featureDetails.put(features[0], features[1]);
		}

		return featureDetails;
	}

	/**
	 * It reads the getControlGroupId from BAN and Customer Id
	 * 
	 * 
	 * @return
	 */

	private String getControlGroupId(String ban, String customerId) {
		String controlGroupId = null;
		CustomerVO customerVOBan;
		try {
			customerVOBan = dataMSClient.retrieveServiceLocations("WCG", customerId, "1S");

			for (BanServiceLocationVO banServiceLocationVO : customerVOBan.getBanServiceLocationVOs()) {
				if (banServiceLocationVO.getAccountNumber() != null
						&& banServiceLocationVO.getAccountNumber().equals(ban)) {
					controlGroupId = banServiceLocationVO.getControlGroupId();
					break;
				}
			}
		} catch (SLDBException e) {

			e.printStackTrace();
		}
		return controlGroupId;
	}

	/**
	 * It Creates the corresponding Order Action Type
	 * 
	 * 
	 * @return
	 */

	public String getOrderActionCode(String actionCode) {
		String orderActionCode = null;
		switch (actionCode) {
		case "A":
			orderActionCode = OrderActionCodes.INSTALL_STRING;
			break;
		case "C":
			orderActionCode = OrderActionCodes.CHANGE_STRING;
			break;
		case "D":
			orderActionCode = OrderActionCodes.DISCONNECT_STRING;
			break;
		case "R":
			orderActionCode = OrderActionCodes.RENEW_STRING;
			break;

		case "B":
			orderActionCode = OrderActionCodes.BLOCK_STRING;
			break;
		case "U":
			orderActionCode = OrderActionCodes.UNBLOCK_STRING;
			break;
		default:
			break;
		}
		return orderActionCode;
	}

	/**
	 * It Creates the Error message in validation Message VO
	 * 
	 * 
	 * @return
	 */
	private String getErrorMessageInValidationMessageVO(String message) {
		ValidationMessageVO validationMessageVO = new ValidationMessageVO();
		validationMessageVO.setCode("08");
		validationMessageVO.setDisplayMessage(message);
		return validationMessageVO.toString();
	}

	/**
	 * Validation for the NS Bulk Processing
	 * 
	 * 
	 * @return
	 */

	private void validateNSBulkFile(BulkOrderUploadItemDTO curBulkOrderUploadItemDTO, String reProvisionFlag,
			Map<String, Long> ponInfo) throws SLDBException {

		if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getProduct())) {
			curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
			curBulkOrderUploadItemDTO
					.setComments(getErrorMessageInValidationMessageVO("A product offering is required."));
			return;
		}

		if (curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType().equals(OrderActionCodes.INSTALL_STRING)
				|| curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType()
						.equals(OrderActionCodes.CHANGE_STRING)) {
			addDefaultFeature(curBulkOrderUploadItemDTO);
		}

		Long slOrderStatus = orderTollFreeFeatureRepository.getPrevSlOrderStatus(curBulkOrderUploadItemDTO.getWtn());

		if (slOrderStatus != null) {
			if (slOrderStatus != OrderStatusConstants.ORDER_STATUS_COMPLETE) {
				curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
				curBulkOrderUploadItemDTO.setComments(getErrorMessageInValidationMessageVO("ANI has a pending Order "));
				return;
			}
		}

		if (curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType().equals(OrderActionCodes.BLOCK_STRING)) {
			if (!StringUtils.isEmpty(curBulkOrderUploadItemDTO.getJurisdiction())
					|| !StringUtils.isEmpty(curBulkOrderUploadItemDTO.getForceAniLoad())
					|| !StringUtils.isEmpty(curBulkOrderUploadItemDTO.getPic())) {
				curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
				curBulkOrderUploadItemDTO.setComments(
						getErrorMessageInValidationMessageVO("Block Order requires a Block Features only."));
				return;
			}
			if (!StringUtils.isEmpty(curBulkOrderUploadItemDTO.getFeatureId())) {
				for (String f : curBulkOrderUploadItemDTO.getFeatureId().split(",")) {
					if (!getFeatureDetails().get(f).contains("Block")) {
						curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						curBulkOrderUploadItemDTO.setComments(
								getErrorMessageInValidationMessageVO("Block Order requires a Block Features only."));
						return;
					}
				}
			} else {
				curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
				curBulkOrderUploadItemDTO
						.setComments(getErrorMessageInValidationMessageVO("Block Order requires a Block Features."));
				return;
			}
		}

		if (!curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType().equals(OrderActionCodes.INSTALL_STRING)) {
			OrderTollFreeFeatureDTO prevOrderTollfree = orderTollFreeFeatureRepository.getPreviousOrderTollFreeFeatures(
					curBulkOrderUploadItemDTO.getWtn(),
					curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getCustomerId());
			if (prevOrderTollfree != null) {
				if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getFeatureId())) {
					if (!StringUtils.isEmpty(prevOrderTollfree.getUnvalidatedAC())
							&& (!"D".equals(curBulkOrderUploadItemDTO.getIsMandatoryFeature()))) {
						curBulkOrderUploadItemDTO.setFeatureId(prevOrderTollfree.getUnvalidatedAC());
						if ("U".equals(prevOrderTollfree.getAccountCodeEsf()))
							curBulkOrderUploadItemDTO.setIsMandatoryFeature("Y");
						if ("N".equals(prevOrderTollfree.getAccountCodeEsf()))
							curBulkOrderUploadItemDTO.setIsMandatoryFeature("N");
					}
					if (!StringUtils.isEmpty(prevOrderTollfree.getValidatedAC())
							&& (!"D".equals(curBulkOrderUploadItemDTO.getIsMandatoryFeature()))) {
						curBulkOrderUploadItemDTO.setFeatureId(prevOrderTollfree.getValidatedAC());
						curBulkOrderUploadItemDTO.setCodeTable(prevOrderTollfree.getAcTableName());
						curBulkOrderUploadItemDTO.setCodeDigit(prevOrderTollfree.getAcDigits());
						if ("C".equals(prevOrderTollfree.getAccountCodeEsf()))
							curBulkOrderUploadItemDTO.setIsMandatoryFeature("Y");
						if ("Y".equals(prevOrderTollfree.getAccountCodeEsf()))
							curBulkOrderUploadItemDTO.setIsMandatoryFeature("N");
					}
					if ("D".equals(curBulkOrderUploadItemDTO.getIsMandatoryFeature()))
						curBulkOrderUploadItemDTO.setIsMandatoryFeature(null);
					if (!StringUtils.isEmpty(prevOrderTollfree.getOtherFeat())) {
						curBulkOrderUploadItemDTO.setFeatureId(prevOrderTollfree.getOtherFeat());
					}
				}

				if (curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType()
						.equals(OrderActionCodes.BLOCK_STRING)
						|| curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType()
								.equals(OrderActionCodes.UNBLOCK_STRING)
						|| curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType()
								.equals(OrderActionCodes.DISCONNECT_STRING)) {
					if ("B".equals(prevOrderTollfree.getJurisdiction())) {
						curBulkOrderUploadItemDTO.setJurisdiction("Inter & Intra LATA");
					} else if ("E".equals(prevOrderTollfree.getJurisdiction())) {
						curBulkOrderUploadItemDTO.setJurisdiction("Inter LATA");
					}
					curBulkOrderUploadItemDTO.setForceAniLoad(prevOrderTollfree.getForcedANI());
					curBulkOrderUploadItemDTO.setPic(prevOrderTollfree.getPicRequest());
				} else if (curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType()
						.equals(OrderActionCodes.CHANGE_STRING) ) {
					if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getJurisdiction())) {
						if ("B".equals(prevOrderTollfree.getJurisdiction())) {
							curBulkOrderUploadItemDTO.setJurisdiction("Inter & Intra LATA");
						} else if ("E".equals(prevOrderTollfree.getJurisdiction())) {
							curBulkOrderUploadItemDTO.setJurisdiction("Inter LATA");
						}
					}
					else {
						if ((reProvisionFlag == null)  &&(!("B".equals(prevOrderTollfree.getJurisdiction()) && 
									"Inter & Intra LATA".equals(curBulkOrderUploadItemDTO.getJurisdiction()))
							|| ("E".equals(prevOrderTollfree.getJurisdiction()) &&
								"Inter LATA".equals(curBulkOrderUploadItemDTO.getJurisdiction())))){
									/*Jurisdiction change not allowed */
							curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
							curBulkOrderUploadItemDTO.setComments(
									getErrorMessageInValidationMessageVO("Invalid Change:  Change order not applicable for JI Feature changes."));
							return;
						}
					}
					if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getForceAniLoad()))
						curBulkOrderUploadItemDTO.setForceAniLoad(prevOrderTollfree.getForcedANI());
					if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getPic()))
						curBulkOrderUploadItemDTO.setPic(prevOrderTollfree.getPicRequest());
					String featureIds = StringUtils.isEmpty(prevOrderTollfree.getOtherFeat()) ? null
							: prevOrderTollfree.getOtherFeat();
					if (!StringUtils.isEmpty(prevOrderTollfree.getUnvalidatedAC())) {
						featureIds = featureIds != null ? featureIds + "," + prevOrderTollfree.getUnvalidatedAC()
								: prevOrderTollfree.getUnvalidatedAC();
					}
					if (!StringUtils.isEmpty(prevOrderTollfree.getValidatedAC())) {
						featureIds = featureIds != null ? featureIds + "," + prevOrderTollfree.getValidatedAC()
								: prevOrderTollfree.getValidatedAC();
					}
					if (curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType().equals(OrderActionCodes.CHANGE_STRING)
							&& ("P".equals(reProvisionFlag) ||("A".equals(reProvisionFlag))))  {
						String orderActivtyStatus = orderTollFreeFeatureRepository
								.getPrevPICOrderActivityStatus(curBulkOrderUploadItemDTO.getWtn());

						if (orderActivtyStatus != null) {
							
							if (orderActivtyStatus.equals("7") || orderActivtyStatus.equals("2")) {
								/* Call the re-start Activity if an error activity is available */
								Long orderActivityPK = orderTollFreeFeatureRepository
										.getPrevPICOrderActivityPK(curBulkOrderUploadItemDTO.getWtn());
								try {
									if (workflowClient.restartActivity(orderActivityPK)) {
										curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_SUCCESS);
										curBulkOrderUploadItemDTO
												.setComments("Reprovisioned the PIC step");
										return;
									} else {
										curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
										curBulkOrderUploadItemDTO.setComments(
												getErrorMessageInValidationMessageVO("Reprovisioned failed in the PIC step"));
										return;
									}
								} catch (SLDBException e) {
									curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
									curBulkOrderUploadItemDTO.setComments(
											getErrorMessageInValidationMessageVO("Reprovisioned failed in the PIC step"));
									e.printStackTrace();
									return;
								}

							} else if (orderActivtyStatus.equals("3")) {
								/* Change Order */
								curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_RECEIVED);
							}
						}
					}
					if (prevOrderTollfree.getAccountNumber()
							.equals(curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getBan())
							&& prevOrderTollfree.getBtn().equals(curBulkOrderUploadItemDTO.getBtn())
							&& prevOrderTollfree.getProductOfferingID()
									.equals(curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getProduct())
							&& prevOrderTollfree.getForcedANI().equals(curBulkOrderUploadItemDTO.getForceAniLoad())
							&& prevOrderTollfree.getPicRequest().equals(curBulkOrderUploadItemDTO.getPic())
							&& (("B".equals(prevOrderTollfree.getJurisdiction())
									&& "Inter & Intra LATA".equals(curBulkOrderUploadItemDTO.getJurisdiction()))
									|| ("E".equals(prevOrderTollfree.getJurisdiction())
											&& "Inter LATA".equals(curBulkOrderUploadItemDTO.getJurisdiction())))
							&& Objects.equals(featureIds, curBulkOrderUploadItemDTO.getFeatureId())){
						curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
						curBulkOrderUploadItemDTO
								.setComments(getErrorMessageInValidationMessageVO("No changes detected in the Order."));
						return;
					}
					
				}
			} else if (curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType()
					.equals(OrderActionCodes.UNBLOCK_STRING)) {
				prevOrderTollfree = orderTollFreeFeatureRepository.getPrevCustActiveOrderTollFreeFeatures(
								curBulkOrderUploadItemDTO.getWtn());
				if(prevOrderTollfree != null) {
					if(prevOrderTollfree.getLastUpdatedUser().equals("DATA MIGRATION")) {
						if ("B".equals(prevOrderTollfree.getJurisdiction())) {
							curBulkOrderUploadItemDTO.setJurisdiction("Inter & Intra LATA");
						} else if ("E".equals(prevOrderTollfree.getJurisdiction())) {
							curBulkOrderUploadItemDTO.setJurisdiction("Inter LATA");
						}
						curBulkOrderUploadItemDTO.setForceAniLoad(prevOrderTollfree.getForcedANI());						
						curBulkOrderUploadItemDTO.setPic(prevOrderTollfree.getPicRequest());
					}
				}
				else {
					curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
					curBulkOrderUploadItemDTO
							.setComments(getErrorMessageInValidationMessageVO("ANI is not active for performing "
									+ curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType() + " Operation "));
					return;
				}
			}
			else {
				curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
				curBulkOrderUploadItemDTO
						.setComments(getErrorMessageInValidationMessageVO("ANI is not active for performing "
								+ curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType() + " Operation "));
				return;
			}
		}
		if (curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getOrderType().equals(OrderActionCodes.UNBLOCK_STRING)) {
			Long orderActionType = orderTollFreeFeatureRepository.getPrevOrderActionType(
					curBulkOrderUploadItemDTO.getWtn(),
					curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getCustomerId());
			if (orderActionType.intValue() != OrderActionCodes.BLOCK) {
				curBulkOrderUploadItemDTO.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
				curBulkOrderUploadItemDTO.setComments(
						getErrorMessageInValidationMessageVO("Active ANI has a no Block Internt'l/Caribbean Feature."));
				return;
			}
		}

		
		if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getForceAniLoad()))
			curBulkOrderUploadItemDTO.setForceAniLoad("No");
		if (StringUtils.isEmpty(curBulkOrderUploadItemDTO.getPic()))
			curBulkOrderUploadItemDTO.setPic("Self");

		validateAndGeneratePON(curBulkOrderUploadItemDTO,
				curBulkOrderUploadItemDTO.getBulkOrderUploadDTO().getCustomerId(), ponInfo);
	}
}
