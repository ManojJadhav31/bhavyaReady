package com.level3.voice.tollfree.processor;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.tollfree.client.WorkflowClient;

/**
 * Async process to trigger the workflow with the 
 * salesorder id information.
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Service
public class OrderSubmitAsyncProcessor {
    private static final Logger LOGGER = Logger.getLogger(OrderSubmitAsyncProcessor.class);
    
    @Autowired
    WorkflowClient workflowClient; 

    @Async("ldOrderSubmitProcessorExecutor")
    public void submitOrder(Long pon) throws SLDBException{
        try {
//        	orderProcessorFactory.getBean(request).process(request);
        	workflowClient.submitStartPonWorkflow(pon);
        } catch (Exception e) {
            LOGGER.error(e, e);
        }
    }
}