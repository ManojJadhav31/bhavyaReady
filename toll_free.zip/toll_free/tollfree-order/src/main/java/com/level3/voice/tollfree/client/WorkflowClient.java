package com.level3.voice.tollfree.client;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.common.exception.SLDBException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/**
 * Client to interact with workflow microservice
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class WorkflowClient {

	private static final Logger LOGGER = Logger.getLogger(WorkflowClient.class);

	@Value("${tollfree.workflow.client.url}")
	private String baseUrl;

	@Value("${tollfree.workflow.client.connect.timeout.ms}")
	private Integer connectTimeoutMs;

	@Value("${tollfree.workflow.client.read.timeout.ms}")
	private Integer readTimeoutMs;

	@Value("${tollfree.workflow.client.retry.count.int}")
	private Integer retryCount;

	@Value("${tollfree.workflow.client.retry.interval.ms}")
	private Integer retryIntervalMs;

	WebResource webResource;

	@PostConstruct
	public void init() throws Exception {
		Client client = Client.create();
		client.setReadTimeout(readTimeoutMs);
		client.setConnectTimeout(connectTimeoutMs);
		webResource = client.resource(this.baseUrl);
	}

	/**
	 * Submit start workflow for pon
	 * 
	 * @param slOrderId
	 * @throws SLDBException
	 */
	@Transactional
	public void submitOrderToWorkflow(Long pon) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/order/start/pon/";

		WebResource.Builder builder = webResource.path(serviceURL + pon).entity(null, MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse clientResponse = builder.post(ClientResponse.class);
			checkHttpResponse(clientResponse);
			if (clientResponse.getStatus() != 200 && clientResponse.getStatus() != 204) {
				throw new Exception("Pon " + pon + " workflow submission failed.");
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while Submitting to Workflow" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while submitting to workflow" + errorInfo);
		}

	}

	/**
	 * Submit start workflow for slorderid
	 * 
	 * @param slOrderId
	 * @throws SLDBException
	 */
	@Transactional
	public void submitStartWorkflow(Long slOrderId) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/order/start/slOrder/";

		WebResource.Builder builder = webResource.path(serviceURL + slOrderId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse clientResponse = builder.post(ClientResponse.class);
			checkHttpResponse(clientResponse);
			if (clientResponse.getStatus() != 200 && clientResponse.getStatus() != 204) {
				throw new Exception("Order " + slOrderId + " workflow submission failed.");
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while Submitting to Workflow" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while submitting to workflow" + errorInfo);
		}

	}

	/**
	 * Submit start workflow for slorderid
	 * 
	 * @param pon
	 * @throws SLDBException
	 */
	@Transactional
	public void submitStartPonWorkflow(Long pon) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/order/start/pon/";

		WebResource.Builder builder = webResource.path(serviceURL + pon + "/orders")
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse clientResponse = builder.post(ClientResponse.class);
			checkHttpResponse(clientResponse);
			if (clientResponse.getStatus() != 200 && clientResponse.getStatus() != 204) {
				throw new Exception("Pon " + pon + " workflow submission failed.");
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while Submitting to @submitStartPonWorkflow Workflow" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while submitting to @submitStartPonWorkflow workflow" + errorInfo);
		}

	}

	/**
	 * Check http response.
	 * 
	 * @param response the response
	 * @throws Exception the exception
	 */
	private void checkHttpResponse(ClientResponse response) throws SLDBException {
		if (response.getStatus() != 200) {
			LOGGER.error("Bad HTTP status returned while trying to obtain info from Service Availatbilty. Status: "
					+ response.getStatus() + response.getEntity(String.class));
			throw new SLDBException(
					"Bad HTTP status returned while  trying to obtain info from Service Availatbilty. Status: "
							+ response.getStatus());
		}
	}

	/**
	 * Restart Activity in with orderActivityPk
	 * 
	 * @param orderActivityPk
	 * @throws SLDBException
	 */
	@Transactional
	public boolean restartActivity(Long orderActivityPK) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/order/restartactivity";

		MultivaluedMap<String, String> queryParams = new MultivaluedHashMap<>();
		queryParams.add("orderActivityPk", orderActivityPK.toString());
		queryParams.add("userName", "BULKLOAD-BATCH");

		WebResource.Builder builder = webResource.path(serviceURL).queryParams(queryParams)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse clientResponse = builder.put(ClientResponse.class);
			if (clientResponse.getStatus() != 200 && clientResponse.getStatus() != 204) {
				return false;
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while Restarting Activity" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while Restarting  Activity" + errorInfo);
		}
		return true;

	}

}
