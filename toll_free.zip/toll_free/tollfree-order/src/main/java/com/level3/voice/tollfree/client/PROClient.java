package com.level3.voice.tollfree.client;

import javax.annotation.PostConstruct;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.CacheConstants;
import com.level3.voice.common.util.SecurityUtil;
import com.level3.voice.tollfree.model.Switches;
import com.level3.voice.tollfree.model.TrunkGroups;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/**
 * Client to interact with pro tollfree APIs
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class PROClient {

	private static final Logger LOGGER = Logger.getLogger(PROClient.class);

	@Value("${tollfree.mediation.client.url}")
	private String baseUrl;

	@Value("${tollfree.mediation.client.connect.timeout.ms}")
	private Integer connectTimeoutMs;

	@Value("${tollfree.mediation.client.read.timeout.ms}")
	private Integer readTimeoutMs;

	@Value("${tollfree.mediation.client.retry.count.int}")
	private Integer retryCount;

	@Value("${tollfree.mediation.client.retry.interval.ms}")
	private Integer retryIntervalMs;

	@Value("${sldb.3flow.application.secret}")
	private String digestKeyValue;

	@Value("${sldb.3flow.application.key}")
	private String applicationKey;

	ObjectMapper objectMapper;

	WebResource webResource;

	@PostConstruct
	public void init() throws Exception {
		Client client = Client.create();
		client.setReadTimeout(readTimeoutMs);
		client.setConnectTimeout(connectTimeoutMs);
		objectMapper = new ObjectMapper();
		webResource = client.resource(this.baseUrl);
	}

	/**
	 * This method is to retrieve the switches associated to Ban
	 * 
	 * @param ban
	 * @return
	 * @throws Exception
	 */
	@Audited
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":retrieveSwitchesByBan")
	public Switches retrieveSwitchesByBan(String ban) throws Exception {
		Switches switches = null;
		String serviceURL = "/Inventory/v3/Voice/switch/";

		WebResource wr = webResource.path(serviceURL).queryParam("billingAccountNumber", ban);

		WebResource.Builder builder = SecurityUtil
				.createSecurityHeader(wr, applicationKey, digestKeyValue, "Tollfree-Micro-Mediation")
				.accept(MediaType.APPLICATION_JSON_TYPE);

		try {
			ClientResponse response = builder.get(ClientResponse.class);
			switches = unmarshalSwitches(response.getEntity(String.class));
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieveSwitchesByBan " + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieveSwitchesByBan " + errorInfo);
		}
		return switches;
	}

	/**
	 * Unmarshal the response as Switches
	 * 
	 * @param response
	 * @return
	 * @throws SLDBException
	 */
	private Switches unmarshalSwitches(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		Switches result = null;
		try {
			result = new Gson().fromJson(response, Switches.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}

	/**
	 * This method is to retrieve the trunk groups associated to BAN and selected
	 * switch
	 * 
	 * @param ban
	 * @param switchfinalNumber
	 * @return
	 * @throws Exception
	 */
	@Audited
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":retrieveTrunkGroupsByBanSwitch")
	public TrunkGroups retrieveTrunkGroupsByBanSwitch(String ban, String switchfinalNumber) throws Exception {
		TrunkGroups trunkGroups = null;
		String serviceURL = "/Inventory/v3/Voice/trunkGroup/";

		WebResource wr = webResource.path(serviceURL).queryParam("billingAccountNumber", ban)
				.queryParam("switchFinalNumber", switchfinalNumber);

		WebResource.Builder builder = SecurityUtil
				.createSecurityHeader(wr, applicationKey, digestKeyValue, "Tollfree-Micro-Mediation")
				.accept(MediaType.APPLICATION_JSON_TYPE);

		try {
			ClientResponse response = builder.get(ClientResponse.class);
			trunkGroups = unmarshalTrunkGroups(response.getEntity(String.class));
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieveTrunkGroupsByBanSwitch " + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieveTrunkGroupsByBanSwitch " + errorInfo);
		}
		return trunkGroups;
	}

	/**
	 * Unmarshal the response as TrunkGroups
	 * 
	 * @param response
	 * @return
	 * @throws SLDBException
	 */
	private TrunkGroups unmarshalTrunkGroups(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		TrunkGroups result = null;
		try {
			result = new Gson().fromJson(response, TrunkGroups.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}

}
