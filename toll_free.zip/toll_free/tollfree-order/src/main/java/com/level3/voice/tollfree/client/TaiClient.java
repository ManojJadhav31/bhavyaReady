package com.level3.voice.tollfree.client;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import javax.ws.rs.core.MediaType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.level3.voice.common.exception.SLDBException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

@Component
public class TaiClient {

	private static final Logger LOGGER = Logger.getLogger(TaiClient.class);

	@Value("${tollfree.tai.client.url}")
	private String baseUrl;

	@Value("${tollfree.tai.client.connect.timeout.ms}")
	private Integer connectTimeoutMs;

	@Value("${tollfree.tai.client.read.timeout.ms}")
	private Integer readTimeoutMs;

	ObjectMapper objectMapper;

	WebResource webResource;

	@PostConstruct
	public void init() throws Exception {
		Client client = Client.create();
		client.setReadTimeout(readTimeoutMs);
		client.setConnectTimeout(connectTimeoutMs);
		objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		webResource = client.resource(this.baseUrl);
	}

	@Transactional
	public String getOcnData(String tn) throws SLDBException {
		String serviceURL = this.baseUrl + "/ocn/";

		WebResource.Builder builder = webResource.path("/ocn/" + tn).entity(null, MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse clientResponse = null;
		try {
			clientResponse = builder.get(ClientResponse.class);
			checkHttpResponse(clientResponse);
			if (clientResponse.getStatus() != 200 && clientResponse.getStatus() != 204) {
				throw new Exception("TN " + tn + " submission failed.");
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while Submitting to Workflow" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while submitting to workflow" + errorInfo);
		}
		return clientResponse == null ? null : clientResponse.getEntity(String.class);
	}

	private void checkHttpResponse(ClientResponse response) throws SLDBException {
		if (response.getStatus() != 200) {
			LOGGER.error("Bad HTTP status returned while trying to obtain info from Service Availatbilty. Status: "
					+ response.getStatus() + response.getEntity(String.class));
			throw new SLDBException(
					"Bad HTTP status returned while  trying to obtain info from Service Availatbilty. Status: "
							+ response.getStatus());
		}
	}

}
