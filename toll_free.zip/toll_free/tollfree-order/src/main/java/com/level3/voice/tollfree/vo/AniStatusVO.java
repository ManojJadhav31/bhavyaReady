package com.level3.voice.tollfree.vo;


public class AniStatusVO {
	
	 private String statusCount;
	 private String status;
	 
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusCount() {
		return statusCount;
	}
	public void setStatusCount(String statusCount) {
		this.statusCount = statusCount;
	}
	 
}
