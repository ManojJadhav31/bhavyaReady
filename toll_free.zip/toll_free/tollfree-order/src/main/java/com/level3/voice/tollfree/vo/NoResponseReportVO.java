package com.level3.voice.tollfree.vo;

public class NoResponseReportVO {
	
	private String companyName;
	private String oCN;
	private String customerName;
	private String customerId;
	private String entryDate;
	private String provisionBegin;
	private Integer DaysElapsed;
	private String btn;
	private String wtn;
	private String jurisdication;
	private String orderNumber;
	
	
	
	
	
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getoCN() {
		return oCN;
	}
	public void setoCN(String oCN) {
		this.oCN = oCN;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public Integer getDaysElapsed() {
		return DaysElapsed;
	}
	public void setDaysElapsed(Integer daysElapsed) {
		DaysElapsed = daysElapsed;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public String getWtn() {
		return wtn;
	}
	public void setWtn(String wtn) {
		this.wtn = wtn;
	}
	public String getJurisdication() {
		return jurisdication;
	}
	public void setJurisdication(String jurisdication) {
		this.jurisdication = jurisdication;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	public String getProvisionBegin() {
		return provisionBegin;
	}
	public void setProvisionBegin(String provisionBegin) {
		this.provisionBegin = provisionBegin;
	}
	
		

}