package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class ActivityChartVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String year;
	private String status;
	private Long noOfActivities;
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getNoOfActivities() {
		return noOfActivities;
	}
	public void setNoOfActivities(Long noOfActivities) {
		this.noOfActivities = noOfActivities;
	}
	
	
}
