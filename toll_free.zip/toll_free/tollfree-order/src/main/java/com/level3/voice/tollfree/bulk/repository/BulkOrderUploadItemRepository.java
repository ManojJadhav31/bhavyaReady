package com.level3.voice.tollfree.bulk.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadDTO;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadItemDTO;
import com.level3.voice.tollfree.persist.dto.ChargeDTO;

/**
 * This repository is to retrieve/persist bulk upload item details from BulkOrderUploadItemDTO table
 * 
 * @author <a href="mailto:manjunatha.d@centurylink.com">Manjunatha D</a>
 */
@Component
public interface BulkOrderUploadItemRepository extends JpaRepository<BulkOrderUploadItemDTO, Long> {

	@Query(value="select bui from BulkOrderUploadItemDTO bui, BulkOrderUploadDTO bu where bui.bulkOrderUploadDTO=bu and bu.voId = ?1")
	List<BulkOrderUploadItemDTO> findByVoId(String voId);

	@Query(value="select bui from BulkOrderUploadItemDTO bui, BulkOrderUploadDTO bu where bui.bulkOrderUploadDTO.id = ?1")
	List<BulkOrderUploadItemDTO> findByBulkOrderUpload(Long itemId);

}
