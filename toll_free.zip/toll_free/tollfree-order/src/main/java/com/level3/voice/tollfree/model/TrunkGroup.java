package com.level3.voice.tollfree.model;

import java.io.Serializable;
import java.util.Map;

/**
 * Model object to represent the TrunkGroup object sent from PRO
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class TrunkGroup implements Serializable {

	private static final long serialVersionUID = 1L;
	private String serviceType;
	private String orderId;
	private String direction;
	private String tgClli;
	private String switchFinalNumber;
	private String signalingProtocol;
	private String status;
	private String tgNumber;
	private String pathName;
	private String updateAppId;
	private int updateDate;
	private int objectId;
	private String createLogonId;
	private int createDate;
	private String updateLogonId;
	private String createUserId;
	private String createAppId;
	private String updateUserId;
	private Map<String, String> metaDataMap;

	/**
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * @return the direction
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}

	/**
	 * @return the tgClli
	 */
	public String getTgClli() {
		return tgClli;
	}

	/**
	 * @param tgClli the tgClli to set
	 */
	public void setTgClli(String tgClli) {
		this.tgClli = tgClli;
	}

	/**
	 * @return the switchFinalNumber
	 */
	public String getSwitchFinalNumber() {
		return switchFinalNumber;
	}

	/**
	 * @param switchFinalNumber the switchFinalNumber to set
	 */
	public void setSwitchFinalNumber(String switchFinalNumber) {
		this.switchFinalNumber = switchFinalNumber;
	}

	/**
	 * @return the signalingProtocol
	 */
	public String getSignalingProtocol() {
		return signalingProtocol;
	}

	/**
	 * @param signalingProtocol the signalingProtocol to set
	 */
	public void setSignalingProtocol(String signalingProtocol) {
		this.signalingProtocol = signalingProtocol;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the tgNumber
	 */
	public String getTgNumber() {
		return tgNumber;
	}

	/**
	 * @param tgNumber the tgNumber to set
	 */
	public void setTgNumber(String tgNumber) {
		this.tgNumber = tgNumber;
	}

	/**
	 * @return the pathName
	 */
	public String getPathName() {
		return pathName;
	}

	/**
	 * @param pathName the pathName to set
	 */
	public void setPathName(String pathName) {
		this.pathName = pathName;
	}

	/**
	 * @return the updateAppId
	 */
	public String getUpdateAppId() {
		return updateAppId;
	}

	/**
	 * @param updateAppId the updateAppId to set
	 */
	public void setUpdateAppId(String updateAppId) {
		this.updateAppId = updateAppId;
	}

	/**
	 * @return the updateDate
	 */
	public int getUpdateDate() {
		return updateDate;
	}

	/**
	 * @param updateDate the updateDate to set
	 */
	public void setUpdateDate(int updateDate) {
		this.updateDate = updateDate;
	}

	/**
	 * @return the objectId
	 */
	public int getObjectId() {
		return objectId;
	}

	/**
	 * @param objectId the objectId to set
	 */
	public void setObjectId(int objectId) {
		this.objectId = objectId;
	}

	/**
	 * @return the createLogonId
	 */
	public String getCreateLogonId() {
		return createLogonId;
	}

	/**
	 * @param createLogonId the createLogonId to set
	 */
	public void setCreateLogonId(String createLogonId) {
		this.createLogonId = createLogonId;
	}

	/**
	 * @return the createDate
	 */
	public int getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(int createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the updateLogonId
	 */
	public String getUpdateLogonId() {
		return updateLogonId;
	}

	/**
	 * @param updateLogonId the updateLogonId to set
	 */
	public void setUpdateLogonId(String updateLogonId) {
		this.updateLogonId = updateLogonId;
	}

	/**
	 * @return the createUserId
	 */
	public String getCreateUserId() {
		return createUserId;
	}

	/**
	 * @param createUserId the createUserId to set
	 */
	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	/**
	 * @return the createAppId
	 */
	public String getCreateAppId() {
		return createAppId;
	}

	/**
	 * @param createAppId the createAppId to set
	 */
	public void setCreateAppId(String createAppId) {
		this.createAppId = createAppId;
	}

	/**
	 * @return the updateUserId
	 */
	public String getUpdateUserId() {
		return updateUserId;
	}

	/**
	 * @param updateUserId the updateUserId to set
	 */
	public void setUpdateUserId(String updateUserId) {
		this.updateUserId = updateUserId;
	}

	/**
	 * @return the metaDataMap
	 */
	public Map<String, String> getMetaDataMap() {
		return metaDataMap;
	}

	/**
	 * @param metaDataMap the metaDataMap to set
	 */
	public void setMetaDataMap(Map<String, String> metaDataMap) {
		this.metaDataMap = metaDataMap;
	}

}
