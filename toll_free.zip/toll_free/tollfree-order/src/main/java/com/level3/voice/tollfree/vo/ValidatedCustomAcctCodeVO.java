package com.level3.voice.tollfree.vo;

import java.io.Serializable;

/**
 * VO Object to hold the Validated Custom Acct Code properties
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class ValidatedCustomAcctCodeVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String codeDigits;
	private String codeTableName;
	private String codeTableId;

	public String getCodeTableName() {
		return codeTableName;
	}

	public void setCodeTableName(String codeTableName) {
		this.codeTableName = codeTableName;
	}

	/**
	 * @return the codeDigits
	 */
	public String getCodeDigits() {
		return codeDigits;
	}

	/**
	 * @param codeDigits
	 *            the codeDigits to set
	 */
	public void setCodeDigits(String codeDigits) {
		this.codeDigits = codeDigits;
	}

	public String getCodeTableId() {
		return codeTableId;
	}

	public void setCodeTableId(String codeTableId) {
		this.codeTableId = codeTableId;
	}
}
