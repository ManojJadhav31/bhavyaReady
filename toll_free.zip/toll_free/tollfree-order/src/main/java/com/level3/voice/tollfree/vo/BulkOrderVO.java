package com.level3.voice.tollfree.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.CompareToBuilder;


/**
 * VO to be returned to the caller each VO will hold a record sent in the
 * spreadsheet during upload
 * 
 * @author <a href="mailto:Manjunatha.d@centurylink.com">Manjunatha D</a>
 *
 */
public class BulkOrderVO extends TNDataVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String orderType;
	private String customerId;
	private String featureIds;
	private String product;

	/**
	 * @return the orderType
	 */
	public String getOrderType() {
		return orderType;
	}

	/**
	 * @param orderType the orderType to set
	 */
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the featureIds
	 */
	public String getFeatureIds() {
		return featureIds;
	}

	/**
	 * @param featureIds the featureIds to set
	 */
	public void setFeatureIds(String featureIds) {
		this.featureIds = featureIds;
	}

	/**
	 * @return the product
	 */
	public String getProduct() {
		return product;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(String product) {
		this.product = product;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkOrderVO [orderType=" + orderType + ", customerId=" + customerId + ", featureIds=" + featureIds
				+ ", product=" + product + ", getWtn()=" + getWtn() + ", getBtn()=" + getBtn() + ", getPic()="
				+ getPic() + ", getJurisdiction()=" + getJurisdiction() + ", getForceAniLoad()=" + getForceAniLoad()
				+ ", getCic()=" + getCic() + ", getCrc()=" + getCrc() + ", getValidationMessageVOs()="
				+ getValidationMessageVOs() + ", getFeatures()=" + getFeatures() + ", getValidatedCustomAcctCodeVO()="
				+ getValidatedCustomAcctCodeVO() + "]";
	}

}
