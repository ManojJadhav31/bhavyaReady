package com.level3.voice.tollfree.bulk.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadDTO;

/**
 * This repository is to retrieve/persist bulk upload details from BulkOrderUploadDTO table
 * 
 * @author <a href="mailto:manjunatha.d@centurylink.com">Manjunatha D</a>
 */
@Component
public interface BulkOrderUploadRepository extends JpaRepository<BulkOrderUploadDTO, Long> {

	@Query(value="select bu from BulkOrderUploadDTO bu where bu.voId = ?1")
	List<BulkOrderUploadDTO> findByVoId(String voId);
}
