package com.level3.voice.tollfree.bulk.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.level3.voice.tollfree.vo.OrderChartVO;

/**
 * This DTO is representation of the charge table
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */

@SqlResultSetMapping(
	    name="OrderChartResult",
	    classes={
	      @ConstructorResult(
	        targetClass=OrderChartVO.class,
	        columns={
	          @ColumnResult(name="month", type=String.class),
	          @ColumnResult(name="orderCount", type=Long.class)
	          })
	      }
)

@Entity
@Table(name = "BULK_ORDER_UPLOAD")
public class BulkOrderUploadDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bulk_order_upload_seq")
    @SequenceGenerator(sequenceName = "BULK_ORDER_UPLOAD_SEQ", allocationSize = 1, name = "bulk_order_upload_seq")
	@Column(name="ID")
	private Long id;
	
	@Column(name = "FILE_NAME")
	private String fileName;
	@Column(name = "FILE_DATA")
	private byte[] fileData;
	@Column(name = "FILE_TYPE")
	private String fileType;
	@Column(name = "VOID")
	private String voId;
	@Column(name = "PRODUCT")
	private String product;
	@Column(name = "BAN")
	private String ban;
	@Column(name = "CUSTOMER_ID")
	private String customerId;
	@Column(name = "ORDER_TYPE")
	private String orderType;
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "CREATED_ON")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;
	
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name = "MODIFIED_ON")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedOn;
	
	@OneToMany(mappedBy="bulkOrderUploadDTO",fetch=FetchType.EAGER)
	private List<BulkOrderUploadItemDTO> bulkOrderUploadItemDTOList;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFileData() {
		return fileData;
	}

	public void setFileData(byte[] bs) {
		this.fileData = bs;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getVoId() {
		return voId;
	}

	public void setVoId(String voId) {
		this.voId = voId;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getBan() {
		return ban;
	}

	public void setBan(String ban) {
		this.ban = ban;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public List<BulkOrderUploadItemDTO> getBulkOrderUploadItemDTOList() {
		return bulkOrderUploadItemDTOList;
	}

	public void setBulkOrderUploadItemDTOList(List<BulkOrderUploadItemDTO> bulkOrderUploadItemDTOList) {
		this.bulkOrderUploadItemDTOList = bulkOrderUploadItemDTOList;
	}
	
}
