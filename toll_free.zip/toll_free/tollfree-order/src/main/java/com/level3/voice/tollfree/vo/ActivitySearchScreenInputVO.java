package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class ActivitySearchScreenInputVO implements Serializable{
	
	private static final long serialVersionUID = 1L;


	private String voiceOrderId;
	private String activity;
	private String orderCompleteDate;
	private String tn;
	
	public String getVoiceOrderId() {
		return voiceOrderId;
	}
	public void setVoiceOrderId(String voiceOrderId) {
		this.voiceOrderId = voiceOrderId;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
		public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getOrderCompleteDate() {
		return orderCompleteDate;
	}
	public void setOrderCompleteDate(String orderCompleteDate) {
		this.orderCompleteDate = orderCompleteDate;
	}	

}
