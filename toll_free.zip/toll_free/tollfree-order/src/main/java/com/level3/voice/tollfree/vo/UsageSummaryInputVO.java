package com.level3.voice.tollfree.vo;

import java.util.Date;
/**

 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */

public class UsageSummaryInputVO {
	
	
	private Long account;
	private String serviceType;
	private Date fromDate;
	private Date toDate;
	
	
	
	
	
	public Long getAccount() {
		return account;
	}
	public void setAccount(Long account) {
		this.account = account;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	
	
	

}
