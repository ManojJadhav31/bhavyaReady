package com.level3.voice.tollfree.bulk.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.bulk.batch.processor.BulkOrderProcessor;

/**
 * The method gets executed after the job
 * 
 * @author <a href="mailto:manjunath.d@centurylink.com">Manju (ab68221)</a>
 */
@Component
public class ExcelUploadCompletionNotificationListener extends JobExecutionListenerSupport {

	private static final Logger logger = LoggerFactory.getLogger(ExcelUploadCompletionNotificationListener.class);

	@Autowired
	@Lazy
	private BulkOrderProcessor bulkOrderProcessor;

	@Override
	public void afterJob(JobExecution jobExecution) {
		logger.info("!!! After BulkOrderExcelUpload Job!");
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			JobParameter voId = jobExecution.getJobParameters().getParameters().get("VOICE_ORDER_ID");
			Long voIdLong = (Long) voId.getValue();

			JobParameter subscriberIdParam = jobExecution.getJobParameters().getParameters().get("SUBSCRIBER_ID");
			Long subscriberId = (Long) subscriberIdParam.getValue();

			try {
				bulkOrderProcessor.startBulkOrderSubmitBatch(voIdLong, subscriberId);
			} catch (Exception e) {
				logger.info("Exception in start submit order batch." + e.getMessage());
				e.printStackTrace();
			}
			logger.info("!!! BulkOrderExcelUpload JOB FINISHED at " + System.currentTimeMillis()
					+ "Msec ! Time to verify the results");

		}
	}
}
