package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class OrderChartVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String month;
	private Long orderCount;

	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public Long getOrderCount() {
		return orderCount;
	}
	public void setOrderCount(Long orderCount) {
		this.orderCount = orderCount;
	}
	public OrderChartVO(String month, Long orderCount) {
		super();
		this.month = month;
		this.orderCount = orderCount;
	}
	
	
}
