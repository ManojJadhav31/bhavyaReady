package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class TriggerActivityInputVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String actionType;
	private long[] orderActivityPk;
	
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	public long[] getOrderActivityPk() {
		return orderActivityPk;
	}
	public void setOrderActivityPk(long[] orderActivityPk) {
		this.orderActivityPk = orderActivityPk;
	}

}
