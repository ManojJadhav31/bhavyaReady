package com.level3.voice.tollfree.manager;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbookType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.BatchProcessConstants;
import com.level3.voice.persist.dto.ProductDTO;
import com.level3.voice.persist.dto.SubscriberDTO;
import com.level3.voice.persist.dto.VoiceOrderDTO;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.persist.repository.VoiceOrderRepository;
import com.level3.voice.tollfree.assembler.OrderSubmissionAssembler;
import com.level3.voice.tollfree.bulk.batch.processor.BulkOrderExcelTemplateProcessor;
import com.level3.voice.tollfree.bulk.batch.processor.BulkOrderProcessor;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadBatchDTO;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadDTO;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadItemDTO;
import com.level3.voice.tollfree.bulk.repository.BulkOrderUploadBatchRepository;
import com.level3.voice.tollfree.bulk.repository.BulkOrderUploadItemRepository;
import com.level3.voice.tollfree.bulk.repository.BulkOrderUploadRepository;
import com.level3.voice.tollfree.client.DataMSClient;
import com.level3.voice.tollfree.client.TaiClient;
import com.level3.voice.tollfree.client.WorkflowClient;
import com.level3.voice.tollfree.constants.TollFreeOrderConstants;
import com.level3.voice.tollfree.exception.TollFreeOrderServiceException;
import com.level3.voice.tollfree.persist.dto.CdrServiceTypeUsageDTO;
import com.level3.voice.tollfree.persist.repository.AniDataRepository;
import com.level3.voice.tollfree.persist.repository.CdrServiceTypeUsageRepository;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderActivityRepository;
import com.level3.voice.tollfree.persist.vo.ProductSummaryVO;
import com.level3.voice.tollfree.processor.OrderSubmitAsyncProcessor;
import com.level3.voice.tollfree.utils.OrderActionCodes;
import com.level3.voice.tollfree.utils.TollFreeOrderServiceUtils;
import com.level3.voice.tollfree.utils.ValidationCode;
import com.level3.voice.tollfree.vo.ActivitySearchScreenInputVO;
import com.level3.voice.tollfree.vo.ActivitySearchVO;
import com.level3.voice.tollfree.vo.AniDataVO;
import com.level3.voice.tollfree.vo.AniSearchInputReqVO;
import com.level3.voice.tollfree.vo.BanServiceLocationVO;
import com.level3.voice.tollfree.vo.CrcVO;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.FeaturesVO;
import com.level3.voice.tollfree.vo.NS1SBulkOrderVO;
import com.level3.voice.tollfree.vo.OrderVO;
import com.level3.voice.tollfree.vo.ProductVO;
import com.level3.voice.tollfree.vo.ServiceLocationByCustIdVO;
import com.level3.voice.tollfree.vo.TNDataVO;
import com.level3.voice.tollfree.vo.UsageSummaryInputVO;
import com.level3.voice.tollfree.vo.ValidateTNRequestVO;
import com.level3.voice.tollfree.vo.ValidatedCustomAcctCodeVO;
import com.level3.voice.tollfree.vo.ValidationMessageVO;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;

/**
 * Manager to hold the business logics which would be invoked from the service
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class TollFreeOrderServiceManager {

	@Value("${tn.upload.excel.template.sheet.names}")
	public String sheetNames;
	@Value("${tn.upload.excel.template.1spicld.columns}")
	public String oneSPICLDColumns;
	@Value("${validate.tn.format}")
	private String TN_FORMAT;

	@Value("${tn.upload.excel.bulk.template.sheet.names}")
	public String bulkSheetNames;

	@Value("${tn.upload.excel.bulk.template.columns}")
	public String bulkChangeColumns;

	@Value("${tn.upload.excel.bulk.template.rows}")
	public String bulkChangeRows;

	@Value("${tn.upload.excel.bulk.folder.location}")
	public String folderLocation;
	@Value("${tn.upload.excel.bulk.ftp.user}")
	public String ftpUser;
	@Value("${tn.upload.excel.bulk.ftp.password}")
	public String ftpPassword;

	@Autowired
	VoiceOrderRepository voiceOrderRepository;
	@Autowired
	TollFreeOrderServiceUtils tollFreeOrderServiceUtils;
	@Autowired
	OrderTollFreeFeatureRepository orderTollFreeFeatureRepository;
	@Autowired
	DataMSClient dataMSClient;
	@Autowired
	OrderSubmitAsyncProcessor orderSubmitAsyncProcessor;
	@Autowired
	WorkflowClient workflowClient;
	@Autowired
	OrderSubmissionAssembler orderSubmissionAssembler;

	@Autowired
	private BulkOrderProcessor bulkOrderProcessor;

	@Autowired
	BulkOrderExcelTemplateProcessor bulkOrderExcelTemplateProcessor;

	@Autowired
	BulkOrderUploadRepository bulkOrderUploadRepository;
	
	@Autowired
	BulkOrderUploadBatchRepository bulkOrderUploadBatchRepository;
	
	@Autowired
	BulkOrderUploadItemRepository bulkOrderUploadItemRepository;

	@Autowired
	AniDataRepository aniDataRepository;

	@Autowired
	SlOrderRepository slOrderRepository;

	@Autowired
	ProcessTNData processTNData;
	@Autowired
	CdrServiceTypeUsageRepository cdrServiceTypeUsageRepository;
	@Autowired
	TollfreeOrderActivityRepository tollfreeOrderActivityRepository;
	@Autowired
	TaiClient taiClient;

	@Autowired
	EntityManager entityManager;

	private static final Logger logger = Logger.getLogger(TollFreeOrderServiceManager.class);

	/**
	 * Process the spreadsheet from the temp directory location using apache poi,
	 * retrieve each record and create a List of TNDataVO objects
	 * 
	 * @param filePath
	 * @return List<TNDataVO>
	 * @throws Exception
	 */
	public List<TNDataVO> process(String filePath) throws Exception {
		InputStream file = new FileInputStream(new File(filePath));

		XSSFWorkbook workbook = new XSSFWorkbook(file);
		String workBookSheetName = tollFreeOrderServiceUtils.getSheetName(workbook);
		if (!tollFreeOrderServiceUtils.getSheetNames(workBookSheetName, sheetNames)) {
			throw new TollFreeOrderServiceException("@TollFreeOrderServiceManager: process: Invalid sheets.");
		}

		List<TNDataVO> tnDataVOs = new ArrayList<TNDataVO>();
		Map<String, String> allSheetColumns = tollFreeOrderServiceUtils.getSheetColumns(getColumns(workBookSheetName));

		if (allSheetColumns == null || (allSheetColumns != null && allSheetColumns.isEmpty())) {
			throw new TollFreeOrderServiceException(
					"@TollFreeOrderServiceManager process: Sheet columns are not available.");
		}

		for (int j = 0; j < workbook.getNumberOfSheets();) {
			XSSFSheet sheet = workbook.getSheetAt(j);

			long startTime = System.currentTimeMillis();
			ExecutorService es = Executors.newFixedThreadPool(500);

			Iterator<Row> rows = sheet.rowIterator();
			while (rows.hasNext()) {
				XSSFRow r = (XSSFRow) rows.next();
				es.execute(new Runnable() {
					@Override
					public void run() {
						if (r.getRowNum() == 0) {
							return;
						}

						DataFormatter objDefaultFormat = new DataFormatter();
						String btn = objDefaultFormat.formatCellValue(
								r.getCell(Integer.parseInt(allSheetColumns.get(TollFreeOrderConstants.BTN))));
						String wtn = objDefaultFormat.formatCellValue(
								r.getCell(Integer.parseInt(allSheetColumns.get(TollFreeOrderConstants.WTN))));

						if (StringUtils.isEmpty(btn) || StringUtils.isEmpty(wtn)) {
							return;
						}

						TNDataVO tnDataVO = tollFreeOrderServiceUtils.getTNDataVO(r, allSheetColumns);

						if (tnDataVO != null) {
							synchronized (tnDataVOs) {
								tnDataVOs.add(tnDataVO);
							}
						}
					}
				});
			}
			es.shutdown();
			try {
				es.awaitTermination(180, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				logger.error("@TollFreeOrderServiceManager process: Interrupted exception: " + e.getMessage());
			}
			long endTime = System.currentTimeMillis();
			logger.info("@TollFreeOrderServiceManager process took " + (endTime - startTime) + " milliseconds.");

			return tnDataVOs;
		}
		return null;
	}

	/**
	 * Retrieve the proper columns from the application properties based on the
	 * sheet name
	 * 
	 * @param workBookSheetName
	 * @return columns related to that sheetname
	 */
	private String getColumns(String workBookSheetName) {
		if (TollFreeOrderConstants.ONESPICLD.equalsIgnoreCase(workBookSheetName)) {
			return oneSPICLDColumns;
		} else if (TollFreeOrderConstants.BULK_CHANGE.equalsIgnoreCase(workBookSheetName)) {
			return bulkChangeColumns;
		} else if (TollFreeOrderConstants.ORDER_INFO.equalsIgnoreCase(workBookSheetName)) {
			return bulkChangeRows;
		}
		return null;
	}

	/**
	 * Method which holds the logic to create spreadsheet using the list of
	 * TNDataVOs
	 * 
	 * @param TNDataVOs
	 * @return
	 * @throws IOException
	 * @throws TollFreeOrderServiceException
	 * @throws SLDBException
	 * @throws EncryptedDocumentException
	 * @throws InvalidFormatException
	 */
	public byte[] exportExcel(List<TNDataVO> tnDataVOs) throws IOException, TollFreeOrderServiceException,
			SLDBException, EncryptedDocumentException, InvalidFormatException {

		// TODO change to property file
		InputStream in = this.getClass().getResourceAsStream("/" + "ExcelTemplate/1SPIC-LD_Upload_Template_final.xlsm");

		XSSFWorkbook xssfWorkbook = new XSSFWorkbook(in);
		xssfWorkbook.setWorkbookType(XSSFWorkbookType.XLSM);
		String workBookSheetName = tollFreeOrderServiceUtils.getSheetName(xssfWorkbook);
		if (!tollFreeOrderServiceUtils.getSheetNames(workBookSheetName, sheetNames)) {
			throw new TollFreeOrderServiceException("@TollFreeOrderServiceManager: process: Invalid sheets.");
		}
		Map<String, String> allSheetColumns = tollFreeOrderServiceUtils.getSheetColumns(getColumns(workBookSheetName),
				true);
		Sheet datatypeSheet = xssfWorkbook.getSheetAt(0);
		tollFreeOrderServiceUtils.updateExcelData(allSheetColumns, datatypeSheet, tnDataVOs);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			xssfWorkbook.write(bos);
		} finally {
			bos.close();
		}
		byte[] excelbytes = bos.toByteArray();
		xssfWorkbook.close();
		return excelbytes;
	}

	/**
	 * Submit order flow for 1S order flow. This functions should be generic for
	 * other products like 8S 8D
	 * 
	 * @param orderVO
	 * @return
	 * @throws Exception
	 */
	public OrderVO submitOrder(OrderVO orderVO) throws Exception {

		long startTime = System.currentTimeMillis();
		boolean doSubmit = true;
		Long voiceOrderId = 0L;

		if (StringUtils.isEmpty(orderVO.getActionType())) {
			orderVO.setActionType(OrderActionCodes.INSTALL_STRING);
		}
		doSubmit = validateTNData(orderVO, doSubmit);

		if (doSubmit) {
			voiceOrderId = Long.valueOf(voiceOrderRepository.getVoiceOrderSeq().longValue());
			// TODO need to add the timer for below methods
			Map<String, Long> ponInfo = persistOrder(orderVO, voiceOrderId, null);
			if (voiceOrderId != null && ponInfo != null && ponInfo.size() > 0) {
				triggerPONWorkflow(voiceOrderId, ponInfo);
				triggerSlOrderWokflow(voiceOrderId);
			}
		}
		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @submitOrder took " + (endTime - startTime)
				+ " milliseconds for VOID: " + voiceOrderId);
		return orderVO;
	}

	@Transactional
	private Map<String, Long> persistOrder(OrderVO orderVO, Long voiceOrderId, Long subscriberId) throws Exception {
		long startTime = System.currentTimeMillis();
		Date sysdate = Calendar.getInstance().getTime();

		VoiceOrderDTO voiceOrderDTO = voiceOrderRepository.findOne(voiceOrderId);
		if (voiceOrderDTO == null) {
			orderSubmissionAssembler.assembleVoiceOrder(orderVO, voiceOrderId);
		}

		Map<String, Long> ponInfo = processPONGrouping(orderVO, sysdate, voiceOrderId, subscriberId);
		createSuccessMessage(orderVO, voiceOrderId);
		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @persistOrder took " + (endTime - startTime)
				+ " milliseconds for VOID: " + voiceOrderId);
		return ponInfo;

	}

	/**
	 * This method to validate all the TN, perform current subscriber line table
	 * check for presence if not check presence in NUMS and also NPA NXX validation
	 * from NUMS
	 * 
	 * @param orderVO
	 * @param doSubmit
	 * @return
	 * @throws Exception
	 */
	private boolean validateTNData(OrderVO orderVO, boolean doSubmit) throws Exception {
		long startTime = System.currentTimeMillis();
		ExecutorService es = Executors.newFixedThreadPool(500);
		for (TNDataVO gVO : orderVO.getTnDataVOs()) {
			es.execute(new Runnable() {
				@Override
				public void run() {
					try {
						List<ValidationMessageVO> validationMessageVOs = validateTNData(gVO, orderVO);
						if (validationMessageVOs != null && !validationMessageVOs.isEmpty()) {
							gVO.setValidationMessageVOs(validationMessageVOs);
							gVO.setValid(false);
							orderVO.setDoSubmit(false);
						}
					} catch (Exception e) {
						logger.error("@TollFreeOrderServiceManager: @validateTNData: Exception for TN: " + gVO.getWtn()
								+ " with message: " + e.getMessage());
					}
				}
			});
		}
		es.shutdown();
		try {
			es.awaitTermination(180, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			logger.error("@TollFreeOrderServiceManager: @validateTNData: Interrupted exception: " + e.getMessage());
		}
		long endTime = System.currentTimeMillis();

		logger.info(
				"@TollFreeOrderServiceManager @validateTNData API took " + (endTime - startTime) + " milliseconds for: "
						+ orderVO.getBan() + " : " + orderVO.getCustomerID() + " : " + orderVO.getServiceLocationId());
		return orderVO.isDoSubmit();
	}

	/**
	 * This method would validate both WTN and BTN in the TNDataVO which user has
	 * selected
	 * 
	 * @param gVO
	 * @return
	 * @throws Exception
	 */
	public List<ValidationMessageVO> validateTNData(TNDataVO gVO, OrderVO orderVO) throws Exception {
		List<ValidationMessageVO> validationMessageVOs = new ArrayList<ValidationMessageVO>();

		// This feature is to enable user to enter WTN/BTN with charecter like [-,.,(,)
		// (Space)]
		formPlainTNAndValidate(gVO, validationMessageVOs);
		if (validationMessageVOs.size() > 0) {
			return validationMessageVOs;
		}

		if (orderVO.isInstallFlow()) {
			checkTNInflight(gVO, orderVO, validationMessageVOs);
			checkTNInInventory(gVO, orderVO, validationMessageVOs);
		} else {
			validateTNFlow(gVO, validationMessageVOs, orderVO);
		}
		return validationMessageVOs;
	}

	private void formPlainTNAndValidate(TNDataVO gVO, List<ValidationMessageVO> validationMessageVOs) {
		long startTime = System.currentTimeMillis();

		if (gVO.getWtn() == null || gVO.getWtn().isEmpty() || gVO.getWtn().equals("")) {
			ValidationMessageVO validationMessageVO = new ValidationMessageVO();
			validationMessageVO.setCode(ValidationCode.TNISEMPTY.getMessageCode());
			validationMessageVO.setDisplayMessage(ValidationCode.TNISEMPTY.getMessage());
			validationMessageVOs.add(validationMessageVO);
		}

		if (gVO.getBtn().isEmpty() || gVO.getBtn().equals("") || gVO.getBtn() == null) {
			ValidationMessageVO validationMessageVO = new ValidationMessageVO();
			validationMessageVO.setCode(ValidationCode.TNISEMPTY.getMessageCode());
			validationMessageVO.setDisplayMessage(ValidationCode.TNISEMPTY.getMessage());
			validationMessageVOs.add(validationMessageVO);
		}
		String plainWTN = gVO.getWtn().replaceAll("\\s+|\\.|-|\\(|\\)", "");
		if (!gVO.getWtn().isEmpty() && !tollFreeOrderServiceUtils.isTNValid(plainWTN, TN_FORMAT)) {
			ValidationMessageVO validationMessageVO = new ValidationMessageVO();
			validationMessageVO.setCode(ValidationCode.TNINVALID.getMessageCode());
			validationMessageVO
					.setDisplayMessage("WTN [" + gVO.getWtn() + "] " + ValidationCode.TNINVALID.getMessage());
			validationMessageVOs.add(validationMessageVO);
		} else {
			gVO.setWtn(plainWTN);
		}

		String plainBTN = gVO.getBtn().replaceAll("\\s+|\\.|-|\\(|\\)", "");

		if (!gVO.getBtn().isEmpty() && !tollFreeOrderServiceUtils.isTNValid(plainBTN, TN_FORMAT)) {
			ValidationMessageVO validationMessageVO = new ValidationMessageVO();
			validationMessageVO.setCode(ValidationCode.TNINVALID.getMessageCode());
			validationMessageVO
					.setDisplayMessage("BTN [" + gVO.getBtn() + "] " + ValidationCode.TNINVALID.getMessage());
			validationMessageVOs.add(validationMessageVO);
		} else {
			gVO.setBtn(plainBTN);
		}
		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @formPlainTNAndValidate took " + (endTime - startTime)
				+ " milliseconds for: " + gVO.getWtn());

	}

	/**
	 * This method is to make sure user is not allowed to perform multiple block, or
	 * unblocks or disconnects one after the other
	 * 
	 * @param gVO
	 * @param validationMessageVOs
	 * @param orderVO
	 */
	private void validateTNFlow(TNDataVO gVO, List<ValidationMessageVO> validationMessageVOs, OrderVO orderVO) {
		int currentActionType = orderTollFreeFeatureRepository.getActionType(gVO.getWtn(), orderVO.getCustomerID());
		String currentAction = OrderActionCodes.getOrderActionCode(currentActionType);
		if (currentAction != null & currentAction.equalsIgnoreCase(orderVO.getActionType())
				&& !orderVO.isChangeFlow()) {
			ValidationMessageVO validationMessageVO = new ValidationMessageVO();
			validationMessageVO.setCode("07");
			validationMessageVO.setDisplayMessage("ANI [" + gVO.getWtn() + "] " + " previous order type is already "
					+ currentAction + " .Please select other change option.");
			validationMessageVOs.add(validationMessageVO);
		}
	}

	/**
	 * Check the TN presence in the 3Flow DB, This would take care of handling the
	 * TN case if its in pending state
	 * 
	 * @param gVO
	 * @param orderVO
	 * @param validationMessageVOs
	 * @throws SLDBException
	 */
	private void checkTNInflight(TNDataVO gVO, OrderVO orderVO, List<ValidationMessageVO> validationMessageVOs)
			throws SLDBException {
		ValidateTNRequestVO validateWTNRequestVO = new ValidateTNRequestVO();
		validateWTNRequestVO.setTn(gVO.getWtn());
		validateWTNRequestVO.setValidateInflightTN(true);
		validateWTNRequestVO.setActionType(orderVO.getActionType());
		validateWTNRequestVO.setCustomerId(orderVO.getCustomerID());
		ValidationMessageVO validationWTNMessageVO = validateTN(validateWTNRequestVO, TollFreeOrderConstants.WTN);
		addValidationMessage(validationMessageVOs, validationWTNMessageVO);
	}

	/**
	 * Validation for WTN and BTN against TN data in NUMS tables whihc is the
	 * inventory of TN data
	 * 
	 * @param gVO
	 * @param orderVO
	 * @param validationMessageVOs
	 * @throws Exception
	 */
	private void checkTNInInventory(TNDataVO gVO, OrderVO orderVO, List<ValidationMessageVO> validationMessageVOs)
			throws Exception {
		long startTime = System.currentTimeMillis();
		if (tollFreeOrderServiceUtils.isTNPresentInNums(gVO.getWtn()) && !tollFreeOrderServiceUtils
				.isCustomerMove(gVO.getWtn(), orderVO.getActionType(), orderVO.getCustomerID())) {
			ValidationMessageVO validationMessageVO = new ValidationMessageVO();
			validationMessageVO.setEntityName("NUMS");
			validationMessageVO.setCode(ValidationCode.TNINNUMS.getMessageCode());
			validationMessageVO
					.setDisplayMessage("ANI [ " + gVO.getWtn() + " ] " + ValidationCode.TNINNUMS.getMessage());
			addValidationMessage(validationMessageVOs, validationMessageVO);
		}
		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @checkTNInInventory took " + (endTime - startTime)
				+ " milliseconds for: " + gVO.getWtn());
	}

	/**
	 * Method to add validation messages into the list
	 * 
	 * @param validationMessageVOs
	 * @param validationWTNMessageVO
	 */
	private void addValidationMessage(List<ValidationMessageVO> validationMessageVOs,
			ValidationMessageVO validationWTNMessageVO) {
		if (validationWTNMessageVO != null) {
			validationMessageVOs.add(validationWTNMessageVO);
		}
	}

	/**
	 * This method is used to validate the TN from the UI when user enters them
	 * manually
	 * 
	 * @param validateTNRequestVO
	 * @return
	 * @throws SLDBException
	 */
	public ValidationMessageVO validateTN(ValidateTNRequestVO validateTNRequestVO) throws SLDBException {
		return validateTN(validateTNRequestVO, null);
	}

	/**
	 * Method which holds the logic to invoke the validation against TN based on the
	 * flags in VO object
	 * 
	 * @param validateTNRequestVO
	 * @return ResponseVO
	 * @throws SLDBException
	 */
	public ValidationMessageVO validateTN(ValidateTNRequestVO validateTNRequestVO, String entityName)
			throws SLDBException {
		long startTime = System.currentTimeMillis();
		ValidationMessageVO validationMessageVO = new ValidationMessageVO();
		validationMessageVO.setEntityName(entityName);
		if (!tollFreeOrderServiceUtils.isTNValid(validateTNRequestVO.getTn(), TN_FORMAT)) {
			validationMessageVO.setCode(ValidationCode.TNINVALID.getMessageCode());
			validationMessageVO.setDisplayMessage(
					"ANI [" + validateTNRequestVO.getTn() + "] " + ValidationCode.TNINVALID.getMessage());
			return validationMessageVO;
		}

		if (validateTNRequestVO.isValidateInflightTN()
				&& tollFreeOrderServiceUtils.isTNInflight(validateTNRequestVO.getTn())
				&& !tollFreeOrderServiceUtils.isCustomerMove(validateTNRequestVO.getTn(),
						validateTNRequestVO.getActionType(), validateTNRequestVO.getCustomerId())) {
			validationMessageVO.setCode(ValidationCode.TNINFLIGHT.getMessageCode());
			validationMessageVO.setDisplayMessage(
					"ANI [" + validateTNRequestVO.getTn() + "] " + ValidationCode.TNINFLIGHT.getMessage());
			return validationMessageVO;
		}

		String ocn = taiClient.getOcnData(validateTNRequestVO.getTn());
		if (StringUtils.isEmpty(ocn)) {
			validationMessageVO.setCode(ValidationCode.TNINVALIDNPANXX.getMessageCode());
			validationMessageVO.setDisplayMessage(ValidationCode.TNINVALIDNPANXX.getMessage());
			return validationMessageVO;
		}

		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @validateTN took " + (endTime - startTime) + " milliseconds for: "
				+ validateTNRequestVO.getTn());
		return null;
	}

	/**
	 * This method takes care of grouping TNs based on the configuration selected
	 * against them and groups them to a PON. This PON group will be later used in
	 * the parentworkflow activity for PRO and NPAL
	 * 
	 * @param orderVO
	 * @param sysdate
	 * @param voiceOrderId
	 * @param subscriberId
	 * @param subscriber
	 * @param product
	 * @param address
	 * @throws Exception
	 */
	private Map<String, Long> processPONGrouping(OrderVO orderVO, Date sysdate, Long voiceOrderId,
			final Long subscriberId) throws Exception {

		long startTime = System.currentTimeMillis();
		List<TNDataVO> tnDataVOs = orderVO.getTnDataVOs();
		Map<String, Long> ponInfo = new HashMap<String, Long>();

		orderVO = orderSubmissionAssembler.assembleOrderAdditionalDetails(orderVO);

		final OrderVO ordVO = orderVO;

		if (tnDataVOs == null)
			return null;
		for (TNDataVO tnDataVO : tnDataVOs) {
			Long parentTransId = null;
			populateCrc(ordVO, tnDataVO);
			if (tnDataVO.getPon() != null) {
				parentTransId = tnDataVO.getPon();
			} else {
				String uniqueKey = getUniqueKey(tnDataVO, ordVO);
				if (ponInfo != null && ponInfo.containsKey(uniqueKey)) {
					parentTransId = ponInfo.get(uniqueKey);
				} else {
					parentTransId = orderTollFreeFeatureRepository.getParentTxId();
					ponInfo.put(uniqueKey, parentTransId);
				}
			}
		}
		ExecutorService es = Executors.newFixedThreadPool(500);

		Long subId = null;
		if (subscriberId == null) {
			SubscriberDTO subscriber = orderSubmissionAssembler.assembleSubscriber(orderVO, sysdate);
			subId = subscriber.getSubscriberId();
		} else {
			subId = subscriberId;
		}
		final Long finalSubcriberId = subId;
		ProductDTO product = orderSubmissionAssembler.assmebleProduct(orderVO);
		final String inHouseBizOrgId = getBizOrgId(orderVO);

		for (TNDataVO tnDataVO : tnDataVOs) {
			es.execute(new Runnable() {
				@Override
				public void run() {
					try {
						processTNData.process(ordVO, tnDataVO, ponInfo, sysdate, voiceOrderId, finalSubcriberId,
								product.getProductId(), inHouseBizOrgId);
					} catch (Exception e) {
						logger.error("@TollFreeOrderServiceManager: @processPONGrouping: Exception for TN: "
								+ tnDataVO.getWtn() + " with message: " + e.getMessage());
					}
				}
			});
		}
		es.shutdown();
		try {
			es.awaitTermination(180, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			logger.error("@TollFreeOrderServiceManager: @processPONGrouping: Interrupted exception: " + e.getMessage());
		}

		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @processPONGrouping took " + (endTime - startTime)
				+ " milliseconds for VOID: " + voiceOrderId);

		return ponInfo;
	}

	private String getBizOrgId(OrderVO orderVO) throws SLDBException {
		String inHouseBizOrgId = dataMSClient.getInHouseBizOrg("WCG", orderVO.getCustomerID());
		if (StringUtils.isEmpty(inHouseBizOrgId)) {
			return orderVO.getBusOrgId();
		}
		return inHouseBizOrgId;
	}

	@Transactional
	private HashMap<String, String> persistOrderLevelInfo(OrderVO orderVO, SubscriberDTO subscriber, ProductDTO product,
			Date sysdate) {
		String userName = orderVO.getUserName() != null ? orderVO.getUserName() : "TEST";
		HashMap<String, String> ids = new HashMap<String, String>();

		@SuppressWarnings("unchecked")
		List<SubscriberDTO> subscribers = entityManager.createQuery("from SUBSCRIBER "
				+ "where businessName = :businessName and custTypeInd=:custTypeInd and lastUpdatedUser=:lastUpdatedUser")
				.setParameter("businessName", orderVO.getCustomerName()).setParameter("custTypeInd", "B")
				.setParameter("lastUpdatedUser", userName).getResultList();

		if (!subscribers.isEmpty()) {
			subscriber = subscribers.get(0);
		} else {
			subscriber = orderSubmissionAssembler.assembleSubscriber(orderVO, sysdate);
		}

		if (subscriber.getSubscriberId() != null) {
			ids.put("subscriberId", subscriber.getSubscriberId().toString());
		}

		product = orderSubmissionAssembler.assmebleProduct(orderVO);
		if (product.getProductId() != null) {
			ids.put("productId", product.getProductId().toString());
		}
		return ids;
	}

	/**
	 * Trigger PON Workflow
	 * 
	 * @param voiceOrderId
	 * @param ponInfo
	 */
	private void triggerPONWorkflow(Long voiceOrderId, Map<String, Long> ponInfo) {
		long startTime = System.currentTimeMillis();
		Collection<Long> pons = ponInfo.values();
		ExecutorService es = Executors.newFixedThreadPool(500);
		for (Long pon : pons) {
			es.execute(new Runnable() {
				@Override
				public void run() {
					try {
						workflowClient.submitOrderToWorkflow(pon);
						logger.info("Pon Worflow flow triggered for sales order id: " + pon);
					} catch (Exception e) {
						logger.error("@TollFreeOrderServiceManager: @processPONGrouping: Exception with message: "
								+ e.getMessage());
					}
				}
			});
		}
		es.shutdown();
		try {
			es.awaitTermination(180, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			logger.error("PON Workflow flow interrupted exception: " + e.getMessage());
		}
		logger.info("All PON Workflow flow triggered for voice order id: " + voiceOrderId);
		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @triggerPONWorkflow took " + (endTime - startTime)
				+ " milliseconds for VOID: " + voiceOrderId);
	}

	private void triggerSlOrderWokflow(Long voiceOrderId) {
		Set<BigDecimal> ponSet = slOrderRepository.findInflightOrderPonsByVoiceOrderId(voiceOrderId);

		for (BigDecimal pon : ponSet) {
			try {
				logger.info("@TollFreeOrderServiceManager @triggerSlOrderWokflow: Started for: "
						+ voiceOrderId + " pon: " + pon);
				orderSubmitAsyncProcessor.submitOrder(pon.longValue());
			} catch (SLDBException e) {
				logger.error(
						"@TollFreeOrderServiceManager @triggerSlOrderWokflow: " + e.getMessage());
			}
			logger.info("@TollFreeOrderServiceManager @triggerSlOrderWokflow: Completed for: "
					+ voiceOrderId + " pon: " + pon);
		}
	}

	/**
	 * This method is to retrieve customer details from sandstone
	 * 
	 * @param orderVO
	 * @return
	 * @throws SLDBException
	 */
	private String getCrc(OrderVO orderVO, String cic) throws SLDBException {
		long startTime = System.currentTimeMillis();
		CrcVO crcVO = dataMSClient.getCrc(orderVO.getOrgId(), orderVO.getCustomerID(), cic);
		String crc = StringUtils.isEmpty(crcVO.getCrc()) ? "WCG" : crcVO.getCrc();
		long endTime = System.currentTimeMillis();

		logger.info("@TollFreeOrderServiceManager @getCrc took " + (endTime - startTime) + " milliseconds for for: "
				+ orderVO.getOrgId() + " : " + orderVO.getCustomerID() + " : " + cic);
		return crc;
	}

	/**
	 * This method is used to create the unique key with the TN data which helps to
	 * identify the unique TN and groups them when config matches under a pon
	 * 
	 * @param tnDataVO
	 * @param ordVO
	 * @return
	 */
	private String getUniqueKey(TNDataVO tnDataVO, OrderVO ordVO) {
		String key = tnDataVO.getPic() + "_" + tnDataVO.getCrc() + "_" + tnDataVO.getForceAniLoad() + "_"
				+ tollFreeOrderServiceUtils.getJurisdiction(tnDataVO);

		String customerID = orderTollFreeFeatureRepository.getPrevCustActiveCustomerId(tnDataVO.getWtn());

		if (OrderActionCodes.INSTALL_STRING.equalsIgnoreCase(ordVO.getActionType()) && !StringUtils.isEmpty(customerID)
				&& !customerID.equalsIgnoreCase(ordVO.getCustomerID())) {
			key = key + "_" + customerID;
		}

		List<FeaturesVO> featuresVOs = tnDataVO.getFeatures();
		if (featuresVOs == null) {
			return key;
		}

		for (FeaturesVO featuresVO : featuresVOs) {
			key = key + "_" + featuresVO.getFeatureOfferingId();
		}

		if (tnDataVO.getValidatedCustomAcctCodeVO() == null) {
			return key;
		}

		ValidatedCustomAcctCodeVO validatedCustomAcctCodeVO = tnDataVO.getValidatedCustomAcctCodeVO();
		key = key + "_" + validatedCustomAcctCodeVO.getCodeDigits() + "_"
				+ validatedCustomAcctCodeVO.getCodeTableName();

		return key;
	}

	/**
	 * This method is to cache the unique value only during the submit of one voice
	 * order and then use the same for other slOrders
	 * 
	 * @param orderVO
	 * @param tnDataVO
	 * @throws SLDBException
	 */
	private void populateCrc(OrderVO orderVO, TNDataVO tnDataVO) throws SLDBException {
		tnDataVO.setCrc(getCrc(orderVO, tnDataVO.getCic()));
	}

	/**
	 * Create Success Message once the complete submit is complete
	 * 
	 * @param orderVO
	 * @param parentTransId
	 */
	private void createSuccessMessage(OrderVO orderVO, Long voiceOrderId) {
		ValidationMessageVO validationMessageVO = new ValidationMessageVO();
		validationMessageVO.setCode(ValidationCode.SUBMITSUCCESS.getMessageCode());
		validationMessageVO.setDisplayMessage(ValidationCode.SUBMITSUCCESS.getMessage() + voiceOrderId);
		orderVO.setValidationMessageVO(validationMessageVO);
	}

	/**
	 * It reads Order information from the uploaded excel and writes the data in
	 * database
	 * 
	 * @param request
	 * @param uploadedFile
	 * @param filename
	 * @param directory
	 * @param filepath
	 * @return
	 */
	public Map<String, String> processBulkUpload(MultipartHttpServletRequest request, MultipartFile uploadedFile,
			String filename, String directory, String filepath) {
		try {
			Map<String, String> result = new HashMap<String, String>();
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
			stream.write(((MultipartFile) uploadedFile).getBytes());
			stream.close();

			Long voiceOrderId = null;
			OrderVO orderVO = readOrderInfoFromExcel(filepath);
			validateOrderInfo(orderVO);

			BulkOrderUploadDTO bulkOrderUploadDTO = new BulkOrderUploadDTO();
			bulkOrderUploadDTO.setBan(orderVO.getBan());
			bulkOrderUploadDTO.setCreatedBy("BULKUPLOAD");
			bulkOrderUploadDTO.setCreatedOn(new Date());
			bulkOrderUploadDTO.setCustomerId(orderVO.getCustomerID());
			bulkOrderUploadDTO.setFileData(((MultipartFile) uploadedFile).getBytes());
			bulkOrderUploadDTO.setFileName(filename);
			bulkOrderUploadDTO.setFileType("XLS");
			bulkOrderUploadDTO.setModifiedBy("BULKUPLOAD");
			bulkOrderUploadDTO.setModifiedOn(new Date());
			bulkOrderUploadDTO.setOrderType(orderVO.getActionType());
			bulkOrderUploadDTO.setProduct(orderVO.getProductId());

			voiceOrderId = createVoiceOrderForBulk(orderVO);
			bulkOrderUploadDTO.setVoId(voiceOrderId.toString());

			bulkOrderUploadRepository.saveAndFlush(bulkOrderUploadDTO);
			Date sysdate = Calendar.getInstance().getTime();

			SubscriberDTO subscriber = orderSubmissionAssembler.assembleSubscriber(bulkOrderUploadDTO, sysdate);
			bulkOrderProcessor.startBulkOrderUploadBatch(filepath, voiceOrderId, bulkOrderUploadDTO.getId(),
					subscriber.getSubscriberId());

			// this is to stop if not even one record is valid
			List<BulkOrderUploadItemDTO> bulkOrderUploadItemList = bulkOrderUploadItemRepository
					.findByBulkOrderUpload(bulkOrderUploadDTO.getId());

			if (bulkOrderUploadItemList.size() == 0) {
				bulkOrderUploadDTO = bulkOrderUploadRepository.findOne(bulkOrderUploadDTO.getId());
				bulkOrderUploadDTO.setVoId(null);
				bulkOrderUploadRepository.saveAndFlush(bulkOrderUploadDTO);

				logger.error("@processBulkUpload : there are no valid rows in the excel to process");
				throw new RuntimeException("There are no valid rows in the excel to process");
			}

			// Its to check if none are valid rows
			List<BulkOrderUploadItemDTO> bulkOrderUploadItemValidList = bulkOrderUploadItemList.stream()
					.filter(item -> BatchProcessConstants.BATCH_STATUS_RECEIVED.equals(item.getStatus()))
					.collect(Collectors.toList());

			if (bulkOrderUploadItemValidList.size() == 0) {
				logger.error("@processBulkUpload : there are no valid rows in the excel to process");
				throw new RuntimeException("There are no valid rows in the excel to process");
			}

			logger.info("@processBulkUpload batch process: voice order id: " + voiceOrderId);
			result.put("voId", voiceOrderId.toString());

			bulkOrderUploadRepository.flush();
			return result;

		} catch (Exception e) {
			logger.error("Exception processing file upload: " + "\n", e);
			throw new RuntimeException("Exception processing file upload. " + e.getMessage(), e);
		}
	}

	private void validateOrderInfo(OrderVO orderVO) {
		List<String> actionTypes = new ArrayList<>();
		actionTypes.add(OrderActionCodes.INSTALL_STRING);
		actionTypes.add(OrderActionCodes.CHANGE_STRING);
		actionTypes.add(OrderActionCodes.BLOCK_STRING);
		actionTypes.add(OrderActionCodes.UNBLOCK_STRING);
		actionTypes.add(OrderActionCodes.DISCONNECT_STRING);

		if (StringUtils.isEmpty(orderVO.getActionType())
				|| (orderVO.getActionType() != null && !actionTypes.contains(orderVO.getActionType()))) {
			throw new RuntimeException("Invalid order type.");
		}
		CustomerVO customerVO = null;
		try {
			customerVO = dataMSClient.retrieveCustomerInfo("WCG", orderVO.getCustomerID());
		} catch (SLDBException e) {
			logger.error("CustomerID is not available in the system.");
			throw new RuntimeException("Invalid CustomerID.");
		}
		if (customerVO == null || StringUtils.isEmpty(customerVO.getCustomerId())) {
			logger.info("CustomerID is not available in the system.");
			throw new RuntimeException("Invalid CustomerID.");
		}
		CustomerVO customerVOBan = null;
		try {
			customerVOBan = dataMSClient.serviceLocationByBan("WCG", orderVO.getCustomerID(), orderVO.getBan());
		} catch (SLDBException e) {
			logger.error("Invalid BAN.");
			throw new RuntimeException("Invalid BAN.");
		}
		if (customerVOBan == null || customerVOBan.getBanServiceLocationVOs() == null
				|| customerVOBan.getBanServiceLocationVOs().size() == 0) {
			logger.info("Invalid BAN.");
			throw new RuntimeException("Invalid BAN.");
		}
		String serviceLocationId = null;
		for (BanServiceLocationVO banServiceLocationVO : customerVOBan.getBanServiceLocationVOs()) {
			if (banServiceLocationVO.getAccountNumber() != null
					&& banServiceLocationVO.getAccountNumber().equals(orderVO.getBan())) {
				serviceLocationId = banServiceLocationVO.getServiceLocationId();
				break;
			}
		}

		CustomerVO customerVOProd = null;
		try {
			customerVOProd = dataMSClient.getProductList("WCG", orderVO.getCustomerID(), serviceLocationId, "1S");
		} catch (SLDBException e) {
			logger.error("Invalid Product Id.");
			throw new RuntimeException("Invalid Product Id.");
		}
		if (customerVOProd == null || customerVOProd.getProductVOs() == null
				|| customerVOProd.getProductVOs().size() == 0) {
			logger.info("Invalid Product Id.");
			throw new RuntimeException("Invalid Product Id.");
		} else {
			boolean found = false;
			for (ProductVO po : customerVOProd.getProductVOs()) {
				if (po.getProductIOfferingId() != null && po.getProductIOfferingId().equals(orderVO.getProductId())) {
					found = true;
					break;
				}
			}
			if (!found) {
				logger.info("Invalid Product Id.");
				throw new RuntimeException("Invalid Product Id.");
			}
		}

	}

	/**
	 * It reads Order information from the uploaded excel
	 * 
	 * @param filePath
	 * @return
	 * @throws Exception
	 */
	public OrderVO readOrderInfoFromExcel(String filePath) throws Exception {

		InputStream file = new FileInputStream(new File(filePath));

		XSSFWorkbook workbook = new XSSFWorkbook(file);
		String workBookSheetName = tollFreeOrderServiceUtils.getSheetName(workbook);
		if (!tollFreeOrderServiceUtils.getSheetNames(workBookSheetName, bulkSheetNames)) {
			throw new RuntimeException("@TollFreeOrderServiceManager: process: Invalid sheets.");
		}

		OrderVO orderVO = new OrderVO();
		Map<String, String> orderInfoRows = tollFreeOrderServiceUtils
				.getSheetColumns(getColumns(TollFreeOrderConstants.ORDER_INFO));

		if (orderInfoRows == null || (orderInfoRows != null && orderInfoRows.isEmpty())) {
			throw new TollFreeOrderServiceException(
					"@TollFreeOrderServiceManager process: Sheet columns are not available.");
		}

		int numberOfSheets = workbook.getNumberOfSheets();
		if (numberOfSheets > 0) {
			XSSFSheet sheet = workbook.getSheetAt(0);

			Iterator<Row> rows = sheet.rowIterator();

			while (rows.hasNext()) {
				XSSFRow r = (XSSFRow) rows.next();

				if (r.getRowNum() <= 3) {
					DataFormatter objDefaultFormat = new DataFormatter();

					if (TollFreeOrderConstants.PRODUCT.equals(objDefaultFormat.formatCellValue(r.getCell(0)))) {
						orderVO.setProductId(objDefaultFormat.formatCellValue(r.getCell(1)));
					} else if (TollFreeOrderConstants.BAN.equals(objDefaultFormat.formatCellValue(r.getCell(0)))) {
						orderVO.setBan(objDefaultFormat.formatCellValue(r.getCell(1)));
					} else if (TollFreeOrderConstants.CUSTOMER_ID
							.equals(objDefaultFormat.formatCellValue(r.getCell(0)))) {
						orderVO.setCustomerID(objDefaultFormat.formatCellValue(r.getCell(1)));
					} else if (TollFreeOrderConstants.ORDER_TYPE
							.equals(objDefaultFormat.formatCellValue(r.getCell(0)))) {
						orderVO.setActionType(objDefaultFormat.formatCellValue(r.getCell(1)));
					}
					orderVO.setOrderType("1S");
				}
			}

			if (StringUtils.isEmpty(orderVO.getProductId()) || StringUtils.isEmpty(orderVO.getBan())
					|| StringUtils.isEmpty(orderVO.getCustomerID()) || StringUtils.isEmpty(orderVO.getActionType())) {
				logger.info(
						"PRODUCT/BAN/CUSTOMER_ID/ORDER_TYPE is missing in excel templete. Please correct and upload");
				throw new RuntimeException(
						"@TollFreeOrderServiceManager process: PRODUCT/BAN/CUSTOMER_ID/ORDER_TYPE is missing in excel templete. Please correct and upload");
			}

		}
		return orderVO;
	}

	/**
	 * It creates the new voice order for given order information
	 * 
	 * @param orderVO
	 * @return
	 */
	public Long createVoiceOrderForBulk(OrderVO orderVO) {
		Long voiceOrderId = Long.valueOf(voiceOrderRepository.getVoiceOrderSeq().longValue());

		orderSubmissionAssembler.assembleVoiceOrder(orderVO, voiceOrderId);
		return voiceOrderId;
	}

	public OrderVO submitBulkOrder(OrderVO orderVO, Long voiceOrderId, Long subscriberId) throws Exception {
		// TODO this needs to be moved to UI.
		if (StringUtils.isEmpty(orderVO.getActionType())) {
			orderVO.setActionType(OrderActionCodes.INSTALL_STRING);
		}
		persistOrder(orderVO, voiceOrderId, subscriberId);

		return orderVO;
	}

	/**
	 * It fetches workflow activity for a given tn
	 * 
	 * @param tn
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ActivitySearchVO> getActivities(ActivitySearchScreenInputVO activityScreenReqParams)
			throws ParseException {

		List<Object[]> aniScreenDTOs = new ArrayList<>();

		List<ActivitySearchVO> aniSearchlist = new ArrayList<>();

		String query = "select oa.activity_type_id as activity_id,oa.order_activity_pk,ac.activity_name,ast.name,oa.last_processing_start,oa.last_processing_stop , oa.comments,otf.tn,vo.voice_order_id, oa.parent_trans_id"
				+ " from order_activity oa INNER JOIN activity ac on oa.activity_type_id = ac.activity_id"
				+ " INNER JOIN activity_status ast on oa.status = ast.activity_status_id"
				+ " INNER JOIN sl_order slo on slo.sl_order_id = oa.sl_order_id"
				+ " INNER JOIN order_tollfree_features otf ON otf.sl_order_id=slo.sl_order_id"
				+ " INNER JOIN voice_order vo ON vo.voice_order_id=slo.voice_order_id"
				+ getWhereData(activityScreenReqParams) + " order by oa.order_activity_pk";

		aniScreenDTOs = entityManager.createNativeQuery(query).getResultList();

		for (int i = 0; i < aniScreenDTOs.size(); i++) {

			ActivitySearchVO aniActivityVO = new ActivitySearchVO();

			Object[] tempObject = (Object[]) aniScreenDTOs.get(i);

			aniActivityVO.setActivityId(Integer.parseInt(tempObject[0].toString()));
			aniActivityVO.setOrderActivityPk(tempObject[1].toString());
			aniActivityVO.setActivityName(tempObject[2].toString());
			aniActivityVO.setName(tempObject[3].toString());
			if (tempObject[4] != null) {
				aniActivityVO.setStartTime(tempObject[4].toString());
			} else {
				aniActivityVO.setStartTime(null);
			}
			if (tempObject[5] != null) {
				aniActivityVO.setEndTime(tempObject[5].toString());
			} else {
				aniActivityVO.setEndTime(null);
			}
			if (tempObject[6] != null) {
				aniActivityVO.setComments(tempObject[6].toString());
			}

			if (tempObject[7] != null) {
				aniActivityVO.setTn(tempObject[7].toString());
			}

			if (tempObject[8] != null) {
				aniActivityVO.setVoiceOrderId(tempObject[8].toString());
			}
			if (tempObject[9] != null) {
				aniActivityVO.setParentTransId(tempObject[9].toString());
			}

			aniSearchlist.add(aniActivityVO);

		}

		return aniSearchlist;

	}

	/**
	 * It reads Order information from the uploaded excel and writes the data in
	 * database
	 * 
	 * @param request
	 * @param uploadedFile
	 * @param filename
	 * @param directory
	 * @param filepath
	 * @return
	 */
	@SuppressWarnings("resource")
	public Map<String, String> processNSBulkUpload(String filename) {
		try {
			logger.info("@processNSBulkUpload batch process: fileName: " + filename);
			logger.info("@processNSBulkUpload batch process: folderLocation: " + folderLocation);

			Map<String, String> result = new HashMap<String, String>();
			OrderVO orderVO = new OrderVO();
			NS1SBulkOrderVO nsBulkOrder;

			String url = "smb:" + folderLocation + "BulkOrdersArchive/" + filename;
			NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(null, ftpUser, ftpPassword);
			SmbFile dir = new SmbFile(url, auth);

			SmbFileInputStream out = new SmbFileInputStream(dir);
			byte[] buffer = new byte[(int) dir.length()];
			out.read(buffer);

			BufferedReader reader = new BufferedReader(new InputStreamReader(new SmbFileInputStream(dir)));
			String line = reader.readLine();

			if (!line.isEmpty()) {

				nsBulkOrder = NS1SBulkOrderVO.to1SObject(line);
				if (nsBulkOrder == null) {
					logger.info("@processNSBulkUpload batch process: Null first record fileName: " + filename);
					result.put("No Data found ", filename.toString());
				}
				if (!nsBulkOrder.getServiceType().equals("1S")) {
					logger.info("@processNSBulkUpload batch process: Skipped fileName: " + filename + " Service Type: ["
							+ nsBulkOrder.getServiceType() + "]");
					result.put("Skipped", filename.toString());
				} else {
					if (null == nsBulkOrder.getServiceLocationId() || null == nsBulkOrder.getProductId()
							|| null == nsBulkOrder.getCustomerId() || null == nsBulkOrder.getOrderType()) {
						logger.info(
								"PRODUCT/BAN/CUSTOMER_ID/ORDER_TYPE is missing in excel templete. Please correct and upload");
						result.put("Validation failed Mandatory parameters not available ", filename.toString());
					}
					// orderVO.setBan(nsBulkOrder.getServiceLocationId());
					orderVO.setProductId(nsBulkOrder.getProductId());
					orderVO.setCustomerID(nsBulkOrder.getCustomerId());
					orderVO.setOrderType("1S");
					if("P".equals(nsBulkOrder.getOrderType()))
						nsBulkOrder.setOrderType("C");
					orderVO.setActionType(getOrderActionCode(nsBulkOrder.getOrderType()));

/*					CustomerVO customerVOBan = dataMSClient.retrieveServiceLocations("WCG", nsBulkOrder.getCustomerId(),
							"1S");
					for (BanServiceLocationVO banServiceLocationVO : customerVOBan.getBanServiceLocationVOs()) {
						if (banServiceLocationVO.getAccountNumber() != null && banServiceLocationVO
								.getServiceLocationId().equals(nsBulkOrder.getServiceLocationId())) {
							orderVO.setBan(banServiceLocationVO.getAccountNumber());
							break;
						}
					}
					if (orderVO.getActionType().equals(OrderActionCodes.INSTALL_STRING)) {
						Long orderActionType = orderTollFreeFeatureRepository
								.getPrevOrderActionType(nsBulkOrder.getWtn(), nsBulkOrder.getCustomerId());
						if (orderActionType != null)
							if (orderActionType.intValue() != OrderActionCodes.DISCONNECT)
								orderVO.setActionType(OrderActionCodes.CHANGE_STRING);
					}
*/
					Long voiceOrderId = createVoiceOrderForBulk(orderVO);
					BulkOrderUploadBatchDTO bulkOrderUploadBatchDTO = new BulkOrderUploadBatchDTO();
					BulkOrderUploadDTO bulkOrderUploadDTO = new BulkOrderUploadDTO();
					bulkOrderUploadDTO.setBan(orderVO.getBan());
					bulkOrderUploadDTO.setCreatedBy("BULKUPLOAD");
					bulkOrderUploadDTO.setCreatedOn(new Date());
					bulkOrderUploadDTO.setCustomerId(orderVO.getCustomerID());
					bulkOrderUploadBatchDTO.setCustomerId(orderVO.getCustomerID());
					bulkOrderUploadBatchDTO.setFileData(buffer);
					bulkOrderUploadBatchDTO.setFileName(filename);
					bulkOrderUploadBatchDTO.setVoId(voiceOrderId.toString());
					/*
					bulkOrderUploadDTO.setFileData(buffer);
					bulkOrderUploadDTO.setFileName(filename);
					bulkOrderUploadDTO.setFileType("BULK");
					bulkOrderUploadDTO.setModifiedBy("BULKUPLOAD");
					bulkOrderUploadDTO.setModifiedOn(new Date());
					bulkOrderUploadDTO.setOrderType(orderVO.getActionType());
					bulkOrderUploadDTO.setProduct(orderVO.getProductId());
					bulkOrderUploadDTO.setVoId(voiceOrderId.toString());

					
					 * bulkOrderUploadRepository.saveAndFlush(bulkOrderUploadDTO);
					 *
					 */
					bulkOrderUploadBatchRepository.saveAndFlush(bulkOrderUploadBatchDTO);
					Date sysdate = Calendar.getInstance().getTime();
					SubscriberDTO subscriber = orderSubmissionAssembler.assembleSubscriber(bulkOrderUploadDTO, sysdate);
					bulkOrderProcessor.startNSBulkOrderUploadBatch(filename, voiceOrderId, bulkOrderUploadDTO.getId(),
							subscriber.getSubscriberId());

					logger.info("@processBulkUpload batch process: voice order id: " + voiceOrderId);
					result.put("voId", voiceOrderId.toString());
				}
			}
			return result;

		} catch (Exception e) {
			logger.error("Exception processing file upload: " + "\n", e);
			throw new RuntimeException("Exception processing file upload. " + e.getMessage(), e);
		}
	}

	public String getOrderActionCode(String actionCode) {
		String orderActionCode = null;
		switch (actionCode) {
		case "A":
			orderActionCode = OrderActionCodes.INSTALL_STRING;
			break;
		case "C":
			orderActionCode = OrderActionCodes.CHANGE_STRING;
			break;
		case "D":
			orderActionCode = OrderActionCodes.DISCONNECT_STRING;
			break;
		case "R":
			orderActionCode = OrderActionCodes.RENEW_STRING;
			break;

		case "B":
			orderActionCode = OrderActionCodes.BLOCK_STRING;
			break;
		case "U":
			orderActionCode = OrderActionCodes.UNBLOCK_STRING;
			break;
		default:
			break;
		}
		return orderActionCode;
	}
	

	public List<AniDataVO> getAniData(AniSearchInputReqVO aniSearchInput) {
		ArrayList<AniDataVO> aniDataList = new ArrayList<>();
		Object[] listOfObjects = aniDataRepository.getAniDataForReport(aniSearchInput.getWtn(), aniSearchInput.getBtn(),
				aniSearchInput.getServiceLocationId(), aniSearchInput.getCustomerId());
		ArrayList<Object> list = new ArrayList<Object>(Arrays.asList(listOfObjects));

		for (int i = 0; i < list.size(); i++) {
			AniDataVO aniDataVO = new AniDataVO();
			Object[] tempObject = (Object[]) list.get(i);

			aniDataVO.setCustomerId((tempObject[0].toString()));
			aniDataVO.setCustomerName((tempObject[1].toString()));
			aniDataVO.setServiceLocationId((tempObject[2].toString()));
			aniDataVO.setProductId((tempObject[3].toString()));
			aniDataVO.setTn((tempObject[4].toString()));
			aniDataVO.setBtn((tempObject[5].toString()));
			if (tempObject[6] != null) {
				aniDataVO.setCic((tempObject[6].toString()));
			}
			if (tempObject[7] != null) {
				aniDataVO.setStatus((tempObject[7].toString()));
			}
			if (tempObject[8] != null) {
				aniDataVO.setOcn(tempObject[8].toString());
			}
			if (tempObject[9] != null) {
				aniDataVO.setIntraLataFirstUsage((tempObject[8].toString()));
			}
			if (tempObject[10] != null) {
				aniDataVO.setIntraLataLastUsage((tempObject[9].toString()));
			}
			if (tempObject[11] != null) {
				aniDataVO.setInterLataFirstUsage((tempObject[10].toString()));
			}
			if (tempObject[12] != null) {
				aniDataVO.setInterLataLastUsage((tempObject[11].toString()));
			}
			aniDataList.add(aniDataVO);
		}
		return aniDataList;
	}

	public List<BulkOrderUploadDTO> getBulkUploadData(String voId) {
		return bulkOrderUploadRepository.findByVoId(voId);
	}

	public List<ServiceLocationByCustIdVO> getAllServiceLocations(String customerId) {
		ArrayList<ServiceLocationByCustIdVO> serviceLocList = new ArrayList<>();
		Object[] listOfObjects = aniDataRepository.getAllServiceLocation(customerId);
		ArrayList<Object> list = new ArrayList<Object>(Arrays.asList(listOfObjects));
		for (int i = 0; i < list.size(); i++) {
			Object[] tempObject = (Object[]) list.get(i);
			ServiceLocationByCustIdVO serviceLocationByCustIdVO = new ServiceLocationByCustIdVO();

			if (tempObject[0] != null) {
				serviceLocationByCustIdVO.setServiceLocationID(tempObject[0].toString());
			}
			if (tempObject[1] != null) {
				serviceLocationByCustIdVO.setStatus(tempObject[1].toString());
			}
			if (tempObject[2] != null) {
				serviceLocationByCustIdVO.setWtn(tempObject[2].toString());
			}
			if (tempObject[3] != null) {
				serviceLocationByCustIdVO.setBtn(tempObject[3].toString());
			}
			if (tempObject[4] != null) {
				serviceLocationByCustIdVO.setServiceBeginDate(tempObject[4].toString());
			}
			if (tempObject[5] != null) {
				serviceLocationByCustIdVO.setIntraLataFirstUsage(tempObject[5].toString());
			}
			if (tempObject[6] != null) {
				serviceLocationByCustIdVO.setIntraLataLastUsage(tempObject[6].toString());
			}
			if (tempObject[7] != null) {
				serviceLocationByCustIdVO.setInterLatafirstUsage(tempObject[7].toString());
			}
			if (tempObject[8] != null) {
				serviceLocationByCustIdVO.setInterLataLastUsage(tempObject[8].toString());
			}
			if (tempObject[9] != null) {
				serviceLocationByCustIdVO.setServiceEndDate(tempObject[9].toString());
			}

			serviceLocList.add(serviceLocationByCustIdVO);

		}
		return serviceLocList;

	}


	private String getWhereData(ActivitySearchScreenInputVO activityScreenReqParams) throws ParseException {
		String data = "";

		if (activityScreenReqParams.getTn() != null && activityScreenReqParams.getTn().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " otf.tn= '" + activityScreenReqParams.getTn() + "'";

		}
		if (activityScreenReqParams.getVoiceOrderId() != null
				&& activityScreenReqParams.getVoiceOrderId().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " slo.voice_order_id= '" + activityScreenReqParams.getVoiceOrderId() + "'";
		}

		if (activityScreenReqParams.getOrderCompleteDate() != null
				&& activityScreenReqParams.getOrderCompleteDate().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " TRUNC(oa.last_processing_stop) = '" + activityScreenReqParams.getOrderCompleteDate() + "'";
		}

		if (activityScreenReqParams.getActivity() != null
				&& activityScreenReqParams.getActivity().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " oa.activity_type_id= '" + activityScreenReqParams.getActivity() + "'";
		}
		return data;
	}

	private String addWhereAndData(String data) {
		if (StringUtils.isEmpty(data)) {
			data = data + " where slo.order_active_yn = 'Y' and ac.is_displayable_yn='Y' and ";
		} else {
			data = data + " and ";
		}
		return data;
	}

	public List<ProductSummaryVO> getProductSummary(String customerId, String serviceLocationId) {

		List<Object> objects = tollfreeOrderActivityRepository.getProductSummary(customerId, serviceLocationId);
		Iterator<Object> objectsItor = objects.iterator();
		List<ProductSummaryVO> productSummList = new ArrayList<ProductSummaryVO>();
		while (objectsItor.hasNext()) {
			Object[] tempObject = (Object[]) objectsItor.next();
			ProductSummaryVO productSummaryVO = new ProductSummaryVO();

			if (tempObject[0] != null) {
				productSummaryVO.setProductOffering(tempObject[0].toString());
			}
			if (tempObject[1] != null) {
				productSummaryVO.setQtyActive(sumActive(tempObject));
			}
			if (tempObject[2] != null) {
				productSummaryVO.setQtyPending(tempObject[2].toString());
			}
			if (tempObject[3] != null) {
				productSummaryVO.setQtyDisconnect(tempObject[4].toString());
			}
			productSummList.add(productSummaryVO);
		}

		return productSummList;
	}

	public List<ProductSummaryVO> getCustProductSummary(String customerId) {
		List<Object> objects = tollfreeOrderActivityRepository.getCustProductSumamry(customerId);

		Iterator<Object> objectsItor = objects.iterator();
		List<ProductSummaryVO> productSummList = new ArrayList<ProductSummaryVO>();
		while (objectsItor.hasNext()) {
			Object[] tempObject = (Object[]) objectsItor.next();
			ProductSummaryVO productSummaryVO = new ProductSummaryVO();

			if (tempObject[0] != null) {
				productSummaryVO.setProductOffering(tempObject[0].toString());
			}
			if (tempObject[1] != null) {
				productSummaryVO.setQtyActive(sumActive(tempObject));
			}
			if (tempObject[2] != null) {
				productSummaryVO.setQtyPending(tempObject[2].toString());
			}
			if (tempObject[3] != null) {
				productSummaryVO.setQtyDisconnect(tempObject[4].toString());
			}
			productSummList.add(productSummaryVO);
		}

		return productSummList;
	}
	
	private String sumActive(Object[] tempObject) {
		String active = tempObject[1].toString();
		String blocked = tempObject[3].toString();
		long activeNumber = 0l;
		if(!StringUtils.isEmpty(active)) {
			activeNumber = Long.valueOf(active).longValue();
		}
		long blockedNumber = 0l;
		if(!StringUtils.isEmpty(blocked)) {
			blockedNumber = Long.valueOf(blocked).longValue();
		}
		long total = activeNumber + blockedNumber;
		return String.valueOf(total);
	}

}
