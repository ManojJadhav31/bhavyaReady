package com.level3.voice.tollfree.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.manager.TollFreeDashboardServiceManager;
import com.level3.voice.tollfree.vo.ActivityChartVO;
import com.level3.voice.tollfree.vo.ActivitySearchVO;
import com.level3.voice.tollfree.vo.OrderChartVO;

/**
 *  
 * @author <a href="mailto:Manjunatha.D@centurylink.com">Manjunatha D</a>
 *
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/Voice/dashboard")
public class TollFreeOrderDashboardService {

	private static final Logger logger = Logger.getLogger(TollFreeOrderDashboardService.class);

	@Autowired
	TollFreeDashboardServiceManager tollFreeDashboardServiceManager;
	
	@RequestMapping(path = "/ordersChart/{createdBy:.+}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<OrderChartVO> getOrderChart(@PathVariable String createdBy) {
		List<OrderChartVO> orderChartVOList = tollFreeDashboardServiceManager.getOrderChart(createdBy);

		return orderChartVOList;
	}
	
	@RequestMapping(path = "/activitiesChart/{createdBy:.+}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ActivityChartVO> getActivityChart(@PathVariable String createdBy) {
		List<ActivityChartVO> activityChartVOList = tollFreeDashboardServiceManager.getActivityChart(createdBy);

		return activityChartVOList;
	}
}
