package com.level3.voice.tollfree.vo;

import java.io.Serializable;
import java.util.List;


/**
 * VO to be returned to the caller each VO will hold a record sent in the
 * spreadsheet during upload
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class TNDataVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String wtn;
	private String btn;
	private String pic;
	private String jurisdiction;
	private String forceAniLoad;
	private String cic;
	private String crc;
	private boolean isValid = true;
	private List<ValidationMessageVO> validationMessageVOs;
	private List<FeaturesVO> features;
	private ValidatedCustomAcctCodeVO validatedCustomAcctCodeVO;
	private Long pon;
	
	/**
	 * @return the wtn
	 */
	public String getWtn() {
		return wtn;
	}

	/**
	 * @param wtn
	 *            the wtn to set
	 */
	public void setWtn(String wtn) {
		this.wtn = wtn;
	}

	/**
	 * @return the btn
	 */
	public String getBtn() {
		return btn;
	}

	/**
	 * @param btn
	 *            the btn to set
	 */
	public void setBtn(String btn) {
		this.btn = btn;
	}

	/**
	 * @return the pic
	 */
	public String getPic() {
		return pic;
	}

	/**
	 * @param pic
	 *            the pic to set
	 */
	public void setPic(String pic) {
		this.pic = pic;
	}

	/**
	 * @return the jurisdiction
	 */
	public String getJurisdiction() {
		return jurisdiction;
	}

	/**
	 * @param jurisdiction
	 *            the jurisdiction to set
	 */
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	/**
	 * @return the forceAniLoad
	 */
	public String getForceAniLoad() {
		return forceAniLoad;
	}

	/**
	 * @param forceAniLoad
	 *            the forceAniLoad to set
	 */
	public void setForceAniLoad(String forceAniLoad) {
		this.forceAniLoad = forceAniLoad;
	}

	/**
	 * @return the cic
	 */
	public String getCic() {
		return cic;
	}

	/**
	 * @param cic
	 *            the cic to set
	 */
	public void setCic(String cic) {
		this.cic = cic;
	}
	
	public String getCrc() {
		return crc;
	}

	public void setCrc(String crc) {
		this.crc = crc;
	}

	public boolean isValid() {
		return isValid;
	}

	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}

	public List<ValidationMessageVO> getValidationMessageVOs() {
		return validationMessageVOs;
	}

	public void setValidationMessageVOs(List<ValidationMessageVO> validationMessageVOs) {
		this.validationMessageVOs = validationMessageVOs;
	}

	public List<FeaturesVO> getFeatures() {
		return features;
	}

	public void setFeatures(List<FeaturesVO> features) {
		this.features = features;
	}
	
	public ValidatedCustomAcctCodeVO getValidatedCustomAcctCodeVO() {
		return validatedCustomAcctCodeVO;
	}

	public void setValidatedCustomAcctCodeVO(ValidatedCustomAcctCodeVO validatedCustomAcctCodeVO) {
		this.validatedCustomAcctCodeVO = validatedCustomAcctCodeVO;
	}

	public Long getPon() {
		return pon;
	}

	public void setPon(Long pon) {
		this.pon = pon;
	}
}
