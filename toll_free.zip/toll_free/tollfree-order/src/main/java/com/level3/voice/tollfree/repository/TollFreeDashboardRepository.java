package com.level3.voice.tollfree.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadDTO;
import com.level3.voice.tollfree.persist.dto.ChargeDTO;

/**
 * @author <a href="mailto:manjunatha.d@centurylink.com">Manjunatha D</a>
 */
@Component
public class TollFreeDashboardRepository {

	@Autowired
	EntityManager entityManager;

	public List getOrderChart(String createdBy) {
		String query = "select to_char(order_date,'Month') as Month, " + 
				"count(sl_order_id) as orderCount " + 
				"from sl_order  " + 
				"where create_user='"+createdBy+"' and to_char(order_date, 'YYYY') = to_char(sysdate, 'YYYY') " + 
				"group by to_char(order_date,'MM'), to_char(order_date,'Month') "
				+ "order by to_char(order_date,'MM')";
		return entityManager.createNativeQuery(query,"OrderChartResult").getResultList();
	}

	public List getActivityChart(String createdBy) {
		String query = "select to_char(slo.order_date, 'YYYY') as Year,ast.name as status, " + 
				"count(activity_type_id) as no_of_activities " + 
				"from order_activity oa, sl_order slo,activity_status ast " + 
				"where oa.sl_order_id=slo.sl_order_id and slo.create_user='"+createdBy+"'  " + 
				"and to_char(slo.order_date, 'YYYY') = to_char(sysdate, 'YYYY') " + 
				"and ast.activity_status_id=oa.status " + 
				"group by  to_char(slo.order_date, 'YYYY'),ast.name";
		return entityManager.createNativeQuery(query).getResultList();
	}
	
	
}
