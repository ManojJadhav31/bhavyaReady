package com.level3.voice.tollfree.service;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.HttpHeaders;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.bulk.batch.processor.BulkOrderProcessor;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadDTO;
import com.level3.voice.tollfree.client.SAUIUpdateServiceClient;
import com.level3.voice.tollfree.client.sauiupdate.UIResponseVo;
import com.level3.voice.tollfree.exception.TollFreeOrderServiceException;
import com.level3.voice.tollfree.manager.TollFreeOrderServiceManager;
import com.level3.voice.tollfree.persist.vo.ProductSummaryVO;
import com.level3.voice.tollfree.persist.vo.SearchScreenInputVO;
import com.level3.voice.tollfree.utils.ValidationCode;
import com.level3.voice.tollfree.vo.ActivitySearchScreenInputVO;
import com.level3.voice.tollfree.vo.ActivitySearchVO;
import com.level3.voice.tollfree.vo.OrderVO;
import com.level3.voice.tollfree.vo.TNDataVO;
import com.level3.voice.tollfree.vo.TriggerActivityInputVO;
import com.level3.voice.tollfree.vo.ValidateTNRequestVO;
import com.level3.voice.tollfree.vo.ValidationMessageVO;

/**
 * Service endpoints which would be used to interact with 3Flow DB and other
 * functionality other than sandstone DB interaction
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/Voice/order")
public class TollFreeOrderService {

	private static final Logger logger = Logger.getLogger(TollFreeOrderService.class);

	@Autowired
	private TollFreeOrderServiceManager tollFreeOrderServiceManager;

	@Autowired
	BulkOrderProcessor bulkOrderProcessor;

	@Autowired
	SAUIUpdateServiceClient sauiUpdateClient;

	/**
	 * uploadOneSData would be called when user is trying to upload a spreadsheet
	 * for 1S or Tollfree orders
	 * 
	 * @param request
	 * @return List<TNPropertyRecordVO>
	 */
	@PostMapping(path = "/1s/upload", consumes = { MediaType.ALL_VALUE })
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@Audited
	public List<TNDataVO> uploadOneSData(MultipartHttpServletRequest request) {
		logger.debug("Inside TNVerifyAddController");
		String errorMessage = "";

		if (request == null) {
			errorMessage = "@TollFreeOrderService: uploadOneSData: MultipartHttpServletRequest is null";
			logger.error(errorMessage);
			createErrorResponse(errorMessage);
		}

		MultipartFile uploadedFile = request.getFile("file");
		if (uploadedFile == null) {
			errorMessage = "@TollFreeOrderService: uploadOneSData: Please attach the file";
			logger.error(errorMessage);
			createErrorResponse(errorMessage);
		}

		logger.info("@TollFreeOrderService: uploadOneSData: uploaded file size: " + uploadedFile.getSize());

		String filename = (uploadedFile).getOriginalFilename();
		String directory = System.getProperty("java.io.tmpdir");
		String filepath = Paths.get(directory, filename).toString();

		logger.debug("@TollFreeOrderService: uploadOneSData: Uploaded file " + filepath + " File name: " + filename);

		return process(uploadedFile, filepath);
	}

	/**
	 * Method where the processor is called to process the records in the
	 * spreadsheet and return the data as output
	 * 
	 * @param request
	 * @param uploadedFile
	 * @param filename
	 * @param directory
	 * @param filepath
	 * @return List<TNPropertyRecordVO>
	 */
	private List<TNDataVO> process(MultipartFile uploadedFile, String filepath) {
		try {
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(filepath)));
			stream.write(((MultipartFile) uploadedFile).getBytes());
			stream.close();

			return tollFreeOrderServiceManager.process(filepath);

		} catch (Exception e) {
			logger.error("Exception processing file upload: " + "\n", e);
			Level3Response l3Response = (e instanceof TollFreeOrderServiceException)
					? Level3Response.BAD_REQUEST_400_INVALID_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail("@TollFreeOrderService: process: Exception processing file upload: " + e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * Method to handle the error message
	 * 
	 * @param errorMessage
	 */
	private void createErrorResponse(String errorMessage) {
		Level3Response l3Response = Level3Response.INTERNAL_SERVER_ERROR_500;
		l3Response.setDetail(
				"@TollFreeOrderService: createErrorResponse: Exception processing file upload: " + errorMessage);
		throw new ServiceException(l3Response);
	}

	/**
	 * Export Feature to create the spreadsheet using the macro enabled template
	 * spreadsheet with the tn property record data
	 * 
	 * @param tnPropertyRecordVOs
	 * @return
	 * @throws IOException
	 * @throws TollFreeOrderServiceException
	 * @throws SLDBException
	 * @throws EncryptedDocumentException
	 * @throws InvalidFormatException
	 */
	@PostMapping(path = "/1s/export", consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@Audited
	public ResponseEntity<ByteArrayResource> exportOneSData(@RequestBody List<TNDataVO> tnPropertyRecordVOs) {

		try {
			byte[] data = tollFreeOrderServiceManager.exportExcel(tnPropertyRecordVOs);
			ByteArrayResource resource = new ByteArrayResource(data);

			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment;")
					.header(HttpHeaders.CONTENT_TYPE,
							"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
					.contentLength(data.length).body(resource);

		} catch (Exception e) {
			logger.error("Exception processing file export: " + "\n", e);
			Level3Response l3Response = (e instanceof TollFreeOrderServiceException)
					? Level3Response.BAD_REQUEST_400_INVALID_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(
					"@TollFreeOrderService: exportOneSData: Exception processing file upload: " + e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * API called while submitting a 1S/tollfree order
	 * 
	 * @param orderVO
	 * @return List<ResponseVO>
	 */
	@PostMapping(path = "/submit", consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@CrossOrigin
	@ResponseBody
	@ResponseStatus(HttpStatus.OK)
	@Audited
	public OrderVO submitOrder(@RequestBody OrderVO orderVO) {
		try {
			if (orderVO == null) {
				String errorMessage = "@TollFreeOrderService: submitOrder: OrderVO is null";
				logger.error(errorMessage);
				throw new TollFreeOrderServiceException(errorMessage);
			}
			return tollFreeOrderServiceManager.submitOrder(orderVO);
		} catch (Exception e) {
			logger.error("Exception processing submit order : " + "\n", e);
			ValidationMessageVO validationMessageVO = new ValidationMessageVO();
			validationMessageVO.setCode(ValidationCode.SUBMITFAILURE.getMessageCode());
			validationMessageVO.setDisplayMessage(ValidationCode.SUBMITFAILURE.getMessage() + e.getMessage());
			orderVO.setValidationMessageVO(validationMessageVO);
			return orderVO;
		}

	}

	/**
	 * API called to validate a TN to check if TN is a valid format and has not
	 * inflight order associated to it in 3Flow
	 * 
	 * @param validateTNRequestVO
	 * @return ResponseVO
	 */
	@PostMapping(path = "/validate/tn", consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@Audited
	public ValidationMessageVO validateTN(@RequestBody ValidateTNRequestVO validateTNRequestVO) {
		try {

			if (validateTNRequestVO == null) {
				String errorMessage = "@TollFreeOrderService: validateTN: validateTNRequestVO is null";
				logger.error(errorMessage);
				createErrorResponse(errorMessage);
			}

			return tollFreeOrderServiceManager.validateTN(validateTNRequestVO);
		} catch (Exception e) {
			logger.error("Exception processing validate tn : " + "\n", e);
			Level3Response l3Response = (e instanceof TollFreeOrderServiceException)
					? Level3Response.BAD_REQUEST_400_INVALID_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(
					"@TollFreeOrderService: submitOrder: Exception processing file upload: " + e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@PostMapping(path = "/1s/uploadBulkOrder", consumes = { MediaType.ALL_VALUE })
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@Audited
	public Map<String, String> uploadBulkOrder(MultipartHttpServletRequest request) throws Exception {
		logger.debug("Inside uploadBulkOrder");
		String errorMessage = "";

		if (request == null) {
			errorMessage = "@TollFreeOrderService: uploadBulkOrder: MultipartHttpServletRequest is null";
			logger.error(errorMessage);
			createErrorResponse(errorMessage);
		}

		MultipartFile uploadedFile = request.getFile("file");
		if (uploadedFile == null) {
			errorMessage = "@TollFreeOrderService: uploadBulkOrder: Please attach the file";
			logger.error(errorMessage);
			createErrorResponse(errorMessage);
		}

		logger.info("@TollFreeOrderService: uploadBulkOrder: uploaded file size: " + uploadedFile.getSize());
		
		String filename = (uploadedFile).getOriginalFilename();
		String directory = System.getProperty("java.io.tmpdir");
		String filepath = Paths.get(directory, filename).toString();

		logger.debug("@TollFreeOrderService: uploadOneSData: Uploaded file " + filepath + " File name: " + filename);

		return tollFreeOrderServiceManager.processBulkUpload(request, uploadedFile, filename, directory, filepath);
	}

	/**
	 * Standalone batch trigger and verification
	 * 
	 * @param batchId
	 * @throws Exception
	 */
	@GetMapping(path = "/launchJob/{voId}")
	public void handle(@PathVariable Long voId) throws Exception {
		//TODO subscriber need to create
		bulkOrderProcessor.startBulkOrderSubmitBatch(Long.valueOf(voId), null);
	}

	/**
	 * Method where the processor is called to get the workflow activities of a tn
	 * and return as output
	 * 
	 * @param tn
	 * @return List<ActivitySearchVO>
	 */
	@RequestMapping(path = "/activitySearch", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ActivitySearchVO> getWorkflowActivities(@RequestBody ActivitySearchScreenInputVO activityScreenReqParams) throws ParseException {
		if (activityScreenReqParams == null )  {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid search request. Please select at-least one of the required fields");
			throw new ServiceException(l3Response);
		}

		List<ActivitySearchVO> listOfActivities = tollFreeOrderServiceManager.getActivities(activityScreenReqParams);

		return listOfActivities;

	}

	/**
	 * Method where the processor is called to trigger the workflow activities
	 * 
	 * @param order
	 *            activity pk array
	 * @param type
	 *            of activity
	 * @return
	 * @throws RemoteException
	 */
	@RequestMapping(path = "/triggerActivity", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE }, consumes = {
					MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public UIResponseVo[] triggerActivity(@RequestBody TriggerActivityInputVO triggerActivityParams)
			throws RemoteException {
		if (triggerActivityParams.getActionType() == null || triggerActivityParams.getOrderActivityPk().length == 0) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid search request. Please select at-least one of the required fields");
			throw new ServiceException(l3Response);
		}

		UIResponseVo[] response = null;

		if (triggerActivityParams.getActionType().equals("Restart Activity")) {
			response = sauiUpdateClient.restartActivity(triggerActivityParams.getOrderActivityPk());
		}

		if (triggerActivityParams.getActionType().equals("Complete Activity")) {
			response = sauiUpdateClient.forceCompleteActivity(triggerActivityParams.getOrderActivityPk());
		}
		return response;

	}

	@PostMapping(path = "/launchNS")
	@CrossOrigin
	@ResponseStatus(HttpStatus.OK)
	@Audited
	public Map<String, String> uploadNSBulkOrder(@RequestBody String fileName) throws Exception {
		logger.debug("@TollFreeOrderService: uploadNSBulkOrder: Uploaded  File name: " + fileName);
		//return new HashMap<String, String>();
		return tollFreeOrderServiceManager.processNSBulkUpload(fileName);
	}

	/**
	 * This method is to search bulkupload based on VOID
	 * 
	 * @param voId
	 * @return
	 */
	@RequestMapping(path = "/bulkSearch/{voId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<BulkOrderUploadDTO> getBulkUploadData(@PathVariable String voId) {
		List<BulkOrderUploadDTO> bulkOrderUploadDTOs = tollFreeOrderServiceManager.getBulkUploadData(voId);

		return bulkOrderUploadDTOs;
	}

	@RequestMapping(path = "/productSummary/{customerId}/{serviceLocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	List<ProductSummaryVO> getProductSummary(@PathVariable String customerId, @PathVariable String serviceLocationId) {
		if (StringUtils.isEmpty(customerId)
				|| StringUtils.isEmpty(serviceLocationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getProductSummary: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<ProductSummaryVO> productSummary = null;
		try {
			productSummary = tollFreeOrderServiceManager.getProductSummary(customerId,serviceLocationId);
		} catch (Exception e) {
			logger.error("@getProductSummary: Exception processing getProductSummary", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productSummary;
	}
	
	@RequestMapping(path = "/getCustProductSummary/{customerId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ProductSummaryVO> getCustProductSummary(@PathVariable String customerId) {
		if ( StringUtils.isEmpty(customerId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getAllAccountInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<ProductSummaryVO> productSummary = null;
		try {
			productSummary = tollFreeOrderServiceManager.getCustProductSummary(customerId);
		} catch (Exception e) {
			logger.error("@getAllAccountInfo: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productSummary;
	}

}
