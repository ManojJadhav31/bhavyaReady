package com.level3.voice.tollfree.bulk.batch;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.BatchProcessConstants;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadDTO;
import com.level3.voice.tollfree.bulk.dto.BulkOrderUploadItemDTO;
import com.level3.voice.tollfree.bulk.repository.BulkOrderUploadItemRepository;
import com.level3.voice.tollfree.bulk.repository.BulkOrderUploadRepository;
import com.level3.voice.tollfree.client.DataMSClient;
import com.level3.voice.tollfree.client.WorkflowClient;
import com.level3.voice.tollfree.processor.OrderSubmitAsyncProcessor;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import jcifs.smb.SmbFileOutputStream;

/**
 * The method gets executed after the job 
 * @author 
 * <a href="mailto:manjunath.d@centurylink.com">Manju (ab68221)</a>
 */
@Component
public class BulkOrderSubmitJobCompletionNotificationListener extends JobExecutionListenerSupport {

	private static final Logger logger = LoggerFactory.getLogger(BulkOrderSubmitJobCompletionNotificationListener.class);

	
	@Autowired
	BulkOrderUploadRepository bulkOrderUploadRepository;
	
	@Autowired
	BulkOrderUploadItemRepository bulkOrderUploadItemRepository;
	
	@Autowired
	SlOrderRepository slOrderRepository;
	
	@Autowired
	OrderSubmitAsyncProcessor orderSubmitAsyncProcessor;

	@Autowired
	DataMSClient dataMSClient;

	@Value("${tn.upload.excel.bulk.folder.location}")
	public String folderLocation;

	@Value("${tn.upload.excel.bulk.ftp.user}")
	public String ftpUser;

	@Value("${tn.upload.excel.bulk.ftp.password}")
	public String ftpPassword;
	
	@Autowired
	WorkflowClient workflowClient;
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		logger.info("!!! After BulkOrderSubmitJob!");
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			JobParameter voId = jobExecution.getJobParameters().getParameters().get("VOICE_ORDER_ID");
			Long voIdLong = (Long) voId.getValue();
			
			List<BulkOrderUploadItemDTO> bulkOrderUploadItemList = bulkOrderUploadItemRepository.findByVoId(voIdLong.toString());
			Set<Long> pons = new HashSet<Long>();
			for (BulkOrderUploadItemDTO item : bulkOrderUploadItemList) {
				if (item.getStatus() != null
						&& !BatchProcessConstants.BATCH_STATUS_ERROR_CAPS.equals(item.getStatus())) {
					pons.add(item.getPon());
				}

			}
			try {
				triggerPONWorkflow(voIdLong, pons);
			} catch (Exception e) {
				for (BulkOrderUploadItemDTO item : bulkOrderUploadItemList) {
					item.setStatus(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS);
					item.setComments("Exception while triggering PON workflow");
				}
				bulkOrderUploadItemRepository.save(bulkOrderUploadItemList);
				bulkOrderUploadItemRepository.flush();
			}

			triggerSlOrderWokflow(pons);
			responseFileGeneratorForBulk(voIdLong);
			logger.info("!!! BulkOrderSubmitJob FINISHED at " + System.currentTimeMillis()
					+ "Msec ! Time to verify the results");
		}
	}
	private void triggerSlOrderWokflow(Set<Long> ponSet) {
		for (Long pon : ponSet) {
			try {
				logger.info("@BulkOrderSubmitJobCompletionNotificationListener @triggerSlOrderWokflow: Started for: "
						+ ponSet + " pon: " + pon);
				if(pon !=null)
					orderSubmitAsyncProcessor.submitOrder(pon);
			} catch (SLDBException e) {
				logger.error(
						"@BulkOrderSubmitJobCompletionNotificationListener @triggerSlOrderWokflow: " + e.getMessage());
			}
			logger.info("@BulkOrderSubmitJobCompletionNotificationListener @triggerSlOrderWokflow: Completed for: "
					+ ponSet + " pon: " + pon);
		}
	}
	
	/**
	 * The jResponse file generator for the NS BULK files.
	 * 
	 * @param voiceOrderId
	 *  
	 * @throws Exception
	 */
	
	private void responseFileGeneratorForBulk( Long voIdLong) {

		logger.info(" Inside Response File Generator ");
		List<BulkOrderUploadDTO> bulkUploadItem = bulkOrderUploadRepository.findByVoId(voIdLong.toString());
		List<BulkOrderUploadItemDTO> bulkOrderUploadItemList = bulkOrderUploadItemRepository.findByVoId(voIdLong.toString());
		if (!("BULK".equals(bulkUploadItem.get(0).getFileType()))) {
			return;
		}
		int count = 0, acceptCount = 0, rejectCount = 0;
		String fileName = bulkUploadItem.get(0).getFileName();
		String filePathName = "smb:" + folderLocation + bulkUploadItem.get(0).getCustomerId() + "/Response/"
				+ FilenameUtils.removeExtension(fileName) + ".RSP";
		NtlmPasswordAuthentication auth = new NtlmPasswordAuthentication(null, ftpUser, ftpPassword);
		String rejFilePathName = "smb:" + folderLocation + bulkUploadItem.get(0).getCustomerId() + "/Response/"
				+ FilenameUtils.removeExtension(fileName) + ".REJ";
		try {
			SmbFile resp = new SmbFile(filePathName, auth);
			SmbFile rej = new SmbFile(rejFilePathName, auth);
			SmbFileOutputStream respFile = new SmbFileOutputStream(resp,true);
			SmbFileOutputStream rejFile = null;
			Date date = new Date();

			String writeLine = fileName + "\t Date: " + (new SimpleDateFormat("yyyyMMdd").format(date))
					+ "\t Pick Time: " + (new SimpleDateFormat("HH:mm:ss").format(date));

			respFile.write(writeLine.getBytes());
			String url = "smb:" + folderLocation + "BulkOrdersArchive/" + fileName;
			SmbFile dir = new SmbFile(url, auth);

			BufferedReader reader = new BufferedReader(new InputStreamReader(new SmbFileInputStream(dir)));
			String line = reader.readLine();

			if (line.isEmpty()) {
				reader.close();
			}
			boolean prevRecord = false;
			List<String> wtnList=new ArrayList<String>();
			
			do {
				if (!line.isEmpty()) {
					if ("1S".equals(line.substring(10, 12).trim())) {
						prevRecord = false;
						String wtn = line.substring(49, 59).trim();
						wtnList.add(wtn);
						List<BulkOrderUploadItemDTO> tnBulkList = bulkOrderUploadItemList.stream()
								.filter(item -> item.getWtn().equals(wtn)).collect(Collectors.toList());
						if (tnBulkList.size() > 0) {
							if (tnBulkList.get(Collections.frequency(wtnList, wtn)-1).getStatus().equals(BatchProcessConstants.BATCH_STATUS_ERROR_CAPS)) {
								rejectCount++;
								prevRecord = false;
								/* Write to reject file and RSP file */
								if (rejFile == null)
									rejFile = new SmbFileOutputStream(rej,true);
								
								rejFile.write((line+"\r\n").getBytes());
								writeLine = "\r\nRecord " + count + " : Rejected - [" + getValidationMessageVO(tnBulkList.get(0).getComments()) + "]";
								respFile.write(writeLine.getBytes());
								
							} else {
								acceptCount++;
								prevRecord = true;
							}
						}
					}
					if ("FT".equals(line.substring(10, 12).trim())) {
						if (prevRecord == false) {
							rejectCount++;
							writeLine = "\r\nRecord " + count
									+ " : Rejected	Record rejected because of base order rejection.";
							respFile.write(writeLine.getBytes());
						} else
							acceptCount++;
					}
					count++;
				}
				line = reader.readLine();
			} while (line != null);
			
			if (rejFile != null)
				rejFile.close();
			
			reader.close();
			writeLine = "\r\nFile Contains  " + (count - 1) + " Records   " 
								+ acceptCount + " Accepted   " 
								+ rejectCount + " Rejected   0  Warnings";
			respFile.write(writeLine.getBytes());

			writeLine = "\r\nFile Processed at " + (new SimpleDateFormat("HH:mm:ss").format(date)) + " on "
					+ (new SimpleDateFormat("yyyyMMdd").format(date)) + "\r\n";
			
			respFile.write(writeLine.getBytes());
			respFile.close();
			/*Update Batch Drop file as Completed if its there*/
			dataMSClient.updateBatchDrop(fileName, bulkUploadItem.get(0).getCustomerId());
			
		} catch (Exception e) {
			logger.error(
					"@BatchBULK Upload Completion: @responseFileGeneratorForBulk: Exception in responseFileGenerator: "
							+ e.getMessage());
		}
	}
	
	
	/**
	 * The validation message extarction.
	 * 
	 * @param comments
	 *  
	 * @throws Exception
	 */
	private String getValidationMessageVO(String comments) {
		String message=null;
		if (comments == null)
			return message;
		String[] expressions = comments.split(", code");
		if(expressions.length > 0 ) {
			message=expressions[0].split("=")[1];
		}
		return message;
	
	}
	
	/**
	 * Trigger PON Workflow
	 * 
	 * @param voiceOrderId
	 * @param ponInfo
	 */
	private void triggerPONWorkflow(Long voiceOrderId, Set<Long> pons) {
		ExecutorService es = Executors.newFixedThreadPool(500);
		for (Long pon : pons) {
			es.execute(new Runnable() {
				@Override
				public void run() {
					try {
						workflowClient.submitOrderToWorkflow(pon);
					} catch (Exception e) {
						logger.error("@TollFreeOrderServiceManager: @processPONGrouping: Exception with message: "
								+ e.getMessage());
					}
				}
			});
		}
		es.shutdown();
		try {
			es.awaitTermination(180, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			logger.error("PON Workflow flow interrupted exception: " + e.getMessage());
		}
		logger.info("PON Workflow flow triggered for voice order id: " + voiceOrderId);
	}
}
