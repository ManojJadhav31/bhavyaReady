package com.level3.voice.tollfree.repository;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.vo.AniDataVO;
import com.level3.voice.tollfree.vo.AniSearchInputReqVO;
import com.level3.voice.tollfree.vo.AniStatusVO;

@Component
public class AniDetailsRepository {

	@Autowired
	EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<AniDataVO> getAniDataForReports(AniSearchInputReqVO aniSearchReqParams) throws ParseException {

		List<Object[]> ReportScreenDTOs = new ArrayList<>();
		List<AniDataVO> aniSearchlist = new ArrayList<>();

		String reportDataQuery = "select adv.CUSTOMER_ID,adv.CUSTOMER_NAME,adv.SERVICE_ADDRESS_ID,adv.PRODUCT_OFFERING_ID,adv.tn,adv.btn,\r\n"
				+ "adv.cic,os.status,adv.ocn,adv.INTRALATA_FIRST_USAGE_DATE,adv.INTRALATA_LAST_USAGE_DATE,adv.INTERLATA_FIRST_USAGE_DATE,adv.INTERLATA_LAST_USAGE_DATE, "
				+ "adv.tc,adv.si,adv.name,adv.ACCOUNT_NUMBER,adv.ORDER_DATE from SUBL_OWNER.GET_ORDER_DETAILS_VIEW adv INNER JOIN  SUBL_OWNER.GET_ORDER_STATUS_VIEW os "
				+ "on adv.sl_order_Id=os.sl_order_id "
				+ getWhereData(aniSearchReqParams);

		ReportScreenDTOs = entityManager.createNativeQuery(reportDataQuery).getResultList();
		for (int i = 0; i < ReportScreenDTOs.size(); i++) {
			AniDataVO aniDataVO = new AniDataVO();
			Object[] tempObject = (Object[]) ReportScreenDTOs.get(i);
			if (tempObject[0] != null) {
				aniDataVO.setCustomerId((tempObject[0].toString()));
			}
			if (tempObject[1] != null) {
				aniDataVO.setCustomerName((tempObject[1].toString()));
			}
			if (tempObject[2] != null && tempObject[16] != null) {
				aniDataVO.setServiceLocationId((tempObject[2].toString() + "/" + tempObject[16].toString()));
			}
			if (tempObject[3] != null) {
				aniDataVO.setProductId((tempObject[3].toString()));
			}
			if (tempObject[4] != null) {
				aniDataVO.setTn((tempObject[4].toString()));
			}
			if (tempObject[5] != null) {
				aniDataVO.setBtn((tempObject[5].toString()));
			}
			if (tempObject[6] != null) {
				aniDataVO.setCic((tempObject[6].toString()));
			}
			if (tempObject[7] != null) {
				aniDataVO.setStatus((tempObject[7].toString()));
			}
			if (tempObject[8] != null) {
				aniDataVO.setOcn(tempObject[8].toString());
			}
			if (tempObject[9] != null) {
				aniDataVO.setIntraLataFirstUsage((tempObject[9].toString()));
			}
			if (tempObject[10] != null) {
				aniDataVO.setIntraLataLastUsage((tempObject[10].toString()));
			}
			if (tempObject[11] != null) {
				aniDataVO.setInterLataFirstUsage((tempObject[11].toString()));
			}
			if (tempObject[12] != null) {
				aniDataVO.setInterLataLastUsage((tempObject[12].toString()));
			}
			if (tempObject[13] != null) {
				aniDataVO.setTc((tempObject[13].toString()));
			}
			if (tempObject[14] != null) {
				aniDataVO.setSi((tempObject[14].toString()));
			}
			if (tempObject[15] != null) {
				aniDataVO.setName((tempObject[15].toString()));
			}
			if (tempObject[17] != null) {
				aniDataVO.setOrderDate((tempObject[17].toString()));
			}
			aniSearchlist.add(aniDataVO);
		}

		return aniSearchlist;
	}

	@SuppressWarnings("unchecked")
	public List<AniStatusVO> getAniByStatusCount(AniSearchInputReqVO aniSearchReqParams) throws ParseException {
		List<Object[]> reportServiceSummaryDTOs = new ArrayList<>();

		String reportDataQuery = "select name, count(name) from SUBL_OWNER.GET_SERV_SUMMARY_VIEW adv"
				+ getWhereData(aniSearchReqParams) + " group by name";

		reportServiceSummaryDTOs = entityManager.createNativeQuery(reportDataQuery).getResultList();
		AniStatusVO activeAniStatusVO = new AniStatusVO();
		List<AniStatusVO> tempList = new ArrayList<AniStatusVO>();
		for (int i = 0; i < reportServiceSummaryDTOs.size(); i++) {
			Object[] tempObject = (Object[]) reportServiceSummaryDTOs.get(i);
			if (tempObject[0] != null && ("Install".equals(tempObject[0]) || "Unblock".equals(tempObject[0])
					|| "Change".equals(tempObject[0]))) {
				activeAniStatusVO.setStatus("Active");
				if (activeAniStatusVO.getStatusCount() == null) {
					activeAniStatusVO.setStatusCount("0");
				}
				if (tempObject[1] != null) {
					Long totalActiveCount = Long.parseLong(activeAniStatusVO.getStatusCount())
							+ Long.parseLong(tempObject[1].toString());
					activeAniStatusVO.setStatusCount(totalActiveCount.toString());
				}

			} else {
				AniStatusVO aniStatusVO = new AniStatusVO();
				if (tempObject[0] != null) {
					aniStatusVO.setStatus(tempObject[0].toString());
				}

				if (tempObject[1] != null) {
					aniStatusVO.setStatusCount(tempObject[1].toString());
				}
				if (aniStatusVO.getStatus() != null)
					tempList.add(aniStatusVO);
			}

		}
		if (activeAniStatusVO.getStatus() != null)
			tempList.add(activeAniStatusVO);
		return tempList;
	}

	private String getWhereData(AniSearchInputReqVO aniSearchReqParams) {
		String data = "";

		if (aniSearchReqParams.getWtn() != null && aniSearchReqParams.getWtn().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " adv.tn= '" + aniSearchReqParams.getWtn() + "'";

		}
		if (aniSearchReqParams.getBtn() != null && aniSearchReqParams.getBtn().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " adv.btn= '" + aniSearchReqParams.getBtn() + "'";

		}
		if (aniSearchReqParams.getServiceLocationId() != null
				&& aniSearchReqParams.getServiceLocationId().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " adv.service_Address_Id= '" + aniSearchReqParams.getServiceLocationId() + "'";
		}
		if (aniSearchReqParams.getCustomerId() != null
				&& aniSearchReqParams.getCustomerId().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " adv.customer_Id= '" + aniSearchReqParams.getCustomerId() + "'";
		}
		if (!StringUtils.isEmpty(aniSearchReqParams.getName())) {
			data = addWhereAndData(data);
			if ("Active".equals(aniSearchReqParams.getName())) {
				data = data + " adv.name IN ('Install','Unblock','Change')";
			} else {
				data = data + " adv.name= '" + aniSearchReqParams.getName() + "'";
			}

		}
		if (aniSearchReqParams.getStatus() != null && aniSearchReqParams.getStatus().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			data = data + " os.status= '" + aniSearchReqParams.getStatus() + "'";
		}
		if (aniSearchReqParams.getOrderStartDate() != null && aniSearchReqParams.getOrderEndDate() != null
				&& aniSearchReqParams.getOrderStartDate().toString().trim().length() > 0
				&& aniSearchReqParams.getOrderEndDate().toString().trim().length() > 0) {
			data = addWhereAndData(data);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
			Calendar eCal = Calendar.getInstance();
			eCal.setTime(aniSearchReqParams.getOrderEndDate());
			eCal.add(Calendar.DATE, 1);
			data = data + " adv.order_Date > '" + sdf.format(aniSearchReqParams.getOrderStartDate())
					+ "' and  adv.order_Date < '" + sdf.format(eCal.getTime()) + "'";
		}
		return data;

	}

	private String addWhereAndData(String data) {
		if (StringUtils.isEmpty(data)) {
			data = data + " where ";
		} else {
			data = data + " and ";
		}
		return data;
	}
}
