package com.level3.voice.tollfree.manager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.persist.dto.SlOrderDTO;
import com.level3.voice.persist.repository.SlOrderRepository;
import com.level3.voice.tollfree.persist.dto.LandingScreenDTO;
import com.level3.voice.tollfree.persist.dto.OrderTollFreeFeatureDTO;
import com.level3.voice.tollfree.persist.dto.TNDataDTO;
import com.level3.voice.tollfree.persist.repository.LandingDataRepository;
import com.level3.voice.tollfree.persist.repository.OrderTollFreeFeatureRepository;
import com.level3.voice.tollfree.persist.repository.TNSearchRepository;
import com.level3.voice.tollfree.persist.vo.LandingScreenSearchVO;
import com.level3.voice.tollfree.persist.vo.SearchScreenInputVO;
import com.level3.voice.tollfree.vo.FeaturesVO;
import com.level3.voice.tollfree.vo.OrderVO;
import com.level3.voice.tollfree.vo.TNDataVO;
import com.level3.voice.tollfree.vo.ValidatedCustomAcctCodeVO;

@Component
public class LandingDataServiceManager {
	@Autowired
	LandingDataRepository landingDataRepository;

	@Autowired
	TNSearchRepository tnDearchRepository;

	@Autowired
	EntityManager entityManager;

	@Autowired
	SlOrderRepository slOrderRepository;

	@Autowired
	OrderTollFreeFeatureRepository orderTollfreeFeatureRepository;

	@Value("#{'${list.of.features}'.split(',')}")
	private List<String> featuresGroup;

	private static final Logger logger = Logger.getLogger(LandingDataServiceManager.class);

	public List<LandingScreenDTO> getVoiceData(SearchScreenInputVO landingScreenReqParams) throws ParseException {
		List<LandingScreenDTO> objs = landingDataRepository.getVoiceData(landingScreenReqParams);
		return objs;
	}

	public List<TNDataDTO> getTNs(String voiceOrderId) {
		List<TNDataDTO> objs = tnDearchRepository.getTNs(voiceOrderId);
		return objs;
	}

	/*
	 * public List<LandingScreenDTO> getVoiceDataFromANI(SearchScreenInputVO
	 * landingScreenReqParams) throws ParseException { List<LandingScreenDTO> objs =
	 * landingDataRepository.getVoiceDataFromANI(landingScreenReqParams); return
	 * objs; }
	 */

	public OrderVO getOrderTnData(String voiceOrderId, String tn) {

		OrderVO orderVO = new OrderVO();
		List<TNDataVO> tndataVO = new ArrayList<>();

		Map<String, String> featureDetails = getFeatureDetails();

		List<OrderTollFreeFeatureDTO> orderTollfreeFeaturelist = orderTollfreeFeatureRepository
				.getAllByVoiceOrderId(Long.parseLong(voiceOrderId), tn);

		if (orderTollfreeFeaturelist == null
				|| (orderTollfreeFeaturelist != null && orderTollfreeFeaturelist.isEmpty())) {
			return null;
		}

		OrderTollFreeFeatureDTO orderTollFreeFeaturedto = orderTollfreeFeaturelist.get(0);

		SlOrderDTO slOrderdto = slOrderRepository.findOne(orderTollFreeFeaturedto.getSlOrderId());

		orderVO.setBan(orderTollFreeFeaturedto.getAccountNumber());
		orderVO.setCustomerID(slOrderdto.getExternalCustomerId());
		orderVO.setBusOrgId(slOrderdto.getCustomerBizOrgId());
		orderVO.setOrgId(slOrderdto.getMasterBizOrgId());
		orderVO.setCustomerName(slOrderdto.getCustomerBizOrgName());
		orderVO.setControlGroupId(orderTollFreeFeaturedto.getControlGroupId());
		orderVO.setProductId(orderTollFreeFeaturedto.getProductOfferingID());
		orderVO.setServiceLocationId(orderTollFreeFeaturedto.getServiceAddressId());

		if (orderTollfreeFeaturelist != null) {

			for (int i = 0; i < orderTollfreeFeaturelist.size(); i++) {

				orderTollFreeFeaturedto = new OrderTollFreeFeatureDTO();

				orderTollFreeFeaturedto = orderTollfreeFeaturelist.get(i);
				if (orderTollFreeFeaturedto.getTn().equals(tn)) {

					TNDataVO tndatadto = new TNDataVO();
					FeaturesVO featuredto = new FeaturesVO();
					List<FeaturesVO> featureVO = new ArrayList<>();

					ValidatedCustomAcctCodeVO validatedCustomAcctCodedto = new ValidatedCustomAcctCodeVO();

					// setting tnDataVOs
					tndatadto.setWtn(orderTollFreeFeaturedto.getTn());
					tndatadto.setBtn(orderTollFreeFeaturedto.getBtn());
					tndatadto.setCic(orderTollFreeFeaturedto.getCic());
					tndatadto.setPic(orderTollFreeFeaturedto.getPicRequest());
					tndatadto.setForceAniLoad(orderTollFreeFeaturedto.getForcedANI());
					tndatadto.setJurisdiction(orderTollFreeFeaturedto.getJurisdiction());
					// setting features...
					String featureBlockAll = orderTollFreeFeaturedto.getBlockAll();
					String featureBlockCaribInter = orderTollFreeFeaturedto.getBlockCaribInter();
					String featureBlockFraudAll = orderTollFreeFeaturedto.getBlockFraudAll();
					String featureBlockFraudCaribInter = orderTollFreeFeaturedto.getBlockFraudCaribInter();
					String featureBlocking = orderTollFreeFeaturedto.getBlocking();
					String featurePositiveANI = orderTollFreeFeaturedto.getPositiveANI();
					String featurePortedANI = orderTollFreeFeaturedto.getPortedANI();
					String featureUnvalidatedAC = orderTollFreeFeaturedto.getUnvalidatedAC();
					String featureValidatedAC = orderTollFreeFeaturedto.getValidatedAC();

					if (featureBlockAll != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featureBlockAll));
						featuredto.setFeatureOfferingId(featureBlockAll);
						featureVO.add(featuredto);
					}
					if (featureBlockCaribInter != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featureBlockCaribInter));
						featuredto.setFeatureOfferingId(featureBlockCaribInter);
						featureVO.add(featuredto);
					}
					if (featureBlockFraudAll != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featureBlockFraudAll));
						featuredto.setFeatureOfferingId(featureBlockFraudAll);
						featureVO.add(featuredto);
					}
					if (featureBlockFraudCaribInter != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featureBlockFraudCaribInter));
						featuredto.setFeatureOfferingId(featureBlockFraudCaribInter);
						featureVO.add(featuredto);
					}
					if (featureBlocking != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featureBlocking));
						featuredto.setFeatureOfferingId(featureBlocking);
						featureVO.add(featuredto);
					}

					if (featurePositiveANI != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featurePositiveANI));
						featuredto.setFeatureOfferingId(featurePositiveANI);
						featureVO.add(featuredto);
					}

					if (featurePortedANI != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featurePortedANI));
						featuredto.setFeatureOfferingId(featurePortedANI);
						featureVO.add(featuredto);
					}
					if (featureUnvalidatedAC != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featureUnvalidatedAC));
						featuredto.setFeatureOfferingId(featureUnvalidatedAC);
						featuredto.setAccountCodeESF(orderTollFreeFeaturedto.getAccountCodeEsf());
						featureVO.add(featuredto);

					}
					if (featureValidatedAC != null) {
						featuredto = new FeaturesVO();
						featuredto.setFeatureDescription(featureDetails.get(featureValidatedAC));
						featuredto.setFeatureOfferingId(featureValidatedAC);
						featuredto.setAccountCodeESF(orderTollFreeFeaturedto.getAccountCodeEsf());
						featureVO.add(featuredto);

						validatedCustomAcctCodedto = new ValidatedCustomAcctCodeVO();

						validatedCustomAcctCodedto.setCodeDigits(orderTollFreeFeaturedto.getAcDigits());
						validatedCustomAcctCodedto.setCodeTableName(orderTollFreeFeaturedto.getAcTableName());
						validatedCustomAcctCodedto.setCodeTableId(orderTollFreeFeaturedto.getAcTableId());
					} else {
						validatedCustomAcctCodedto = null;
					}

					tndatadto.setFeatures(featureVO);
					if (validatedCustomAcctCodedto != null) {
						tndatadto.setValidatedCustomAcctCodeVO(validatedCustomAcctCodedto);
					}

					tndataVO.add(tndatadto);

				}

			}
			orderVO.setTnDataVOs(tndataVO);
		}

		return orderVO;
	}

	private Map<String, String> getFeatureDetails() {
		Map<String, String> featureDetails = new HashMap<String, String>();

		for (String featureGroup : featuresGroup) {
			String[] features = featureGroup.split(":");
			featureDetails.put(features[0], features[1]);
		}

		return featureDetails;
	}

	public List<LandingScreenSearchVO> getDataForLandingScreen(SearchScreenInputVO landingScreenReqParams)
			throws ParseException {
		return landingDataRepository.getDataForSearch(landingScreenReqParams);
		// return objs;
	}

	public boolean validateInputData(SearchScreenInputVO landingScreenReqParams) {
		boolean valid = false;
		if (landingScreenReqParams.getVoiceOrderId() != null
				&& landingScreenReqParams.getVoiceOrderId().toString().trim().length() > 0) {

			SlOrderDTO slObj = slOrderRepository.findOne(Long.parseLong(landingScreenReqParams.getVoiceOrderId()));
			if (slObj != null)
				valid = true;
		} else if (landingScreenReqParams.getVoiceOrderId() != null
				&& landingScreenReqParams.getTn().toString().trim().length() > 0) {
			List<OrderTollFreeFeatureDTO> dtoObj = orderTollfreeFeatureRepository
					.getOrderByTN(landingScreenReqParams.getTn());
			if (dtoObj.size() > 0)
				valid = true;
		}
		return valid;
	}

}