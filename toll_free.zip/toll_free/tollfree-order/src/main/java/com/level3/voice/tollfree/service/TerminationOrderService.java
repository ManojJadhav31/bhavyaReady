package com.level3.voice.tollfree.service;

import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.manager.TerminationOrderServiceManager;
import com.level3.voice.tollfree.model.Switches;
import com.level3.voice.tollfree.model.TrunkGroups;

/**
 * Retrieve termination related data using the service
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/termination")
public class TerminationOrderService {

	private static final Logger logger = Logger.getLogger(TerminationOrderService.class);

	@Autowired
	private TerminationOrderServiceManager terminationOrderServiceManager;

	/**
	 * Retrieve the switches associated to the BAN
	 * 
	 * @param ban
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(path = "/retrieve/switch/{ban}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public Switches retrieveSwitchDetails(@PathVariable String ban) throws ParseException {
		if (StringUtils.isEmpty(ban)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("@retrieveSwitchDetails: Invalid Input. Please provide ban d the required fields");
			throw new ServiceException(l3Response);
		}
		try {
			return terminationOrderServiceManager.retrieveSwitchDetails(ban);
		} catch (Exception e) {
			logger.error("@retrieveSwitchDetails: Exception processing retrieveSwitchDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * Retrieve trunk groups related to the BAN and switch final number [switch]
	 * which user selected
	 * 
	 * @param ban
	 * @param switchfinalNumber
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(path = "/retrieve/trunkgroup/{ban}/{switchfinalNumber}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public TrunkGroups retrieveTrunkGroupDetails(@PathVariable String ban, @PathVariable String switchfinalNumber)
			throws ParseException {
		if (StringUtils.isEmpty(ban)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("@retrieveTrunkGroupDetails: Invalid Input. Please provide ban d the required fields");
			throw new ServiceException(l3Response);
		}
		try {
			return terminationOrderServiceManager.retrieveTrunkGroupDetails(ban, switchfinalNumber);
		} catch (Exception e) {
			logger.error("@retrieveTrunkGroupDetails: Exception processing retrieveTrunkGroupDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
	}

}
