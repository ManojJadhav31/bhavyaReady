package com.level3.voice.tollfree.vo;

import java.io.Serializable;

/**
 * VO object holds information of all the feature information which user has
 * selected for a TN
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class FeaturesVO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String featureOfferingId;
	private String featureDescription;
	private String accountCodeESF;
	
	public String getFeatureOfferingId() {
		return featureOfferingId;
	}
	public void setFeatureOfferingId(String featureOfferingId) {
		this.featureOfferingId = featureOfferingId;
	}
	public String getFeatureDescription() {
		return featureDescription;
	}
	public void setFeatureDescription(String featureDescription) {
		this.featureDescription = featureDescription;
	}
	public String getAccountCodeESF() {
		return accountCodeESF;
	}
	public void setAccountCodeESF(String accountCodeESF) {
		this.accountCodeESF = accountCodeESF;
	}
	

}
