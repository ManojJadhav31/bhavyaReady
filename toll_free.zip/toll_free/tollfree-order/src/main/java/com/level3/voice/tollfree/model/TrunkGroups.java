package com.level3.voice.tollfree.model;

import java.io.Serializable;
import java.util.List;

/**
 * Model object to represent the TrunkGroups object sent from PRO
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class TrunkGroups implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<TrunkGroup> trunkGroups;

	/**
	 * @return the trunkGroups
	 */
	public List<TrunkGroup> getTrunkGroups() {
		return trunkGroups;
	}

	/**
	 * @param trunkGroups the trunkGroups to set
	 */
	public void setTrunkGroups(List<TrunkGroup> trunkGroups) {
		this.trunkGroups = trunkGroups;
	}

}
