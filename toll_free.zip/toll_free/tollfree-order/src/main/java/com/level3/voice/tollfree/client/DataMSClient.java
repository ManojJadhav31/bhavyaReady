package com.level3.voice.tollfree.client;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.CacheConstants;
import com.level3.voice.tollfree.persist.dto.ServiceAddressDTO;
import com.level3.voice.tollfree.vo.CrcVO;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.OrderAdditionalDetailsVO;
import com.level3.voice.tollfree.vo.ResponseVO;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

/**
 * Client to interact with tollfree data microservice
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class DataMSClient {

	private static final Logger LOGGER = Logger.getLogger(DataMSClient.class);

	@Value("${tollfree.data.client.url}")
	private String baseUrl;

	@Value("${tollfree.data.client.connect.timeout.ms}")
	private Integer connectTimeoutMs;

	@Value("${tollfree.data.client.read.timeout.ms}")
	private Integer readTimeoutMs;

	@Value("${tollfree.data.client.retry.count.int}")
	private Integer retryCount;

	@Value("${tollfree.data.client.retry.interval.ms}")
	private Integer retryIntervalMs;

	ObjectMapper objectMapper;

	WebResource webResource;

	@PostConstruct
	public void init() throws Exception {
		Client client = Client.create();
		client.setReadTimeout(readTimeoutMs);
		client.setConnectTimeout(connectTimeoutMs);
		objectMapper = new ObjectMapper();
		webResource = client.resource(this.baseUrl);
	}

	/**
	 * Submit start workflow for slorderid
	 * 
	 * @param slOrderId
	 * @throws SLDBException
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":retrievelocation")
	public ServiceAddressDTO retrieveServiceLocation(String orgId, String customerId, String serviceLocationId)
			throws SLDBException {
		ServiceAddressDTO serviceLocationDTO = null;
		String serviceURL = "/ServiceDelivery/v1/Voice/location/";

		WebResource.Builder builder = webResource.path(serviceURL + orgId + "/" + customerId + "/" + serviceLocationId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);
			serviceLocationDTO = unmarshal(response.getEntity(String.class));
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieving service location" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieving the service location" + errorInfo);
		}
		return serviceLocationDTO;
	}

	/**
	 * This method is to retrieve the rateplan and SCID information based on
	 * organization id and product offering id
	 * 
	 * @param orgId
	 * @param productOfferingId
	 * @return
	 * @throws SLDBException
	 */
	public OrderAdditionalDetailsVO getOrderAdditionalDetails(String orgId, String productOfferingId,
			String accountNumber, String serviceLocationId) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/orderadditionaldetails/";
		String status = "A";
		OrderAdditionalDetailsVO orderAdditionalDetailsVO = null;

		WebResource.Builder builder = webResource
				.path(serviceURL + orgId + "/" + productOfferingId + "/" + status + "/" + accountNumber + "/"
						+ serviceLocationId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);

			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				orderAdditionalDetailsVO = unmarshalOrderAdditionalDetailsVO(response.getEntity(String.class));
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieving rate plan" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieving the rate plan" + errorInfo);
		}
		return orderAdditionalDetailsVO;
	}

	/**
	 * This method is to retrieve the customer details - billing account number and
	 * CRC for the accountNumber and serviceLocationId
	 * 
	 * @param accountNumber
	 * @param serviceLocationId
	 * @return
	 * @throws SLDBException
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":getCrc")
	public CrcVO getCrc(String organizationId, String customerId, String cic) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/crc/";
		CrcVO accountVO = null;

		WebResource.Builder builder = webResource.path(serviceURL + organizationId + "/" + customerId + "/" + cic)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);

			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				accountVO = unmarshalCrcVO(response.getEntity(String.class));
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieving rate plan" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieving the customer acc details" + errorInfo);
		}
		return accountVO;
	}

	/**
	 * This method is to validate NPA NXX
	 * 
	 * @param orgId
	 * @param productOfferingId
	 * @return
	 * @throws SLDBException
	 */
	public ResponseVO validateNPANXX(String tn) throws SLDBException {
		long startTime = System.currentTimeMillis();

		String serviceURL = "/ServiceDelivery/v1/Voice/validateNPNXX/";
		ResponseVO responseVO = null;

		WebResource.Builder builder = webResource.path(serviceURL + tn).entity(null, MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);

			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				responseVO = unmarshalResponseVO(response.getEntity(String.class));
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieving rate plan" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieving the rate plan" + errorInfo);
		}
		long endTime = System.currentTimeMillis();

		LOGGER.info("@DataMSClient @validateNPANXX took " + (endTime - startTime) + " milliseconds for: " + tn);
		return responseVO;
	}

	private ResponseVO unmarshalResponseVO(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		ResponseVO result = null;
		try {
			result = objectMapper.readValue(response, ResponseVO.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}

	/**
	 * Unmarshal the response as ServiceLocationDTO object
	 * 
	 * @param response
	 * @return
	 * @throws SLDBException
	 */
	private ServiceAddressDTO unmarshal(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		ServiceAddressDTO result = null;
		try {
			result = objectMapper.readValue(response, ServiceAddressDTO.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}

	/**
	 * Umarshal the response as RatePlanVO object
	 * 
	 * @param response
	 * @return
	 * @throws SLDBException
	 */
	private OrderAdditionalDetailsVO unmarshalOrderAdditionalDetailsVO(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		OrderAdditionalDetailsVO result = null;
		try {
			result = objectMapper.readValue(response, OrderAdditionalDetailsVO.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}

	/**
	 * Unmarshal the response in AccountVO object
	 * 
	 * @param response
	 * @return
	 * @throws SLDBException
	 */
	private CrcVO unmarshalCrcVO(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		CrcVO result = null;
		try {
			result = objectMapper.readValue(response, CrcVO.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}

	/**
	 * This method is to retrive customer info by ID
	 * 
	 * @param orgId
	 * @param customerId
	 * @return
	 * @throws SLDBException
	 */
	public CustomerVO retrieveCustomerInfo(String orgId, String customerId) throws SLDBException {
		CustomerVO customerVO = null;
		String serviceURL = "/ServiceDelivery/v1/Voice/customer/";

		WebResource.Builder builder = webResource.path(serviceURL + orgId + "/" + customerId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);

			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				customerVO = unmarshalCustomerVO(response.getEntity(String.class));
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieveCustomerInfo" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieveCustomerInfo" + errorInfo);
		}
		return customerVO;
	}

	private CustomerVO unmarshalCustomerVO(String entity) throws SLDBException {
		if (entity == null) {
			return null;
		}
		CustomerVO customerVO = null;
		try {
			customerVO = objectMapper.readValue(entity, CustomerVO.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return customerVO;
	}

	/**
	 * Its for getting the service location based on BAN
	 * 
	 * @param orgId
	 * @param customerId
	 * @param ban
	 * @return
	 * @throws SLDBException
	 */
	public CustomerVO serviceLocationByBan(String orgId, String customerId, String ban) throws SLDBException {
		CustomerVO customerVO = null;
		String serviceURL = "/ServiceDelivery/v1/Voice/serviceLocationIdByBan/";

		WebResource.Builder builder = webResource.path(serviceURL + orgId + "/" + customerId + "/" + ban)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);
			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				customerVO = unmarshalCustomerVO(response.getEntity(String.class));
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieveCustomerInfo" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieveCustomerInfo" + errorInfo);
		}
		return customerVO;
	}

	/**
	 * To get list of product list
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param servLocId
	 * @param detailType
	 * @return
	 * @throws SLDBException
	 */
	public CustomerVO getProductList(String organizationId, String customerId, String servLocId, String detailType)
			throws SLDBException {
		CustomerVO customerVO = null;
		String serviceURL = "/ServiceDelivery/v1/Voice/product/";/*
																	 * {organizationId}/{customerId}/{servLocId}/{
																	 * detailType}
																	 */

		WebResource.Builder builder = webResource
				.path(serviceURL + organizationId + "/" + customerId + "/" + servLocId + "/" + detailType)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);
			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				customerVO = unmarshalCustomerVO(response.getEntity(String.class));
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieveCustomerInfo" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieveCustomerInfo" + errorInfo);
		}
		return customerVO;
	}

	public CustomerVO fetchCodeTabList(String organizationId, String customerId) throws SLDBException {
		CustomerVO customerVO = null;
		String serviceURL = "/ServiceDelivery/v1/Voice/codetable/";// {organizationId}/{customerId}";

		WebResource.Builder builder = webResource.path(serviceURL + organizationId + "/" + customerId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);
			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				customerVO = unmarshalCustomerVO(response.getEntity(String.class));
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while fetchCodeTabList" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while fetchCodeTabList" + errorInfo);
		}
		return customerVO;
	}

	public CustomerVO fetchCICVO(String organizationId, String customerId, String serviceLocationId)
			throws SLDBException {
		CustomerVO customerVO = null;
		String serviceURL = "/ServiceDelivery/v1/Voice/cic/";// {organizationId}/{customerId}/{servLocId}";

		WebResource.Builder builder = webResource
				.path(serviceURL + organizationId + "/" + customerId + "/" + serviceLocationId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);
			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				customerVO = unmarshalCustomerVO(response.getEntity(String.class));
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while fetchCICVO" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while fetchCICVO" + errorInfo);
		}
		return customerVO;
	}

	/**
	 * This method is to retrive customer info by ID
	 * 
	 * @param orgId
	 * @param customerId
	 * @return
	 * @throws SLDBException
	 */
	public CustomerVO retrieveServiceLocations(String orgId, String customerId, String detailType)
			throws SLDBException {
		CustomerVO customerVO = null;
		String serviceURL = "/ServiceDelivery/v1/Voice/banlocationidinfo/";

		WebResource.Builder builder = webResource.path(serviceURL + orgId + "/" + customerId + "/" + detailType)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		try {
			ClientResponse response = builder.get(ClientResponse.class);

			if (response.getStatus() != 200) {
				String mRespBody = response.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				customerVO = unmarshalCustomerVO(response.getEntity(String.class));
			}

		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while retrieveCustomerInfo" + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("Exception while retrieveCustomerInfo" + errorInfo);
		}
		return customerVO;
	}

	/**
	 * This method is to retrieve default CIC
	 * 
	 * @param orgId
	 * @param customerId
	 * @param serviceLocationId
	 * @return
	 * @throws SLDBException
	 */
	public String getDefaultCIC(String orgId, String customerId, String serviceLocationId) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/defaultCIC/";

		WebResource.Builder builder = webResource.path(serviceURL + orgId + "/" + customerId + "/" + serviceLocationId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse clientResponse = null;
		try {

			clientResponse = builder.get(ClientResponse.class);
			if (clientResponse.getStatus() != 200) {
				LOGGER.error("Bad HTTP status returned while trying to obtain info from Service Availatbilty. Status: "
						+ clientResponse.getStatus() + clientResponse.getEntity(String.class));
				throw new SLDBException(
						"Bad HTTP status returned while  trying to obtain info from Service Availatbilty. Status: "
								+ clientResponse.getStatus());
			}
			if (clientResponse.getStatus() != 200 && clientResponse.getStatus() != 204) {
				throw new Exception(
						"CIC " + orgId + "/" + customerId + "/" + serviceLocationId + " submission failed.");
			}
			return clientResponse.getEntity(String.class);
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while getting the default CIC " + errorInfo, e);

		}
		return null;
	}

	/**
	 * This method is to retrieve default features
	 * 
	 * @param orgId
	 * @param customerId
	 * @param serviceLocationId
	 * @return
	 * @throws SLDBException
	 */
	public CustomerVO getDefaultFetaures(String organizationId, String productOfferingId, String controlGroupId)
			throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/defaultFeatures/";
		CustomerVO customerVO = null;
		WebResource.Builder builder = webResource
				.path(serviceURL + organizationId + "/" + productOfferingId + "/" + controlGroupId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse clientResponse = null;
		try {
			clientResponse = builder.get(ClientResponse.class);
			if (clientResponse.getStatus() != 200) {
				String mRespBody = clientResponse.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			} else {
				customerVO = unmarshalCustomerVO(clientResponse.getEntity(String.class));
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while getting the default features  " + errorInfo, e);

		}
		return customerVO;
	}

	/**
	 * This method is to retrieve default features
	 * 
	 * @param orgId
	 * @param customerId
	 * @param serviceLocationId
	 * @return
	 * @throws SLDBException
	 */
	public String getInHouseBizOrg(String organizationId, String custId) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/inhousebizorg/";
		WebResource.Builder builder = webResource.path(serviceURL + organizationId + "/" + custId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse clientResponse = null;
		try {
			clientResponse = builder.get(ClientResponse.class);
			if (clientResponse.getStatus() != 200) {
				String mRespBody = clientResponse.getEntity(String.class);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while getting the default features  " + errorInfo, e);

		}
		return clientResponse == null ? null : clientResponse.getEntity(String.class);
	}

	/**
	 * 
	 * This method is to Update batch Drop Status
	 * 
	 * @param fileName
	 * @param customerId
	 * 
	 * @return
	 * @throws SLDBException
	 */
	public void updateBatchDrop(String fileName, String customerId) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/update/batchDrop/";

		WebResource.Builder builder = webResource.path(serviceURL + fileName + "/" + customerId)
				.entity(null, MediaType.APPLICATION_JSON_TYPE).accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse clientResponse = null;
		try {
			clientResponse = builder.post(ClientResponse.class);
			if (clientResponse.getStatus() != 200) {
				LOGGER.error("Bad HTTP status returned while Updating the BatchDrop Status: "
						+ clientResponse.getStatus() + clientResponse.getEntity(String.class));
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception while getting the default CIC " + errorInfo, e);
		}
		return;
	}

	/**
	 * This method is to call the tollfree data to retrieve the flag value for the
	 * different ban property associated to the customer for the selected BAN
	 * 
	 * @param ban
	 * @throws SLDBException
	 */
	@Audited
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":isDifferentBanEnabled")
	public boolean isDifferentBanEnabled(String ban) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/isdifferentban/";

		WebResource.Builder builder = webResource.path(serviceURL + ban).entity(null, MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse clientResponse = null;
		try {
			clientResponse = builder.get(ClientResponse.class);
			if (clientResponse.getStatus() != 200) {
				String mRespBody = "Bad HTTP status returned while retrieving isDifferentBanEnabled flag : "
						+ clientResponse.getStatus() + clientResponse.getEntity(String.class);
				LOGGER.error(mRespBody);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Unable to publish message, Error message: " + errorInfo, e);
			throw new SLDBException("Unable to publish message, Error message: " + errorInfo);
		}
		String response = clientResponse.getEntity(String.class);
		return clientResponse == null ? false : Boolean.valueOf(response).booleanValue();
	}
	
	/**
	 * This method is to retrieve all the ban
	 * associated to the selected ban. 
	 * 
	 * @param ban
	 * @throws SLDBException
	 */
	@Audited
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":getCustomerBans")
	public List<String> getCustomerBans(String ban) throws SLDBException {
		String serviceURL = "/ServiceDelivery/v1/Voice/customerbans/";

		WebResource.Builder builder = webResource.path(serviceURL + ban).entity(null, MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse clientResponse = null;
		try {
			clientResponse = builder.get(ClientResponse.class);
			if (clientResponse.getStatus() != 200) {
				String mRespBody = "Bad HTTP status returned while retrieving isDifferentBanEnabled flag : "
						+ clientResponse.getStatus() + clientResponse.getEntity(String.class);
				LOGGER.error(mRespBody);
				throw new SLDBException("Unable to publish message, Error message: " + mRespBody);
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Unable to publish message, Error message: " + errorInfo, e);
			throw new SLDBException("Unable to publish message, Error message: " + errorInfo);
		}
		return unmarshalCustomerBans(clientResponse.getEntity(String.class));
	}
	
	/**
	 * Unmarshal the response as ServiceLocationDTO object
	 * 
	 * @param response
	 * @return
	 * @throws SLDBException
	 */
	private List<String> unmarshalCustomerBans(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		List<String> result = null;
		try {
			result = new Gson().fromJson(response, new TypeToken<List<String>>(){}.getType());
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}

}
