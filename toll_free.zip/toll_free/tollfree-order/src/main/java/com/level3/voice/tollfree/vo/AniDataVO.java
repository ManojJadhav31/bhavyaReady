package com.level3.voice.tollfree.vo;

/**
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */
/**
 * @author AB37648
 *
 */
public class AniDataVO {

	
	private String customerId;
	private String customerName;
	private String serviceLocationId;
	private String productId;
	private String LoaDate;
	private String tn;
	private String btn;
	private String cic;
	private String status;
	private String ocn;
	private String intraLataFirstUsage;
	private String intraLataLastUsage;
	private String interLataFirstUsage;
	private String interLataLastUsage;
	private String featuresAssociated;
	private String tc;
	private String si;
	private String name;
	private String accountNumber;
	private String orderDate;
	
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getServiceLocationId() {
		return serviceLocationId;
	}
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getLoaDate() {
		return LoaDate;
	}
	public void setLoaDate(String loaDate) {
		LoaDate = loaDate;
	}
	public String getTn() {
		return tn;
	}
	public void setTn(String tn) {
		this.tn = tn;
	}
	public String getBtn() {
		return btn;
	}
	public void setBtn(String btn) {
		this.btn = btn;
	}
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOcn() {
		return ocn;
	}
	public void setOcn(String ocn) {
		this.ocn = ocn;
	}
	public String getIntraLataFirstUsage() {
		return intraLataFirstUsage;
	}
	public void setIntraLataFirstUsage(String intraLataFirstUsage) {
		this.intraLataFirstUsage = intraLataFirstUsage;
	}
	public String getIntraLataLastUsage() {
		return intraLataLastUsage;
	}
	public void setIntraLataLastUsage(String intraLataLastUsage) {
		this.intraLataLastUsage = intraLataLastUsage;
	}
	public String getInterLataFirstUsage() {
		return interLataFirstUsage;
	}
	public void setInterLataFirstUsage(String interLataFirstUsage) {
		this.interLataFirstUsage = interLataFirstUsage;
	}
	public String getInterLataLastUsage() {
		return interLataLastUsage;
	}
	public void setInterLataLastUsage(String interLataLastUsage) {
		this.interLataLastUsage = interLataLastUsage;
	}
	public String getFeaturesAssociated() {
		return featuresAssociated;
	}
	public void setFeaturesAssociated(String featuresAssociated) {
		this.featuresAssociated = featuresAssociated;
	}
	public String getTc() {
		return tc;
	}
	public void setTc(String tc) {
		this.tc = tc;
	}
	public String getSi() {
		return si;
	}
	public void setSi(String si) {
		this.si = si;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
}
