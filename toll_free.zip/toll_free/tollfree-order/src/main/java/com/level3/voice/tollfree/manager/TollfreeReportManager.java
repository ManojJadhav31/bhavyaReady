package com.level3.voice.tollfree.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.tollfree.persist.dto.CdrServiceTypeUsageDTO;
import com.level3.voice.tollfree.persist.dto.GetNoResponseFtpDTO;
import com.level3.voice.tollfree.persist.dto.GetNoResponseNdmDTO;
import com.level3.voice.tollfree.persist.dto.GetNoResponseNonNdmDTO;
import com.level3.voice.tollfree.persist.dto.LECResponseDTO;
import com.level3.voice.tollfree.persist.repository.AniDataRepository;
import com.level3.voice.tollfree.persist.repository.CdrServiceTypeUsageRepository;
import com.level3.voice.tollfree.persist.repository.LecResponseRepository;
import com.level3.voice.tollfree.persist.repository.NoResponseFtpRepository;
import com.level3.voice.tollfree.persist.repository.NoResponseNdmRepository;
import com.level3.voice.tollfree.persist.repository.NoResponseNonNdmRepository;
import com.level3.voice.tollfree.persist.repository.TollfreeOrderReportsRepository;
import com.level3.voice.tollfree.repository.AniDetailsRepository;
import com.level3.voice.tollfree.vo.AniDataVO;
import com.level3.voice.tollfree.vo.AniSearchInputReqVO;
import com.level3.voice.tollfree.vo.AniStatusVO;
import com.level3.voice.tollfree.vo.NoResponseReportVO;
import com.level3.voice.tollfree.vo.ServiceLocationByCustIdVO;
import com.level3.voice.tollfree.vo.UsageSummaryInputVO;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.UniformInterfaceException;

/**
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */
@Component
public class TollfreeReportManager {
	private static final Logger logger = Logger.getLogger(TollfreeReportManager.class);

	@Autowired
	CdrServiceTypeUsageRepository cdrServiceTypeUsageRepository;
	@Autowired
	AniDataRepository aniDataRepository;
	@Autowired
	TollfreeOrderReportsRepository tollfreeOrderReportsRepository;
	@Autowired
	AniDetailsRepository aniDetailsRepository;
	@Autowired
	LecResponseRepository lecResponseRepository;
	@Autowired
	NoResponseNonNdmRepository noResponseNonNdmRepository;
	@Autowired
	NoResponseNdmRepository noResponseNdmRepository;
	@Autowired
	NoResponseFtpRepository noResponseFtpRepository;	
	@Value("#{'${tollfree.serviceDescription}'.split(',')}")
	private List<String> serviceDescription;

	public List<AniStatusVO> getServiceSummary(AniSearchInputReqVO aniSearchReqParams) throws ParseException {
		return aniDetailsRepository.getAniByStatusCount(aniSearchReqParams);
	}

	public List<CdrServiceTypeUsageDTO> getUsageSummary(UsageSummaryInputVO usageSummaryInput) {
		List<Object[]> cdrUsageList=(List<Object[]>) cdrServiceTypeUsageRepository.getUsageSummary(usageSummaryInput.getAccount(),
				usageSummaryInput.getFromDate(), usageSummaryInput.getToDate());
		List<CdrServiceTypeUsageDTO> cdrServiceTypeUsageDTOList=new ArrayList<CdrServiceTypeUsageDTO>();
		for(int i=0; i<cdrUsageList.size();i++) {
			Object[] tempObject = (Object[]) cdrUsageList.get(i);
			if(tempObject[0]!=null&&tempObject[1]!=null&&tempObject[2]!=null) {
			CdrServiceTypeUsageDTO cdrServiceTypeUsageDTO = new CdrServiceTypeUsageDTO(tempObject[0].toString(),tempObject[1].toString(), tempObject[2].toString(),this.getServiceDescription(tempObject[0].toString()));
			cdrServiceTypeUsageDTOList.add(cdrServiceTypeUsageDTO);
			}
			
			
		}
		
		return cdrServiceTypeUsageDTOList ;
	}
public String getServiceDescription(String str) {
	Map<String, String> ServiceDescriptionList = new HashMap<String, String>();
	for (String c : serviceDescription) {
		
			String[] description = c.split(":");
			ServiceDescriptionList.put(description[0], description[1]);
			if(ServiceDescriptionList.containsKey(str)) {
				return ServiceDescriptionList.get(str);
				
			}
	}
	
	return null;
	
}
	public List<AniDataVO> getReportsData(AniSearchInputReqVO aniSearchReqParams) throws ParseException {
		return aniDetailsRepository.getAniDataForReports(aniSearchReqParams);
	}

	public List<ServiceLocationByCustIdVO> getAllServiceLocations(String customerId) {
		ArrayList<ServiceLocationByCustIdVO> serviceLocList = new ArrayList<>();
		Object[] listOfObjects = aniDataRepository.getAllServiceLocation(customerId);
		ArrayList<Object> list = new ArrayList<Object>(Arrays.asList(listOfObjects));
		for (int i = 0; i < list.size(); i++) {
			Object[] tempObject = (Object[]) list.get(i);
			ServiceLocationByCustIdVO serviceLocationByCustIdVO = new ServiceLocationByCustIdVO();

			if (tempObject[0] != null) {
				serviceLocationByCustIdVO.setServiceLocationID(tempObject[0].toString());
			}
			if (tempObject[1] != null) {
				serviceLocationByCustIdVO.setStatus(tempObject[1].toString());
			}
			if (tempObject[2] != null) {
				serviceLocationByCustIdVO.setWtn(tempObject[2].toString());
			}
			if (tempObject[3] != null) {
				serviceLocationByCustIdVO.setBtn(tempObject[3].toString());
			}
			if (tempObject[4] != null) {
				serviceLocationByCustIdVO.setServiceBeginDate(tempObject[4].toString());
			}
			if (tempObject[5] != null) {
				serviceLocationByCustIdVO.setIntraLataFirstUsage(tempObject[5].toString());
			}
			if (tempObject[6] != null) {
				serviceLocationByCustIdVO.setIntraLataLastUsage(tempObject[6].toString());
			}
			if (tempObject[7] != null) {
				serviceLocationByCustIdVO.setInterLatafirstUsage(tempObject[7].toString());
			}
			if (tempObject[8] != null) {
				serviceLocationByCustIdVO.setInterLataLastUsage(tempObject[8].toString());
			}
			if (tempObject[9] != null) {
				serviceLocationByCustIdVO.setServiceEndDate(tempObject[9].toString());
			}

			serviceLocList.add(serviceLocationByCustIdVO);

		}
		return serviceLocList;

	}

	public List<NoResponseReportVO> getNoResponseReport(String callType, Date startDate, Date endDate) {
		logger.error("@NoResponseReport with calltype:" + callType + "and Sdate:" + startDate + "EndDate:" + endDate);
		List<GetNoResponseNdmDTO> ndmList;
		List<GetNoResponseFtpDTO> ftlList;
		List<GetNoResponseNonNdmDTO> nonndmlist;
		List<NoResponseReportVO> noRespVoList = new ArrayList<NoResponseReportVO>();
		if (callType.equalsIgnoreCase("ndm")) {
			ndmList = noResponseNdmRepository.getAllNdmData(startDate, endDate);
			Iterator<GetNoResponseNdmDTO> objectsItor = ndmList.iterator();
			while (objectsItor.hasNext()) {
				NoResponseReportVO noResponseReportVO = new NoResponseReportVO();
				GetNoResponseNdmDTO temp = objectsItor.next();
				noResponseReportVO.setCompanyName(temp.getCompanyName());
				noResponseReportVO.setCustomerName(temp.getCustomerBizOrgName());
				noResponseReportVO.setCustomerId(temp.getCustomerId());
				noResponseReportVO.setoCN(temp.getOcn());
				noResponseReportVO.setBtn(temp.getBtn());
				noResponseReportVO.setWtn(temp.getWtn());
				noResponseReportVO.setEntryDate(temp.getEntryDate().toString());
				noResponseReportVO.setJurisdication(temp.getJurisdiction());
				noResponseReportVO.setOrderNumber(temp.getOrderNumber());
				noResponseReportVO.setProvisionBegin(temp.getProvisionBeginDate());

				Instant instant = Instant.now();
				long timeStampMillis = instant.toEpochMilli();
				long daysElapsedMillis = timeStampMillis - temp.getEntryDate().getTime();
				int days = (int) (daysElapsedMillis / (1000 * 60 * 60 * 24));
				noResponseReportVO.setDaysElapsed(days);

				noRespVoList.add(noResponseReportVO);
			}

		}
		if (callType.equalsIgnoreCase("ftp")) {
			ftlList = noResponseFtpRepository.getAllFtpData(startDate, endDate);
			Iterator<GetNoResponseFtpDTO> objectsItor = ftlList.iterator();
			while (objectsItor.hasNext()) {
				NoResponseReportVO noResponseReportVO = new NoResponseReportVO();
				GetNoResponseFtpDTO temp = objectsItor.next();
				noResponseReportVO.setCompanyName(temp.getCompanyName());
				noResponseReportVO.setCustomerName(temp.getCustomerBizOrgName());
				noResponseReportVO.setCustomerId(temp.getCustomerId());
				noResponseReportVO.setoCN(temp.getOcn());
				noResponseReportVO.setBtn(temp.getBtn());
				noResponseReportVO.setWtn(temp.getWtn());
				noResponseReportVO.setEntryDate(temp.getEntryDate().toString());
				noResponseReportVO.setJurisdication(temp.getJurisdiction());
				noResponseReportVO.setOrderNumber(temp.getOrderNumber());
				noResponseReportVO.setProvisionBegin(temp.getProvisionBeginDate());

				Instant instant = Instant.now();
				long timeStampMillis = instant.toEpochMilli();
				long daysElapsedMillis = timeStampMillis - temp.getEntryDate().getTime();
				int days = (int) (daysElapsedMillis / (1000 * 60 * 60 * 24));
				noResponseReportVO.setDaysElapsed(days);

				noRespVoList.add(noResponseReportVO);

			}

		}
		if (callType.equalsIgnoreCase("nonNdm")) {
			nonndmlist = noResponseNonNdmRepository.getAllNonNdmData(startDate, endDate);
			Iterator<GetNoResponseNonNdmDTO> objectsItor = nonndmlist.iterator();
			while (objectsItor.hasNext()) {
				NoResponseReportVO noResponseReportVO = new NoResponseReportVO();
				GetNoResponseNonNdmDTO temp = objectsItor.next();
				noResponseReportVO.setCompanyName(temp.getCompanyName());
				noResponseReportVO.setCustomerName(temp.getCustomerBizOrgName());
				noResponseReportVO.setCustomerId(temp.getCustomerId());
				noResponseReportVO.setoCN(temp.getOcn());
				noResponseReportVO.setBtn(temp.getBtn());
				noResponseReportVO.setWtn(temp.getWtn());
				noResponseReportVO.setEntryDate(temp.getEntryDate().toString());
				noResponseReportVO.setJurisdication(temp.getJurisdiction());
				noResponseReportVO.setOrderNumber(temp.getOrderNumber());
				noResponseReportVO.setProvisionBegin(temp.getProvisionBeginDate());

				Instant instant = Instant.now();
				long timeStampMillis = instant.toEpochMilli();
				long daysElapsedMillis = timeStampMillis - temp.getEntryDate().getTime();
				int days = (int) (daysElapsedMillis / (1000 * 60 * 60 * 24));
				noResponseReportVO.setDaysElapsed(days);

				noRespVoList.add(noResponseReportVO);

			}
		}
		return noRespVoList;

	}

	public List<LECResponseDTO> getUnAuthorizedPicDisputes(Date startDate, Date endDate)
			throws ClientHandlerException, UniformInterfaceException, SLDBException {
		Calendar eCal = Calendar.getInstance();
		eCal.setTime(endDate);
		eCal.add(Calendar.HOUR, 23);
		eCal.add(Calendar.MINUTE, 59);
		eCal.add(Calendar.SECOND, 59);

		List<Object> listofObjects = tollfreeOrderReportsRepository.getUnAuthorizedPicDisputes(startDate,
				eCal.getTime());
		Iterator<Object> objectsItor = listofObjects.iterator();
		List<LECResponseDTO> lecResponseDTOs = new ArrayList<LECResponseDTO>();
		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			LECResponseDTO lECResponseDTO = new LECResponseDTO();
			if (object[0] != null) {
				lECResponseDTO.setCustomerName(object[0].toString());
			}
			if (object[1] != null) {
				lECResponseDTO.setCustomerId(object[1].toString());
			}
			if (object[2] != null) {
				lECResponseDTO.setLec(object[2].toString());
			}
			if (object[3] != null) {
				lECResponseDTO.setEndUser(object[3].toString());
			}
			if (object[4] != null) {
				lECResponseDTO.setTc(object[4].toString());
			}
			if (object[5] != null) {
				lECResponseDTO.setSi(object[5].toString());
			}
			if (object[6] != null) {
				lECResponseDTO.setBtnNew(object[6].toString());
			}
			if (object[7] != null) {
				lECResponseDTO.setWtnNew(object[7].toString());
			}
			if (object[8] != null) {
				lECResponseDTO.setLecDate(object[8].toString());
			}
			if (object[9] != null) {
				lECResponseDTO.setDate1(object[9].toString());
			}
			if (object[10] != null) {
				lECResponseDTO.setJi(object[10].toString());
			}
			lecResponseDTOs.add(lECResponseDTO);
		}
		for (LECResponseDTO lecResponseDTO : lecResponseDTOs) {
			if (lecResponseDTO.getDate1() != null && lecResponseDTO.getDate1().length() >= 6) {
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");

				Calendar calendar = Calendar.getInstance();
				calendar.set(Integer.parseInt(lecResponseDTO.getDate1().substring(0, 2)),
						Integer.parseInt(lecResponseDTO.getDate1().substring(2, 4)) - 1,
						Integer.parseInt(lecResponseDTO.getDate1().substring(4, 6)));
				lecResponseDTO.setDate1(sdf.format(calendar.getTime()));
			}
			if ("B".equalsIgnoreCase(lecResponseDTO.getJi())) {
				lecResponseDTO.setJi("Inter & Intra LATA");
			} else if ("E".equalsIgnoreCase(lecResponseDTO.getJi())) {
				lecResponseDTO.setJi("Inter LATA");
			}
		}
		return lecResponseDTOs;

	}

}