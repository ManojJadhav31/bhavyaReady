package com.level3.voice.tollfree.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.manager.TollfreeReportManager;
import com.level3.voice.tollfree.persist.dto.CdrServiceTypeUsageDTO;
import com.level3.voice.tollfree.persist.dto.LECResponseDTO;
import com.level3.voice.tollfree.vo.AniDataVO;
import com.level3.voice.tollfree.vo.AniSearchInputReqVO;
import com.level3.voice.tollfree.vo.AniStatusVO;
import com.level3.voice.tollfree.vo.NoResponseReportVO;
import com.level3.voice.tollfree.vo.ServiceLocationByCustIdVO;
import com.level3.voice.tollfree.vo.UsageSummaryInputVO;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.UniformInterfaceException;

/**
 * @author <a href="mailto:mushahid.khan@centurylink.com">Mushahid Khan</a>
 *
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/Voice/reports")
public class TollFreeOrderReportService {

	@Autowired
	TollfreeReportManager tollfreeReportManager;
	private static final Logger logger = Logger.getLogger(TollFreeOrderReportService.class);

	@RequestMapping(path = "/serviceSummary", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<AniStatusVO> getServiceSummary(@RequestBody AniSearchInputReqVO aniSearchReqParams) {
		List<AniStatusVO> ReportServiceSummaryDTOs = null;
		if (aniSearchReqParams != null && (StringUtils.isEmpty(aniSearchReqParams.getCustomerId())
				&& StringUtils.isEmpty(aniSearchReqParams.getServiceLocationId()))) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid search request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		try {
			ReportServiceSummaryDTOs = tollfreeReportManager.getServiceSummary(aniSearchReqParams);
		} catch (Exception e) {
			logger.error("@getTNs: Exception processing getTNs", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		return ReportServiceSummaryDTOs;
	}

	@RequestMapping(path = "/usageSummary", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<CdrServiceTypeUsageDTO> getUsageSummary(@RequestBody UsageSummaryInputVO usageSummaryInput) {
		if (usageSummaryInput.getAccount() == null) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		return tollfreeReportManager.getUsageSummary(usageSummaryInput);

	}

	@RequestMapping(path = "/serviceLocations/{customerId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ServiceLocationByCustIdVO> getSeriviceLocationsbyCustomerID(@PathVariable String customerId) {
		if (customerId == null) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		return tollfreeReportManager.getAllServiceLocations(customerId);

	}

	@RequestMapping(path = "/aniData", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<AniDataVO> getReportsData(@RequestBody AniSearchInputReqVO aniSearchReqParams) {
		List<AniDataVO> ReportScreenDTOs = null;
		if (aniSearchReqParams != null && StringUtils.isEmpty(aniSearchReqParams.getCustomerId())) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid search request. CustomerId is mandatory");
			throw new ServiceException(l3Response);
		}
		try {
			ReportScreenDTOs = tollfreeReportManager.getReportsData(aniSearchReqParams);
		} catch (Exception e) {
			logger.error("@getTNs: Exception processing getTNs", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		return ReportScreenDTOs;
	}

	@RequestMapping(path = "/getNoResponseReports/{callType}/{startDate}/{endDate}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<NoResponseReportVO> getNoResponseNDMlecs(@PathVariable String callType,
			@PathVariable("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@PathVariable("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate) {
		if (StringUtils.isEmpty(callType)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getNoResponseNDMLecs: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<NoResponseReportVO> noResponseReportVOList = null;
		try {
			noResponseReportVOList = tollfreeReportManager.getNoResponseReport(callType,startDate,endDate);
		} catch (Exception e) {
			// LOG.error("@getNoResponseNDMLecs: Exception processing
			// getNoResponseNDMLecs", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return noResponseReportVOList;
	}

	@RequestMapping(path = "/getUnAuthPicDisputes/{startDate}/{endDate}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<LECResponseDTO> getUnAuthorizedPicDisputes(
			@PathVariable("startDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
			@PathVariable("endDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate)
			throws ClientHandlerException, UniformInterfaceException, SLDBException {

		List<LECResponseDTO> lECResponseDTOs = tollfreeReportManager.getUnAuthorizedPicDisputes(startDate, endDate);
		return lECResponseDTOs;
	}
}
