package com.level3.voice.tollfree.constants;
/**
 * Constants for TollFree-Order MS
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class TollFreeOrderConstants {

	public static final String ONESPICLD = "1SPICLD";
	public static final String BULK_CHANGE = "Bulk_Change";
	public static final String ORDER_INFO = "Order_Info";
	/**
	 * TNData Columns
	 */
	public static final String BTN = "BTN";
	public static final String WTN = "WTN";
	public static final String PIC = "PIC";
	public static final String JURISDICTION = "JURISDICTION";
	public static final String FORCE_ANI_LOAD = "FORCE_ANI_LOAD";
	public static final String CIC = "CIC";
	public static final String FEATURES = "FEATURES";
	public static final String CODE_DIGITS = "CODE_DIGITS";
	public static final String CODE_TABLE = "CODE_TABLE";
	public static final String IS_MANDATORY = "IS_MANDATORY";
	
	public static final String ORDER_TYPE = "ORDER_TYPE";
	public static final String CUSTOMER_ID	="CUSTOMER_ID";
	public static final String FEATURE_ID ="FEATURE_ID";
	public static final String PRODUCT = "PRODUCT";
	public static final String BAN = "BAN";
	public static final String AN_ORDER_TYPE = "AN";
}
