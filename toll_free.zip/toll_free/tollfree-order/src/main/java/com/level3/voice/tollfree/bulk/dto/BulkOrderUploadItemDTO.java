package com.level3.voice.tollfree.bulk.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.level3.voice.tollfree.vo.OrderVO;

/**
 * This DTO is representation of the charge table
 * 
 * @author <a href="mailto:Manjunatha.D@centurylink.com">Manjunatha D</a>
 *
 */
@Entity
@Table(name = "BULK_ORDER_UPLOAD_ITEM")
public class BulkOrderUploadItemDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "bulk_order_upload_item_seq")
    @SequenceGenerator(sequenceName = "BULK_ORDER_UPLOAD_ITEM_SEQ", allocationSize = 1, name = "bulk_order_upload_item_seq")
	@Column(name="ID")
	private Long id;
	
	@Column(name="FEATURE_ID")
	private String featureId;
	@Column(name="WTN")
	private String wtn;
	@Column(name="BTN")
	private String btn;
	@Column(name="CIC")
	private String cic;
	@Column(name="JURISDICTION")
	private String jurisdiction;
	@Column(name="FORCE_ANI_LOAD")
	private String forceAniLoad;
	@Column(name="PIC")
	private String pic;
	@Column(name="CRC")
	private String crc;
	@Column(name="PON")
	private Long pon;
	@Column(name="CODE_DIGIT")
	private String codeDigit;
	@Column(name="CODE_TABLE")
	private String codeTable;
	@Column(name="STATUS")
	private String status;
	@Column(name="COMMENTS")
	private String comments;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "CREATED_ON")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdOn;
	
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name = "MODIFIED_ON")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedOn;
	
	@JsonIgnore
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="BULK_ORDER_UPLOAD_ID")
	private BulkOrderUploadDTO bulkOrderUploadDTO;
	
	@Column(name="IS_MANDATORY_FEATURE")
	private String isMandatoryFeature;
	
	@Transient
	private OrderVO orderVO;
	
	public BulkOrderUploadItemDTO() {
		
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the featureId
	 */
	public String getFeatureId() {
		return featureId;
	}

	/**
	 * @param featureId the featureId to set
	 */
	public void setFeatureId(String featureId) {
		this.featureId = featureId;
	}

	/**
	 * @return the wtn
	 */
	public String getWtn() {
		return wtn;
	}

	/**
	 * @param wtn the wtn to set
	 */
	public void setWtn(String wtn) {
		this.wtn = wtn;
	}

	/**
	 * @return the btn
	 */
	public String getBtn() {
		return btn;
	}

	/**
	 * @param btn the btn to set
	 */
	public void setBtn(String btn) {
		this.btn = btn;
	}

	/**
	 * @return the cic
	 */
	public String getCic() {
		return cic;
	}

	/**
	 * @param cic the cic to set
	 */
	public void setCic(String cic) {
		this.cic = cic;
	}

	/**
	 * @return the jurisdiction
	 */
	public String getJurisdiction() {
		return jurisdiction;
	}

	/**
	 * @param jurisdiction the jurisdiction to set
	 */
	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	/**
	 * @return the forceAniLoad
	 */
	public String getForceAniLoad() {
		return forceAniLoad;
	}

	/**
	 * @param forceAniLoad the forceAniLoad to set
	 */
	public void setForceAniLoad(String forceAniLoad) {
		this.forceAniLoad = forceAniLoad;
	}

	/**
	 * @return the pic
	 */
	public String getPic() {
		return pic;
	}

	/**
	 * @param pic the pic to set
	 */
	public void setPic(String pic) {
		this.pic = pic;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdOn
	 */
	public Date getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn the createdOn to set
	 */
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @param modifiedBy the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the modifiedOn
	 */
	public Date getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn the modifiedOn to set
	 */
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	
	public BulkOrderUploadDTO getBulkOrderUploadDTO() {
		return bulkOrderUploadDTO;
	}

	public void setBulkOrderUploadDTO(BulkOrderUploadDTO bulkOrderUploadDTO) {
		this.bulkOrderUploadDTO = bulkOrderUploadDTO;
	}

	
	public OrderVO getOrderVO() {
		return orderVO;
	}

	public void setOrderVO(OrderVO orderVO) {
		this.orderVO = orderVO;
	}

	public String getCrc() {
		return crc;
	}

	public void setCrc(String crc) {
		this.crc = crc;
	}

	public Long getPon() {
		return pon;
	}

	public void setPon(Long pon) {
		this.pon = pon;
	}

	public String getCodeDigit() {
		return codeDigit;
	}

	public void setCodeDigit(String codeDigit) {
		this.codeDigit = codeDigit;
	}

	public String getCodeTable() {
		return codeTable;
	}

	public void setCodeTable(String codeTable) {
		this.codeTable = codeTable;
	}
	
	public String getIsMandatoryFeature() {
		return isMandatoryFeature;
	}

	public void setIsMandatoryFeature(String isMandatoryFeature) {
		this.isMandatoryFeature = isMandatoryFeature;
	}

	@Override
	public String toString() {
		return "BulkOrderUploadItemDTO [id=" + id + ", featureId=" + featureId + ", wtn=" + wtn + ", btn=" + btn
				+ ", cic=" + cic + ", jurisdiction=" + jurisdiction + ", forceAniLoad=" + forceAniLoad + ", pic=" + pic
				+ ", crc=" + crc + ", pon=" + pon + ", codeDigit=" + codeDigit + ", codetable=" + codeTable
				+ ", status=" + status + ", comments=" + comments + ", createdBy=" + createdBy + ", createdOn="
				+ createdOn + ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + ", bulkOrderUploadDTO="
				+ bulkOrderUploadDTO + ", orderVO=" + orderVO + "]";
	}

}
