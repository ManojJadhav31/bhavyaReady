package com.level3.voice.tollfree.client;

import javax.annotation.PostConstruct;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.model.Level3Response;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;

@Component
public class NUMSClient {
	
	private static final Logger LOGGER = Logger.getLogger(NUMSClient.class);

	@Value("${tollfree.nums.client.url}#{'/ServiceDelivery/v1/nums/'}")
	private String baseUrl;

	@Value("${tollfree.nums.client.connect.timeout.ms}")
	private Integer connectTimeoutMs;

	@Value("${tollfree.nums.client.read.timeout.ms}")
	private Integer readTimeoutMs;
	
	ObjectMapper objectMapper;
	
	com.sun.jersey.api.client.WebResource webResource;

	@PostConstruct
	public void init() throws Exception {
		Client client = Client.create();
		client.setReadTimeout(readTimeoutMs);
		client.setConnectTimeout(connectTimeoutMs);
		objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		webResource = client.resource(this.baseUrl);
	}
	
	/**
	 * Send the tollfreetnVO construcuted to NUMS and 
	 * process the response to mark the activity with proper status and comments
	 * 
	 * @param tollFreeTnVO
	 * @param orderActivityDTO
	 * @throws Exception
	 */
	public boolean isTNPresentInNums(String tn) throws Exception {
		long startTime = System.currentTimeMillis();
		String serviceUrl = "/validate/tn/";

		WebResource.Builder builder = webResource.path(serviceUrl + tn).type(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse response = builder.get(ClientResponse.class);
		Level3Response l3Response = unmarshal(response.getEntity(String.class));

		long endTime = System.currentTimeMillis();

		LOGGER.info(
				"@NUMSClient @isTNPresentInNums took " + (endTime - startTime) + " milliseconds for: "
						+ tn);
		
		if (l3Response.getHttpStatusCodeInt() == 200) {
			return false;
		} else {
			return true;
		}
	}
	
	
	public String getLecNameByTn(String tn) throws ClientHandlerException, UniformInterfaceException, SLDBException {
		long startTime = System.currentTimeMillis();
		String serviceUrl = "/retrieve/ocname/";

		WebResource.Builder builder = webResource.path(serviceUrl + tn).type(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		builder.header("Authorization", "SVC_3FLOW");
		builder.header("X-GLM-API-Authorization", "3067");

		ClientResponse response = builder.get(ClientResponse.class);
		String resp =response.getEntity(String.class);

		long endTime = System.currentTimeMillis();

		LOGGER.info(
				"@NUMSClient @getLecNameByTn took " + (endTime - startTime) + " milliseconds for: "
						+ tn);
		
		return resp;
		
	}

	/**
	 * Unmarshall the request and form the
	 * level3response object
	 * 
	 * @param response
	 * @return
	 * @throws SLDBException
	 */
	private Level3Response unmarshal(String response) throws SLDBException {
		if (response == null) {
			return null;
		}
		Level3Response result = null;
		try {
			LOGGER.info("String response is.."+response);
			result = objectMapper.readValue(response, Level3Response.class);
		} catch (Exception e) {
			LOGGER.error(" Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return result;
	}
}
