CREATE OR REPLACE VIEW "SUBL_OWNER"."GET_SERVICE_STATUS_VIEW" ("SL_ORDER_ID", "STATUS")
AS
  (SELECT slo.sl_order_id,
    CASE
      WHEN (slo.action_type_id != 3
      AND slo.action_type_id   != 6
      AND slo.order_active_yn   ='Y'
      AND slo.sl_order_id       =
        (SELECT oa.sl_order_id
        FROM order_activity oa
        WHERE oa.sl_order_id      = slo.sl_order_id
        AND oa.order_activity_pk IN
          (SELECT oa1.order_activity_pk
          FROM order_activity oa1,
            order_tollfree_features otf3
          WHERE oa1.sl_order_id     = slo.sl_order_id
          AND oa1.status            = 3
          AND oa1.activity_type_id IN (930,931)
          AND otf3.sl_order_id     = slo.sl_order_id
          AND (otf3.validated_ac   IS NOT NULL
          OR otf3.unvalidated_ac   IS NOT NULL)
          )
        UNION
        SELECT oa.sl_order_id
        FROM order_activity oa
        WHERE oa.sl_order_id      = slo.sl_order_id
        AND oa.order_activity_pk IN
          (SELECT oa1.order_activity_pk
          FROM order_activity oa1,
            order_tollfree_features otf3
          WHERE oa1.sl_order_id     = slo.sl_order_id
          AND oa1.status            = 3
          AND oa1.activity_type_id IN (921,924,915)
          AND otf3.sl_order_id     = slo.sl_order_id
          AND (otf3.validated_ac   IS NULL
          AND otf3.unvalidated_ac  IS NULL)
          )
        UNION
        SELECT oa.sl_order_id
        FROM order_activity oa
        WHERE oa.sl_order_id      = slo.sl_order_id
        AND slo.action_type_id    =7
        AND oa.order_activity_pk IN
          (SELECT oa1.order_activity_pk
          FROM order_activity oa1
          WHERE oa1.sl_order_id    = slo.sl_order_id
          AND oa1.status           = 3
          AND oa1.activity_type_id =921
          )
        ))
      THEN 'Active'
      WHEN slo.action_type_id = 6
      AND slo.sl_order_id     =
        (SELECT sl_order_id
        FROM
          (SELECT oa.sl_order_id
          FROM order_activity oa
          WHERE oa.sl_order_id    = slo.sl_order_id
          AND oa.activity_type_id =921
          AND oa.status           = 3
          ORDER BY oa.LAST_PROCESSING_STOP DESC
          )
        WHERE rownum=1
        )
      AND (SELECT COUNT(slo3.sl_order_id)
        FROM sl_order slo3,
          order_tollfree_features otf4
        WHERE slo3.order_active_yn='Y'
        AND otf4.sl_order_id!     =slo.sl_order_id
        AND otf4.sl_order_id      =slo3.sl_order_id
        AND otf4.tn              IN
          (SELECT otf5.tn
          FROM order_tollfree_features otf5
          WHERE slo.sl_order_id=otf5.sl_order_id
          ))                  <=0
      THEN 'Blocked'
      WHEN slo.action_type_id = 3
      AND slo.order_status_id =4
      THEN 'Disconnected'
      ELSE (
        CASE
          WHEN slo.order_active_yn ='Y'
          AND slo.order_status_id IN(1,2)
          THEN 'Pending'
        END)
    END AS status
  FROM sl_order slo
  WHERE slo.sl_order_id IN
    (SELECT slo1.sl_order_id
    FROM sl_order slo1,
      order_tollfree_features otf1
    WHERE slo1.sl_order_id= otf1.sl_order_id
    AND slo1.sl_order_id IN
      (SELECT sl_order_id
      FROM
        (SELECT otf2.tn,
          slo2.sl_order_id
        FROM sl_order slo2,
          order_tollfree_features otf2
        WHERE slo2.sl_order_id= otf2.sl_order_id
        and otf2.sl_order_id = slo.sl_order_id
        GROUP BY otf2.tn,
          slo2.sl_order_id
        ORDER BY slo2.order_version DESC
        )
      )
    )
  );
