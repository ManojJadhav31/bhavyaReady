Insert into ORDER_SOURCE (ORDER_SOURCE_ID,NAME) values (15,'Web');
Insert into ORDER_SOURCE (ORDER_SOURCE_ID,NAME) values (16,'Order Entry');