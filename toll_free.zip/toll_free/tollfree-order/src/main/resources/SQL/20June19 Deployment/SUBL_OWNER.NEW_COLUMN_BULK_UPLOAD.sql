ALTER TABLE bulk_order_upload_item
ADD is_mandatory_feature varchar(1);
