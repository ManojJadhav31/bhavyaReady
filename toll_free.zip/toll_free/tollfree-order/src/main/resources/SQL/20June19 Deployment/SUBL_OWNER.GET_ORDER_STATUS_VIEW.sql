CREATE OR REPLACE VIEW SUBL_OWNER.GET_ORDER_STATUS_VIEW (
	SL_ORDER_ID,
	status)
    AS (SELECT slo.sl_order_id,
  CASE
    WHEN (slo.order_status_id = 4 and oa.status != 2) or (slo.order_status_id = 4 and oa.status is null)
    THEN 'Completed'
    WHEN oa.status = 2
    THEN 'Error'
    ELSE 'Pending'
  END AS status
FROM sl_order slo
LEFT OUTER JOIN order_activity oa
ON oa.sl_order_id = slo.sl_order_id
AND oa.status     in
  (SELECT DISTINCT status
  FROM order_activity
  WHERE sl_order_id = slo.sl_order_id and status = 2
  ));

GRANT SELECT,
	UPDATE,
	INSERT,
	DELETE
	ON SUBL_OWNER.GET_ORDER_STATUS_VIEW
	TO SUBL_USER;