  Update activity_rules set activity_id = '937' where rule_pk = 9407325955;
  Update activity_rules set activity_id = '938' where rule_pk = 9407325956;