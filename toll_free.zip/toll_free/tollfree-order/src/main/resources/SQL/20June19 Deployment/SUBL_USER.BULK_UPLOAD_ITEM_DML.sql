ALTER TABLE bulk_order_upload_item DROP COLUMN is_mandatory_feature;

ALTER TABLE bulk_order_upload_item ADD CODE_TABLE VARCHAR2(20);
ALTER TABLE bulk_order_upload_item ADD CODE_DIGIT VARCHAR2(10);
ALTER TABLE bulk_order_upload_item ADD is_mandatory_feature varchar(1);
