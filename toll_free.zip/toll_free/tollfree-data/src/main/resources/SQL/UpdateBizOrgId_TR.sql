USE [Sandstone]
GO

/****** Object:  Trigger [dbo].[UpdateBizOrgId_TR]    Script Date: 3/15/2019 1:17:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO


CREATE TRIGGER [dbo].[UpdateBizOrgId_TR] ON [dbo].[ProdOfferingLocAsscQueue] 
AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON
	DECLARE	@t_CustomerBizOrgId VARCHAR(20),
	@t_ProdLocationQueueId VARCHAR(20)
	
	SELECT  @t_CustomerBizOrgId = c.BusOrg,
			@t_ProdLocationQueueId = i.ProdLocationQueueId
			FROM INSERTED i Inner join Customer c on i.customerId = c.customerId
		BEGIN
			UPDATE ProdOfferingLocAsscQueue
			SET CustomerBizOrgId = @t_CustomerBizOrgId
			WHERE ProdLocationQueueId = @t_ProdLocationQueueId
		END
END

GO