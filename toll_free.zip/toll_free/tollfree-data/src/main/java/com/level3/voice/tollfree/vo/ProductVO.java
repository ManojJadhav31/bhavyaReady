package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class ProductVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String productIOfferingId;
	private String productName;
	
	/**Default Constructor*/
	public ProductVO() {
		
	}
	
	/**Full Constructor*/
	public ProductVO(String productOfferingId, String productName) {
		this.productIOfferingId =  productOfferingId;
		this.productName = productName;
	}
	
	public String getProductIOfferingId() {
		return productIOfferingId;
	}
	public void setProductIOfferingId(String productIOfferingId) {
		this.productIOfferingId = productIOfferingId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
}
