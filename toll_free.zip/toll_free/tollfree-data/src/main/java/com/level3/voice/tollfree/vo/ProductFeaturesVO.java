package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class ProductFeaturesVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String featureOfferingId;
	private String featureDescription;
	
	public String getFeatureOfferingId() {
		return featureOfferingId;
	}
	public void setFeatureOfferingId(String featureOfferingId) {
		this.featureOfferingId = featureOfferingId;
	}
	public String getFeatureDescription() {
		return featureDescription;
	}
	public void setFeatureDescription(String featureDescription) {
		this.featureDescription = featureDescription;
	}
}
