package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class FeaturesVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private FeatureVO feature;

	public FeatureVO getFeature() {
		return feature;
	}

	public void setFeature(FeatureVO feature) {
		this.feature = feature;
	}

}
