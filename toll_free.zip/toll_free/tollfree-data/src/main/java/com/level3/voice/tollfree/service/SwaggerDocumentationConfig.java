package com.level3.voice.tollfree.service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-09-15T16:40:25.083Z")

/**
 * Configuration file which hold information of
 * the package from where the API is present
 * 
 * @author <a href="mailto:Keerthi.Selvaraj@centurylink.com">Keerthi Selvaraj</a>
 *
 */
@Configuration
public class SwaggerDocumentationConfig {

	@Bean
	public Docket customImplementation() {
		return new Docket(DocumentationType.SWAGGER_2)
				.apiInfo(apiInfo())
				.select()
				.apis(RequestHandlerSelectors.basePackage("com.level3.voice.tollfree"))
				.paths(PathSelectors.regex("/ServiceDelivery/v1/Voice/.*"))
				.build();

	}

	ApiInfo apiInfo() {
		return new ApiInfoBuilder()
				.title("Order API").description("Order API ").termsOfServiceUrl("")
				.license("Apache License Version 2.0")
				.licenseUrl("https://github.com/springfox/springfox/blob/master/LICENSE").version("2.0").build();
	}

}
