package com.level3.voice.tollfree.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "voiceComplete")
@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class VoiceComplete implements Serializable {

	private static final long serialVersionUID = 1L;
	private String dtfScid;
	private String siptPIID;
	private String masterateSheetID;
	private String isGlobal;
	private String isInterconnectVoipVC;
	
	public String getDtfScid() {
		return dtfScid;
	}
	public void setDtfScid(String dtfScid) {
		this.dtfScid = dtfScid;
	}
	public String getSiptPIID() {
		return siptPIID;
	}
	public void setSiptPIID(String siptPIID) {
		this.siptPIID = siptPIID;
	}
	public String getMasterateSheetID() {
		return masterateSheetID;
	}
	public void setMasterateSheetID(String masterateSheetID) {
		this.masterateSheetID = masterateSheetID;
	}
	public String getIsGlobal() {
		return isGlobal;
	}
	public void setIsGlobal(String isGlobal) {
		this.isGlobal = isGlobal;
	}
	public String getIsInterconnectVoipVC() {
		return isInterconnectVoipVC;
	}
	public void setIsInterconnectVoipVC(String isInterconnectVoipVC) {
		this.isInterconnectVoipVC = isInterconnectVoipVC;
	}
}
