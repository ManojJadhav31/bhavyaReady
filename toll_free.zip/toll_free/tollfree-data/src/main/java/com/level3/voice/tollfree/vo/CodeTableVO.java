package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class CodeTableVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String codeTableId;
	private String codeTableName;
	private String codeDigits;
	private String nonMandatoryInd;
	
	/**Default Constructor*/
	public CodeTableVO() {

	}
	
	/**Full Constructor*/
	public CodeTableVO(String codeTableId, String codeTableName, String codeDigits){
		this.codeTableId = codeTableId;
		this.codeTableName = codeTableName;
		this.codeDigits = codeDigits;
	}
	
	public String getCodeTableId() {
		return codeTableId;
	}
	public void setCodeTableId(String codeTableId) {
		this.codeTableId = codeTableId;
	}
	public String getCodeTableName() {
		return codeTableName;
	}
	public void setCodeTableName(String codeTableName) {
		this.codeTableName = codeTableName;
	}
	public String getCodeDigits() {
		return codeDigits;
	}
	public void setCodeDigits(String codeDigits) {
		this.codeDigits = codeDigits;
	}

	public String getNonMandatoryInd() {
		return nonMandatoryInd;
	}

	public void setNonMandatoryInd(String nonMandatoryInd) {
		this.nonMandatoryInd = nonMandatoryInd;
	}
	
	

}
