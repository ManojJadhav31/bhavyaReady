package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class CICVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String cic;
	private String preference;

	/**Default Constructor*/
	public CICVO() {
	}
	
	/**Full Constructor*/
	public CICVO(String cic, String preference) {
		this.cic = cic;
		this.preference = preference;
	}
	
	public String getCic() {
		return cic;
	}
	public void setCic(String cic) {
		this.cic = cic;
	}
	public String getPreference() {
		return preference;
	}
	public void setPreference(String preference) {
		this.preference = preference;
	}
}
