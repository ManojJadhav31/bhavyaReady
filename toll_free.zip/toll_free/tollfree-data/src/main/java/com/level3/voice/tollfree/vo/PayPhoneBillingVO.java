package com.level3.voice.tollfree.vo;

public class PayPhoneBillingVO {
	private String contextId;
	private String code;
	private String description;
	private String sortPriority;
	
	
	public String getContextId() {
		return contextId;
	}
	public void setContextId(String contextId) {
		this.contextId = contextId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSortPriority() {
		return sortPriority;
	}
	public void setSortPriority(String sortPriority) {
		this.sortPriority = sortPriority;
	}
	
	
	

}
