package com.level3.voice.tollfree.vo;

public enum ValidationCode {

	TNVALID("ANI is valid", "00"),
	TNINFLIGHT("ANI is currently assigned to another pending order", "01"),
	TNINVALID("ANI format is invalid, Please enter valid 10-digit format", "02"),
	TNINVALIDNPANXX("ANI has invalid NPA NXX, Please enter valid NPA NXX", "03");

	private String message;
	private String code;

	ValidationCode(String message,String code){
		this.message = message;
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public String getMessageCode() {
		return code;
	}
}
