package com.level3.voice.tollfree.client;

import java.io.StringReader;

import javax.annotation.PostConstruct;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.level3.voice.client.pipeline.PipelineClient;
import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.util.CacheConstants;
import com.level3.voice.common.util.SecurityUtil;
import com.level3.voice.tollfree.model.Level3Response;
import com.level3.voice.tollfree.model.Service;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.LoggingFilter;

/**
 * Client to interact with pipe line through mediation to retrieve service id
 * for provided SCID during enterpise scenario
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
@Component
public class PipeLineServiceIdClient extends PipelineClient {

	private static final Logger LOGGER = Logger.getLogger(PipeLineServiceIdClient.class);

	WebResource webResource;

	@Override
	@PostConstruct
	public void init() {
		Client client = Client.create();
		client.setReadTimeout(this.getReadTimeoutMs());
		client.setConnectTimeout(this.getConnectTimeoutMs());
		client.addFilter(new LoggingFilter(System.out));
		webResource = client.resource(this.getBaseUrl());
	}

	/**
	 * Submit start workflow for slorderid
	 * @param scid
	 * @return
	 * @throws Exception
	 */
	@Audited
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":pipeline")
	public Service retrieveServiceId(String scid) throws Exception {

		WebResource wr = webResource.path("rootServiceId").queryParam("scid", scid);

		try {
			WebResource.Builder builder = SecurityUtil.createSecurityHeader(wr, this.getApplicationKey(),
					this.getApplicationSecret(), "Tollfree-Micro-Pipeline").accept(MediaType.APPLICATION_XML);
			ClientResponse response = builder.get(ClientResponse.class);
			String xmlResponse =  this.checkResponseAndReadPayload(response, "retrieveServiceId");
			Level3Response level3Response = unmarshallServiceXmlResponseString(xmlResponse);
			return retrieveServiceId(level3Response);
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("@PipeLineClient: Exception while retrieveServiceId: " + errorInfo, e);
			if (e instanceof SLDBException) {
				throw (SLDBException) e;
			}
			throw new SLDBException("@PipeLineClient: Exception while retrieveServiceId: " + errorInfo);
		}
	}
	
	/**
	 * Unmarshall the response from pipeline
	 * 
	 * @param source
	 * @return
	 * @throws SLDBException
	 */
	public static Level3Response unmarshallServiceXmlResponseString(
            String source) throws SLDBException {
        if (source == null) {
            return null;
        }

        Level3Response result = null;
        try {
            JAXBContext jaxbContext = JAXBContext
                    .newInstance(Level3Response.class);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            Object returnObject = unmarshaller.unmarshal(new StringReader(source));
            if (returnObject instanceof Level3Response) {
                result = (Level3Response) returnObject;
            }
        } catch (JAXBException e) {
            throw new SLDBException(e);
        }

        return result;
    }

	/**
	 * retrieve service id from the response 
	 * 
	 * Always there will be only one service since input sent SCID is always one and
	 * its one to one mapping
	 * 
	 * @param level3Response2
	 * @return
	 * @throws SLDBException
	 */
	@SuppressWarnings("static-method")
	private Service retrieveServiceId(Level3Response level3Response) throws SLDBException {
		if (level3Response == null) {
			return null;
		}
		try {
			Service service = level3Response.getService();
			if (service != null) {
				return service;
			}
		} catch (Exception e) {
			LOGGER.error("@PipeLineClient: @unmarshal: Error Exception Data ", e);
			throw new SLDBException(e);
		}
		return null;
	}
	

}
