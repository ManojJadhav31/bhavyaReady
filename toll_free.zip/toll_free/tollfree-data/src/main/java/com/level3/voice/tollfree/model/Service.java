package com.level3.voice.tollfree.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for Service complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
* &lt;complexType name="Service"&gt;
*   &lt;complexContent&gt;
*     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
*       &lt;sequence&gt;
*         &lt;element name="serviceID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
*         &lt;element name="scid" type="{}ProductComponents" minOccurs="0"/&gt;
*       &lt;/sequence&gt;
*     &lt;/restriction&gt;
*   &lt;/complexContent&gt;
* &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Service", propOrder = { "serviceID", "scid" ,"ban","ProductPartNumber","voiceComplete"})
public class Service {

	protected String serviceID;
	protected String scid;
	protected String ban;
	protected String ProductPartNumber;
	protected VoiceComplete voiceComplete;
	public String getServiceID() {
		return serviceID;
	}
	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}
	public String getScid() {
		return scid;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	public String getBan() {
		return ban;
	}
	public void setBan(String ban) {
		this.ban = ban;
	}
	public String getProductPartNumber() {
		return ProductPartNumber;
	}
	public void setProductPartNumber(String productPartNumber) {
		this.ProductPartNumber = productPartNumber;
	}
	public VoiceComplete getVoiceComplete() {
		return voiceComplete;
	}
	public void setVoiceComplete(VoiceComplete voiceComplete) {
		this.voiceComplete = voiceComplete;
	}

}
