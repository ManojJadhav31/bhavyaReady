package com.level3.voice.tollfree.service;

import java.util.List;

import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.manager.SchedulerEventManager;
import com.level3.voice.tollfree.persist.dto.ProdOfferingLocAsscQueueDTO;
import com.level3.voice.tollfree.persist.dto.ServiceOrderExtractDTO;
import com.level3.voice.tollfree.vo.AccountDetailsVO;
import com.level3.voice.tollfree.vo.ServiceOrderExtractVO;

/**
 * This service is used to handle retrieve and presist ProdOfferingLocAsscQueue
 * 
 * @author <a href="mailto:Nnupur.Krishnaa@centurylink.com">Nnupur Krishnaa</a>
 *
 */

@RestController
@RequestMapping("/ServiceDelivery/v1/schedule/")
public class SchedulerEventService {

	private static final Logger LOG = LoggerFactory.getLogger(SchedulerEventService.class);

	@Autowired
	SchedulerEventManager schedulerEventManager;

	/**
	 * This method is to retrieve all the ProdOfferingLocAsscQueue which 
	 * have the dequeue date as null
	 * 
	 * @return
	 */
	@GetMapping(path = "/events", consumes = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON })
	@CrossOrigin
	@Audited
	public List<ProdOfferingLocAsscQueueDTO> triggerEvents() {
		LOG.info("Connection Successfull!");
		return schedulerEventManager.getDatafromLocQueue();
	}
	
	/**
	 * This method is used to persist the dequeue date for the 
	 * ProdOfferingLocAsscQueue which have successfully published events
	 * 
	 * @param prodOfferingLocAsscQueueDTO
	 * @return
	 */
	@PostMapping(path = "/persist", consumes = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON })
	@ResponseBody
	@CrossOrigin
	@Audited
	public Level3Response persistDequeueDate(@RequestBody ProdOfferingLocAsscQueueDTO prodOfferingLocAsscQueueDTO) {
		LOG.info("Connection Successfull!");
		return schedulerEventManager.persistDequeueDate(prodOfferingLocAsscQueueDTO);
	}
	
	/**
	 * This end point is to retrieve the account details for the SES call
	 * triggered from the scheduler when there is a new wholesale location added in NS
	 * 
	 * @param serviceLocationId
	 * @return
	 */
	@RequestMapping(path = "/retrieve/account/{serviceLocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
	@ResponseBody
	@Audited
	@CrossOrigin
	public AccountDetailsVO getAccountDetails(@PathVariable String serviceLocationId) {
		if (StringUtils.isEmpty(serviceLocationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getAccountDetails: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		AccountDetailsVO accountDetailsVO = null;
		try {
			accountDetailsVO = schedulerEventManager.getAccountDetails(serviceLocationId);
		} catch (Exception e) {
			LOG.error("@getAccountDetails: Exception processing getAccountDetails ", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return accountDetailsVO;
	}
	

	/**
	 * This end point is to retrieve the account details for the SES call
	 * triggered from the scheduler when there is a new wholesale location added in NS
	 * 
	 * @param serviceLocationId
	 * @return
	 */
	@RequestMapping(path = "/productgroupcode/{productOfferingId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@ResponseBody
	@Audited
	@CrossOrigin
	public String getProductGroupCode(@PathVariable String productOfferingId) {
		if (StringUtils.isEmpty(productOfferingId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getProductGroupCode: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		String productGroupCode = null;
		try {
			productGroupCode = schedulerEventManager.getProductGroupCode(productOfferingId);
		} catch (Exception e) {
			LOG.error("@getProductGroupCode: Exception processing getAccountDetails ", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productGroupCode;
	}
	
	/**
	 * This end point is to retrieve the ServiceOrderExtract details for the SES/UP call
	 * triggered from the scheduler when there is a new entry added in NS
	 * 
	 * @param serviceLocationId
	 * @return
	 */
	@RequestMapping(path = "/tollfree/data", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ServiceOrderExtractVO> retrieveTollfreeData() {
		List<ServiceOrderExtractVO> serviceOrderExtractVOs = null;
		try {
			serviceOrderExtractVOs = schedulerEventManager.retrieveTollfreeData();
		} catch (Exception e) {
			LOG.error("@retrieveServiceExtract: Exception processing retrieveServiceExtract ", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return serviceOrderExtractVOs;
	}
	
	/**
	 * This end point is to persist the ServiceOrderExtract details after the SES/UP call
	 * is completed
	 * 
	 * @param serviceLocationId
	 * @return
	 */
	@PostMapping(path = "/tollfree/persist", consumes = { MediaType.APPLICATION_JSON, MediaType.APPLICATION_JSON })
	@ResponseBody
	@CrossOrigin
	@Audited
	public Level3Response persistServiceExtract(@RequestBody ServiceOrderExtractDTO serviceOrderExtractDTO) {
		Level3Response response = null;
		try {
			response = schedulerEventManager.persistServiceExtract(serviceOrderExtractDTO);
		} catch (Exception e) {
			LOG.error("@retrieveServiceExtract: Exception processing persistServiceExtract ", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return response;
	}
}
