package com.level3.voice.tollfree.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.level3.voice.tollfree.client.PipeLineServiceIdClient;
import com.level3.voice.tollfree.model.Service;
import com.level3.voice.tollfree.persist.dto.ServiceAddressDTO;
import com.level3.voice.tollfree.persist.dto.ServiceLocDTO;
import com.level3.voice.tollfree.persist.repository.ServiceLocRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeDataRepository;
import com.level3.voice.tollfree.persist.vo.BillingAccountNumberVO;
import com.level3.voice.tollfree.persist.vo.ContactsVO;
import com.level3.voice.tollfree.persist.vo.CountryDetailsVO;
import com.level3.voice.tollfree.persist.vo.CustomerInfoVO;
import com.level3.voice.tollfree.persist.vo.ProductDiscPlanVo;
import com.level3.voice.tollfree.persist.vo.ProductSummaryVO;
import com.level3.voice.tollfree.persist.vo.VolumeDiscPlanVO;
import com.level3.voice.tollfree.vo.AddressVO;
import com.level3.voice.tollfree.vo.BanServiceLocationVO;
import com.level3.voice.tollfree.vo.CICVO;
import com.level3.voice.tollfree.vo.CodeTableVO;
import com.level3.voice.tollfree.vo.CrcVO;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.FeatureVO;
import com.level3.voice.tollfree.vo.FeaturesVO;
import com.level3.voice.tollfree.vo.MarketAreaVO;
import com.level3.voice.tollfree.vo.OrderAdditionalDetailsVO;
import com.level3.voice.tollfree.vo.PayPhoneBillingVO;
import com.level3.voice.tollfree.vo.ProductFeaturesVO;
import com.level3.voice.tollfree.vo.ProductVO;
import com.level3.voice.tollfree.vo.ResponseVO;
import com.level3.voice.tollfree.vo.ServiceLocationInformationVO;
import com.level3.voice.tollfree.vo.ServiceLocationVO;
import com.level3.voice.tollfree.vo.ValidationCode;
import com.level3.voice.tollfree.vo.VoiceServiceSearchVO;
import com.level3.voice.tollfree.vo.VoiceServiceVO;

/**
 * TollFree API Manager to access Repository functions
 * 
 * @author <a href="mailto:Keerthi.Selvaraj@centurylink.com">Keerthi selvaraj
 *         </a>
 *
 */
@Component
public class TollFreeDataServiceManager {

	@Autowired
	TollFreeDataRepository tollFreeDataRepository;

	@Autowired
	PipeLineServiceIdClient pipeLineClient;

	@Autowired
	ServiceLocRepository serviceLocRepository;

	@Value("#{'${list.of.filtered.features}'.split(',')}")
	private List<String> filteredFeatures;

	private static final Logger log = Logger.getLogger(TollFreeDataServiceManager.class);

	/**
	 * Method to retrieve BAN's from TollFree repository using Organization id and
	 * customer id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return array of objects where object is [Account ID,Account Name]
	 */
	public List<CustomerVO> getAllAccountInfo(String organizationId, String customerId) {
		List<Object> objects = tollFreeDataRepository.getAccountInfo(organizationId, customerId);

		Iterator<Object> objectsItor = objects.iterator();
		List<CustomerVO> customerVOs = new ArrayList<CustomerVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			CustomerVO customerVO = new CustomerVO();
			customerVO.setCustomerId(String.valueOf(object[0]).trim());
			customerVO.setCustomerName(String.valueOf(object[1]).trim());
			customerVOs.add(customerVO);
		}

		return customerVOs;
	}

	/**
	 * Method to retrieve BANs and service location association with BAN from
	 * TollFree repository using Organization id and customer id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return array of objects where object is [Account ID,Account Name]
	 */
	public CustomerVO getBANServLocInfo(String organizationId, String customerId, String detailType) {
		List<Object> objects = getData(organizationId, customerId, detailType);
		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		Map<String, BanServiceLocationVO> banServLocationVOs = new HashMap<String, BanServiceLocationVO>();
		Object[] controlGroupobject = tollFreeDataRepository.getControlGroupId(customerId);
		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			BanServiceLocationVO banServLocationVO = banServLocationVOs.get(String.valueOf(object[1]).trim());
			if (banServLocationVO != null) {
				String detailtype = getDetailType(object, banServLocationVO);
				banServLocationVO.setDetailType(detailtype);
				continue;
			}
			banServLocationVO = new BanServiceLocationVO();
			banServLocationVO.setAccountNumber(String.valueOf(object[0]).trim());
			banServLocationVO.setServiceLocationId(String.valueOf(object[1]).trim());
			banServLocationVO.setServiceLocationName(String.valueOf(object[2]).trim());
			if (object[3] != null) {
				banServLocationVO.setControlGroupId(String.valueOf(object[3]).trim());
			} else {
				banServLocationVO.setControlGroupId(controlGroupobject[26].toString());
			}
			banServLocationVO.setDetailType(String.valueOf(object[5]).trim());
			banServLocationVOs.put(banServLocationVO.getServiceLocationId(), banServLocationVO);
		}
		customerVO.setBanServiceLocationVOs(new ArrayList<BanServiceLocationVO>(banServLocationVOs.values()));
		return customerVO;

	}

	private List<Object> getData(String organizationId, String customerId, String detailType) {
		if(detailType.equalsIgnoreCase("TF")) {
			List<Object> objects = new ArrayList<>();
			List<Object> objects8S = tollFreeDataRepository.getBanServLoc(organizationId, customerId, "8S");
			List<Object> objects8D = tollFreeDataRepository.getBanServLoc(organizationId, customerId, "8D");
			
			objects.addAll(objects8S);
			objects.addAll(objects8D);
			return objects; 
		}
		return tollFreeDataRepository.getBanServLoc(organizationId, customerId, detailType);
	}

	private String getDetailType(Object[] object, BanServiceLocationVO banServLocationVO) {
		return StringUtils.isEmpty(banServLocationVO.getDetailType())
				? String.valueOf(object[5]).trim()
				: "BOTH";
	}

	/**
	 * Method to retrieve CIC's from TollFree repository using Organization id,
	 * customer id and service location id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param servLocId
	 * @return array of objects where object is [CIC,preference]
	 */
	public CustomerVO getAllCustomerCIC(String organizationId, String customerId, String servLocId) {
		List<Object> objects = tollFreeDataRepository.getCustomerCIC(organizationId, customerId, servLocId);

		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		List<CICVO> cicVOs = new ArrayList<CICVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			CICVO cicVO = new CICVO();
			cicVO.setCic(String.valueOf(object[0]).trim());
			cicVO.setPreference(String.valueOf(object[1]).trim());
			cicVOs.add(cicVO);
		}

		customerVO.setCicVOs(cicVOs);
		return customerVO;
	}

	/**
	 * Method to retrieve Service Locations's from TollFree repository using
	 * Organization id, customer id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return array of objects where object is [Service Location ID,Service
	 *         Location Name]
	 */
	public CustomerVO getAllServiceLocation(String organizationId, String customerId) {
		List<Object> objects = tollFreeDataRepository.getServiceLocation(organizationId, customerId);

		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		List<ServiceLocationVO> serviceLocationVOs = new ArrayList<ServiceLocationVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			ServiceLocationVO serviceLocationVO = new ServiceLocationVO();
			serviceLocationVO.setServiceLocationId(String.valueOf(object[0]).trim());
			serviceLocationVO.setServiceLocationName(String.valueOf(object[1]).trim());
			serviceLocationVO.setControlGroupId(String.valueOf(object[2]).trim());
			serviceLocationVOs.add(serviceLocationVO);
		}

		customerVO.setServiceLocationVOs(serviceLocationVOs);
		return customerVO;
	}

	/**
	 * Method to retrieve product's from TollFree repository using Organization id,
	 * customer id, service location id and detail type
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param serviceLocationId
	 * @param detailType
	 * @return array of Object where object is
	 *         [productOfferingId,productOfferingDescription]
	 */
	public CustomerVO getAllProductInfo(String organizationId, String customerId, String servLocId, String detailType) {
		List<Object> objects = tollFreeDataRepository.getProductInfo(organizationId, customerId, servLocId, detailType);

		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		List<ProductVO> productVOs = new ArrayList<ProductVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			ProductVO productVO = new ProductVO();
			productVO.setProductIOfferingId(String.valueOf(object[0]).trim());
			productVO.setProductName(String.valueOf(object[1]).trim());
			productVOs.add(productVO);
		}

		customerVO.setProductVOs(productVOs);
		return customerVO;

	}

	/**
	 * Method to retrieve List of code tables using org id and customer id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return array of objects where object is [TableId, TableName, CodeDigits ]
	 */
	public CustomerVO getAllCodeTable(String organizationId, String customerId) {
		List<Object> objects = tollFreeDataRepository.getCodeTable(organizationId, customerId);

		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		List<CodeTableVO> codeTableVOs = new ArrayList<CodeTableVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			CodeTableVO codeTableVO = new CodeTableVO();
			codeTableVO.setCodeTableId(String.valueOf(object[0]).trim());
			codeTableVO.setCodeTableName(String.valueOf(object[1]).trim());
			codeTableVO.setCodeDigits(String.valueOf(object[2]).trim());
			codeTableVO.setNonMandatoryInd(String.valueOf(object[3]).trim());
			codeTableVOs.add(codeTableVO);
		}

		customerVO.setCodeTableVOs(codeTableVOs);
		return customerVO;
	}

	/**
	 * Method to retrieve rate plan id using product offering id, org id and status
	 * 
	 * @param productOfferingId
	 * @param organizationId
	 * @param status
	 * @return rateplanId
	 */
	public OrderAdditionalDetailsVO getOrderAdditionalDetails(String productOfferingId, String organizationId,
			String status, String accountNumber, String serviceLocationId) {
		int rateplan = 0;
		String scid = "";
		String billingAccountNumber = "";
		OrderAdditionalDetailsVO orderAdditionalDetailsVO = new OrderAdditionalDetailsVO();
		try {
			rateplan = tollFreeDataRepository.getRatePlanInfo(productOfferingId, organizationId, status);
		} catch (NoResultException e) {
			log.error("No data retrieved @getCustomerDetails from the inputs: product offering id: " + productOfferingId
					+ " organizationId: " + organizationId + " status: " + status);
		}
		orderAdditionalDetailsVO.setRatePlanId(rateplan == 0 ? "" : String.valueOf(rateplan));
		try {
			scid = (String) tollFreeDataRepository.getSCIDInfo(productOfferingId, organizationId);
		} catch (NoResultException e) {
			log.error("No data retrieved @getCustomerDetails from the inputs: product offering id: " + productOfferingId
					+ " organizationId: " + organizationId + " status: " + status);
		}

		orderAdditionalDetailsVO.setScid(scid != null ? scid.trim() : "");

		try {
			billingAccountNumber = (String) tollFreeDataRepository.getBillingAccountNumber(accountNumber,
					serviceLocationId);
		} catch (NoResultException e) {
			log.error("No data retrieved @getCustomerDetails from the inputs: accoutNumber: " + accountNumber
					+ " serviceLocationId: " + serviceLocationId);
		}
		orderAdditionalDetailsVO.setAccountNumber(billingAccountNumber != null ? billingAccountNumber.trim() : "");

		return orderAdditionalDetailsVO;
	}

	/**
	 * Method to retrieve account details using accountnumber and locationid
	 * 
	 * @param productOfferingId
	 * @param organizationId
	 * @param status
	 * @return rateplanId
	 */
	public CrcVO getCrcDetails(String organizationId, String customerId, String cic) {
		String crc = "";
		CrcVO crcVO = new CrcVO();

		try {
			crc = (String) tollFreeDataRepository.getCRC(organizationId, customerId, cic);
		} catch (NoResultException e) {
			log.error("No data retrieved @getCustomerDetails from the inputs: organizationId: " + organizationId
					+ " customerId: " + customerId + " cic: " + cic);
		}
		crcVO.setCrc(crc != null ? crc.trim() : null);

		return crcVO;
	}

	/**
	 * Method to retrieve the customer info using organizationid and customer id
	 * 
	 * @param organizationId
	 * @param custId
	 * @return Customer info
	 */
	public CustomerVO getCustomers(String organizationId, String custId) {
		List<Object> objectList = tollFreeDataRepository.getCustomers(organizationId, custId);

		List<CustomerVO> customerVOList = new ArrayList<CustomerVO>();
		Iterator<Object> objectsItor = objectList.iterator();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			CustomerVO customerVO = new CustomerVO();
			customerVO.setCustomerId(String.valueOf(object[0]).trim());
			customerVO.setCustomerName(String.valueOf(object[1]).trim());
			customerVO.setOrganizationId(String.valueOf(object[2]).trim());
			customerVO.setCustomerBizOrgId(String.valueOf(object[3]).trim());
			customerVOList.add(customerVO);

		}

		if (!customerVOList.isEmpty()) {
			return customerVOList.get(0);
		} else {
			return new CustomerVO();
		}
	}

	/**
	 * Method to validate the NPANX of a tn by checking against the NPANXX table
	 * 
	 * @param tn
	 * @return ResponseVO
	 */
	public ResponseVO validateNPANXX(String tn) {
		ResponseVO responseVO = new ResponseVO();
		if (!isNPANXXValid(tn)) {
			responseVO.setCode(ValidationCode.TNINVALIDNPANXX.getMessageCode());
			responseVO.setDisplayMessage(ValidationCode.TNINVALIDNPANXX.getMessage());
			return responseVO;
		}
		responseVO.setCode(ValidationCode.TNVALID.getMessageCode());
		responseVO.setDisplayMessage(ValidationCode.TNVALID.getMessage());
		return responseVO;
	}

	/**
	 * Method which retrieves details from NPANXX table and checks the presence of
	 * NPA NXX for the inputs passed and returns boolean value
	 * 
	 * @param tn
	 * @return boolean
	 */
	public boolean isNPANXXValid(String tn) {
		String npa = tn.substring(0, 3);
		String nxx = tn.substring(3, 6);
		List<Object> npanxxList = tollFreeDataRepository.getNPANXX(npa, nxx);
		return npanxxList.size() > 0;
	}

	/**
	 * Method to retrieve the customer id and customer name using busOrg
	 * 
	 * @param busOrg
	 * @return getBusOrgInfo
	 */
	public CustomerVO getBusOrg(String busOrg) {
		List<Object> objectList = tollFreeDataRepository.getBusOrg(busOrg);

		List<CustomerVO> customerVOList = new ArrayList<CustomerVO>();
		Iterator<Object> objectsItor = objectList.iterator();
		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			CustomerVO customerVO = new CustomerVO();
			customerVO.setCustomerId(String.valueOf(object[0]).trim());
			customerVO.setCustomerName(String.valueOf(object[1]).trim());
			customerVO.setOrganizationId(String.valueOf(object[2]).trim());
			customerVOList.add(customerVO);
		}
		if (!customerVOList.isEmpty()) {
			return customerVOList.get(0);
		} else {
			return new CustomerVO();
		}
	}

	/**
	 * 
	 * @param organizationId
	 * @param controlGroupId
	 * @param productOfferingId
	 * @param isFromOneStop
	 * @param oneStopFeatureInd
	 * @return array of objects where object is [FeatureOfferingId, Description]
	 */
	public CustomerVO getProdFeatures(String organizationId, String customerId, String serviceLocationId,
			String productOfferingId, Boolean isFromOneStop) {
		List<Object> objects = tollFreeDataRepository.getProdFeatures(organizationId, customerId, serviceLocationId,
				productOfferingId, isFromOneStop);

		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		List<ProductFeaturesVO> productFeaturesVOs = new ArrayList<ProductFeaturesVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			ProductFeaturesVO productFeaturesVO = new ProductFeaturesVO();
			productFeaturesVO.setFeatureOfferingId(String.valueOf(object[0]).trim());
			productFeaturesVO.setFeatureDescription(String.valueOf(object[1]).trim());
			if (filteredFeatures != null && filteredFeatures.contains(productFeaturesVO.getFeatureOfferingId())) {
				productFeaturesVOs.add(productFeaturesVO);
			}
		}

		customerVO.setProductFeaturesVOs(productFeaturesVOs);

		return customerVO;
	}

	public CustomerVO getdefaultFeatures(String organizationId, String productOfferingId, String controlGroupId) {
		// TODO Auto-generated method stub
		List<Object> objects = tollFreeDataRepository.getdefaultProdFeatures(organizationId, productOfferingId,
				controlGroupId);

		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		List<ProductFeaturesVO> productFeaturesVOs = new ArrayList<ProductFeaturesVO>();

		while (objectsItor.hasNext()) {
			Integer object = (Integer) objectsItor.next();
			ProductFeaturesVO productFeaturesVO = new ProductFeaturesVO();
			productFeaturesVO.setFeatureOfferingId(String.valueOf(object).trim());
			productFeaturesVOs.add(productFeaturesVO);
		}

		customerVO.setProductFeaturesVOs(productFeaturesVOs);

		return customerVO;
	}

	/**
	 * @param organizationId
	 * @param customerId
	 * @param serviceLocationId
	 * @return ServiceLocationDTO
	 */
	public ServiceAddressDTO getServLocDetails(String organizationId, String customerId, String serviceLocationId) {
		Object[] object = (Object[]) tollFreeDataRepository.getServiceLocation(organizationId, customerId,
				serviceLocationId);

		ServiceAddressDTO servLocation = new ServiceAddressDTO();
		servLocation.setAddressId(Long.parseLong(String.valueOf(object[0]).trim()));
		servLocation.setAddressFormatId(Long.parseLong(String.valueOf(object[1]).trim()));
		servLocation.setOrganizationId(String.valueOf(object[2]).trim());
		servLocation.setCustomerId(String.valueOf(object[3]).trim());
		servLocation.setAddress1(String.valueOf(object[4]).trim());
		servLocation.setAddress2(String.valueOf(object[5]).trim());
		servLocation.setAddress3(String.valueOf(object[6]).trim());
		servLocation.setAddress4(String.valueOf(object[7]).trim());
		servLocation.setAddress5(String.valueOf(object[8]).trim());
		servLocation.setAddress6(String.valueOf(object[9]).trim());
		servLocation.setCountryId(Long.parseLong(String.valueOf(object[10]).trim()));
		servLocation.setCountyName(String.valueOf(object[11]).trim());
		servLocation.setZipCodePlus4(String.valueOf(object[12]).trim());
		servLocation.setGeographicCode(String.valueOf(object[13]).trim());
		servLocation.setInsideOutsideCityLimits(String.valueOf(object[14]).trim());
		servLocation.setCountryCode(String.valueOf(object[15]).trim());
		servLocation.setCountryName(String.valueOf(object[16]).trim());
		return servLocation;
	}

	public List<CustomerVO> getCustomerName(String custName) {
		List<Object> objects = tollFreeDataRepository.getCustomerName(custName);

		Iterator<Object> objectsItor = objects.iterator();
		List<CustomerVO> customerVOs = new ArrayList<CustomerVO>();

		while (objectsItor.hasNext()) {
			CustomerVO customerVO = new CustomerVO();
			Object[] object = (Object[]) objectsItor.next();

			customerVO.setCustomerId(String.valueOf(object[0]).trim());
			customerVO.setCustomerName(String.valueOf(object[1]).trim());
			customerVO.setOrganizationId(String.valueOf(object[2]).trim());
			customerVO.setCustomerBizOrgId(String.valueOf(object[3]).trim());
			customerVOs.add(customerVO);
		}
		return customerVOs;

	}

	/**
	 * This method is to get service location for given params
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param ban
	 * @return
	 */
	public CustomerVO getServLocInfoForBAN(String organizationId, String customerId, String ban) {
		List<Object> objects = tollFreeDataRepository.getServLocInfoForBAN(organizationId, customerId, ban);

		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		List<BanServiceLocationVO> banServiceLocationVOs = new ArrayList<BanServiceLocationVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			BanServiceLocationVO banServiceLocationVO = new BanServiceLocationVO();
			banServiceLocationVO.setAccountNumber(String.valueOf(object[0]).trim());
			banServiceLocationVO.setServiceLocationId(String.valueOf(object[1]).trim());
			banServiceLocationVO.setServiceLocationName(String.valueOf(object[2]).trim());
			banServiceLocationVO.setControlGroupId(String.valueOf(object[3]).trim());
			banServiceLocationVOs.add(banServiceLocationVO);
		}

		customerVO.setBanServiceLocationVOs(banServiceLocationVOs);

		return customerVO;
	}

	public String getAccountDetails(String serviceLocationId) {
		String locationId = serviceLocationId.split("_")[1];
		return tollFreeDataRepository.getBillingAccountNumber(locationId);
	}

	/**
	 * This method is to get Active TN's for serviceLocation
	 * 
	 * @param servLocId
	 * @param Page
	 * @param PageSize
	 * @return VoiceServiceSearchVO
	 * @throws Exception
	 */
	public VoiceServiceSearchVO getTNInventoryServiceId(String servLocId, int page, int pageSize) throws Exception {
		VoiceServiceSearchVO voiceServiceSearchVO = new VoiceServiceSearchVO();

		int fromList = 0, toList = 0, size = 0;

		List<Object> objects = tollFreeDataRepository.getTNInventoryServiceId(servLocId);

		if (objects == null)
			return null;

		size = objects.size();

		if (page > 1)
			fromList = ((page - 1) * pageSize) - 1;

		toList = (page * pageSize) - 1;

		if (size < toList) {
			toList = size;
		}

		if (objects.size() == 0 || fromList > size)
			return null;
		Iterator<Object> objectsItor = objects.subList(fromList, toList).iterator();

		List<VoiceServiceVO> voiceServices = new ArrayList<VoiceServiceVO>();
		Service pipelineService = pipeLineClient.retrieveServiceId(servLocId);

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			VoiceServiceVO voiceService = new VoiceServiceVO();
			voiceService.setCountryCode("1");
			voiceService.setCountry2LetterIsoCode("US");
			voiceService.setVoiceServiceType("tollfreeNumber");
			voiceService.setCustomerRequestDate(String.valueOf(object[1]));
			String action = !StringUtils.isEmpty(String.valueOf(object[5])) ? String.valueOf(object[5]).trim() : "";
			if ("Remove".equalsIgnoreCase(action)) {
				voiceService.setDisconnectDate(String.valueOf(object[2]));
				voiceService.setVoiceparentServiceId(String.valueOf(object[4]));
				voiceService.setLocationparentServiceId(
						getServiceSCID(pipelineService, servLocId, String.valueOf(object[7])));
				voiceService.setLocationparentServiceIdType("ETF");
			} else {
				voiceService.setCustomerCommitDate(String.valueOf(object[1]));
				voiceService.setInstallDate(String.valueOf(object[3]));
				voiceService.setVoiceServiceId(String.valueOf(object[4]));
				voiceService
						.setLocationServiceId(getServiceSCID(pipelineService, servLocId, String.valueOf(object[7])));
				voiceService.setLocationServiceIdType("ETF");
			}

			voiceService.setOrderDate(String.valueOf(object[8]));
			voiceService.setParentOrderId(String.valueOf(object[0]));
			voiceService.setProductId(pipelineService.getProductPartNumber());
			voiceService.setParentServiceId(getServiceId(pipelineService));
			voiceService.setTelephoneNumber("1" + String.valueOf(object[4]));

			voiceService.setSubscriberLineOrderId(String.valueOf(object[9]));

			List<Object> featureObjects = tollFreeDataRepository
					.getTNInventoryFeature(String.valueOf(object[0]).trim());
			if (featureObjects != null && featureObjects.size() > 0) {
				Iterator<Object> featureObjectsItor = featureObjects.iterator();
				List<FeaturesVO> featList = new ArrayList<FeaturesVO>();
				while (featureObjectsItor.hasNext()) {
					Object[] featureObject = (Object[]) featureObjectsItor.next();
					FeaturesVO features = new FeaturesVO();
					FeatureVO feature = new FeatureVO();
					feature.setName("chargeCode");
					feature.setValue(String.valueOf(featureObject[0]).trim());
					features.setFeature(feature);
					featList.add(features);
				}
				voiceService.setProductFeatures(featList);
			}

			voiceService.setTollFreeYn("Y");
			voiceServices.add(voiceService);
		}

		voiceServiceSearchVO.setVoiceServiceList(voiceServices);
		voiceServiceSearchVO.setPageNumber(page);
		voiceServiceSearchVO.setPageSize(pageSize);
		if (size % pageSize == 0)
			voiceServiceSearchVO.setTotalPageNumber(size / pageSize);
		else
			voiceServiceSearchVO.setTotalPageNumber((size / pageSize) + 1);
		return voiceServiceSearchVO;
	}

	private String getServiceId(Service service) {
		if (service.getVoiceComplete() != null && service.getVoiceComplete().getSiptPIID() != null) {
			return service.getVoiceComplete().getSiptPIID();
		}
		return service.getServiceID();
	}

	private String getServiceSCID(Service service, String serviceSCID, String serviceLocationId) {
		if (service.getVoiceComplete() != null && service.getVoiceComplete().getIsInterconnectVoipVC() != null
				&& "Yes".equalsIgnoreCase(service.getVoiceComplete().getIsInterconnectVoipVC())) {
			return serviceSCID.trim() + "_" + serviceLocationId;
		}
		return serviceSCID.trim();
	}

	public List<CustomerInfoVO> getCustomerInfo(String organizationId) {
		// TODO Auto-generated method stub
		return tollFreeDataRepository.getCustomerInfo(organizationId);
	}

	public List<BillingAccountNumberVO> getAccountInfo(String customerid, String servicelocationid) {
		// TODO Auto-generated method stub
		return tollFreeDataRepository.getAccountDetails(customerid, servicelocationid);
	}

	public List<Object> getStatus(String accountNumber) {
		// TODO Auto-generated method stub
		return tollFreeDataRepository.getStatus(accountNumber);
	}

	public List<ContactsVO> getContacts(String organizationId, String customerid, String servicelocationid,
			String contactType) {
		// TODO Auto-generated method stub
		return tollFreeDataRepository.getContacts(organizationId, customerid, servicelocationid, contactType);
	}

	public List<ServiceLocationInformationVO> getCustomerDetails(String customerid, String serviceLocationId) {
		List<Object> objects = tollFreeDataRepository.getCustomerDetails(customerid, serviceLocationId);
		Iterator<Object> objectsItor = objects.iterator();
		List<ServiceLocationInformationVO> servLocationsVOs = new ArrayList<ServiceLocationInformationVO>();
		ServiceLocationInformationVO serviceLocationInformationVo = new ServiceLocationInformationVO();
		while (objectsItor.hasNext()) {

			Object[] object = (Object[]) objectsItor.next();
			if (object[0] != null) {
				serviceLocationInformationVo.setName(object[0].toString());
			}
			if (object[1] != null) {
				serviceLocationInformationVo.setId(object[1].toString());
			}
			if (object[2] != null) {
				serviceLocationInformationVo.setStatus(object[2].toString());
			}
			if (object[3] != null) {
				serviceLocationInformationVo.setType(object[3].toString());
			}
			if (object[4] != null) {
				serviceLocationInformationVo.setControlGroupId(object[4].toString());
			} else {
				Object[] cGobject = tollFreeDataRepository.getControlGroupId(customerid);
				serviceLocationInformationVo.setControlGroupId(cGobject[26].toString());
			}
			if (object[5] != null) {
				serviceLocationInformationVo.setMarketAreaId(object[5].toString());
			}
			if (object[6] != null) {
				serviceLocationInformationVo.setPayPhoneDeclarationCode(object[6].toString());
			}
			serviceLocationInformationVo.setPiId("");

			servLocationsVOs.add(serviceLocationInformationVo);

		}

		return servLocationsVOs;

	}

	public AddressVO getAddressDetails(String customerid, String servicelocationId) {
		AddressVO addressVO = new AddressVO();
		try {
			Object[] object = tollFreeDataRepository.getAddressDetails(customerid, servicelocationId);

			if (object[0] != null) {
				addressVO.setStreetAddress1(object[0].toString());
			}
			if (object[1] != null) {
				addressVO.setStreetAddress2(object[1].toString());
			}
			if (object[2] != null) {
				addressVO.setCity(object[2].toString());
			}
			if (object[3] != null) {
				addressVO.setState(object[3].toString());
			}
			if (object[4] != null) {
				addressVO.setPostalCode(object[4].toString());
			}
			if (object[5] != null) {
				addressVO.setCountryId(object[5].toString());
			}
			if (object[6] != null) {
				addressVO.setCountyName(object[6].toString());
			} else {
				addressVO.setCountyName("");
			}
		} catch (NoResultException e) {
			return null;
		}

		return addressVO;
	}

	public List<ProductSummaryVO> getProductSummary(String organizationId, String customerId,
			String serviceLocationId) {
		// TODO Auto-generated method stub
		List<Object> objects = tollFreeDataRepository.getProductSumamry(organizationId, customerId, serviceLocationId);

		Iterator<Object> objectsItor = objects.iterator();
		List<ProductSummaryVO> productSummaryVOs = new ArrayList<ProductSummaryVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			ProductSummaryVO ProductSummaryVO = new ProductSummaryVO();
			ProductSummaryVO.setProductOffering(String.valueOf(object[0]).trim());
			ProductSummaryVO.setQtyActive(String.valueOf(object[1]).trim());
			ProductSummaryVO.setQtyPending(String.valueOf(object[2]).trim());
			ProductSummaryVO.setQtyDisconnect(String.valueOf(object[3]).trim());
			productSummaryVOs.add(ProductSummaryVO);
		}

		return productSummaryVOs;
	}

	public List<PayPhoneBillingVO> getPayPhoneBilling() {
		List<PayPhoneBillingVO> payPhoneBillingVOs = new ArrayList<PayPhoneBillingVO>();
		List<Object> objects = tollFreeDataRepository.getPayPhoneBillingData();
		Iterator<Object> objectsItor = objects.iterator();
		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			PayPhoneBillingVO payPhoneBillingVO = new PayPhoneBillingVO();
			if (object[0] != null) {
				payPhoneBillingVO.setContextId(object[0].toString());
			}
			if (object[1] != null) {
				payPhoneBillingVO.setCode(object[1].toString());
			}
			if (object[2] != null) {
				payPhoneBillingVO.setDescription(object[2].toString());
			}
			if (object[3] != null) {
				payPhoneBillingVO.setSortPriority(object[3].toString());
			}
			payPhoneBillingVOs.add(payPhoneBillingVO);
		}
		return payPhoneBillingVOs;

	}

	public List<MarketAreaVO> getMarketArea() {
		List<MarketAreaVO> marketAreaVOs = new ArrayList<MarketAreaVO>();
		List<Object> objects = tollFreeDataRepository.getMarketArea();
		Iterator<Object> objectsItor = objects.iterator();
		while (objectsItor.hasNext()) {
			MarketAreaVO marketAreaVO = new MarketAreaVO();
			Object[] object = (Object[]) objectsItor.next();
			if (object[0] != null) {
				marketAreaVO.setMarketAreaId(object[0].toString());
			}
			if (object[1] != null) {
				marketAreaVO.setMarketAreaName(object[1].toString());
			}
			if (object[2] != null) {
				marketAreaVO.setDescription(object[2].toString());
			}
			if (object[3] != null) {
				marketAreaVO.setAreaBegin(object[3].toString());
			}
			if (object[4] != null) {
				marketAreaVO.setAreaEnd(object[4].toString());
			}
			if (object[5] != null) {
				marketAreaVO.setStatus(object[5].toString());
			}
			marketAreaVOs.add(marketAreaVO);
		}

		return marketAreaVOs;
	}

	/**
	 * This method is to retrieve all the Service Location Based on customer id and
	 * OrganizationId from UV_ServiceLocation4 view
	 * 
	 * @param organizationId
	 * @param customerId
	 * 
	 * @return List<ServiceLocDTO>
	 */
	public List<ServiceLocDTO> getServiceLocnfo(String organizationId, String customerId) {

		return (List<ServiceLocDTO>) serviceLocRepository.findServLocByCustomerId(organizationId, customerId);
	}

	public AddressVO getCustAddress(String customerId) {
		// TODO Auto-generated method stub

		AddressVO addressVO = new AddressVO();
		try {
			Object[] object = tollFreeDataRepository.getCustAddress(customerId);

			if (object[0] != null) {
				addressVO.setStreetAddress1(object[0].toString());
			}
			if (object[1] != null) {
				addressVO.setStreetAddress2(object[1].toString());
			}
			if (object[2] != null) {
				addressVO.setCity(object[2].toString());
			}
			if (object[3] != null) {
				addressVO.setState(object[3].toString());
			}
			if (object[4] != null) {
				addressVO.setPostalCode(object[4].toString());
			}
			if (object[5] != null) {
				addressVO.setCountryId(object[5].toString());
			}
			if (object[6] != null) {
				addressVO.setCountryName(object[6].toString());
			} else {
				addressVO.setCountryName("");
			}

		} catch (NoResultException e) {
			return null;
		}

		return addressVO;
	}

	public List<ContactsVO> getCustContacts(String organizationId, String customerid, String category) {
		// TODO Auto-generated method stub
		return tollFreeDataRepository.getCustContacts(organizationId, customerid, category);
	}

	public List<ContactsVO> getSalesRepDetails(String organizationId, String customerid, String category) {
		// TODO Auto-generated method stub
		return tollFreeDataRepository.getSalesRepDetails(organizationId, customerid, category);
	}

	public String getIntraLataDetails(String customerid, String organizationId) {
		List<String> resList = tollFreeDataRepository.getIntraLataDetails(customerid, organizationId);
		String retString = "";
		if (!resList.isEmpty()) {
			retString = resList.get(0);
		}
		return retString;

	}

	public ProductDiscPlanVo getProductDiscPLan(String customerid, String organizationId) {
		List<ProductDiscPlanVo> prodlist = new ArrayList<ProductDiscPlanVo>();
		prodlist = tollFreeDataRepository.getProductDiscPLan(customerid, organizationId);
		if (prodlist.isEmpty()) {
			return new ProductDiscPlanVo();
		} else {
			return prodlist.get(0);
		}
	}

	public List<VolumeDiscPlanVO> getVolumeDiscPLan(String customerid, String organizationId) {
		// TODO Auto-generated method stub
		return tollFreeDataRepository.getVolumeDiscPLan(customerid, organizationId);
	}

	public CountryDetailsVO getCountryDetails(String countryid) {
		return tollFreeDataRepository.getCountryDetails(countryid);
	}

	public List<BillingAccountNumberVO> getCustAccInfo(String customerid, String organizationId) {
		List<BillingAccountNumberVO> billingAccountNoList = new ArrayList<BillingAccountNumberVO>();
		List<Object> objects = tollFreeDataRepository.getCustAccInfo(customerid, organizationId);
		Iterator<Object> objectsItor = objects.iterator();
		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			BillingAccountNumberVO billingAccountNumberVO = new BillingAccountNumberVO();
			if (object[0] != null) {
				billingAccountNumberVO.setAccountNumber(object[0].toString());
			}
			if (object[1] != null) {
				billingAccountNumberVO.setAccountName(object[1].toString());
			}
			billingAccountNoList.add(billingAccountNumberVO);
		}

		return billingAccountNoList;
	}

	/*
	 * public CustomerVO getProductOfferingInfo(String organizationId, String
	 * productOfferingId) { // TODO Auto-generated method stub List<Object> objects
	 * = tollFreeDataRepository.getProductOfferingInfo(organizationId,
	 * productOfferingId);
	 * 
	 * Iterator<Object> objectsItor = objects.iterator(); CustomerVO customerVO =
	 * new CustomerVO(); List<ProductVO> productVOs = new ArrayList<ProductVO>();
	 * 
	 * while (objectsItor.hasNext()) { Object[] object = (Object[])
	 * objectsItor.next(); ProductVO productVO = new ProductVO();
	 * productVO.setProductIOfferingId(String.valueOf(object[0]).trim());
	 * productVO.setProductName(String.valueOf(object[3]).trim());
	 * productVOs.add(productVO); }
	 * 
	 * customerVO.setProductVOs(productVOs);
	 * 
	 * return customerVO; }
	 */

	/**
	 * Method to retrieve default CIC from TollFree repository using Organization
	 * id, customer id and service location Id
	 * 
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param serviceLocationId
	 * @return default CIC value
	 */
	public String getDefaultCIC(String organizationId, String customerId, String serviceLocationId) {
		return tollFreeDataRepository.getDefaultCIC(organizationId, customerId, serviceLocationId);
	}

	/**
	 * This method is to handle to retrieve the in house bizOrg which PRO needs from
	 * emailid temporary stored until migration in PRO/NPAL is complete
	 * 
	 * @param organizationId
	 * @param custId
	 * @return
	 */
	public String getInHouseBizOrg(String organizationId, String custId) {
		String bizOrgId = "";

		try {
			bizOrgId = (String) tollFreeDataRepository.getBizOrgForInHouseAcc(organizationId, custId);
		} catch (NoResultException e) {
			log.error("No data retrieved @getInHouseBizOrg from the inputs: organizationId: " + organizationId
					+ " customerId: " + custId + " bizOrgId: " + bizOrgId);
		}

		return bizOrgId != null ? bizOrgId.trim() : null;
	}

	public CustomerVO getProductOffering(List<Integer> prodOfferingIds) {
		List<Object> objects = tollFreeDataRepository.getProductOffering(prodOfferingIds);

		Iterator<Object> objectsItor = objects.iterator();
		CustomerVO customerVO = new CustomerVO();
		List<ProductVO> productVOs = new ArrayList<ProductVO>();

		while (objectsItor.hasNext()) {
			Object[] object = (Object[]) objectsItor.next();
			ProductVO productVO = new ProductVO();
			productVO.setProductIOfferingId(String.valueOf(object[0]).trim());
			productVO.setProductName(String.valueOf(object[1]).trim());
			productVOs.add(productVO);
		}

		customerVO.setProductVOs(productVOs);

		return customerVO;
	}

	public int getBatchDropStatus(String fileName, String customerid) {
		return tollFreeDataRepository.getBatchDropStatus(fileName, customerid);
	}

	public void completeBatchDropStatus(String fileName, String customerid) {
		tollFreeDataRepository.completeBatchDropStatus(fileName, customerid);
	}
	
	/**
	 * Method used to identified if the diff ban is enabled
	 * for tollfree BANs
	 *  
	 * @param ban
	 * @return
	 */
	public String isDifferentBanEnabled(String ban) {
		return tollFreeDataRepository.isDifferentBanEnabled(ban);
	}

	/**
	 * Retrieve all ban associated to the 
	 * ban which is passed
	 * 
	 * @param ban
	 * @return
	 */
	public List<String> getCustomerBans(String ban) {
		List<String> customerBans = new ArrayList<>();
		List<Object> banList = tollFreeDataRepository.getCustomerBans(ban);
		
		for(Object customerBan: banList) {
			customerBans.add(String.valueOf(customerBan).trim());
		}
		return customerBans;
	}
}
