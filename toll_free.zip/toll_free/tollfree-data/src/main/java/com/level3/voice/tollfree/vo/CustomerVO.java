package com.level3.voice.tollfree.vo;

import java.io.Serializable;
import java.util.List;

public class CustomerVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String customerId;
	private String customerName;
	private String organizationId;
	private String customerBizOrgId;
	private String ratePlanId;
	private List<BillingAccountNumberVO> billingAccountNumberVOs;
	private List<ServiceLocationVO> serviceLocationVOs;
	private List<BanServiceLocationVO> banServiceLocationVOs;
	private List<CICVO> cicVOs;
	private List<ProductVO> productVOs;
	private List<ProductFeaturesVO> productFeaturesVOs;
	private List<CodeTableVO> codeTableVOs;
	
	/** default constructor */
	public CustomerVO() {
		
	}
	
	/**
	 * Minimal Constructor
	 */
	public CustomerVO(String customerId, String customerName, String organizationId, String customerBizOrgId) {
		this.customerId = customerId;
		this.customerName = customerName;
		this.organizationId = organizationId;
		this.customerBizOrgId = customerBizOrgId;
	}
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getCustomerBizOrgId() {
		return customerBizOrgId;
	}
	public void setCustomerBizOrgId(String customerBizOrgId) {
		this.customerBizOrgId = customerBizOrgId;
	}
	public String getRatePlanId() {
		return ratePlanId;
	}
	public void setRatePlanId(String ratePlanId) {
		this.ratePlanId = ratePlanId;
	}
	public List<BillingAccountNumberVO> getBillingAccountNumberVOs() {
		return billingAccountNumberVOs;
	}
	public void setBillingAccountNumberVOs(List<BillingAccountNumberVO> billingAccountNumberVOs) {
		this.billingAccountNumberVOs = billingAccountNumberVOs;
	}
	public List<ServiceLocationVO> getServiceLocationVOs() {
		return serviceLocationVOs;
	}
	public void setServiceLocationVOs(List<ServiceLocationVO> serviceLocationVOs) {
		this.serviceLocationVOs = serviceLocationVOs;
	}
	public List<BanServiceLocationVO> getBanServiceLocationVOs() {
		return banServiceLocationVOs;
	}
	public void setBanServiceLocationVOs(List<BanServiceLocationVO> banServiceLocationVOs) {
		this.banServiceLocationVOs = banServiceLocationVOs;
	}
	public List<CICVO> getCicVOs() {
		return cicVOs;
	}
	public void setCicVOs(List<CICVO> cicVOs) {
		this.cicVOs = cicVOs;
	}
	public List<ProductVO> getProductVOs() {
		return productVOs;
	}
	public void setProductVOs(List<ProductVO> productVOs) {
		this.productVOs = productVOs;
	}
	public List<ProductFeaturesVO> getProductFeaturesVOs() {
		return productFeaturesVOs;
	}
	public void setProductFeaturesVOs(List<ProductFeaturesVO> productFeaturesVOs) {
		this.productFeaturesVOs = productFeaturesVOs;
	}
	public List<CodeTableVO> getCodeTableVOs() {
		return codeTableVOs;
	}
	public void setCodeTableVOs(List<CodeTableVO> codeTableVOs) {
		this.codeTableVOs = codeTableVOs;
	}
}
