package com.level3.voice.tollfree.vo;

import java.io.Serializable;

/**
 * This VO is to handle the scheduler call to SES to retrieve
 * the BAN 6.3 and BAN 7.8 in one object for service location id
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class AccountDetailsVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String accountNumber;
	private String billingAccountNumber;
	private String serviceLocationId;
	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}
	/**
	 * @param accountNumber the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * @return the billingAccountNumber
	 */
	public String getBillingAccountNumber() {
		return billingAccountNumber;
	}
	/**
	 * @param billingAccountNumber the billingAccountNumber to set
	 */
	public void setBillingAccountNumber(String billingAccountNumber) {
		this.billingAccountNumber = billingAccountNumber;
	}
	/**
	 * @return the serviceLocationId
	 */
	public String getServiceLocationId() {
		return serviceLocationId;
	}
	/**
	 * @param serviceLocationId the serviceLocationId to set
	 */
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}
	
}

