package com.level3.voice.tollfree.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.manager.AdminDataManager;
import com.level3.voice.tollfree.persist.dto.BusinessUnitAffiliateDTO;
import com.level3.voice.tollfree.persist.dto.ChargeDepartmentDTO;
import com.level3.voice.tollfree.persist.dto.CurrencyDTO;
import com.level3.voice.tollfree.persist.dto.GeneralLedgerCodeDTO;
import com.level3.voice.tollfree.persist.dto.ProductMasterDTO;
import com.level3.voice.tollfree.persist.dto.ProductOfferingDTO;
import com.level3.voice.tollfree.persist.dto.ProductsDTO;
import com.level3.voice.tollfree.persist.dto.ProfitCenterDTO;
import com.level3.voice.tollfree.persist.dto.RatePlanDTO;
import com.level3.voice.tollfree.persist.dto.ServiceLocDTO;
import com.level3.voice.tollfree.persist.dto.SpecialEndPointTypeDTO;
import com.level3.voice.tollfree.persist.dto.TaxClassificationMasterDTO;
import com.level3.voice.tollfree.vo.ValidationMessageVO;

/**
 * This service is used to handle all the data retrieval, updates, to sandstone
 * done by Admin users
 * 
 * @author <a href="mailto:Mushahid.Khan@centurylink.com">Mushahid Khan</a>
 *
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/admin/")
public class AdminDataService {

	private static final Logger LOG = Logger.getLogger(AdminDataService.class);

	@Autowired
	private AdminDataManager adminDataManager;

	/**
	 * This method is used to retrieve all the product offering data based on the
	 * organization id
	 * 
	 * @param orgId
	 * @return
	 */
	@RequestMapping(path = "/productoffering/{orgId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ProductOfferingDTO> getProductOfferingData(@PathVariable String orgId) {
		LOG.debug("the parameter recieved is :" + orgId);
		List<ProductOfferingDTO> productOfferingDTOs = null;
		try {

			productOfferingDTOs = adminDataManager.getallProductOfferingData(orgId);
		} catch (Exception e) {
			LOG.error("@getAllAccountInfo: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productOfferingDTOs;

	}

	/**
	 * This method is to get all products from the product master view.
	 * 
	 * @return
	 */
	@RequestMapping(path = "/allproducts", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ProductMasterDTO> getProductData() {

		List<ProductMasterDTO> productMasterDTOs = null;
		try {
			productMasterDTOs = adminDataManager.getAllProductData();
		} catch (Exception e) {
			LOG.error("@getAllAccountInfo: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productMasterDTOs;

	}

	/**
	 * This method is to retrieve products specific to organization id which user
	 * has selected.
	 * 
	 * @param orgId
	 * @return
	 */
	@RequestMapping(path = "/products/{orgId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ProductsDTO> getProductsByOrgId(@PathVariable String orgId) {
		LOG.debug("the parameter recieved is :" + orgId);
		List<ProductsDTO> productsDTOs = null;
		try {

			productsDTOs = adminDataManager.getProductsByOrgId(orgId);
		} catch (Exception e) {
			LOG.error("@getAllAccountInfo: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productsDTOs;

	}

	/**
	 * This method is to retrieve all the profitcenters based on organization id
	 * 
	 * @param orgId
	 * @return
	 */
	@RequestMapping(path = "/profitcenters/{orgId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ProfitCenterDTO> getProfitCenters(@PathVariable String orgId) {
		LOG.debug("@getProfitCenters the parameter recieved is :" + orgId);
		try {
			return adminDataManager.getProfitCenters(orgId);
		} catch (Exception e) {
			LOG.error("@getProfitCenters: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * This method is to retreive all the business unit affiliates for the selected
	 * organization id
	 * 
	 * @param orgId
	 * @return
	 */
	@RequestMapping(path = "/businessunitaffiliates/{orgId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<BusinessUnitAffiliateDTO> getBusinessUnitAffiliates(@PathVariable String orgId) {
		LOG.debug("@getBusinessUnitAffiliates the parameter recieved is :" + orgId);
		try {

			return adminDataManager.getBusinessUnitAffiliates(orgId);
		} catch (Exception e) {
			LOG.error("@getBusinessUnitAffiliates: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * This method is to retrieve all the charge departments based on the selected
	 * organization id
	 * 
	 * @param orgId
	 * @return
	 */
	@RequestMapping(path = "/chargedepartments/{orgId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ChargeDepartmentDTO> getChargeDepartments(@PathVariable String orgId) {
		LOG.debug("@getChargeDepartments the parameter recieved is :" + orgId);
		try {
			return adminDataManager.getChargeDepartments(orgId);
		} catch (Exception e) {
			LOG.error("@getChargeDepartments: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * This method is to retrieve all the currencies from the currency table
	 * 
	 * @return
	 */
	@RequestMapping(path = "/currencies", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<CurrencyDTO> getCurrencies() {
		try {
			return adminDataManager.getCurrencies();
		} catch (Exception e) {
			LOG.error("@getCurrencies: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * This method is to persist product offering data with product offering
	 * charge/rateplan
	 * 
	 * @param productOfferingDTO
	 * @return
	 */
	@PostMapping(path = "/persist", consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@CrossOrigin
	@Audited
	public ValidationMessageVO persistProductOffering(@RequestBody ProductOfferingDTO poDto) {

		try {
			return adminDataManager.persistProductOffering(poDto);
		} catch (Exception e) {
			LOG.error("@getAllAccountInfo: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
	}

	/**
	 * This method is to retrieve all Tax service codes
	 * 
	 * @return
	 */
	@RequestMapping(path = "/taxservicecode/{orgId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<TaxClassificationMasterDTO> getTaxServiceCode(@PathVariable String orgId) {
		LOG.debug("the parameter recieved is :" + orgId);
		List<TaxClassificationMasterDTO> taxClassificationMasterDTOs = null;
		try {

			taxClassificationMasterDTOs = adminDataManager.getTaxServiceCode();
		} catch (Exception e) {
			LOG.error("@getAllAccountInfo: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return taxClassificationMasterDTOs;

	}

	/**
	 * This method is to retrieve all account codes for an organization
	 * 
	 * @return
	 */
	@RequestMapping(path = "/accountcodes/{orgId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<GeneralLedgerCodeDTO> getAccountCodes(@PathVariable String orgId) {
		LOG.debug("the parameter recieved is :" + orgId);
		List<GeneralLedgerCodeDTO> generalLedgerCodeDTO = null;
		try {

			generalLedgerCodeDTO = adminDataManager.getGenralLedgerCodes(orgId);
		} catch (Exception e) {
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return generalLedgerCodeDTO;
	}

	/**
	 * This method is to retrieve all Rate plans for an organization
	 * 
	 * @return List<RatePlanDTO>
	 */
	@RequestMapping(path = "/rateplans/{orgId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<RatePlanDTO> getRatePlans(@PathVariable String orgId) {
		LOG.debug("the parameter recieved is :" + orgId);
		List<RatePlanDTO> ratePlans = null;
		try {

			ratePlans = adminDataManager.getRatePlans(orgId);
		} catch (Exception e) {
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return ratePlans;
	}

	/**
	 * This method is to retrieve complete product offering dto object for an
	 * organization and product offering
	 * 
	 * @return
	 */

	@RequestMapping(path = "/copyExisting/{orgId}/{productOfferingId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public ProductOfferingDTO getProductOfferingInfo(@PathVariable String orgId, @PathVariable Long productOfferingId) {
		LOG.debug("the parameter recieved is :" + orgId + " " + productOfferingId);
		ProductOfferingDTO productOfferingDTO = null;
		try {

			productOfferingDTO = adminDataManager.getProductOfferingInfo(orgId, productOfferingId);
		} catch (Exception e) {
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productOfferingDTO;

	}

	/**
	 * This method is to retrieve all Special End point Codes
	 * 
	 * @return List<SpecialEndPointTypeDTO>
	 */
	@RequestMapping(path = "/specialendpointtypes", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<SpecialEndPointTypeDTO> getSpecialEndPointTypes() {
		List<SpecialEndPointTypeDTO> specialEndPointTypes = null;
		try {

			specialEndPointTypes = adminDataManager.getSpecialEndPointTypes();
		} catch (Exception e) {
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return specialEndPointTypes;
	}
	
}
