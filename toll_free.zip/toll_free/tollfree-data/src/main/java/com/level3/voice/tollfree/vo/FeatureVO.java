package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class FeatureVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private String value;
	
	public String getName() {
		return name;
	}
	public void setName(String featureName) {
		this.name = featureName;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String featureValue) {
		this.value = featureValue;
	}
}
