package com.level3.voice.tollfree.manager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.level3.voice.common.util.CacheConstants;
import com.level3.voice.tollfree.persist.dto.BusinessUnitAffiliateDTO;
import com.level3.voice.tollfree.persist.dto.BusinessUnitChargeDTO;
import com.level3.voice.tollfree.persist.dto.ChargeDTO;
import com.level3.voice.tollfree.persist.dto.ChargeDepartmentDTO;
import com.level3.voice.tollfree.persist.dto.ChargeStructureQuantityDTO;
import com.level3.voice.tollfree.persist.dto.CurrencyDTO;
import com.level3.voice.tollfree.persist.dto.GeneralLedgerCodeDTO;
import com.level3.voice.tollfree.persist.dto.MarketAreaProductOfferingDTO;
import com.level3.voice.tollfree.persist.dto.ProductMasterDTO;
import com.level3.voice.tollfree.persist.dto.ProductOfferingChargeDTO;
import com.level3.voice.tollfree.persist.dto.ProductOfferingDTO;
import com.level3.voice.tollfree.persist.dto.ProductOfferingRatePlanDTO;
import com.level3.voice.tollfree.persist.dto.ProductWithSpecialEndPointDTO;
import com.level3.voice.tollfree.persist.dto.ProductsDTO;
import com.level3.voice.tollfree.persist.dto.ProfitCenterDTO;
import com.level3.voice.tollfree.persist.dto.RatePlanDTO;
import com.level3.voice.tollfree.persist.dto.ServiceLocDTO;
import com.level3.voice.tollfree.persist.dto.SpecialEndPointTypeDTO;
import com.level3.voice.tollfree.persist.dto.TaxClassificationMasterDTO;
import com.level3.voice.tollfree.persist.pk.ChargeStructureQuantityPK;
import com.level3.voice.tollfree.persist.pk.MarketAreaProductOfferingPK;
import com.level3.voice.tollfree.persist.pk.ProductOfferingRatePlanPK;
import com.level3.voice.tollfree.persist.pk.ProductWithSpecialEndPointPK;
import com.level3.voice.tollfree.persist.repository.BusinessUnitAffiliateRepository;
import com.level3.voice.tollfree.persist.repository.BusinessUnitChargeRepository;
import com.level3.voice.tollfree.persist.repository.ChargeDepartmentRepository;
import com.level3.voice.tollfree.persist.repository.ChargeRepository;
import com.level3.voice.tollfree.persist.repository.ChargeStructureQuantityRepository;
import com.level3.voice.tollfree.persist.repository.CurrencyRepository;
import com.level3.voice.tollfree.persist.repository.GeneralLedgerCodeRepository;
import com.level3.voice.tollfree.persist.repository.MarketAreaProductOfferingRepository;
import com.level3.voice.tollfree.persist.repository.ProductDataRepository;
import com.level3.voice.tollfree.persist.repository.ProductOfferingChargeRepository;
import com.level3.voice.tollfree.persist.repository.ProductOfferingRatePlanRepository;
import com.level3.voice.tollfree.persist.repository.ProductOfferingRepository;
import com.level3.voice.tollfree.persist.repository.ProductWithSpecialEndPointRepository;
import com.level3.voice.tollfree.persist.repository.ProductsRepository;
import com.level3.voice.tollfree.persist.repository.ProfitCenterRepository;
import com.level3.voice.tollfree.persist.repository.RatePlanRepository;
import com.level3.voice.tollfree.persist.repository.SpecialEndPointTypeRepository;
import com.level3.voice.tollfree.persist.repository.ServiceLocRepository;
import com.level3.voice.tollfree.persist.repository.TaxClassificationMasterRepository;
import com.level3.voice.tollfree.vo.ValidationMessageVO;

/**
 * The manager class handles all the business logic which are involved for the
 * various calls which happen on the screens which are handled by Admin users
 * 
 * @author <a href="mailto:Mushahid.Khan@centurylink.com">Mushahid Khan</a>
 *
 */
@Component
public class AdminDataManager {
	private static final Logger LOG = Logger.getLogger(AdminDataManager.class);

	@Autowired
	ProductDataRepository productDataRepository;
	@Autowired
	ProductOfferingRepository productOfferingRepository;
	@Autowired
	ProductsRepository productsRepository;
	@Autowired
	ProfitCenterRepository profitCenterRepository;
	@Autowired
	BusinessUnitAffiliateRepository businessUnitAffiliateRepository;
	@Autowired
	ChargeDepartmentRepository chargeDepartmentRepository;
	@Autowired
	CurrencyRepository currencyRepository;
	@Autowired
	GeneralLedgerCodeRepository generalLedgerCodeRepository; 
	@Autowired
	TaxClassificationMasterRepository taxClassificationMasterRepository;
	@Autowired
	ChargeRepository chargeRepository;
	@Autowired
	ProductOfferingChargeRepository productOfferingChargeRepository;
	@Autowired
	MarketAreaProductOfferingRepository marketAreaProductOfferingRepository;
	@Autowired
	ProductOfferingRatePlanRepository productOfferingRatePlanRepository;
	@Autowired
	BusinessUnitChargeRepository businessUnitChargeRepository;
	@Autowired
	ChargeStructureQuantityRepository chargeStructureQuantityRepository;
	@Autowired
	RatePlanRepository ratePlanRepository;
	@Autowired
	SpecialEndPointTypeRepository specialEndPointTypeRepository;
	@Autowired
	ProductWithSpecialEndPointRepository productWithSpecialEndPointRepository;


	/**
	 * Method is to retrieve all product offering id based on organization id
	 * 
	 * @param orgId
	 * @return
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getallProductOfferingData:")
	public List<ProductOfferingDTO> getallProductOfferingData(String orgId) {
		LOG.info("@getallProductOfferingData with orgId:" + orgId);
		return productOfferingRepository.findAllByOrganizationId(orgId);

	}

	/**
	 * Method is to retrieve all products from the product master table.
	 * 
	 * @return
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getAllProductData:")
	public List<ProductMasterDTO> getAllProductData() {
		LOG.info("@getAllProductData");
		return productDataRepository.findAllProductMasterData();
	}

	/**
	 * Method to retrieve products based on the organization selected.
	 * 
	 * @param orgId
	 * @return
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getProductsByOrgId:")
	public List<ProductsDTO> getProductsByOrgId(String orgId) {
		LOG.info("@getProductsByOrgId");
		return productsRepository.findAllByOrganizationId(orgId);

	}

	/**
	 * Method to retrieve profit centers for the provided organization id from
	 * profitcenter table
	 * 
	 * @param orgId
	 * @return
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getProfitCenters:")
	public List<ProfitCenterDTO> getProfitCenters(String orgId) {
		LOG.info("@retrieveProfitCenters");
		return profitCenterRepository.retrieveProfitCenters(orgId);
	}

	/**
	 * Method to retrieve business unit affiliates based on the selected
	 * organization id
	 * 
	 * @param orgId
	 * @return
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getBusinessUnitAffiliates:")
	public List<BusinessUnitAffiliateDTO> getBusinessUnitAffiliates(String orgId) {
		LOG.info("@getProductsByOrgId");
		return businessUnitAffiliateRepository.retrieveProfitCenters(orgId);
	}

	/**
	 * Method to retrieve charge department information for the selected
	 * organization id
	 * 
	 * @param orgId
	 * @return
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getChargeDepartments:")
	public List<ChargeDepartmentDTO> getChargeDepartments(String orgId) {
		LOG.info("@getProductsByOrgId");
		return chargeDepartmentRepository.retrieveProfitCenters(orgId);
	}

	/**
	 * Method to retrieve all currencies to display as a dropdown on the charges
	 * screen
	 * 
	 * @return
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:Currencies:")
	public List<CurrencyDTO> getCurrencies() {
		LOG.info("@getProductsByOrgId");
		return currencyRepository.retrieveProfitCenters();
	}

	/**
	 * Method to persist the product offering data
	 * 
	 * @param productOfferingDTO
	 * @return
	 * @throws Exception 
	 */
	public ValidationMessageVO persistProductOffering(ProductOfferingDTO poDto) throws Exception {
		LOG.info("@persistProductOffering");

		if(poDto == null) {
			LOG.error("@AdminDataManager @persistProductOffering: Input: "+ poDto);
			throw new Exception("@AdminDataManager @persistProductOffering: Product offering details not available.");
		}

		if(poDto.getProductOfferingId() == null) {
			poDto.setProductOfferingId(productOfferingRepository.getMaxProductOfferingid() + 1);
		}
		productOfferingRepository.save(poDto);

		persistProductWithSpecialEndPoint(poDto);
		persistMarketAreaProductOffering(poDto);
		persistProductOfferingRatePlan(poDto);
		persistCharge(poDto);
		return createSuccessMessage(poDto);
	}

	/**
	 * This method is to persist the product offering to endpointtype
	 * relationship based on the product selection on the UI
	 * 
	 * @param poDto
	 */
	private void persistProductWithSpecialEndPoint(ProductOfferingDTO poDto) {
		List<ProductWithSpecialEndPointDTO> productWithSpecialEndPointDTOs = poDto.getProductWithSpecialEndPointDTOs();
		
		if(productWithSpecialEndPointDTOs == null || (productWithSpecialEndPointDTOs != null && productWithSpecialEndPointDTOs.isEmpty())) return;
		
		Iterator<ProductWithSpecialEndPointDTO> productWithSpecialEndPointDTOsItor = productWithSpecialEndPointDTOs.iterator();
		while(productWithSpecialEndPointDTOsItor.hasNext()) {
			ProductWithSpecialEndPointDTO productWithSpecialEndPointDTO = productWithSpecialEndPointDTOsItor.next();
			ProductWithSpecialEndPointPK productWithSpecialEndPointPK = new ProductWithSpecialEndPointPK();
			productWithSpecialEndPointPK.setProductOfferingId(poDto.getProductOfferingId());
			productWithSpecialEndPointPK.setSpecialEndPointTypeCode(productWithSpecialEndPointDTO.getSpecialEndPointTypeCode());
			productWithSpecialEndPointDTO.setProductWithSpecialEndPointPK(productWithSpecialEndPointPK);
			productWithSpecialEndPointRepository.save(productWithSpecialEndPointDTO);
		}
	}

	/**
	 * Method to persist the market area product offering relationship
	 * 
	 * @param productOfferingDTO
	 * @return
	 * @throws Exception 
	 */
	private void persistMarketAreaProductOffering(ProductOfferingDTO poDto) {
		if(poDto.getMarketAreaProductOfferingDTO() != null) {
			MarketAreaProductOfferingDTO marketAreaProductOfferingDTO = poDto.getMarketAreaProductOfferingDTO();
			marketAreaProductOfferingDTO.setMarketAreaProductOfferingPK(populateMarkertAreaProductOfferingPK(poDto,
					marketAreaProductOfferingDTO));
			marketAreaProductOfferingRepository.save(marketAreaProductOfferingDTO);
		}
	}

	/**
	 * This method is to populate the composite key for the MarketAreaProductOfferingDTO
	 * 
	 * @param poDto
	 * @param marketAreaProductOfferingDTO
	 * @return MarketAreaProductOfferingPK
	 */
	private MarketAreaProductOfferingPK populateMarkertAreaProductOfferingPK(ProductOfferingDTO poDto,
			MarketAreaProductOfferingDTO marketAreaProductOfferingDTO) {
		MarketAreaProductOfferingPK marketAreaProductOfferingPK = new MarketAreaProductOfferingPK();
		Long productOfferingId = marketAreaProductOfferingDTO.getProductOfferingId();
		if(productOfferingId == null) {
			productOfferingId = poDto.getProductOfferingId();
		}
		marketAreaProductOfferingPK.setProductOfferingId(productOfferingId);
		marketAreaProductOfferingPK.setMarketAreaId(marketAreaProductOfferingDTO.getMarketAreaId());
		return marketAreaProductOfferingPK;
	}

	/**
	 * Method to persist the product offering rate plan
	 * which would be the usage charge information
	 * 
	 * @param productOfferingDTO
	 * @return
	 * @throws Exception 
	 */
	private void persistProductOfferingRatePlan(ProductOfferingDTO poDto) {
		if(poDto.getProductOfferingRatePlanDTO() != null) {
			ProductOfferingRatePlanDTO productOfferingRatePlanDTO = poDto.getProductOfferingRatePlanDTO();
			productOfferingRatePlanDTO.setProductOfferingRatePlanPK(populateProductOfferingRatePlanPK(poDto,
					productOfferingRatePlanDTO));
			productOfferingRatePlanRepository.save(productOfferingRatePlanDTO);
		}
	}

	/**
	 * This method is to create the composite key for
	 * Productofferingrateplan table 
	 * 
	 * @param poDto
	 * @param productOfferingRatePlanDTO
	 * @return ProductOfferingRatePlanPK
	 */
	private ProductOfferingRatePlanPK populateProductOfferingRatePlanPK(ProductOfferingDTO poDto,
			ProductOfferingRatePlanDTO productOfferingRatePlanDTO) {
		ProductOfferingRatePlanPK productOfferingRatePlanPK = new ProductOfferingRatePlanPK();
		Long productOfferingId = productOfferingRatePlanDTO.getProductOfferingId();
		if(productOfferingId == null) {
			productOfferingId = poDto.getProductOfferingId();
		}
		productOfferingRatePlanPK.setOrganizationId(productOfferingRatePlanDTO.getOrganizationId());
		productOfferingRatePlanPK.setProductOfferingId(productOfferingId);
		productOfferingRatePlanPK.setRatePlanId(productOfferingRatePlanDTO.getRatePlanId());
		return productOfferingRatePlanPK;
	}

	/**
	 * Success Message to be sent once complete
	 * insert/update is performed
	 * 
	 * @param poDTO
	 * @return ValidationMessageVO
	 */
	private ValidationMessageVO createSuccessMessage(ProductOfferingDTO poDTO) {
		ValidationMessageVO validationMessageVO = new ValidationMessageVO();
		validationMessageVO.setCode("04");
		validationMessageVO.setDisplayMessage("Product Offering "+poDTO.getDescription()+" has been successfull saved with product offering id "+poDTO.getProductOfferingId()+".");
		return validationMessageVO;
	}

	/**
	 * Method to persist charge in charge table and also
	 * charge association to the product offering in the
	 * productofferingcharge table
	 * 
	 * @param productOfferingVO
	 * @param poDTO
	 */
	private void persistCharge(ProductOfferingDTO poDTO) {
		List<ChargeDTO> chargeDTOs = poDTO.getChargeDTOs();

		Iterator<ChargeDTO> chargeVOsItor = chargeDTOs.iterator();
		while(chargeVOsItor.hasNext()) {
			ChargeDTO chDto = chargeVOsItor.next();
			if(chDto.getChargeId() == null) {
				chDto.setChargeId(chargeRepository.getMaxChargeid() + 1);
			}
			chargeRepository.save(chDto);
			persistBusinessUnitCharge(chDto);
			persistProductOfferingCharge(poDTO, chDto);
			persistChargeStructureQuantity(chDto);
		}
	}

	/**
	 * Method to persist business unit charge in charge table and also
	 * charge association to the product offering in the
	 * productofferingcharge table
	 * 
	 * @param productOfferingVO
	 * @param poDTO
	 */
	private void persistBusinessUnitCharge(ChargeDTO chDto) {
		if(chDto.getBusinessUnitChargeDTO() != null) {
			BusinessUnitChargeDTO businessUnitChargeDTO = chDto.getBusinessUnitChargeDTO();
			if(businessUnitChargeDTO.getChargeId() == null) {
				businessUnitChargeDTO.setChargeId(chDto.getChargeId());
			}
			businessUnitChargeRepository.save(businessUnitChargeDTO);
		}
	}

	/**
	 * Method to persist product offering charge in charge table and also
	 * charge association to the product offering in the
	 * productofferingcharge table
	 * 
	 * @param productOfferingVO
	 * @param poDTO
	 */
	private void persistProductOfferingCharge(ProductOfferingDTO poDTO, ChargeDTO chDto) {

		ProductOfferingChargeDTO productOfferingChargeDTO = chDto.getProductOfferingChargeDTO();
		if(productOfferingChargeDTO == null) {
			productOfferingChargeDTO = new ProductOfferingChargeDTO();
			productOfferingChargeDTO.setOrganizationId(poDTO.getOrganizationId());
			productOfferingChargeDTO.setChargeBegin(chDto.getBeginDate());
			productOfferingChargeDTO.setChargeEnd(chDto.getEndDate());
			productOfferingChargeDTO.setStatus(chDto.getStatus());
		}
		if(productOfferingChargeDTO != null) {
			if(productOfferingChargeDTO.getChargeId() == null) {
				productOfferingChargeDTO.setChargeId(chDto.getChargeId());
			}
			if(productOfferingChargeDTO.getProductOfferingId() == null) {
				productOfferingChargeDTO.setProductOfferingId(poDTO.getProductOfferingId());
			}
			productOfferingChargeRepository.save(productOfferingChargeDTO);
		}
	}

	/**
	 * Method to persist charge structure quantity in charge table and also
	 * charge association to the product offering in the
	 * productofferingcharge table
	 * 
	 * @param productOfferingVO
	 * @param poDTO
	 */
	private void persistChargeStructureQuantity(ChargeDTO chDto) {
		if(chDto.getFinalChargeStructureQuantityDTO() != null) {
			ChargeStructureQuantityDTO finalChargeStructureQuantityDTO = chDto.getFinalChargeStructureQuantityDTO();
			finalChargeStructureQuantityDTO.setChargeStructureQuantityPK(populateChargeStructureQuantityPK(chDto,
					finalChargeStructureQuantityDTO));
			chargeStructureQuantityRepository.save(finalChargeStructureQuantityDTO);
		}
		
		if(chDto.getInitialChargeStructureQuantityDTO() != null) {
			ChargeStructureQuantityDTO initialChargeStructureQuantityDTO = chDto.getInitialChargeStructureQuantityDTO();
			initialChargeStructureQuantityDTO.setChargeStructureQuantityPK(populateChargeStructureQuantityPK(chDto,
					initialChargeStructureQuantityDTO));
			chargeStructureQuantityRepository.save(initialChargeStructureQuantityDTO);
		}
	}

	/**
	 * This method is to create the composite key for
	 * ChargeStructureQuantity table
	 * 
	 * @param chDto
	 * @param chargeStructureQuantityDTO
	 * @return ChargeStructureQuantityPK
	 */
	private ChargeStructureQuantityPK populateChargeStructureQuantityPK(ChargeDTO chDto,
			ChargeStructureQuantityDTO chargeStructureQuantityDTO) {
		ChargeStructureQuantityPK chargeStructureQuantityPK = new ChargeStructureQuantityPK();
		Long chargeId = chargeStructureQuantityDTO.getChargeId();
		if(chargeId == null) {
			chargeId = chDto.getChargeId();
		}
		chargeStructureQuantityPK.setChargeId(chargeId);
		chargeStructureQuantityPK.setOrganizationId(chargeStructureQuantityDTO.getOrganizationId());
		chargeStructureQuantityPK.setQuantity(chargeStructureQuantityDTO.getQuantity());
		return chargeStructureQuantityPK;
	}

	/**
	 * This method is to retrieve all the general Ledger Codes
	 * from GeneralLedgerCode table
	 * 
	 * @param orgId
	 * @return List<GeneralLedgerCodeDTO>
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getGenralLedgerCodes:")
	public List<GeneralLedgerCodeDTO> getGenralLedgerCodes(String orgId) {
		return generalLedgerCodeRepository.findAllGeneralLedgerCodeDTO(orgId);
	}

	/**
	 * This method is to retrieve all the tax service code
	 * from TaxClassificationMaster table
	 * 
	 * @return List<TaxClassificationMasterDTO>
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getTaxServiceCode:")
	public List<TaxClassificationMasterDTO> getTaxServiceCode() {
		return taxClassificationMasterRepository.findAll();
	}

	/**
	 * This method is to retrieve all the rate plans associated to
	 * organizationid from RatePlanDTO table
	 * 
	 * @return List<RatePlanDTO>
	 */
	@Cacheable(cacheNames = CacheConstants.SERVICE_CACHE + ":AdminData:getRatePlans:")
	public List<RatePlanDTO> getRatePlans(String orgId) {
		return ratePlanRepository.retrieveRatePlans(orgId);
	}

	/**
	 * This method is to retrieve all information
	 * about a product offering
	 * from ProductOffering table
	 * 
	 * @param orgId , productOfferingId
	 * @return List<ProductOfferingDTO>
	 */
	public ProductOfferingDTO getProductOfferingInfo(String orgId, Long productOfferingId) {
		ProductOfferingDTO productOfferingDTO = new ProductOfferingDTO();
		List<ChargeDTO> allChargeDTO = getAllChargeDTO(orgId, productOfferingId);
		
		ProductOfferingRatePlanDTO productOfferingRatePlanDTO = getProductOfferingRatePlan(orgId, productOfferingId);

		MarketAreaProductOfferingDTO marketAreaProductOfferingDTO = getMarketAreaProductOffering(orgId,
				productOfferingId);
		
		List<ProductWithSpecialEndPointDTO> productWithSpecialEndPointDTOs = getProductWithSpecialEndPointDTOs(
				productOfferingId);
		
		productOfferingDTO = productOfferingRepository.findProductOffering(orgId, productOfferingId);

		productOfferingDTO.setChargeDTOs(allChargeDTO);
		productOfferingDTO.setProductOfferingRatePlanDTO(productOfferingRatePlanDTO);
		productOfferingDTO.setMarketAreaProductOfferingDTO(marketAreaProductOfferingDTO);
		productOfferingDTO.setProductWithSpecialEndPointDTOs(productWithSpecialEndPointDTOs);
		productOfferingDTO.setProductOfferingId(null);
		return productOfferingDTO;

	}

	private ProductOfferingRatePlanDTO getProductOfferingRatePlan(String orgId, Long productOfferingId) {
		ProductOfferingRatePlanDTO productOfferingRatePlanDTO = productOfferingRatePlanRepository.findProductOfferingRatePlan(orgId,productOfferingId);
		if(productOfferingRatePlanDTO != null) {
			String productOfferingDescription = ratePlanRepository.getDescriptionForRatePlanId(productOfferingRatePlanDTO.getProductOfferingRatePlanPK().getRatePlanId()).getDescription();
			productOfferingRatePlanDTO.setDescription(productOfferingDescription);
		}
		populateProductOfferingRatePlanPK(productOfferingRatePlanDTO);
		return productOfferingRatePlanDTO;
	}
	
	private void populateProductOfferingRatePlanPK(ProductOfferingRatePlanDTO productOfferingRatePlanDTO) {
		if(productOfferingRatePlanDTO != null) {
			ProductOfferingRatePlanPK productOfferingRatePlanPK = productOfferingRatePlanDTO.getProductOfferingRatePlanPK();
			productOfferingRatePlanDTO.setOrganizationId(productOfferingRatePlanPK.getOrganizationId());
			productOfferingRatePlanDTO.setRatePlanId(productOfferingRatePlanPK.getRatePlanId());
		}
	}
	
	private MarketAreaProductOfferingDTO getMarketAreaProductOffering(String orgId, Long productOfferingId) {
		MarketAreaProductOfferingDTO marketAreaProductOfferingDTO = marketAreaProductOfferingRepository.findMarketAreaProductOffering(orgId, productOfferingId);
		populateMarketAreaProductOfferingPK(marketAreaProductOfferingDTO);
		return marketAreaProductOfferingDTO;
	}
	
	private void populateMarketAreaProductOfferingPK(MarketAreaProductOfferingDTO marketAreaProductOfferingDTO) {
		if(marketAreaProductOfferingDTO != null) {
			MarketAreaProductOfferingPK marketAreaProductOfferingPK = marketAreaProductOfferingDTO.getMarketAreaProductOfferingPK();
			marketAreaProductOfferingDTO.setMarketAreaId(marketAreaProductOfferingPK.getMarketAreaId());
		}
	}
	
	private List<ProductWithSpecialEndPointDTO> getProductWithSpecialEndPointDTOs(Long productOfferingId) {
		List<ProductWithSpecialEndPointDTO> productWithSpecialEndPointDTOs = productWithSpecialEndPointRepository.findProductWithSpecialEndPoint(productOfferingId);
		populateProductWithSpecialEndPointPK(productWithSpecialEndPointDTOs);
		return productWithSpecialEndPointDTOs;
	}
	
	private void populateProductWithSpecialEndPointPK(List<ProductWithSpecialEndPointDTO> productWithSpecialEndPointDTOs) {
		if(productWithSpecialEndPointDTOs != null && !productWithSpecialEndPointDTOs.isEmpty()) {
			Iterator<ProductWithSpecialEndPointDTO> productWithSpecialEndPointDTOsItor = productWithSpecialEndPointDTOs.iterator();
			while(productWithSpecialEndPointDTOsItor.hasNext()) {
				ProductWithSpecialEndPointDTO productWithSpecialEndPointDTO = productWithSpecialEndPointDTOsItor.next();
				ProductWithSpecialEndPointPK productWithSpecialEndPointPK = productWithSpecialEndPointDTO.getProductWithSpecialEndPointPK();
				productWithSpecialEndPointDTO.setSpecialEndPointTypeCode(productWithSpecialEndPointPK.getSpecialEndPointTypeCode());
			}
		}
	}

	private List<ChargeDTO> getAllChargeDTO(String orgId, Long productOfferingId) {
		List<ChargeDTO> allChargeDTO = new ArrayList<ChargeDTO>();
		List<ProductOfferingChargeDTO> productOfferingChargeDTO = productOfferingChargeRepository.findAllByOrgIdAndproductOfferingId(orgId,productOfferingId);

		if(productOfferingChargeDTO != null && productOfferingChargeDTO.size() > 0) {
			for(ProductOfferingChargeDTO poc:productOfferingChargeDTO){
				ChargeDTO chargeDTO = chargeRepository.findChargeByChargeId(poc.getChargeId());
				if(chargeDTO !=null) {
					chargeDTO.setBusinessUnitChargeDTO(businessUnitChargeRepository.findBusUnitChargeByChargeId(poc.getChargeId()));
					populateChargeStructureQuantityDTO(chargeDTO, 
							chargeStructureQuantityRepository.findChargeStructureQuantityByChargeId(poc.getChargeId()));
					chargeDTO.setProductOfferingChargeDTO(poc);
					allChargeDTO.add(chargeDTO);
				}
			}
		}
		return allChargeDTO;
	}
	
	private void populateChargeStructureQuantityDTO(ChargeDTO chargeDTO,
			List<ChargeStructureQuantityDTO> allChargeStructureQuantityDTO) {
		Iterator<ChargeStructureQuantityDTO> chargeStructureQuantityDTOItor = allChargeStructureQuantityDTO.iterator();
		
		ChargeStructureQuantityDTO intialChargeStructureQuantityDTO = null;
		while(chargeStructureQuantityDTOItor.hasNext()) {
			ChargeStructureQuantityDTO chargeStructureQuantityDTO =  chargeStructureQuantityDTOItor.next();
			populateChargeStructurePK(chargeStructureQuantityDTO);
			if(allChargeStructureQuantityDTO.size() == 1) {
				chargeDTO.setInitialChargeStructureQuantityDTO(chargeStructureQuantityDTO);
			}else if(intialChargeStructureQuantityDTO != null) {
				populateChargeStructureQuantityDTO(chargeDTO, intialChargeStructureQuantityDTO, chargeStructureQuantityDTO);
			}else {
				intialChargeStructureQuantityDTO = chargeStructureQuantityDTO;
			}
		}
	}

	private void populateChargeStructurePK(ChargeStructureQuantityDTO chargeStructureQuantityDTO) {
		ChargeStructureQuantityPK chargeStructureQuantityPK = chargeStructureQuantityDTO.getChargeStructureQuantityPK();
		if(chargeStructureQuantityPK != null) {
			chargeStructureQuantityDTO.setOrganizationId(chargeStructureQuantityPK.getOrganizationId());
			chargeStructureQuantityDTO.setQuantity(chargeStructureQuantityPK.getQuantity());
		}
	}

	private void populateChargeStructureQuantityDTO(ChargeDTO chargeDTO,
			ChargeStructureQuantityDTO intialChargeStructureQuantityDTO,
			ChargeStructureQuantityDTO chargeStructureQuantityDTO) {
		if(isInitialQuantityLesser(intialChargeStructureQuantityDTO, chargeStructureQuantityDTO)) {
			chargeDTO.setInitialChargeStructureQuantityDTO(intialChargeStructureQuantityDTO);
			chargeDTO.setFinalChargeStructureQuantityDTO(chargeStructureQuantityDTO);
		}else {
			chargeDTO.setInitialChargeStructureQuantityDTO(chargeStructureQuantityDTO);
			chargeDTO.setFinalChargeStructureQuantityDTO(intialChargeStructureQuantityDTO);
		}
	}

	private boolean isInitialQuantityLesser(ChargeStructureQuantityDTO intialChargeStructureQuantityDTO, 
			ChargeStructureQuantityDTO chargeStructureQuantityDTO) {
		return intialChargeStructureQuantityDTO.getQuantity() < chargeStructureQuantityDTO.getQuantity();
	}

	/**
	 * This method is to retrieve all the special endpoint
	 * type from the SpecialEndPointType table
	 * 
	 * @return List<SpecialEndPointTypeDTO>
	 */
	public List<SpecialEndPointTypeDTO> getSpecialEndPointTypes() {
		return specialEndPointTypeRepository.findAll();
	}
}