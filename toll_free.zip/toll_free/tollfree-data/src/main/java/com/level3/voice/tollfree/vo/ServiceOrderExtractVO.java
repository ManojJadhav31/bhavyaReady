package com.level3.voice.tollfree.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.level3.voice.tollfree.persist.dto.ServiceOrderExtractDTO;

/**
 * The VO object is to capture all the details needed for the SES and UP calls
 * called from Scheduler
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class ServiceOrderExtractVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Date orderDate;
	private String serviceLocationId;
	private List<String> chargeCodes;
	private ServiceOrderExtractDTO serviceOrderExtract;

	/**
	 * @return the orderDate
	 */
	public Date getOrderDate() {
		return orderDate;
	}

	/**
	 * @param orderDate
	 *            the orderDate to set
	 */
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	/**
	 * @return the serviceLocationId
	 */
	public String getServiceLocationId() {
		return serviceLocationId;
	}

	/**
	 * @param serviceLocationId
	 *            the serviceLocationId to set
	 */
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}

	/**
	 * @return the chargeCodes
	 */
	public List<String> getChargeCodes() {
		return chargeCodes;
	}

	/**
	 * @param chargeCodes
	 *            the chargeCodes to set
	 */
	public void setChargeCodes(List<String> chargeCodes) {
		this.chargeCodes = chargeCodes;
	}

	/**
	 * @return the serviceOrderExtract
	 */
	public ServiceOrderExtractDTO getServiceOrderExtract() {
		return serviceOrderExtract;
	}

	/**
	 * @param serviceOrderExtract
	 *            the serviceOrderExtract to set
	 */
	public void setServiceOrderExtract(ServiceOrderExtractDTO serviceOrderExtract) {
		this.serviceOrderExtract = serviceOrderExtract;
	}

}
