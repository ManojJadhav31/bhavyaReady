package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class BillingAccountNumberVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String accountNumber;
	private String accountName;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	
}

