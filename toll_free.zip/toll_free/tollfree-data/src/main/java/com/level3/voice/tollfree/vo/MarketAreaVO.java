package com.level3.voice.tollfree.vo;

public class MarketAreaVO {
	private String marketAreaId;
	private String marketAreaName;
	private String description;
	private String areaBegin;
	private String areaEnd;
	private String Status;
	
	
	public String getMarketAreaId() {
		return marketAreaId;
	}
	public void setMarketAreaId(String marketAreaId) {
		this.marketAreaId = marketAreaId;
	}
	public String getMarketAreaName() {
		return marketAreaName;
	}
	public void setMarketAreaName(String marketAreaName) {
		this.marketAreaName = marketAreaName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAreaBegin() {
		return areaBegin;
	}
	public void setAreaBegin(String areaBegin) {
		this.areaBegin = areaBegin;
	}
	public String getAreaEnd() {
		return areaEnd;
	}
	public void setAreaEnd(String areaEnd) {
		this.areaEnd = areaEnd;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
	
	

}
