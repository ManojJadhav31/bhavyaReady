package com.level3.voice.tollfree.vo;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class VoiceServiceVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String country2LetterIsoCode;
	private String countryCode;
	private String customerCommitDate;
	private String customerRequestDate;
	private String installDate;
	private String disconnectDate;
	private String locationServiceId;
	private String locationparentServiceId;
	private String locationServiceIdType;
	private String locationparentServiceIdType;
	private String voiceServiceId;
	private String voiceparentServiceId;
	private String voiceServiceType;
	private String orderDate;
	private String parentOrderId;
	private String productId;
	private String parentServiceId;
	private String subscriberLineOrderId;
	private String telephoneNumber;

	private List<FeaturesVO> productFeatures;

	private String tollFreeYn;

	/** default constructor */
	public VoiceServiceVO() {

	}

	/**
	 * @return the country2LetterIsoCode
	 */
	public String getCountry2LetterIsoCode() {
		return country2LetterIsoCode;
	}

	/**
	 * @param country2LetterIsoCode
	 *            the country2LetterIsoCode to set
	 */
	public void setCountry2LetterIsoCode(String country2LetterIsoCode) {
		this.country2LetterIsoCode = country2LetterIsoCode;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode
	 *            the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the customerCommitDate
	 */
	public String getCustomerCommitDate() {
		return customerCommitDate;
	}

	/**
	 * @param customerCommitDate
	 *            the customerCommitDate to set
	 */
	public void setCustomerCommitDate(String customerCommitDate) {
		this.customerCommitDate = customerCommitDate;
	}

	/**
	 * @return the customerRequestDate
	 */
	public String getCustomerRequestDate() {
		return customerRequestDate;
	}

	/**
	 * @param customerRequestDate
	 *            the customerRequestDate to set
	 */
	public void setCustomerRequestDate(String customerRequestDate) {
		this.customerRequestDate = customerRequestDate;
	}

	/**
	 * @return the installDate
	 */
	public String getInstallDate() {
		return installDate;
	}

	/**
	 * @param installDate
	 *            the installDate to set
	 */
	public void setInstallDate(String installDate) {
		this.installDate = installDate;
	}

	/**
	 * @return the disconnectDate
	 */
	public String getDisconnectDate() {
		return disconnectDate;
	}

	/**
	 * @param disconnectDate
	 *            the disconnectDate to set
	 */
	public void setDisconnectDate(String disconnectDate) {
		this.disconnectDate = disconnectDate;
	}

	/**
	 * @return the locationServiceId
	 */
	public String getLocationServiceId() {
		return locationServiceId;
	}

	/**
	 * @param locationServiceId
	 *            the locationServiceId to set
	 */
	public void setLocationServiceId(String locationServiceId) {
		this.locationServiceId = locationServiceId;
	}

	/**
	 * @return the locationparentServiceId
	 */
	public String getLocationparentServiceId() {
		return locationparentServiceId;
	}

	/**
	 * @param locationparentServiceId
	 *            the locationparentServiceId to set
	 */
	public void setLocationparentServiceId(String locationparentServiceId) {
		this.locationparentServiceId = locationparentServiceId;
	}

	/**
	 * @return the locationServiceIdType
	 */
	public String getLocationServiceIdType() {
		return locationServiceIdType;
	}

	/**
	 * @param locationServiceIdType
	 *            the locationServiceIdType to set
	 */
	public void setLocationServiceIdType(String locationServiceIdType) {
		this.locationServiceIdType = locationServiceIdType;
	}

	/**
	 * @return the locationparentServiceIdType
	 */
	public String getLocationparentServiceIdType() {
		return locationparentServiceIdType;
	}

	/**
	 * @param locationparentServiceIdType
	 *            the locationparentServiceIdType to set
	 */
	public void setLocationparentServiceIdType(String locationparentServiceIdType) {
		this.locationparentServiceIdType = locationparentServiceIdType;
	}

	/**
	 * @return the voiceServiceId
	 */
	public String getVoiceServiceId() {
		return voiceServiceId;
	}

	/**
	 * @param voiceServiceId
	 *            the voiceServiceId to set
	 */
	public void setVoiceServiceId(String voiceServiceId) {
		this.voiceServiceId = voiceServiceId;
	}

	/**
	 * @return the voiceparentServiceId
	 */
	public String getVoiceparentServiceId() {
		return voiceparentServiceId;
	}

	/**
	 * @param voiceparentServiceId
	 *            the voiceparentServiceId to set
	 */
	public void setVoiceparentServiceId(String voiceparentServiceId) {
		this.voiceparentServiceId = voiceparentServiceId;
	}

	/**
	 * @return the voiceServiceType
	 */
	public String getVoiceServiceType() {
		return voiceServiceType;
	}

	/**
	 * @param voiceServiceType
	 *            the voiceServiceType to set
	 */
	public void setVoiceServiceType(String voiceServiceType) {
		this.voiceServiceType = voiceServiceType;
	}

	/**
	 * @return the orderDate
	 */
	public String getOrderDate() {
		return orderDate;
	}

	/**
	 * @param orderDate
	 *            the orderDate to set
	 */
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	/**
	 * @return the parentOrderId
	 */
	public String getParentOrderId() {
		return parentOrderId;
	}

	/**
	 * @param parentOrderId
	 *            the parentOrderId to set
	 */
	public void setParentOrderId(String parentOrderId) {
		this.parentOrderId = parentOrderId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the parentServiceId
	 */
	public String getParentServiceId() {
		return parentServiceId;
	}

	/**
	 * @param parentServiceId
	 *            the parentServiceId to set
	 */
	public void setParentServiceId(String parentServiceId) {
		this.parentServiceId = parentServiceId;
	}

	/**
	 * @return the subscriberLineOrderId
	 */
	public String getSubscriberLineOrderId() {
		return subscriberLineOrderId;
	}

	/**
	 * @param subscriberLineOrderId
	 *            the subscriberLineOrderId to set
	 */
	public void setSubscriberLineOrderId(String subscriberLineOrderId) {
		this.subscriberLineOrderId = subscriberLineOrderId;
	}

	/**
	 * @return the telephoneNumber
	 */
	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	/**
	 * @param telephoneNumber
	 *            the telephoneNumber to set
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	/**
	 * @return the productFeatures
	 */
	public List<FeaturesVO> getProductFeatures() {
		return productFeatures;
	}

	/**
	 * @param productFeatures
	 *            the productFeatures to set
	 */
	public void setProductFeatures(List<FeaturesVO> productFeatures) {
		this.productFeatures = productFeatures;
	}

	/**
	 * @return the tollFreeYn
	 */
	public String getTollFreeYn() {
		return tollFreeYn;
	}

	/**
	 * @param tollFreeYn
	 *            the tollFreeYn to set
	 */
	public void setTollFreeYn(String tollFreeYn) {
		this.tollFreeYn = tollFreeYn;
	}

}
