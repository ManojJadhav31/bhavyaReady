package com.level3.voice.tollfree.security;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * The annotation to ignore any validation
 * Every REST method that does not need authorization, 
 * should be annotated explicitly with this annotation to avoid NON-AUTHORIZATION 
 * 
 * @author <a href="mailto:Manjunatha.d@centurylink.com">Manjunatha D</a>
 *
 */
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface BypassSecurity {

}
