package com.level3.voice.tollfree.service;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Home redirection to swagger api documentation
 * 
 * @author <a href="mailto:Keerthi.Selvaraj@centurylink.com">Keerthi Selvaraj</a>
 */
@Controller
public class HomeController {
    @RequestMapping(value = "/")
    public String index() {
        return "redirect:swagger-ui.html";
    }
}
