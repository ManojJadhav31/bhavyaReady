package com.level3.voice.tollfree.vo;

import java.io.Serializable;

/**
 * This object is to set the account number and crc 
 * retrieve from sandstone
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class CrcVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String crc;

	public String getCrc() {
		return crc;
	}

	public void setCrc(String crc) {
		this.crc = crc;
	}

}
