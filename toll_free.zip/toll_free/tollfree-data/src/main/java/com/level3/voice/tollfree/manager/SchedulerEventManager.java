package com.level3.voice.tollfree.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import javax.persistence.NoResultException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.common.util.StringUtils;
import com.level3.voice.tollfree.persist.dto.ProdOfferingLocAsscQueueDTO;
import com.level3.voice.tollfree.persist.dto.ServiceOrderExtractDTO;
import com.level3.voice.tollfree.persist.repository.ProdOfferingLocAsscQueueRepository;
import com.level3.voice.tollfree.persist.repository.ServiceOrderExtractRepository;
import com.level3.voice.tollfree.persist.repository.TollFreeDataRepository;
import com.level3.voice.tollfree.vo.AccountDetailsVO;
import com.level3.voice.tollfree.vo.ServiceOrderExtractVO;

/**
 * This is the manager class to hold the business logic for the calls from the
 * scheduler to retrieve or update the ProdOfferingLocAsscQueue record
 * 
 * @author <a href="mailto:Nnupur.Krishnaa@centurylink.com">Nnupur.Krishnaa</a>
 *
 */
@Component
public class SchedulerEventManager {

	@Autowired
	ProdOfferingLocAsscQueueRepository prodOfferingLocAsscQueueRepository;

	@Autowired
	ServiceOrderExtractRepository serviceOrderExtractRepository;

	@Autowired
	TollFreeDataRepository tollFreeDataRepository;

	private static final Logger log = LoggerFactory.getLogger(SchedulerEventManager.class);

	/**
	 * This method is to retrieve all the ProdOfferingLocAsscQueue records where
	 * dequeue value is null
	 * 
	 * @return
	 */
	@Audited
	public List<ProdOfferingLocAsscQueueDTO> getDatafromLocQueue() {
		return prodOfferingLocAsscQueueRepository.findDataWithNoDequeue();
	}

	/**
	 * This method is used to update the dequeue date against the
	 * ProdOfferingLocAsscQueue which have successfully published events
	 * 
	 * @param prodOfferingLocAsscQueueDTO
	 * @return
	 */
	@Audited
	public Level3Response persistDequeueDate(ProdOfferingLocAsscQueueDTO prodOfferingLocAsscQueueDTO) {
		prodOfferingLocAsscQueueRepository.save(prodOfferingLocAsscQueueDTO);
		return Level3Response.OK_200;
	}

	@SuppressWarnings("unused")
	private List<ProdOfferingLocAsscQueueDTO> getStuvbDTOs() {

		List<ProdOfferingLocAsscQueueDTO> prodOfferingLocAsscQueueDTO = new ArrayList<ProdOfferingLocAsscQueueDTO>();
		ProdOfferingLocAsscQueueDTO newprodOfferingLocAsscQueueDTO = new ProdOfferingLocAsscQueueDTO();
		newprodOfferingLocAsscQueueDTO.setProdLocationQueueId(Long.parseLong("2000"));
		newprodOfferingLocAsscQueueDTO.setServiceLocationId("LEVEL3IT");
		newprodOfferingLocAsscQueueDTO.setCustomerId("00001157");
		newprodOfferingLocAsscQueueDTO.setControlGroupId("LEVEL3IT");
		newprodOfferingLocAsscQueueDTO.setEventType(Long.parseLong("2"));
		newprodOfferingLocAsscQueueDTO.setProductOfferingId(Long.parseLong("7171"));

		prodOfferingLocAsscQueueDTO.add(newprodOfferingLocAsscQueueDTO);

		newprodOfferingLocAsscQueueDTO = new ProdOfferingLocAsscQueueDTO();

		newprodOfferingLocAsscQueueDTO.setProdLocationQueueId(Long.parseLong("2001"));
		newprodOfferingLocAsscQueueDTO.setServiceLocationId("LEVEL3ITD");
		newprodOfferingLocAsscQueueDTO.setCustomerId("00001152");
		newprodOfferingLocAsscQueueDTO.setControlGroupId(null);
		newprodOfferingLocAsscQueueDTO.setEventType(Long.parseLong("1"));
		newprodOfferingLocAsscQueueDTO.setProductOfferingId(Long.parseLong("7172"));

		prodOfferingLocAsscQueueDTO.add(newprodOfferingLocAsscQueueDTO);

		return prodOfferingLocAsscQueueDTO;
	}

	/**
	 * Method to retrieve AccountDetails using ServiceLocationId
	 * 
	 * @param productOfferingId
	 * 
	 * @param productOfferingId
	 * @param organizationId
	 * @param status
	 * @return rateplanId
	 */
	public AccountDetailsVO getAccountDetails(String serviceLocationId) {
		String accountNumber = "";
		String billingAccountNumber = "";
		AccountDetailsVO accountDetailsVO = new AccountDetailsVO();
		try {
			accountNumber = tollFreeDataRepository.getAccountDetails(serviceLocationId);
		} catch (NoResultException e) {
			log.error("No data retrieved @getCustomerDetails from the input: serviceLocationId: " + serviceLocationId);
		}
		accountDetailsVO.setAccountNumber(!StringUtils.isEmpty(accountNumber) ? accountNumber.trim() : "");

		if (StringUtils.isEmpty(accountNumber)) {
			return accountDetailsVO;
		}

		try {
			billingAccountNumber = (String) tollFreeDataRepository.getBillingAccountNumber(accountNumber,
					serviceLocationId);
		} catch (NoResultException e) {
			log.error("No data retrieved @getCustomerDetails from the inputs: accoutNumber: " + accountNumber
					+ " serviceLocationId: " + serviceLocationId);
		}
		accountDetailsVO
				.setBillingAccountNumber(!StringUtils.isEmpty(billingAccountNumber) ? billingAccountNumber.trim() : "");

		return accountDetailsVO;
	}

	/**
	 * This method is to get the product group code for a product offering id
	 * 
	 * @param productOfferingId
	 * @return
	 */
	public String getProductGroupCode(String productOfferingId) {
		String productGroupCode = "";
		try {
			productGroupCode = tollFreeDataRepository.getProductGroupCode(productOfferingId);
		} catch (NoResultException e) {
			log.error("No data retrieved @getProductGroupCode from the input: productOfferingId: " + productOfferingId);
		}
		return !StringUtils.isEmpty(productGroupCode) ? productGroupCode.trim() : "";
	}

	/**
	 * This method is to retrieve all the service extract data 
	 * which has is retrieved as N
	 * 
	 * @return
	 */
	public List<ServiceOrderExtractVO> retrieveTollfreeData() {
		List<ServiceOrderExtractVO> serviceOrderExtractVOs = new ArrayList<>();
		List<ServiceOrderExtractDTO> serviceOrderExtractDTOs = serviceOrderExtractRepository.retrieveServiceExtract();

		Iterator<ServiceOrderExtractDTO> serviceOrderExtractDTOsItor = serviceOrderExtractDTOs.iterator();
		while (serviceOrderExtractDTOsItor.hasNext()) {
			ServiceOrderExtractDTO serviceOrderExtractDTO = serviceOrderExtractDTOsItor.next();
			ServiceOrderExtractVO serviceOrderExtractVO = new ServiceOrderExtractVO();
			Object[] orderDetails = (Object[])tollFreeDataRepository.getOrderDetails(serviceOrderExtractDTO.getOrderId());
			serviceOrderExtractVO.setOrderDate((Date)orderDetails[0]);
			serviceOrderExtractVO.setServiceLocationId(String.valueOf(orderDetails[1]));
			serviceOrderExtractVO.setChargeCodes(getChargeCode(serviceOrderExtractDTO.getOrderId()));
			serviceOrderExtractVO.setServiceOrderExtract(serviceOrderExtractDTO);
			serviceOrderExtractVOs.add(serviceOrderExtractVO);
		}

		return serviceOrderExtractVOs;
	}

	/**
	 * Get charge code from DB and remove duplicates
	 * and send only the list of charge code back to the caller
	 * 
	 * @param orderId
	 * @return
	 */
	private List<String> getChargeCode(String orderId) {
		List<Object> objects = tollFreeDataRepository.getChargeCode(orderId);
		List<String> chargeCodes = new ArrayList<>();
		for (Object object : objects) {
			String value = Objects.toString(object, null);
			if (!chargeCodes.contains(value)) {
				chargeCodes.add(value);
			}
		}
		return chargeCodes;
	}

	/**
	 * Persist service order extract with the changes sent from the caller
	 * 
	 * @param serviceOrderExtractDTO
	 * @return
	 */
	public Level3Response persistServiceExtract(ServiceOrderExtractDTO serviceOrderExtractDTO) {
		serviceOrderExtractRepository.save(serviceOrderExtractDTO);
		return Level3Response.OK_200;
	}

}
