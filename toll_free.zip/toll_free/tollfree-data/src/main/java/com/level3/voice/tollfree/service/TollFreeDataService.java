package com.level3.voice.tollfree.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.level3.voice.common.audit.Audited;
import com.level3.voice.common.exception.SLDBException;
import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.manager.TollFreeDataServiceManager;
import com.level3.voice.tollfree.persist.dto.ServiceAddressDTO;
import com.level3.voice.tollfree.persist.dto.ServiceLocDTO;
import com.level3.voice.tollfree.persist.vo.BillingAccountNumberVO;
import com.level3.voice.tollfree.persist.vo.ContactsVO;
import com.level3.voice.tollfree.persist.vo.CountryDetailsVO;
import com.level3.voice.tollfree.persist.vo.CustomerInfoVO;
import com.level3.voice.tollfree.persist.vo.ProductDiscPlanVo;
import com.level3.voice.tollfree.persist.vo.ProductSummaryVO;
import com.level3.voice.tollfree.persist.vo.VolumeDiscPlanVO;
import com.level3.voice.tollfree.vo.AddressVO;
import com.level3.voice.tollfree.vo.CrcVO;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.MarketAreaVO;
import com.level3.voice.tollfree.vo.OrderAdditionalDetailsVO;
import com.level3.voice.tollfree.vo.PayPhoneBillingVO;
import com.level3.voice.tollfree.vo.ResponseVO;
import com.level3.voice.tollfree.vo.ServiceLocationInformationVO;
import com.level3.voice.tollfree.vo.VoiceServiceSearchVO;

/**
 * REST Service to access network strategies Sandstone DB
 * 
 * @author <a href="mailto:Keerthi.Selvaraj@centurylink.com">Keerthi selvaraj
 *         </a>
 */
@RestController
@RequestMapping("/ServiceDelivery/v1/Voice/")
public class TollFreeDataService {

	private static final Logger LOG = Logger.getLogger(TollFreeDataService.class);

	@Autowired
	private TollFreeDataServiceManager tollFreeDataServiceManager;

	/**
	 * Method to get all BAN related to customer id and organization id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return List of CustomerVO
	 */
	@RequestMapping(path = "/account/{organizationId}/{customerId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<CustomerVO> getAllAccountInfo(@PathVariable String organizationId, @PathVariable String customerId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getAllAccountInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<CustomerVO> customerVOs = null;
		try {
			customerVOs = tollFreeDataServiceManager.getAllAccountInfo(organizationId, customerId);
		} catch (Exception e) {
			LOG.error("@getAllAccountInfo: Exception processing getAllAccountInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customerVOs;
	}

	/**
	 * Method to retrieve CIC associated to organization id customer id and service
	 * location id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param servLocId
	 * @return array of objects where object is [CIC,preference]
	 */
	@RequestMapping(path = "/cic/{organizationId}/{customerId}/{servLocId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getAllCustomerCIC(@PathVariable String organizationId, @PathVariable String customerId,
			@PathVariable String servLocId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId) || StringUtils.isEmpty(servLocId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getAllCustomerCIC: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}

		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getAllCustomerCIC(organizationId, customerId, servLocId);
		} catch (Exception e) {
			LOG.error("@getAllCustomerCIC: Exception processing getAllCustomerCIC", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customerVO;
	}

	/**
	 * Method to retrieve all the service locations associated to a organization id
	 * customer id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return array of objects where object is [Service Location ID,Service
	 *         Location Name]
	 */
	@RequestMapping(path = "/servicelocation/{organizationId}/{customerId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getAllServiceLocation(@PathVariable String organizationId, @PathVariable String customerId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getAllServiceLocation: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getAllServiceLocation(organizationId, customerId);
		} catch (Exception e) {
			LOG.error("@getAllServiceLocation: Exception processing getAllServiceLocation", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customerVO;
	}

	/**
	 * Method to retrieve all the product information related to the organization
	 * id, customer id, service location id and detail type
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param serviceLocationId
	 * @param detailType
	 * @return array of objects where object is [ProductOfferingId
	 *         ,ProductOfferingDescription]
	 */
	@RequestMapping(path = "/product/{organizationId}/{customerId}/{servLocId}/{detailType}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getAllProductInfo(@PathVariable String organizationId, @PathVariable String customerId,
			@PathVariable String servLocId, @PathVariable String detailType) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId) || StringUtils.isEmpty(servLocId)
				|| StringUtils.isEmpty(detailType)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getAllAccountInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getAllProductInfo(organizationId, customerId, servLocId,
					detailType);
		} catch (Exception e) {
			LOG.error("@getAllProductInfo: Exception processing getAllProductInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}

		return customerVO;

	}

	/**
	 * API Method to retrieve all the code table values for customer id and org id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return array of objects where object is [TableId, TableName, CodeDigits ]
	 */
	@RequestMapping(path = "/codetable/{organizationId}/{customerId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getAllCodeTable(@PathVariable String organizationId, @PathVariable String customerId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getAllCodeTable: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;
		try {
			organizationId = organizationId.trim();
			customerId = customerId.trim();
			customerVO = tollFreeDataServiceManager.getAllCodeTable(organizationId, customerId);
		} catch (Exception e) {
			LOG.error("@getAllCodeTable: Exception processing getAllCodeTable", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customerVO;
	}

	/**
	 * API Method to retrieve the rate plan id for productofferingid and status
	 * 
	 * @param productOfferingId
	 * @param organizationId
	 * @param status
	 * @return RatePlanId
	 */
	@RequestMapping(path = "/orderadditionaldetails/{organizationId}/{productOfferingId}/{status}/{accountNumber}/{serviceLocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	public OrderAdditionalDetailsVO getOrderAdditionalDetails(@PathVariable String productOfferingId,
			@PathVariable String organizationId, @PathVariable String status, @PathVariable String accountNumber,
			@PathVariable String serviceLocationId) {
		if (StringUtils.isEmpty(productOfferingId) || StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(status)
				|| StringUtils.isEmpty(accountNumber) || StringUtils.isEmpty(serviceLocationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getOrderAdditionalDetails: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		OrderAdditionalDetailsVO ratePlanVO = null;
		try {
			productOfferingId = productOfferingId.trim();
			organizationId = organizationId.trim();
			status = status.trim();
			ratePlanVO = tollFreeDataServiceManager.getOrderAdditionalDetails(productOfferingId, organizationId, status,
					accountNumber, serviceLocationId);
		} catch (Exception e) {
			LOG.error("@getOrderAdditionalDetails: Exception processing getOrderAdditionalDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return ratePlanVO;
	}

	/**
	 * API method to retrieve customer info for organization id and customer id
	 * 
	 * @param organizationId
	 * @param custId
	 * @return Customer Info
	 */
	@RequestMapping(path = "/customer/{organizationId}/{custId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getCustomerInfo(@PathVariable String organizationId, @PathVariable String custId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(custId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getAllCustomerInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getCustomers(organizationId, custId);
		} catch (Exception e) {
			LOG.error("@getAllCustomerInfo: Exception processing getAllCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customerVO;
	}

	/**
	 * API method to validate provided TN has a valid NPA NXX value by checking
	 * against NPANXX Table of NS
	 * 
	 * @param tn
	 * @return ResponseVO
	 */
	@RequestMapping(path = "/validateNPNXX/{tn}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public ResponseVO validateNPANXX(@PathVariable String tn) {
		if (StringUtils.isEmpty(tn)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("validateNPANXX: Invalid input passed. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		try {
			return tollFreeDataServiceManager.validateNPANXX(tn);
		} catch (Exception e) {
			LOG.error("@validateNPANXX: Exception processing validateNPANXX", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
	}

	/**
	 * API method to retrieve customer id and customer name using busOrg
	 * 
	 * @param busOrg
	 * @return getBusOrgInfo
	 */
	@RequestMapping(path = "/busorg/{busOrg}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getBusOrgInfo(@PathVariable String busOrg) {
		if (StringUtils.isEmpty(busOrg)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getBusOrgInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getBusOrg(busOrg);
		} catch (Exception e) {
			LOG.error("@getBusOrgInfo: Exception processing getBusOrgInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		return customerVO;
	}

	/**
	 * API method to retrieve FeatureOfferingId, Description
	 * 
	 * @param organizationId
	 * @param controlGroupId
	 * @param productOfferingId
	 * @param oneStopFeatureInd
	 * @return featuresList
	 */
	@RequestMapping(path = "/productfeatures/{organizationId}/{customerId}/{serviceLocationId}/{productOfferingId}/{isFromOneStop}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getAllProdFeatures(@PathVariable String organizationId, @PathVariable String customerId,
			@PathVariable String serviceLocationId, @PathVariable String productOfferingId,
			@PathVariable String isFromOneStop) {
		LOG.info("organizationId:" + organizationId + "\n customerId:" + customerId + "\n serviceLocationId:"
				+ serviceLocationId + "\n productOfferingId:" + productOfferingId);
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)
				|| StringUtils.isEmpty(serviceLocationId) || StringUtils.isEmpty(productOfferingId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getAllProdFeatures: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;

		try {
			customerVO = tollFreeDataServiceManager.getProdFeatures(organizationId, customerId, serviceLocationId,
					productOfferingId, Boolean.parseBoolean(isFromOneStop));
		} catch (Exception e) {
			LOG.error("Exception processing getFeatures", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		if (customerVO != null && customerVO.getProductFeaturesVOs().isEmpty()) {
			LOG.info("There are no features found for organizationId:" + organizationId + ", customerId:" + customerId
					+ ",serviceLocationId:" + serviceLocationId + ", productOfferingId:" + productOfferingId);
		}
		return customerVO;
	}

	/**
	 * Method to get all BAN related to customer id and organization id and return
	 * filtered data
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return array of objects where object is [Account ID,Account Name]
	 */
	@RequestMapping(path = "/banlocationidinfo/{organizationId}/{customerId}/{detailType}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getBANServLocInfo(@PathVariable String organizationId, @PathVariable String customerId,
			@PathVariable String detailType) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId) || StringUtils.isEmpty(detailType)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getBANServLocInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getBANServLocInfo(organizationId, customerId, detailType);
		} catch (Exception e) {
			LOG.error("@getBANServLocInfo: Exception processing getBANServLocInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customerVO;
	}

	/**
	 * This method is to retrieve service location assocaited to a customer id and
	 * service location id under an organization id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param serviceLocationId
	 * @return
	 */
	@RequestMapping(path = "/location/{organizationId}/{customerId}/{serviceLocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public ServiceAddressDTO getServLocDetails(@PathVariable String organizationId, @PathVariable String customerId,
			@PathVariable String serviceLocationId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)
				|| StringUtils.isEmpty(serviceLocationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getServLocDetails: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		ServiceAddressDTO servLocvO = null;
		try {
			servLocvO = tollFreeDataServiceManager.getServLocDetails(organizationId, customerId, serviceLocationId);
		} catch (Exception e) {
			LOG.error("@getServLocDetails: Exception processing getServLocDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return servLocvO;
	}

	/**
	 * This method is to retrieve billing account details for the customer based on
	 * the accountnumber and service locationid
	 * 
	 * @param accountNumber
	 * @param serviceLocationId
	 * @return
	 */
	@RequestMapping(path = "/crc/{organizationId}/{customerId}/{cic}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CrcVO getCrcDetails(@PathVariable String organizationId, @PathVariable String customerId,
			@PathVariable String cic) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId) || StringUtils.isEmpty(cic)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getCrcDetails: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CrcVO crcVO = null;
		try {
			crcVO = tollFreeDataServiceManager.getCrcDetails(organizationId, customerId, cic);
		} catch (Exception e) {
			LOG.error("@getCrcDetails: Exception processing getCrcDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return crcVO;
	}

	@RequestMapping(path = "/getCustomerName/{custName}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<CustomerVO> getCustomerName(@PathVariable String custName) {
		if (StringUtils.isEmpty(custName)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getCustomerName: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<CustomerVO> customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getCustomerName(custName);
		} catch (Exception e) {
			LOG.error("@getCustomerName: Exception processing getCustomerName", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customerVO;
	}

	/**
	 * This method is to get service location for given params
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param ban
	 * @return
	 */
	@RequestMapping(path = "/serviceLocationIdByBan/{organizationId}/{customerId}/{ban}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getServLocInfoForBAN(@PathVariable String organizationId, @PathVariable String customerId,
			@PathVariable String ban) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getServLocInfoForBAN: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getServLocInfoForBAN(organizationId, customerId, ban);
		} catch (Exception e) {
			LOG.error("@getServLocInfoForBAN: Exception processing getServLocInfoForBAN", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customerVO;
	}

	@RequestMapping(path = "/retrieve/account/{serviceLocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public String getAccountDetails(@PathVariable String serviceLocationId) {
		if (StringUtils.isEmpty(serviceLocationId)
				|| (!StringUtils.isEmpty(serviceLocationId) && serviceLocationId.indexOf("_") == -1)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}

		return tollFreeDataServiceManager.getAccountDetails(serviceLocationId);
	}

	/**
	 * This method is to get Active TN's for given servicelocation
	 * 
	 * @param servicelocation
	 * @param page
	 * @param pageSize
	 * @return VoiceServiceSearchVO
	 */
	@RequestMapping(path = "/voiceService", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public VoiceServiceSearchVO getServLocInfoForTFN(
			@RequestParam(value = "locationServiceId", required = true) String svcLocId,
			@RequestParam(value = "page", required = true) int page,
			@RequestParam(value = "pageSize", required = true) int pageSize) {

		VoiceServiceSearchVO voiceServices = new VoiceServiceSearchVO();

		if (StringUtils.isEmpty(svcLocId) || StringUtils.isEmpty(page) || StringUtils.isEmpty(pageSize)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getServLocInfoForTFN: Invalid. Please have all the required fields");
			LOG.error("@getServLocInfoForTFN: Invalid. Please have all the required fields" + l3Response.toXml());
			return voiceServices;
		}
		try {
			voiceServices = tollFreeDataServiceManager.getTNInventoryServiceId(svcLocId, page, pageSize);
		} catch (Exception e) {
			LOG.error("@getServLocInfoForTFN: Exception processing getServLocInfoForTFN", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return voiceServices;
	}

	/**
	 * API method to retrieve FeatureOfferingId, Description
	 * 
	 * @param organizationId
	 * @param productOfferingId
	 * @return defaultfeaturesList
	 */
	@RequestMapping(path = "/defaultFeatures/{organizationId}/{productOfferingId}/{controlGroupId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getDefaultFeatures(@PathVariable String organizationId, @PathVariable String productOfferingId,
			@PathVariable String controlGroupId) {
		LOG.info("organizationId:" + organizationId + "\n productOfferingId:" + productOfferingId);
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(productOfferingId)
				|| StringUtils.isEmpty(controlGroupId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getDefaultFeatures: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;

		try {
			customerVO = tollFreeDataServiceManager.getdefaultFeatures(organizationId, productOfferingId,
					controlGroupId);
		} catch (Exception e) {
			LOG.error("Exception processing getFeatures", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		if (customerVO != null && customerVO.getProductFeaturesVOs().isEmpty()) {
			LOG.info("There are no features found for organizationId:" + organizationId + ", productOfferingId:"
					+ productOfferingId);
		}
		return customerVO;
	}

	/**
	 * Method to get all customer information for the user associated organization
	 * id
	 * 
	 * @param organizationId
	 * @return array of objects where object is [Customer ID,Customer Name]
	 */
	@RequestMapping(path = "/getCustomerInfo/{organizationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<CustomerInfoVO> getCustomerInfo(@PathVariable String organizationId) {
		if (StringUtils.isEmpty(organizationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getCustomerInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<CustomerInfoVO> customers = null;
		try {
			customers = tollFreeDataServiceManager.getCustomerInfo(organizationId);
		} catch (Exception e) {
			LOG.error("@getCustomerInfo: Exception processing getCustomerInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customers;
	}

	/**
	 * Method to get all account name and account number information for the user
	 * associated Customer ID,servicelocationid
	 * 
	 * @param Customer
	 *            ID,servicelocationid
	 * @return array of objects where object is [Customer ID,servicelocationid]
	 */
	@RequestMapping(path = "/getAccountInfo/{customerid}/{servicelocationid}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<BillingAccountNumberVO> getAccountInfo(@PathVariable String customerid,
			@PathVariable String servicelocationid) {
		if (StringUtils.isEmpty(customerid) || StringUtils.isEmpty(servicelocationid)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getAccountInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<BillingAccountNumberVO> customers = null;
		try {
			customers = tollFreeDataServiceManager.getAccountInfo(customerid, servicelocationid);
		} catch (Exception e) {
			LOG.error("@getAccountInfo: Exception processing getAccountInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customers;
	}

	@RequestMapping(path = "/getStatus/{accountNumber}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<Object> getStatus(@PathVariable String accountNumber) {
		if (StringUtils.isEmpty(accountNumber)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		List<Object> status = null;
		try {
			status = tollFreeDataServiceManager.getStatus(accountNumber);
		} catch (Exception e) {
			LOG.error("@getStatus: Exception processing getStatus", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return status;
	}

	@RequestMapping(path = "/getContacts/{organizationId}/{customerid}/{servicelocationid}/{contactType}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ContactsVO> getContacts(@PathVariable String organizationId, @PathVariable String customerid,
			@PathVariable String servicelocationid, @PathVariable String contactType) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerid)
				|| StringUtils.isEmpty(servicelocationid) || StringUtils.isEmpty(contactType)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		List<ContactsVO> contactsList = null;
		try {
			contactsList = tollFreeDataServiceManager.getContacts(organizationId, customerid, servicelocationid,
					contactType);
		} catch (Exception e) {
			LOG.error("@getContacts: Exception processing getContacts", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return contactsList;
	}

	@RequestMapping(path = "/getCustomerDetails/{customerid}/{serviceLocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ServiceLocationInformationVO> getCustomerDetails(@PathVariable String customerid,
			@PathVariable String serviceLocationId) {
		if (StringUtils.isEmpty(customerid) || StringUtils.isEmpty(serviceLocationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getCustomerDetails: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<ServiceLocationInformationVO> serviceLocationDetail = new ArrayList<ServiceLocationInformationVO>();
		try {
			serviceLocationDetail = tollFreeDataServiceManager.getCustomerDetails(customerid, serviceLocationId);
		} catch (Exception e) {
			LOG.error("@getCustomerDetails: Exception processing getCustomerDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return serviceLocationDetail;
	}

	@RequestMapping(path = "/getCustomerAddress/{customerid}/{servicelocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public AddressVO getCustomerAddress(@PathVariable String customerid, @PathVariable String servicelocationId) {
		if (StringUtils.isEmpty(customerid) || StringUtils.isEmpty(servicelocationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getCustomerAddress: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		AddressVO addressvo = new AddressVO();
		try {
			addressvo = tollFreeDataServiceManager.getAddressDetails(customerid, servicelocationId);
		} catch (Exception e) {
			LOG.error("@getCustomerAddress: Exception processing getCustomerAddress", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return addressvo;

	}

	/**
	 * Method to get all BAN related to customer id and organization id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return List of CustomerVO
	 */
	@RequestMapping(path = "/getProductSummary/{organizationId}/{customerId}/{serviceLocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ProductSummaryVO> getProductSummary(@PathVariable String organizationId,
			@PathVariable String customerId, @PathVariable String serviceLocationId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)
				|| StringUtils.isEmpty(serviceLocationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getProductSummary: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<ProductSummaryVO> productSummary = null;
		try {
			productSummary = tollFreeDataServiceManager.getProductSummary(organizationId, customerId,
					serviceLocationId);
		} catch (Exception e) {
			LOG.error("@getProductSummary: Exception processing getProductSummary", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productSummary;
	}

	@RequestMapping(path = "/getPayPhoneBilling", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<PayPhoneBillingVO> getPayPhoneBilling() {
		List<PayPhoneBillingVO> payPhoneBillingList = new ArrayList<PayPhoneBillingVO>();
		try {
			payPhoneBillingList = tollFreeDataServiceManager.getPayPhoneBilling();

		} catch (Exception e) {
			LOG.error("@getPayPhoneBilling: Exception processing getPayPhoneBilling", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		return payPhoneBillingList;

	}

	@RequestMapping(path = "/getMarketArea", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<MarketAreaVO> getMarketArea() {
		List<MarketAreaVO> marketAreaVoList = new ArrayList<MarketAreaVO>();
		try {
			marketAreaVoList = tollFreeDataServiceManager.getMarketArea();

		} catch (Exception e) {
			LOG.error("@getMarketArea: Exception processing getMarketArea", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}
		return marketAreaVoList;

	}

	/**
	 * Method to get all service Location information for the customerId associated
	 * organization id
	 * 
	 * @param organizationId
	 *            and customerId
	 * @return array of objects of type ServiceLocDTO
	 */
	@RequestMapping(path = "/getServiceLocInfo/{organizationId}/{customerId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ServiceLocDTO> getServiceLocInfo(@PathVariable String organizationId, @PathVariable String customerId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getServiceLocInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<ServiceLocDTO> serviceLocations = null;
		try {
			LOG.debug("the parameter recieved is :" + organizationId + " Customer Id:  " + customerId);
			serviceLocations = tollFreeDataServiceManager.getServiceLocnfo(organizationId, customerId);
		} catch (Exception e) {
			LOG.error("@getServiceLocInfo: Exception processing getServiceLocInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return serviceLocations;
	}

	@RequestMapping(path = "/getCustAddress/{customerId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public AddressVO getCustAddress(@PathVariable String customerId) {
		if (StringUtils.isEmpty(customerId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getCustAddress: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		AddressVO addressVO = new AddressVO();
		try {
			addressVO = tollFreeDataServiceManager.getCustAddress(customerId);
		} catch (Exception e) {
			LOG.error("@getCustAddress: Exception processing getCustAddress", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return addressVO;

	}

	@RequestMapping(path = "/getCustContacts/{organizationId}/{customerid}/{category}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ContactsVO> getCustContacts(@PathVariable String organizationId, @PathVariable String customerid,
			@PathVariable String category) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerid) || StringUtils.isEmpty(category)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		List<ContactsVO> contactsList = null;
		try {
			contactsList = tollFreeDataServiceManager.getCustContacts(organizationId, customerid, category);
		} catch (Exception e) {
			LOG.error("@getCustContacts: Exception processing getCustContacts", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return contactsList;
	}

	@RequestMapping(path = "/getSalesRepDetails/{organizationId}/{customerid}/{category}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<ContactsVO> getSalesRepDetails(@PathVariable String organizationId, @PathVariable String customerid,
			@PathVariable String category) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerid) || StringUtils.isEmpty(category)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		List<ContactsVO> salesRepList = null;
		try {
			salesRepList = tollFreeDataServiceManager.getSalesRepDetails(organizationId, customerid, category);
		} catch (Exception e) {
			LOG.error("@getSalesRepDetails: Exception processing getSalesRepDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return salesRepList;
	}

	@RequestMapping(path = "/getIntraLataDetails/{customerid}/{organizationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public String getIntraLataDetails(@PathVariable String organizationId, @PathVariable String customerid) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerid)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		String intraLataList = null;
		try {
			intraLataList = tollFreeDataServiceManager.getIntraLataDetails(customerid, organizationId);
		} catch (Exception e) {
			LOG.error("@getIntraLataDetails: Exception processing getIntraLataDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return intraLataList;
	}

	@RequestMapping(path = "/getProductDiscPLan/{customerid}/{organizationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public ProductDiscPlanVo getProductDiscPLan(@PathVariable String customerid, @PathVariable String organizationId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerid)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		ProductDiscPlanVo productDisc = null;
		try {
			productDisc = tollFreeDataServiceManager.getProductDiscPLan(customerid, organizationId);
		} catch (Exception e) {
			LOG.error("@getProductDiscPLan: Exception processing getProductDiscPLan", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return productDisc;
	}

	@RequestMapping(path = "/getVolumeDiscPLan/{customerid}/{organizationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<VolumeDiscPlanVO> getVolumeDiscPLan(@PathVariable String customerid,
			@PathVariable String organizationId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerid)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		List<VolumeDiscPlanVO> volumeDisc = new ArrayList<VolumeDiscPlanVO>();
		try {
			volumeDisc = tollFreeDataServiceManager.getVolumeDiscPLan(customerid, organizationId);
		} catch (Exception e) {
			LOG.error("@getVolumeDiscPLan: Exception processing getVolumeDiscPLan", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return volumeDisc;
	}

	@RequestMapping(path = "/getCountryDetails/{countryid}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CountryDetailsVO getCountryDetails(@PathVariable String countryid) {
		if (StringUtils.isEmpty(countryid)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		CountryDetailsVO countryDetails = null;
		try {
			countryDetails = tollFreeDataServiceManager.getCountryDetails(countryid);
		} catch (Exception e) {
			LOG.error("@getCountryDetails: Exception processing getCountryDetails", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return countryDetails;
	}

	@RequestMapping(path = "/getCustAccInfo/{customerid}/{organizationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<BillingAccountNumberVO> getCustAccInfo(@PathVariable String customerid,
			@PathVariable String organizationId) {
		if (StringUtils.isEmpty(customerid) || StringUtils.isEmpty(organizationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("getCustAccInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		List<BillingAccountNumberVO> customers = null;
		try {
			customers = tollFreeDataServiceManager.getCustAccInfo(customerid, organizationId);
		} catch (Exception e) {
			LOG.error("@getCustAccInfo: Exception processing getCustAccInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return customers;
	}

/*	@RequestMapping(path = "/getProductOfferingInfo/{organizationId}/{productOfferingId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public CustomerVO getProductOfferingInfo(@PathVariable String organizationId,
			@PathVariable String productOfferingId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(productOfferingId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getProductOfferingInfo: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getProductOfferingInfo(organizationId, productOfferingId);
		} catch (Exception e) {
			LOG.error("@getProductOfferingInfo: Exception processing getProductOfferingInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}

		return customerVO;
	}*/
	@RequestMapping(path = "/getProductOffering", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin	
	public CustomerVO getProductOffering(@RequestBody List<Integer> prodOfferingIds) {			
		CustomerVO customerVO = null;
		try {
			customerVO = tollFreeDataServiceManager.getProductOffering(prodOfferingIds);
		} catch (Exception e) {
			LOG.error("@getProductOfferingInfo: Exception processing getProductOfferingInfo", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);
		}

		return customerVO;
	}

	/**
	 * This method is to retrieve default CIC associated to a customer id and
	 * service location id under an organization id
	 * 
	 * @param organizationId
	 * @param customerId
	 * @param serviceLocationId
	 * @return
	 */
	@RequestMapping(path = "/defaultCIC/{organizationId}/{customerId}/{serviceLocationId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public String getDefaultCIC(@PathVariable String organizationId, @PathVariable String customerId,
			@PathVariable String serviceLocationId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(customerId)
				|| StringUtils.isEmpty(serviceLocationId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getDefaultCIC: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		String defaultCIC = null;
		try {
			defaultCIC = tollFreeDataServiceManager.getDefaultCIC(organizationId, customerId, serviceLocationId);
		} catch (Exception e) {
			LOG.error("@getDefaultCIC: Exception processing getDefaultCIC", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return defaultCIC;
	}

	/**
	 * API method to retrieve customer info for organization id and customer id
	 * 
	 * @param organizationId
	 * @param custId
	 * @return Customer Info
	 */
	@RequestMapping(path = "/inhousebizorg/{organizationId}/{custId}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public String getInHouseBizOrg(@PathVariable String organizationId, @PathVariable String custId) {
		if (StringUtils.isEmpty(organizationId) || StringUtils.isEmpty(custId)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getInHouseBizOrg: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		String bizOrgId = null;
		try {
			bizOrgId = tollFreeDataServiceManager.getInHouseBizOrg(organizationId, custId);
		} catch (Exception e) {
			LOG.error("@getInHouseBizOrg: Exception processing getInHouseBizOrg", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
		return bizOrgId;
	}

	@RequestMapping(path = "/update/batchDrop/{fileName}/{customerId}", method = RequestMethod.POST, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public void completeBatchDropStatus(@PathVariable String fileName,@PathVariable String customerId) {
		if (StringUtils.isEmpty(fileName)	|| (StringUtils.isEmpty(customerId) )) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_MISSING_DATA;
			l3Response.setDetail("Invalid request. Please provide customerId");
			throw new ServiceException(l3Response);
		}
		if(tollFreeDataServiceManager.getBatchDropStatus(fileName,customerId) >0 ) {
			LOG.info("@completeBatchDropStatus Updating the Batch Drop status as Complete CustomerId:" + customerId + "File name : "+fileName);
			tollFreeDataServiceManager.completeBatchDropStatus(fileName,customerId);
		}
	}
	
	
	/**
	 * API method to identify if the customer associated to 
	 * BAN selected by the user is enabled with different BAN
	 * 
	 * @param organizationId
	 * @param custId
	 * @return Customer Info
	 */
	@RequestMapping(path = "/isdifferentban/{ban}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public String isDifferentBanEnabled(@PathVariable String ban) {
		if (StringUtils.isEmpty(ban)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@isDifferentBanEnabled: Invalid. Please have all the required fields");
			throw new ServiceException(l3Response);
		}
		try {
			return tollFreeDataServiceManager.isDifferentBanEnabled(ban);
		} catch (Exception e) {
			LOG.error("@isDifferentBanEnabled: Exception processing isDifferentBanEnabled", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
	}
	
	/**
	 * Method to get all BAN related to customer id and organization id and return
	 * filtered data
	 * 
	 * @param organizationId
	 * @param customerId
	 * @return array of objects where object is [Account ID,Account Name]
	 */
	@RequestMapping(path = "/customerbans/{ban}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@ResponseBody
	@Audited
	@CrossOrigin
	public List<String> getCustomerBans(@PathVariable String ban) {
		if (StringUtils.isEmpty(ban)) {
			Level3Response l3Response = Level3Response.BAD_REQUEST_400_INVALID_DATA;
			l3Response.setDetail("@getAllBan: Missing ban as input.");
			throw new ServiceException(l3Response);
		}
		try {
			return tollFreeDataServiceManager.getCustomerBans(ban);
		} catch (Exception e) {
			LOG.error("@getAllBan: Exception processing getAllBan", e);
			Level3Response l3Response = (e instanceof SLDBException) ? Level3Response.BAD_REQUEST_400_MISSING_DATA
					: Level3Response.INTERNAL_SERVER_ERROR_500;
			l3Response.setDetail(e.getMessage());
			throw new ServiceException(l3Response);

		}
	}
}
