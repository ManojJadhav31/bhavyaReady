package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class ServiceLocationVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String serviceLocationId;
	private String serviceLocationName;
	private String controlGroupId;
	
	public ServiceLocationVO() {
		
	}
	
	public ServiceLocationVO(String serviceLocationId, String serviceLocationName, String controlGroupId) {
		this.serviceLocationId = serviceLocationId;
		this.serviceLocationName = serviceLocationName;
		this.controlGroupId = controlGroupId;
	}
	
	public String getServiceLocationId() {
		return serviceLocationId;
	}
	public void setServiceLocationId(String serviceLocationId) {
		this.serviceLocationId = serviceLocationId;
	}
	public String getServiceLocationName() {
		return serviceLocationName;
	}
	public void setServiceLocationName(String serviceLocationName) {
		this.serviceLocationName = serviceLocationName;
	}
	public String getControlGroupId() {
		return controlGroupId;
	}
	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}
	
	
}
