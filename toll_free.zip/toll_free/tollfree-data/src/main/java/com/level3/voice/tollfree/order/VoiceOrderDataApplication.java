package com.level3.voice.tollfree.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.centurylink.microservice.springfox.EnableSwaggerDocumentation;
import com.level3.voice.tollfree.service.SwaggerDocumentationConfig;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableDiscoveryClient
@SpringBootApplication
@EnableSwagger2
@ComponentScan(basePackages = {"com.level3.voice.tollfree"})
@EnableSwaggerDocumentation(apiTitle="Staged Orders",
apiDescription="Mangement of Staged Orders")
@Import({SwaggerDocumentationConfig.class})
public class VoiceOrderDataApplication {

	/**
	 * Starts the service.
	 *
	 * @param args
	 *            not used.
	 */
	public static void main(String... args) {
		SpringApplication.run(VoiceOrderDataApplication.class, args);
	}

}
