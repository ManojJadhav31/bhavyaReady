package com.level3.voice.tollfree.vo;

import java.io.Serializable;

public class ValidationMessageVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String displayMessage;
	private String code;
	private String entityName;	
	
	public String getDisplayMessage() {
		return displayMessage;
	}
	public void setDisplayMessage(String displayMessage) {
		this.displayMessage = displayMessage;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
}
