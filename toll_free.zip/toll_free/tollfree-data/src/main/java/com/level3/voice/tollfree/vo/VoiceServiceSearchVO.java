package com.level3.voice.tollfree.vo;

import java.io.Serializable;
import java.util.List;

import com.level3.voice.tollfree.vo.VoiceServiceVO;

/**
 *  @author kumar.arun2
 *
 */
public class VoiceServiceSearchVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<VoiceServiceVO> voiceServices;
	
	private int pageNumber;
	private int pageSize;
	private int totalPageNumber;

	public List<VoiceServiceVO> getVoiceServices() {
		return  voiceServices;
	}	
	public void setVoiceServiceList(List<VoiceServiceVO> VoiceServiceList) {
		voiceServices = VoiceServiceList;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getTotalPageNumber() {
		return totalPageNumber;
	}
	public void setTotalPageNumber(int totalPageNumber) {
		this.totalPageNumber = totalPageNumber;
	}

	
	
}
