package com.level3.voice.tollfree.security;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.level3.voice.common.util.SecurityUtil;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.WebResource.Builder;

@Component
@Order(1)
public class TollFreeAuthenticationFilter extends OncePerRequestFilter {

	@Value("${tollfree.security.client.url}")
	private String baseUrl;

	@Value("${tollfree.isSecurityEnabled}")
	private String isSecurityEnabled;

	@Value("${tollfree.oneStop.application.key}")
	private String applicationKeyValue;

	@Value("${tollfree.oneStop.application.secret}")
	private String digestKeyValue;

	@Value("${sldb.3flow.application.key}")
	private String moabKey;
	
	private static final String MESSAGE_SOURCE = "3FLOW";
	private static final Logger LOGGER = Logger.getLogger(TollFreeAuthenticationFilter.class);

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		// Skip filtering if security is not enabled
		if ("NO".equals(isSecurityEnabled)) {
			filterChain.doFilter(request, response);
			return;
		}
		String path = ((HttpServletRequest) request).getRequestURI();

		String authToken = request.getHeader("Authorization");
		String referer = request.getHeader("Referer");
		String moabKeyReceived = request.getHeader("appKey");
		
		boolean valid = false;
		
		//mohab security
		if(StringUtils.isNotEmpty(moabKeyReceived)) {
			if(moabKey.equals(moabKeyReceived)) {
				filterChain.doFilter(request, response);
				return;
			}else {
				LOGGER.error("[authToken:" + authToken + "]\n is INVALID.");
				response.sendError(HttpServletResponse.SC_FORBIDDEN);
				return;
			}
		}
		
		//Onestop security and security for internal calls
		if (path.endsWith("/health") 
				|| (StringUtils.isNotEmpty(authToken) && "SVC_3FLOW".equals(authToken)) 
				|| (referer != null && StringUtils.isEmpty(authToken)
					&& (referer.startsWith("http://localhost:4200/")
						  || referer.startsWith("http://voicems-env1") || referer.startsWith("https://voicems-env1")
						  || referer.startsWith("http://voicems") || referer.startsWith("https://voicems") 
						  || !referer.startsWith("https://voicemsext")))) {
			filterChain.doFilter(request, response);
			return;
		} else {
			logHeaders(request);
			if (StringUtils.isNotEmpty(authToken) && isValid(authToken)) {
				valid = true;
			}
		}
		if (valid) {
			LOGGER.info("[authToken:" + authToken + "]\n is VALID.");
			filterChain.doFilter(request, response);
		} else {
			LOGGER.error("[authToken:" + authToken + "]\n is INVALID.");
			response.sendError(HttpServletResponse.SC_FORBIDDEN);
			return;
		}

	}

	private void logHeaders(HttpServletRequest request) {
		Enumeration<String> headerNames = request.getHeaderNames();
		LOGGER.info("Request URL:" + request.getRequestURL());
		if (headerNames != null) {
			while (headerNames.hasMoreElements()) {
				String key = headerNames.nextElement();
				LOGGER.debug(key + " : " + request.getHeader(key) + "\n");
			}
		}
	}

	private boolean isValid(String authToken) {
		boolean isValid = false;
		WebResource resource = getWRToValidate();
		Builder builder = null;
		try {
			builder = SecurityUtil.createSecurityHeader(resource, applicationKeyValue, digestKeyValue, MESSAGE_SOURCE);
			builder.header("Authorization", authToken);
		} catch (Exception e) {
			LOGGER.error("Unable to create security header for req with token " + authToken + " Error message: "
					+ e.getMessage(), e);
			e.printStackTrace();
		}
		if (builder != null) {
			ClientResponse response = builder.accept(MediaType.APPLICATION_JSON).get(ClientResponse.class);

			if (response.getStatus() == 200) {
				isValid = true;
			} else {
				String mRespBody = response.getEntity(String.class);
				LOGGER.error("Security Check Failed for Token :" + authToken + " Error message: " + mRespBody);
			}
		}

		return isValid;
	}

	private boolean isValid(String xAuth, String xL3Auth, String xL3Digest, String xL3DigestTime, String auth) {
		WebResource webResource = getWR();
		String serviceURL = "token/validate";

		WebResource.Builder builder = webResource.path(serviceURL).entity(null, MediaType.APPLICATION_JSON_TYPE)
				.accept(MediaType.APPLICATION_JSON_TYPE);

		builder.header("x-level3-application-key", xAuth);
		builder.header("x-level3-authorize", xL3Auth);
		builder.header("x-level3-digest", xL3Digest);
		builder.header("x-level3-digest-time", xL3DigestTime);
		builder.header("Authorization", auth);
		boolean isValid = false;
		try {
			ClientResponse response = builder.get(ClientResponse.class);
			if (response.getStatus() == 200) {
				isValid = true;
			}
		} catch (Exception e) {
			String errorInfo = e.getMessage() == null ? "" : ".  " + e.getMessage();
			LOGGER.error("Exception in security API call" + errorInfo, e);
			// throw new SecurityException();
		}

		return isValid;
	}

	private WebResource getWR() {
		Client client = Client.create();
		client.setReadTimeout(30000);
		client.setConnectTimeout(30000);
		return client.resource(this.baseUrl);
	}

	private WebResource getWRToValidate() {
		Client client = Client.create();
		client.setReadTimeout(30000);
		client.setConnectTimeout(30000);
		return client.resource(this.baseUrl + "/token/validate");
	}
}
