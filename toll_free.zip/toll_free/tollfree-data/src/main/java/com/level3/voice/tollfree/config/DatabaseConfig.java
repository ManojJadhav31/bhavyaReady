package com.level3.voice.tollfree.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;
/**
 * Database config to scan JPA repository and DTO  
 * 
 * @author <a href="mailto:Keerthi.Selvaraj@centurylink.com">Keerthi selvaraj
 *         </a>
 *
 */
@Configuration
@EnableJpaRepositories(basePackages= {"com.level3.voice.tollfree.persist.repository"})
@EnableTransactionManagement
@EntityScan(basePackages= {"com.level3.voice.tollfree.persist.dto"})
public class DatabaseConfig {

}
