package com.level3.voice.tollfree.vo;

import java.io.Serializable;

/**
 * This class is to hold the rateplanid and scid
 * information retrieve from sandstone
 * 
 * @author <a href="mailto:Tarun.Karthigai@centurylink.com">Tarun Karthigai</a>
 *
 */
public class OrderAdditionalDetailsVO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String ratePlanId;
	private String scid;
	private String accountNumber;

	public String getRatePlanId() {
		return ratePlanId;
	}

	public void setRatePlanId(String ratePlanId) {
		this.ratePlanId = ratePlanId;
	}

	public String getScid() {
		return scid;
	}

	public void setScid(String scid) {
		this.scid = scid;
	}
	
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
}
