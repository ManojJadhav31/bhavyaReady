package com.level3.voice.tollfree.vo;

/**
 * @author ab70351
 *
 */
public class ServiceLocationInformationVO {

	private String name;
	private String id;
	private String piId;
	private String status;
	private String type;
	private String controlGroupId;
	private String marketAreaId;
	private String payPhoneDeclarationCode;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPiId() {
		return piId;
	}
	public void setPiId(String piId) {
		this.piId = piId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getControlGroupId() {
		return controlGroupId;
	}
	public void setControlGroupId(String controlGroupId) {
		this.controlGroupId = controlGroupId;
	}
	public String getMarketAreaId() {
		return marketAreaId;
	}
	public void setMarketAreaId(String marketAreaId) {
		this.marketAreaId = marketAreaId;
	}
	public String getPayPhoneDeclarationCode() {
		return payPhoneDeclarationCode;
	}
	public void setPayPhoneDeclarationCode(String payPhoneDeclarationCode) {
		this.payPhoneDeclarationCode = payPhoneDeclarationCode;
	}
	
	
	
}
