package com.level3.voice.tollfree.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.level3.voice.common.rest.exception.ServiceException;
import com.level3.voice.common.rest.model.Level3Response;
import com.level3.voice.tollfree.manager.TollFreeDataServiceManager;
import com.level3.voice.tollfree.vo.CICVO;
import com.level3.voice.tollfree.vo.CodeTableVO;
import com.level3.voice.tollfree.vo.CustomerVO;
import com.level3.voice.tollfree.vo.OrderAdditionalDetailsVO;
import com.level3.voice.tollfree.vo.ProductVO;
import com.level3.voice.tollfree.vo.ServiceLocationVO;

/**
 * Mockito test cases for TollFree API calls
 * 
 * @author <a href="mailto:Keerthi.Selvaraj@centurylink.com">Keerthi
 *         selvaraj</a>
 *
 */
public class TollFreeDataServiceTest {
	public static Logger LOG = Logger.getLogger(TollFreeDataServiceTest.class);

	@Mock
	private TollFreeDataServiceManager tollFreeDataServiceManagerMock;
	@InjectMocks
	private TollFreeDataService tollFreeDataServiceMock;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testgetAccountInfo() throws Exception {
		List<CustomerVO> objs = new ArrayList<CustomerVO>();
		CustomerVO customerVO = new CustomerVO("000004401143", "Williams IT N & C (Voice)", "WCG", null);
		objs.add(customerVO);
		Mockito.when(tollFreeDataServiceManagerMock.getAllAccountInfo("WCG", "00001157")).thenReturn(objs);
		Assert.assertEquals(objs, tollFreeDataServiceMock.getAllAccountInfo("WCG", "00001157"));
	}

	@Test
	public void testAccountInfoInputEmpty() throws Exception {
		try {
			tollFreeDataServiceManagerMock.getAllAccountInfo("", "00001157");
		} catch (Exception e) {
			Assert.assertTrue("Exception is of instance Service Exception ", e instanceof ServiceException);
			if (e instanceof ServiceException) {
				Level3Response l3Response = ((ServiceException) e).getLevel3Response();
				Assert.assertEquals(Level3Response.BAD_REQUEST_400_INVALID_DATA.getHttpStatusCodeInt(),
						l3Response.getHttpStatusCodeInt());
				Assert.assertEquals("@testAccountInfoInputEmpty: Invalid. Please have all the required fields ",
						l3Response.getException().getDetail());
			}
		}
	}

	@Test
	public void testgetCustomerCIC() throws Exception {
		List<CICVO> objs = new ArrayList<CICVO>();
		CustomerVO customerVO = new CustomerVO();
		CICVO cicVO = new CICVO("5102", "1");
		objs.add(cicVO);
		customerVO.setCicVOs(objs);
		Mockito.when(tollFreeDataServiceManagerMock.getAllCustomerCIC("WCG", "00001157", "VWILLIAMS")).thenReturn(customerVO);
		Assert.assertEquals(customerVO, tollFreeDataServiceMock.getAllCustomerCIC("WCG", "00001157", "VWILLIAMS"));
	}

	@Test
	public void testgetCustomerCICInputEmpty() throws Exception {
		try {
			tollFreeDataServiceManagerMock.getAllCustomerCIC("", "00001157", "VWILLIAMS");
		} catch (Exception e) {
			Assert.assertTrue("Exception is of instance Service Exception ", e instanceof ServiceException);
			if (e instanceof ServiceException) {
				Level3Response l3Response = ((ServiceException) e).getLevel3Response();
				Assert.assertEquals(Level3Response.BAD_REQUEST_400_INVALID_DATA.getHttpStatusCodeInt(),
						l3Response.getHttpStatusCodeInt());
				Assert.assertEquals("@testgetCustomerCICInputEmpty: Invalid. Please have all the required fields ",
						l3Response.getException().getDetail());
			}
		}
	}

	@Test
	public void testgetServiceLocation() throws Exception {
		List<ServiceLocationVO> serviceLocationVOs = new ArrayList<ServiceLocationVO>();
		CustomerVO customerVO = new CustomerVO();
		ServiceLocationVO serviceLocationVO = new ServiceLocationVO("TELECOMUTR", "Williams IT N & C (Voice)", null);
		serviceLocationVOs.add(serviceLocationVO);
		customerVO.setServiceLocationVOs(serviceLocationVOs);
		Mockito.when(tollFreeDataServiceManagerMock.getAllServiceLocation("WCG", "00001157")).thenReturn(customerVO);
		Assert.assertEquals(customerVO, tollFreeDataServiceMock.getAllServiceLocation("WCG", "00001157"));
	}

	@Test
	public void testgetServiceLocationInputEmpty() throws Exception {
		try {
			tollFreeDataServiceManagerMock.getAllServiceLocation("WCG", "");
		} catch (Exception e) {
			Assert.assertTrue("Exception is of instance Service Exception ", e instanceof ServiceException);
			if (e instanceof ServiceException) {
				Level3Response l3Response = ((ServiceException) e).getLevel3Response();
				Assert.assertEquals(Level3Response.BAD_REQUEST_400_INVALID_DATA.getHttpStatusCodeInt(),
						l3Response.getHttpStatusCodeInt());
				Assert.assertEquals("@testgetServiceLocationInputEmpty: Invalid. Please have all the required fields ",
						l3Response.getException().getDetail());
			}
		}

	}


	@Test
	public void testgetProductInfo() throws Exception {
		List<ProductVO> productVOs = new ArrayList<ProductVO>();
		CustomerVO customerVO = new CustomerVO();
		ProductVO productVO = new ProductVO("270", "SWITCHED 1+");
		productVOs.add(productVO);
		customerVO.setProductVOs(productVOs);

		Mockito.when(tollFreeDataServiceMock.getAllProductInfo("ITWILL", "00000008", "VYVX500601", "1S"))
		.thenReturn(customerVO);
		Assert.assertEquals(customerVO, tollFreeDataServiceMock.getAllProductInfo("ITWILL", "00000008", "VYVX500601", "1S"));
	}

	@Test
	public void testgetProductInfoInputEmpty() throws Exception {
		try {
			tollFreeDataServiceManagerMock.getAllProductInfo("", "00000008", "VYVX500601", "1S");
		} catch (Exception e) {
			Assert.assertTrue("Exception is of instance Service Exception ", e instanceof ServiceException);
			if (e instanceof ServiceException) {
				Level3Response l3Response = ((ServiceException) e).getLevel3Response();
				Assert.assertEquals(Level3Response.BAD_REQUEST_400_INVALID_DATA.getHttpStatusCodeInt(),
						l3Response.getHttpStatusCodeInt());
				Assert.assertEquals("@testgetServiceLocationInputEmpty: Invalid. Please have all the required fields ",
						l3Response.getException().getDetail());
			}
		}
	}

	@Test
	public void testgetTableCode() throws Exception{

		List<CodeTableVO> codeTableVOs = new ArrayList<CodeTableVO>();
		CustomerVO customerVO = new CustomerVO();
		CodeTableVO codeTableVO = new CodeTableVO("16905", "12345678","04");
		codeTableVOs.add(codeTableVO);
		customerVO.setCodeTableVOs(codeTableVOs);

		Mockito.when(tollFreeDataServiceManagerMock.getAllCodeTable("WCG", "00001157"))
		.thenReturn(customerVO);
		Assert.assertEquals(customerVO, tollFreeDataServiceMock.getAllCodeTable("WCG", "00001157"));
	}

	@Test
	public void testgetTableCodeInputEmpty() throws Exception{
		try {
			tollFreeDataServiceManagerMock.getAllCodeTable("WCG", "");
		}catch(Exception e) {
			Assert.assertTrue("Exception is of instance Service Exception ", e instanceof ServiceException);
			if(e instanceof ServiceException) {
				Level3Response l3Response = ((ServiceException)e).getLevel3Response();
				Assert.assertEquals(Level3Response.BAD_REQUEST_400_INVALID_DATA.getHttpStatusCodeInt(), 
						l3Response.getHttpStatusCodeInt());
				Assert.assertEquals("@testgetTableCodeInputEmpty: Invalid. Please have all the required fields ", 
						l3Response.getException().getDetail());
			}
		}
	}

	@Test
	public void testgetRatePlan() throws Exception{
		OrderAdditionalDetailsVO orderAdditionalDetailsVO = new OrderAdditionalDetailsVO();
		orderAdditionalDetailsVO.setRatePlanId("55");
		
		Mockito.when(tollFreeDataServiceManagerMock.getOrderAdditionalDetails("445","ITWILL","A", "000005023666", "P5023666"))
		.thenReturn(orderAdditionalDetailsVO);
		Assert.assertEquals(orderAdditionalDetailsVO, tollFreeDataServiceMock.getOrderAdditionalDetails("445","ITWILL","A", "000005023666", "P5023666"));
	}

	@Test
	public void testgetRatePlanInputEmpty() throws Exception{
		try {
			tollFreeDataServiceManagerMock.getOrderAdditionalDetails("","ITWILL","A", "000005023666", "P5023666");
		}catch(Exception e) {
			Assert.assertTrue("Exception is of instance Service Exception ", e instanceof ServiceException);
			if(e instanceof ServiceException) {
				Level3Response l3Response = ((ServiceException)e).getLevel3Response();
				Assert.assertEquals(Level3Response.BAD_REQUEST_400_INVALID_DATA.getHttpStatusCodeInt(), 
						l3Response.getHttpStatusCodeInt());
				Assert.assertEquals("@testgetRatePlanInputEmpty: Invalid. Please have all the required fields ", 
						l3Response.getException().getDetail());
			}
		}
	}
}
